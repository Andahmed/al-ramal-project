
/* SOLKGEAR — مجسمات KayKit الحقيقية للمعدات (سيوف/فؤوس/دروع/خوذ/عباءات) من ملفات GLB الأصلية.
   عرض ثلاثي الأبعاد حيّ داخل خانات الحقيبة + مصدر المجسمات لتركيبها على الشخصية. */
(function(){
  "use strict";
  if(window.SOLKGEAR)return;
  var D=window.__KGEAR_DATA||{},DEC={},S={ok:Object.keys(D).length>0,ids:Object.keys(D)};
  window.SOLKGEAR=S;
  function b64(s){var r=atob(s),u=new Uint8Array(r.length);for(var i=0;i<r.length;i++)u[i]=r.charCodeAt(i);return u}
  S.dec=function(id){
    if(DEC[id])return DEC[id];var d=D[id];if(!d)return null;
    var u=b64(d.b),bf=u.buffer;
    return DEC[id]={v:new Float32Array(bf,0,d.v*6),i:new Uint16Array(bf,d.v*24,d.i),bb:d.bb,n:d.i};
  };
  /* ===== اختيار المجسم حسب الخانة + الندرة + دور البطل (يطابق weaponFor) ===== */
  function T(t,a){t=Math.max(1,Math.min(7,t|0||1));return a[Math.min(a.length-1,Math.floor((t-1)*a.length/7))]}
  S.pick=function(slot,tier,role,ranged){
    var r=ranged?"ranged":(role||"dps");
    if(slot==="weapon"){
      if(r==="ranged")return T(tier,["crossbow_1handed","crossbow_1handed","crossbow_1handed","crossbow_2handed","crossbow_2handed","crossbow_2handed","crossbow_2handed"]);
      if(r==="tank")return T(tier,["sword_1handed","sword_1handed","sword_1handed","sword_1handed","sword_2handed","sword_2handed","sword_2handed_color"]);
      if(r==="support")return "staff";
      if(r==="control")return tier>=5?"staff":"wand";
      return T(tier,["dagger","dagger","dagger","axe_1handed","axe_1handed","axe_2handed","axe_2handed"]);
    }
    if(slot==="weapon2"){
      if(r==="ranged")return "quiver";
      if(r==="tank")return "crossbow_1handed";
      if(r==="support")return "spellbook_closed";
      if(r==="control")return "spellbook_open";
      return "dagger";
    }
    if(slot==="armor")return T(tier,["shield_badge","shield_round","shield_square","shield_spikes","shield_round_barbarian","shield_square_color","shield_spikes_color"]);
    if(slot==="helmet"){
      if(r==="support"||r==="control")return tier>=5?"hat_skel_mage":"hat_mage";
      if(r==="tank")return tier>=5?"helm_skel_warrior":"helm_knight";
      return tier>=5?"hood_skel_rogue":"hat_barbarian";
    }
    if(slot==="wing"||slot==="cloak")return T(tier,["cape_rogue","cape_mage","cape_barbarian","cape_knight","cape_skel_rogue","cape_knight","cape_skel_rogue"]);
    return null;
  };
  /* ===== رسم حيّ: سياق WebGL واحد مشترك يُنسخ إلى كانفاس كل خانة ===== */
  var VS="attribute vec3 p;attribute vec3 c;uniform mat4 m;varying vec3 vc;void main(){vc=c;gl_Position=m*vec4(p,1.0);}";
  var FS="precision mediump float;varying vec3 vc;void main(){gl_FragColor=vec4(vc,1.0);}";
  var GLC,gl,prog,loc,BUF={},started=false,dead=false;
  function initGL(){
    if(gl||dead)return !!gl;
    try{
      GLC=document.createElement("canvas");GLC.width=GLC.height=160;
      gl=GLC.getContext("webgl",{alpha:true,premultipliedAlpha:true,antialias:true})||GLC.getContext("experimental-webgl");
      if(!gl){dead=true;return false}
      function sh(t,s){var o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);return o}
      prog=gl.createProgram();gl.attachShader(prog,sh(gl.VERTEX_SHADER,VS));gl.attachShader(prog,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(prog);
      if(!gl.getProgramParameter(prog,gl.LINK_STATUS)){dead=true;gl=null;return false}
      loc={p:gl.getAttribLocation(prog,"p"),c:gl.getAttribLocation(prog,"c"),m:gl.getUniformLocation(prog,"m")};
      gl.enable(gl.DEPTH_TEST);
      return true;
    }catch(e){dead=true;gl=null;return false}
  }
  function buf(id){
    if(BUF[id])return BUF[id];var d=S.dec(id);if(!d)return null;
    var vb=gl.createBuffer(),ib=gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,d.v,gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,d.i,gl.STATIC_DRAW);
    return BUF[id]={vb:vb,ib:ib,n:d.n,bb:d.bb};
  }
  /* زاوية العرض الافتراضية لكل نوع (ميل حتى يظهر المجسم كاملًا داخل الخانة) */
  function view(id){
    if(/^(sword|dagger|axe|staff|wand)/.test(id))return {roll:-0.62,pitch:0.28};
    if(/^crossbow/.test(id))return {roll:0,pitch:0.85};
    if(/^quiver/.test(id))return {roll:-0.25,pitch:0.2};
    if(/^spellbook/.test(id))return {roll:0,pitch:0.75};
    if(/^cape/.test(id))return {roll:0,pitch:0.15};
    return {roll:0,pitch:0.18};
  }
  function mat(id,b,ang,drag){
    var bb=b.bb,cx=(bb[0]+bb[3])/2,cy=(bb[1]+bb[4])/2,cz=(bb[2]+bb[5])/2;
    var dx=bb[3]-bb[0],dy=bb[4]-bb[1],dz=bb[5]-bb[2],R=Math.sqrt(dx*dx+dy*dy+dz*dz)/2*1.02;
    var v=view(id),yaw=ang,pt=v.pitch+(drag?drag.p:0),rl=v.roll;
    var cyw=Math.cos(yaw),syw=Math.sin(yaw),cp=Math.cos(pt),sp=Math.sin(pt),cr=Math.cos(rl),sr=Math.sin(rl);
    /* M = Ortho * Rx(pitch) * Ry(yaw) * Rz(roll) * T(-center) */
    function mul(a,b2){var o=new Float32Array(16);for(var r=0;r<4;r++)for(var c=0;c<4;c++){var s=0;for(var k=0;k<4;k++)s+=a[k*4+r]*b2[c*4+k];o[c*4+r]=s}return o}
    var T0=new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,-cx,-cy,-cz,1]);
    var Rz=new Float32Array([cr,sr,0,0,-sr,cr,0,0,0,0,1,0,0,0,0,1]);
    var Ry=new Float32Array([cyw,0,-syw,0,0,1,0,0,syw,0,cyw,0,0,0,0,1]);
    var Rx=new Float32Array([1,0,0,0,0,cp,sp,0,0,-sp,cp,0,0,0,0,1]);
    var O=new Float32Array([1/R,0,0,0,0,1/R,0,0,0,0,-1/R,0,0,0,0,1]);
    return mul(O,mul(Rx,mul(Ry,mul(Rz,T0))));
  }
  function drawTo(cv,id,ang){
    var b=buf(id);if(!b)return;
    var w=cv.width,h=cv.height;if(GLC.width<w||GLC.height<h){GLC.width=Math.max(GLC.width,w);GLC.height=Math.max(GLC.height,h)}
    gl.viewport(0,0,w,h);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    gl.useProgram(prog);
    gl.bindBuffer(gl.ARRAY_BUFFER,b.vb);gl.enableVertexAttribArray(loc.p);gl.vertexAttribPointer(loc.p,3,gl.FLOAT,false,24,0);
    gl.enableVertexAttribArray(loc.c);gl.vertexAttribPointer(loc.c,3,gl.FLOAT,false,24,12);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,b.ib);
    gl.uniformMatrix4fv(loc.m,false,mat(id,b,ang,cv.__kgDrag));
    gl.drawElements(gl.TRIANGLES,b.n,gl.UNSIGNED_SHORT,0);
    var cx=cv.getContext("2d");cx.clearRect(0,0,w,h);cx.drawImage(GLC,0,GLC.height-h,w,h,0,0,w,h);
  }
  var last=0;
  function loop(ts){
    requestAnimationFrame(loop);
    if(document.hidden||ts-last<33)return;last=ts;
    var list=document.querySelectorAll("canvas[data-kg]");
    if(!list.length)return;
    if(!initGL())return;
    var vh=window.innerHeight;
    for(var i=0;i<list.length;i++){
      var cv=list[i];if(!cv.offsetParent)continue;if(cv.hasAttribute("data-kgdrag")&&!cv.__kgD){cv.__kgD=1;S.enableDrag(cv)}
      var r=cv.getBoundingClientRect();if(r.bottom<0||r.top>vh)continue;
      var id=cv.getAttribute("data-kg"),seed=cv.__kgSeed||(cv.__kgSeed=(i*0.7)%6.28);
      var ang=cv.__kgDrag?cv.__kgDrag.y:(ts/1000*0.9+seed);
      try{drawTo(cv,id,ang)}catch(e){}
    }
  }
  /* سحب بالإصبع/الفأرة لتدوير المجسم يدويًا (اللمس الطويل على الخانة الكبيرة) */
  S.enableDrag=function(cv){
    var down=false,x0=0,y0=0,d0={y:0,p:0};
    cv.addEventListener("pointerdown",function(e){down=true;x0=e.clientX;y0=e.clientY;d0=cv.__kgDrag||{y:(performance.now()/1000*0.9),p:0};try{cv.setPointerCapture(e.pointerId)}catch(_){}});
    cv.addEventListener("pointermove",function(e){if(!down)return;cv.__kgDrag={y:d0.y+(e.clientX-x0)*0.02,p:Math.max(-0.6,Math.min(0.9,d0.p+(e.clientY-y0)*0.01))}});
    cv.addEventListener("pointerup",function(){down=false;setTimeout(function(){cv.__kgDrag=null},1800)});
  };
  /* HTML لخانة: كانفاس حيّ (يرجع null إن لم يتوفر مجسم أو WebGL) */
  S.thumbHTML=function(slot,tier,size,role,ranged,drag){
    if(!S.ok||dead)return null;
    var id=S.pick(slot,tier,role,ranged);if(!id||!D[id])return null;
    var px=Math.round(size*Math.min(2,window.devicePixelRatio||1));
    return '<canvas data-kg="'+id+'" width="'+px+'" height="'+px+'" '+(drag?' data-kgdrag="1"':'')+' style="width:'+size+'px;height:'+size+'px;'+(drag?'touch-action:none;cursor:grab;':'pointer-events:none;')+'filter:drop-shadow(0 2px 3px #000)"></canvas>';
  };
  /* مجسم جاهز للرسم داخل محرك المعركة: يُرفع إلى سياق GL المعطى بنفس تنسيق uploadG */
  S.upload=function(gl2,id,scale,ox,oy,oz,ry){
    var d=S.dec(id);if(!d)return null;
    var n=d.v.length/6,v=new Float32Array(d.v.length),cs=Math.cos(ry||0),sn=Math.sin(ry||0);
    for(var k=0;k<n;k++){
      var x=d.v[k*6]*scale,y=d.v[k*6+1]*scale,z=d.v[k*6+2]*scale;
      v[k*6]=x*cs+z*sn+(ox||0);v[k*6+1]=y+(oy||0);v[k*6+2]=-x*sn+z*cs+(oz||0);
      v[k*6+3]=d.v[k*6+3];v[k*6+4]=d.v[k*6+4];v[k*6+5]=d.v[k*6+5];
    }
    var vb=gl2.createBuffer(),ib=gl2.createBuffer();
    gl2.bindBuffer(gl2.ARRAY_BUFFER,vb);gl2.bufferData(gl2.ARRAY_BUFFER,v,gl2.STATIC_DRAW);
    gl2.bindBuffer(gl2.ELEMENT_ARRAY_BUFFER,ib);gl2.bufferData(gl2.ELEMENT_ARRAY_BUFFER,d.i,gl2.STATIC_DRAW);
    return {vb:vb,ib:ib,n:d.n};
  };
  requestAnimationFrame(loop);
})();

