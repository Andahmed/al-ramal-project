
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push({"otherChunks":["static/chunks/0xa--a0onjdk5.js","static/chunks/3o0hrk7rbnbfq.js","static/chunks/0ohb6jwfe1-fr.js"],"runtimeModuleIds":[94553]});
