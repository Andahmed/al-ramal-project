
/* ============================================================
   SOLBTX — طبقة أسلوب القتال «Mini Tales» لأساطير الرمال
   تُركَّب فوق مشهد SOL3D وتقرأ أحداث المعركة نفسها (EV/BT/LY/u)
   فتضيف بدون أي تعديل على منطق اللعبة:
   1) شريط ترتيب الأدوار القادمة (حسب سرعة الوحدات وأحداث المحرك)
   2) واجهة مهارات أسفل الشاشة: بطاقات الأبطال + حلقة طاقة + توهج الجاهزية
      والنقر على بطل جاهز يركّز الكاميرا عليه ويطلق حلقة احتفالية
   3) عدّاد كومبو تصاعدي لضربات الفريق المتتالية
   4) سجل قتال مباشر قابل للفتح (زر 📜)
   5) لقطة اقتحام للمهارة النهائية: لافتة بلون الفصيلة + تركيز كاميرا + حلقة
   6) تقييم نجوم بعد النصر + ملخص إحصاءات موسع في شاشة النتيجة
   7) ترتيب الصفوف (أمامي/خلفي) باللمس داخل شاشة الاستعداد + إعادة خوض فورية للمعركة
   8) رقاقة تشخيص للمطور عند فتح اللعبة بـ ?debug=1
   كل الواجهة DOM خفيف: تحديث بالتغيير فقط، بلا حلقات رسم إضافية،
   وبلا اهتزاز شاشة أو إضاءات — آمنة على أضعف الهواتف.
   ============================================================ */
(function () {
  "use strict";
  if (window.SOLBTX) return;

  var FA = {
    guardians: { name: "حرّاس المدن", color: "#c46a3a" },
    plains:    { name: "أهل السهول", color: "#8aa848" },
    oasis:     { name: "أهل الواحات", color: "#2fb8a6" },
    shadow:    { name: "بني الظل", color: "#7b68b5" },
    light:     { name: "النور", color: "#e8c76a" },
    abyss:     { name: "الهاوية", color: "#b34a68" }
  };
  var GLYPH = { tank: "🛡", dps: "⚔", support: "⚜", control: "✨", ranger: "🏹" };
  function glyph(role) { return GLYPH[role] || "🏹"; }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function fmt(n) {
    n = Math.round(n || 0);
    if (n >= 1e6) return (n / 1e6).toFixed(1) + "م";
    if (n >= 1e4) return (n / 1e3).toFixed(1) + "ألف";
    return n.toLocaleString("en-US");
  }
  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html !== undefined) e.innerHTML = html;
    return e;
  }

  /* ============ حالة المعركة الحالية ============ */
  var C = null; /* سياق المعركة */
  function newCtx(api) {
    return {
      api: api, ov: null, ready: false,
      names: {}, factions: {}, roles: {}, sides: {},
      ev: [], ei: 0, evIds: null,
      bt0: 0, btWall: performance.now(),
      turnSig: "", skillChips: {}, energySig: {},
      combo: 0, comboMax: 0, lastTeamT: -999,
      log: [], logDirty: false, logOpen: false,
      stats: { crits: 0, skills: 0, ults: 0, topHit: 0, dmg: 0 },
      cutinT: 0, ended: false, resultDone: false,
      dbg: /(?:\?|&)debug=1/.test(location.search),
      fpsN: 0, fps: 0, fpsT: performance.now()
    };
  }

  /* ============ بناء الطبقة ============ */
  function build(C) {
    var host = C.api.root && C.api.root.parentElement;
    if (!host) return;
    var old = host.querySelector(":scope > .btx-overlay");
    if (old) old.remove();
    var ov = el("div", "btx-overlay");
    ov.innerHTML = "";

    /* شريط ترتيب الأدوار */
    C.turnRow = el("div", "btx-turn");
    ov.appendChild(C.turnRow);

    /* عدّاد الكومبو */
    C.comboEl = el("div", "btx-combo");
    ov.appendChild(C.comboEl);

    /* لقطة الاقتحام للنهائية */
    C.cutin = el("div", "btx-cutin");
    C.cutinName = el("b");
    C.cutinSkill = el("span");
    C.cutin.appendChild(C.cutinName);
    C.cutin.appendChild(C.cutinSkill);
    ov.appendChild(C.cutin);

    /* واجهة المهارات أسفل الشاشة */
    C.skillBar = el("div", "btx-skills");
    ov.appendChild(C.skillBar);

    /* زر السجل + لوحة السجل */
    C.logBtn = el("button", "btx-logbtn", "📜");
    C.logBtn.type = "button";
    C.logBtn.addEventListener("click", function () {
      C.logOpen = !C.logOpen;
      C.logBtn.classList.toggle("on", C.logOpen);
      C.logPanel.classList.toggle("on", C.logOpen);
      C.logDirty = true;
    });
    ov.appendChild(C.logBtn);
    C.logPanel = el("div", "btx-log");
    ov.appendChild(C.logPanel);

    /* توست مصغّر خاص بالطبقة */
    C.toast = el("div", "btx-toast");
    ov.appendChild(C.toast);
    C.toastT = 0;

    /* رقاقة التشخيص */
    if (C.dbg) {
      C.dbgEl = el("div", "btx-dbg", "…");
      ov.appendChild(C.dbgEl);
    }

    host.appendChild(ov);
    C.ov = ov;
    C.ready = true;
  }

  function showToast(C, msg) {
    if (!C || !C.toast) return;
    C.toast.textContent = msg;
    C.toast.classList.add("on");
    clearTimeout(C.toastT);
    C.toastT = setTimeout(function () { C.toast.classList.remove("on"); }, 1900);
  }

  /* ============ الملصقات: أبطال شريط المهارات ============ */
  function buildSkillBar(C, p) {
    var d = p.d || [];
    C.skillBar.innerHTML = "";
    C.skillChips = {};
    for (var i = 0; i < d.length && i < 5; i++) {
      var u = d[i];
      var f = FA[u.faction] || FA.guardians;
      var role = (p.LY && p.LY[u.uid] && p.LY[u.uid].role) || u.role || "ranger";
      var chip = el("button", "btx-schip");
      chip.type = "button";
      chip.style.setProperty("--fc", f.color);
      var ring = el("span", "btx-sring");
      var face = el("span", "btx-sface", glyph(role));
      var nm = el("span", "btx-sname", esc(u.name));
      var star = el("span", "btx-sult", "★");
      chip.appendChild(ring);
      chip.appendChild(face);
      chip.appendChild(star);
      chip.appendChild(nm);
      chip.addEventListener("click", makeSkillTap(C, u.uid, u.name, role));
      C.skillBar.appendChild(chip);
      C.skillChips[u.uid] = { chip: chip, ring: ring, lastE: -1, lastRdy: null };
    }
  }
  function findUltName(C, uid) {
    for (var i = 0; i < C.ev.length; i++) {
      var e = C.ev[i];
      if (e.source === uid && e.kind === "ultimate" && e.skillName) return e.skillName;
    }
    return "المهارة النهائية";
  }
  function makeSkillTap(C, uid, name, role) {
    return function () {
      var s = lastU && lastU[uid];
      if (s && s.energy >= 100) {
        C.api.focus(uid, 1.05);
        var f = FA[C.factions[uid]] || FA.guardians;
        C.api.ringAt(uid, f.color, 2.3);
        showToast(C, "⚡ " + name + " — " + findUltName(C, uid));
      } else {
        showToast(C, name + ": الطاقة " + (s ? Math.floor(s.energy) : 0) + "% — نهائية " + glyph(role));
      }
    };
  }

  /* ============ شريط الأدوار القادمة ============ */
  function updateTurn(C, p, now) {
    var chips = [], n = 0;
    for (var i = C.ei; i < C.ev.length && n < 8; i++) {
      var e = C.ev[i];
      if (e.t <= now) continue;
      if (e.kind !== "basic" && e.kind !== "skill" && e.kind !== "ultimate") continue;
      var uid = e.source;
      if (C.names[uid] === undefined) continue;
      chips.push({ uid: uid, t: e.t, k: e.kind });
      n++;
    }
    var bucket = Math.floor((chips.length ? chips[0].t - now : 9) * 5);
    var sig = chips.map(function (c) { return c.uid + (c.k === "ultimate" ? "★" : c.k === "skill" ? "✦" : ""); }).join("|") + "#" + bucket;
    if (sig === C.turnSig) return;
    C.turnSig = sig;
    var h = '<i>الأدوار القادمة</i>';
    for (var j = 0; j < chips.length; j++) {
      var c = chips[j];
      var f = FA[C.factions[c.uid]] || FA.guardians;
      var cls = "btx-tchip" + (C.sides[c.uid] === 1 ? " en" : "") + (c.k === "ultimate" ? " ult" : c.k === "skill" ? " sk" : "");
      h += '<span class="' + cls + '" style="--fc:' + f.color + '" title="' + esc(C.names[c.uid]) + '">' +
        glyph(C.roles[c.uid]) + (j === 0 ? '<b>' + Math.max(0, c.t - now).toFixed(1) + '</b>' : "") + "</span>";
    }
    if (!chips.length) h += '<span class="btx-tend">النهاية</span>';
    C.turnRow.innerHTML = h;
  }

  /* ============ الكومبو ============ */
  function updateCombo(C) {
    var show = C.combo >= 2;
    C.comboEl.classList.toggle("on", show && !C.ended);
    if (!show) return;
    if (C.comboEl._v !== C.combo) {
      C.comboEl._v = C.combo;
      C.comboEl.innerHTML = "كومبو <b>×" + C.combo + "</b>";
      C.comboEl.classList.remove("pop");
      void C.comboEl.offsetWidth;
      C.comboEl.classList.add("pop");
      C.comboEl.classList.toggle("hot", C.combo >= 5);
      C.comboEl.classList.toggle("fire", C.combo >= 9);
    }
  }

  /* ============ السجل ============ */
  function pushLog(C, e) {
    var who = C.names[e.source] || "؟";
    var f = FA[C.factions[e.source]];
    var icon = e.kind === "ultimate" ? "★" : e.kind === "skill" ? "✦" : e.kind === "basic" ? "⚔" : e.kind === "death" ? "💀" : e.kind === "end" ? "🏁" : "•";
    var line = "<i>" + Math.max(0, e.t).toFixed(1) + "ث</i> <b style=\"color:" + (f ? f.color : "#e8c76a") + "\">" + esc(who) + "</b> " + icon;
    if (e.skillName) line += " " + esc(e.skillName);
    if (e.kind === "basic" && e.source !== undefined) line += " هجوم";
    if (e.targets && e.targets.length) {
      var tn = C.names[e.targets[0]] || "";
      line += " <s>→ " + esc(tn) + (e.targets.length > 1 ? " +" + (e.targets.length - 1) : "") + "</s>";
    }
    if (e.value !== undefined && e.kind !== "death" && e.kind !== "end") {
      line += " <em" + (e.effect === "heal" ? " class=\"hp\"" : "") + ">" + (e.effect === "heal" ? "+" : "") + fmt(e.value) + (e.crit ? " ⚡" : "") + "</em>";
    }
    C.log.push("<div>" + line + "</div>");
    if (C.log.length > 80) C.log.shift();
    C.logDirty = true;
    if (C.logPanel && C.logOpen) renderLog(C);
  }
  function renderLog(C) {
    if (!C.logDirty) return;
    C.logDirty = false;
    C.logPanel.innerHTML = "<b>📜 سجل المعركة</b>" + (C.log.length ? C.log.slice().reverse().join("") : "<span class='btx-logempty'>لا أحداث بعد…</span>");
  }

  /* ============ اللقطة الاقتحام للنهائية ============ */
  function cutIn(C, e) {
    var f = FA[C.factions[e.source]] || FA.guardians;
    C.cutinName.textContent = (C.sides[e.source] === 1 ? "☠ " : "") + (C.names[e.source] || "؟");
    C.cutinSkill.textContent = "★ " + (e.skillName || "المهارة النهائية") + (e.targets && e.targets.length > 1 ? " — جماعية!" : "");
    C.cutin.style.setProperty("--fc", f.color);
    C.cutin.classList.remove("on");
    void C.cutin.offsetWidth;
    C.cutin.classList.add("on");
    clearTimeout(C.cutinT);
    C.cutinT = setTimeout(function () { C.cutin.classList.remove("on"); }, 1150 / Math.min(2, Math.max(1, C.api.speed())));
    /* تركيز كاميرا + حلقة احتفالية عند المنفّذ */
    C.api.focus(e.source, 1.15, e.targets && e.targets[0]);
    C.api.ringAt(e.source, C.sides[e.source] === 1 ? "#ff5a4a" : f.color, C.sides[e.source] === 1 ? 1.8 : 2.4);
  }

  /* ============ استهلاك الأحداث ============ */
  function consume(C, p, now) {
    while (C.ei < C.ev.length && C.ev[C.ei].t <= now) {
      var e = C.ev[C.ei++];
      var srcSide = C.sides[e.source];
      var offensive = e.kind === "basic" || e.kind === "skill" || e.kind === "ultimate";
      if (offensive && srcSide === 0) {
        C.combo++;
        if (C.combo > C.comboMax) C.comboMax = C.combo;
        C.lastTeamT = e.t;
        if (e.crit) C.stats.crits++;
        if (e.kind === "skill") { C.stats.skills++; try { C.api.focus(e.source, 0.85, e.targets && e.targets[0]); C.api.ringAt(e.source, (FA[C.factions[e.source]] || FA.guardians).color, 1.7); } catch (e1) {} }
        else if (e.kind === "basic" && e.crit) { try { C.api.focus(e.source, 0.6, e.targets && e.targets[0]); } catch (e2) {} }
        if (e.kind === "ultimate") { C.stats.ults++; cutIn(C, e); }
        if (e.value !== undefined && e.effect !== "heal") {
          C.stats.dmg += e.value;
          if (e.value > C.stats.topHit) C.stats.topHit = e.value;
        }
      } else if (offensive && srcSide === 1) {
        if (C.combo > 0) { C.combo = 0; }
      }
      if (e.kind === "death") { C.combo = 0; }
      if (e.kind === "ultimate" && srcSide !== 0) { /* نهائية عدو تُسجَّل فقط */ }
      if (e.kind !== "end") pushLog(C, e);
      if (e.kind === "end") { C.ended = true; onEnd(C, p, e); }
    }
    if (C.combo > 0 && now - C.lastTeamT > 26) C.combo = 0; /* مهلة انقطاع */
    updateCombo(C);
  }

  /* ============ النجوم والملخص في شاشة النتيجة ============ */
  function onEnd(C, p, e) {
    C.turnRow.classList.add("btx-over");
    C.skillBar.classList.add("btx-over");
    C.comboEl.classList.remove("on");
    if (C.resultDone) return;
    C.resultDone = true;
    var tries = 0;
    var iv = setInterval(function () {
      tries++;
      if (tries > 12 || !C.ov || !C.ov.isConnected) { clearInterval(iv); return; }
      var sheets = document.querySelectorAll("div.rounded-2xl");
      var sheet = null;
      for (var i = 0; i < sheets.length; i++) {
        if ((sheets[i].textContent || "").indexOf("مدة المعركة") >= 0) { sheet = sheets[i]; break; }
      }
      if (!sheet) return;
      clearInterval(iv);
      insertResult(C, p, sheet);
    }, 260);
  }
  function insertResult(C, p, sheet) {
    if (sheet.querySelector(".btx-result")) return;
    var txt = sheet.textContent || "";
    var win = txt.indexOf("نصرٌ حاسم") >= 0 || txt.indexOf("🏆") >= 0;
    var team = p.d || [];
    var surv = 0;
    for (var i = 0; i < team.length; i++) {
      var s = p.u && p.u[team[i].uid];
      if (!s || s.alive !== false) surv++;
    }
    var stars = win ? (surv === team.length ? 3 : surv >= Math.max(2, team.length - 1) ? 2 : 1) : 0;
    var label = stars === 3 ? "نصرة ساحقة!" : stars === 2 ? "نصر واضح" : stars === 1 ? "نصر بالكاد" : "حظ أوفر بالجولة القادمة";
    var st = C.stats;
    var h = '<div class="btx-result">' +
      '<div class="btx-stars">' + "★★★★★".slice(0, stars) + '<u>' + "★★★★★".slice(stars) + '</u></div>' +
      '<div class="btx-starlbl">' + label + '</div>' +
      '<div class="btx-statgrid">' +
      '<span>⏱ المدة<b>' + (p.TD || 0).toFixed(1) + 'ث</b></span>' +
      '<span>🫀 الناجون<b>' + surv + '/' + team.length + '</b></span>' +
      '<span>💥 أعلى ضربة<b>' + fmt(st.topHit) + '</b></span>' +
      '<span>⚡ حرجة<b>' + st.crits + '</b></span>' +
      '<span>✦ مهارات<b>' + st.skills + '</b></span>' +
      '<span>★ نهائيات<b>' + st.ults + '</b></span>' +
      '<span>🔥 أقصى كومبو<b>×' + C.comboMax + '</b></span>' +
      '<span>🩸 ضرر الفريق<b>' + fmt(st.dmg) + '</b></span>' +
      '</div></div>';
    var anchor = sheet.querySelector(".panel");
    if (anchor && anchor.parentElement) anchor.parentElement.insertBefore(el("div", "", h), anchor);
    else sheet.insertAdjacentHTML("afterbegin", h);
  }

  /* ============ ترتيب الصفوف في شاشة الاستعداد (أمامي/خلفي) ============ */
  function prepEditor(C, p) {
    setTimeout(function () {
      if (!C.ov || !C.ov.isConnected) return;
      if (String(p.TT || "").indexOf("إعادة") >= 0) return; /* إعادة مشاهدة بلا محرر */
      var d = p.d || [];
      if (!d.length) return;
      var host = null;
      var cands = document.querySelectorAll("div");
      for (var i = 0; i < cands.length; i++) {
        var tx = cands[i].textContent || "";
        if (tx.indexOf("استعداد المعركة") >= 0 && tx.indexOf("ابدأ المعركة") >= 0 && cands[i].offsetHeight > 0) host = cands[i];
      }
      if (!host || host.querySelector(".sol-fpanel")) return;
      var btnStart = null;
      var bts = host.querySelectorAll("button");
      for (var b = 0; b < bts.length; b++) {
        if ((bts[b].textContent || "").indexOf("ابدأ المعركة") >= 0) { btnStart = bts[b]; break; }
      }
      if (!btnStart) return;
      var stt = window.__solGet ? window.__solGet() : null;
      if (!stt || !Array.isArray(stt.team) || typeof stt.setTeam !== "function") return;
      var order = stt.team.slice();
      if (order.length !== d.length) {
        if (order.length < d.length) return;
        order = order.slice(0, d.length);
      }
      var orig = order.slice();
      var disp = d.slice();
      var sel = -1, busy = false;
      var body = el("div", "sol-fp-body");
      var panel = el("div", "sol-fpanel sol-ui");
      panel.appendChild(body);

      function powerAt(ix) {
        try {
          var id = order[ix];
          if (window.__solPower && window.__solHeroes && window.__solHeroes[id] && stt.heroes && stt.heroes[id])
            return (window.__solPower(window.__solHeroes[id], stt.heroes[id]) || {}).power || 0;
        } catch (e) {}
        return (disp[ix].atk || 0) + (disp[ix].maxHp || 0) / 10;
      }
      function rangedAt(ix) {
        var u = disp[ix];
        try { if (window.__solRanged) return !!window.__solRanged(u.name, u.role, 0, false); } catch (e) {}
        return u.role === "support" || u.role === "control";
      }
      function remap(newOrder) {
        var nd = [];
        for (var i2 = 0; i2 < newOrder.length; i2++) {
          var src = -1;
          for (var j = 0; j < order.length; j++) if (order[j] === newOrder[i2]) { src = j; break; }
          nd.push(src >= 0 ? disp[src] : disp[i2]);
        }
        return nd;
      }
      function smartOrder() {
        var n = d.length, byPow = [], k2, out = [];
        for (k2 = 0; k2 < n; k2++) byPow.push(k2);
        byPow.sort(function (a, b2) { return powerAt(b2) - powerAt(a); });
        var front = [], back = [];
        for (var j2 = 0; j2 < byPow.length; j2++) {
          var rl = disp[byPow[j2]].role;
          if ((rl === "tank" || rl === "control") && front.length < 2) front.push(byPow[j2]);
          else back.push(byPow[j2]);
        }
        while (front.length < 2 && back.length) front.push(back.shift());
        back.sort(function (a, b3) { return (rangedAt(a) ? 0 : 1) - (rangedAt(b3) ? 0 : 1); });
        for (k2 = 0; k2 < n; k2++) out.push(null);
        for (var f = 0; f < front.length && f < 2; f++) out[f] = order[front[f]];
        for (var b4 = 0; b4 < back.length && 2 + b4 < n; b4++) out[2 + b4] = order[back[b4]];
        for (var c3 = 0; c3 < n; c3++) if (out[c3] == null) out[c3] = order[c3];
        return out;
      }
      function slotHTML(ix) {
        var u = disp[ix], rng = false;
        try { rng = !!(window.__solRanged && window.__solRanged(u.name, u.role, 0, false)); } catch (e) {}
        var g2 = glyph(u.role) || (rng ? "🏹" : "⚔");
        return '<div class="sol-fp-slot' + (sel === ix ? " sel" : "") + '" data-slot="' + ix + '"><i>' + (ix + 1) + '</i>' +
          '<button type="button" class="sol-fp-chip' + (sel === ix ? " sel" : "") + '" data-ix="' + ix + '" title="' + esc(u.name) + '">' +
          '<b>' + g2 + '</b><span>' + esc(u.name) + '</span></button></div>';
      }
      function rerender() {
        var n = d.length, frontN = Math.min(2, n), backN = Math.max(0, n - frontN), h = "";
        h += '<div class="sol-fp-t">🧭 ترتيب الصفوف — اسحب البطل إلى أي مكان</div>';
        h += '<div class="sol-fp-lbl">🛡 الصف الأمامي<small>يستقبل الضربات أولًا</small></div>' +
          '<div class="sol-fp-chips sol-grid" style="--c:' + frontN + ';' + (backN === 3 ? 'width:66%;margin-inline:auto' : '') + '">';
        for (var i3 = 0; i3 < frontN; i3++) h += slotHTML(i3);
        h += '</div>';
        if (backN > 0) {
          h += '<div class="sol-fp-lbl">🏹 الصف الخلفي<small>محمي حتى يسقط الأماميون</small></div>' +
            '<div class="sol-fp-chips sol-grid" style="--c:' + Math.min(backN, 4) + '">';
          for (var k3 = frontN; k3 < n; k3++) h += slotHTML(k3);
          h += '</div>';
        }
        h += '<div class="sol-fp-actions"><button type="button" class="sol-fp-btn" data-act="smart">✨ ترتيب ذكي</button>' +
          '<button type="button" class="sol-fp-btn" data-act="reset">↩ الأصلي</button></div>' +
          '<div class="sol-fp-hint">اضغط على البطل واسحبه لأي خانة (أو المس بطلاً ثم بطلاً آخر) • الترتيب يُحفظ لمعاركك القادمة • الرماة والدعم أقوى في الخلف والصامدون في الأمام</div>';
        body.innerHTML = h;
      }
      function go() {
        if (busy) return;
        busy = true;
        var preOrder = order.slice(), preDisp = disp.slice();
        refightWithOrder(order.slice(), d.length, function (msg) {
          order = preOrder; disp = preDisp; sel = -1; rerender();
          busy = false;
          showToast(C, msg || "لم يُطبَّق الترتيب الآن — سيُطبَّق في معركتك القادمة");
        });
        setTimeout(function () { busy = false; }, 500);
      }
      /* --- تبديل مكانين (من السحب أو من اللمس) --- */
      function doSwap(a1, b1) {
        if (a1 === b1 || a1 < 0 || b1 < 0 || a1 >= d.length || b1 >= d.length) { sel = -1; rerender(); return; }
        var tu = disp[a1]; disp[a1] = disp[b1]; disp[b1] = tu;
        var to = order[a1]; order[a1] = order[b1]; order[b1] = to;
        sel = -1; rerender(); go();
      }
      function tapSlot(ix) {
        if (busy) return;
        if (sel < 0) { sel = ix; rerender(); }
        else if (sel === ix) { sel = -1; rerender(); }
        else doSwap(sel, ix);
      }

      /* --- السحب والإفلات بالإصبع/الماوس --- */
      var drag = null, lastDragEnd = 0;
      function slotAt(x, y) {
        var e2 = document.elementFromPoint(x, y);
        var s2 = e2 && e2.closest ? e2.closest(".sol-fp-slot") : null;
        return s2 && body.contains(s2) ? s2 : null;
      }
      function clearOver() {
        var o = body.querySelectorAll(".sol-fp-slot.over");
        for (var q = 0; q < o.length; q++) o[q].classList.remove("over");
      }
      function endDrag(ev, cancelled) {
        if (!drag || (ev && ev.pointerId !== drag.id)) return;
        var dg = drag; drag = null;
        try { dg.chip.releasePointerCapture(dg.id); } catch (e) {}
        if (dg.ghost && dg.ghost.parentNode) dg.ghost.parentNode.removeChild(dg.ghost);
        clearOver();
        try { dg.chip.classList.remove("lifted"); } catch (e) {}
        if (dg.moved) lastDragEnd = Date.now();
        if (cancelled) { if (dg.moved) { sel = -1; rerender(); } return; }
        if (dg.moved) {
          var tgt = slotAt(ev.clientX, ev.clientY);
          var to2 = tgt ? +tgt.getAttribute("data-slot") : -1;
          if (to2 >= 0 && to2 !== dg.ix) doSwap(dg.ix, to2);
          else { sel = -1; rerender(); }
        } else {
          tapSlot(dg.ix);
        }
      }
      body.addEventListener("pointerdown", function (ev) {
        if (busy || drag) return;
        if (ev.pointerType === "mouse" && ev.button !== 0) return;
        var chip = ev.target && ev.target.closest ? ev.target.closest(".sol-fp-chip") : null;
        if (!chip) return;
        var ix0 = +chip.getAttribute("data-ix");
        if (isNaN(ix0)) return;
        drag = { ix: ix0, chip: chip, id: ev.pointerId, x0: ev.clientX, y0: ev.clientY, moved: false, ghost: null };
        try { chip.setPointerCapture(ev.pointerId); } catch (e) {}
      });
      body.addEventListener("pointermove", function (ev) {
        if (!drag || ev.pointerId !== drag.id) return;
        var dx = ev.clientX - drag.x0, dy = ev.clientY - drag.y0;
        if (!drag.moved) {
          if (dx * dx + dy * dy < 64) return; /* أقل من 8px = لمسة عادية */
          drag.moved = true;
          var r = drag.chip.getBoundingClientRect();
          var g3 = drag.chip.cloneNode(true);
          g3.className = "sol-fp-chip sol-fp-ghost";
          g3.style.width = r.width + "px"; g3.style.height = r.height + "px";
          g3.style.left = r.left + "px"; g3.style.top = r.top + "px";
          document.body.appendChild(g3);
          drag.ghost = g3;
          drag.chip.classList.add("lifted");
        }
        drag.ghost.style.transform = "translate(" + dx + "px," + dy + "px) scale(1.1)";
        var hov = slotAt(ev.clientX, ev.clientY);
        clearOver();
        if (hov) hov.classList.add("over");
        if (ev.cancelable) ev.preventDefault();
      });
      body.addEventListener("pointerup", function (ev) { endDrag(ev, false); });
      body.addEventListener("pointercancel", function (ev) { endDrag(ev, true); });
      body.addEventListener("contextmenu", function (ev) { ev.preventDefault(); });
      body.addEventListener("click", function (ev) {
        if (Date.now() - lastDragEnd < 350) return; /* تجاهل النقرة التي تلي السحب */
        var t2 = ev.target && ev.target.closest ? ev.target.closest(".sol-fp-btn") : null;
        if (t2) {
          var act = t2.getAttribute("data-act");
          if (act === "smart") { var so = smartOrder(); var nd2 = remap(so); order = so; disp = nd2; sel = -1; rerender(); go(); }
          else if (act === "reset") { var nd3 = remap(orig); order = orig.slice(); disp = nd3; sel = -1; rerender(); go(); }
          return;
        }
        /* لمس خانة فارغة الحواف بعد اختيار بطل */
        var sl = ev.target && ev.target.closest ? ev.target.closest(".sol-fp-slot") : null;
        if (sl && !ev.target.closest(".sol-fp-chip") && sel >= 0) tapSlot(+sl.getAttribute("data-slot"));
      });
      rerender();
      var btnRow = btnStart.parentElement;
      if (btnRow && btnRow.parentElement) btnRow.parentElement.insertBefore(panel, btnRow.nextSibling);
      else host.appendChild(panel);
    }, 380);
  }

  /* ============ سحب الأبطال على أرض المعركة قبل البدء لتبديل أماكنهم ============ */
  var AD = null, adBound = false;
  function prepActive() {
    var bs = document.querySelectorAll("button");
    for (var i = 0; i < bs.length; i++) if ((bs[i].textContent || "").indexOf("ابدأ المعركة") >= 0 && bs[i].offsetHeight > 0) return true;
    return false;
  }
  function arenaDrag(C, p) {
    setTimeout(function () {
      if (!C.ov || !C.ov.isConnected) return;
      if (String(p.TT || "").indexOf("إعادة") >= 0) return;
      var d = p.d || [];
      if (d.length < 2 || !window.SOL3D || !window.SOL3D.pickHero) return;
      var stt = window.__solGet ? window.__solGet() : null;
      if (!stt || !Array.isArray(stt.team) || typeof stt.setTeam !== "function") return;
      if (stt.team.length < d.length) return;
      AD = { C: C, d: d, order: stt.team.slice(0, d.length), busy: false, sel: null, drag: null, ghost: null, rings: [] };
      if (!adBound) { adBound = true; adBind(); }
    }, 420);
  }
  function adIx(uid) { for (var i = 0; i < AD.d.length; i++) if (AD.d[i].uid === uid) return i; return -1; }
  function adClear() {
    if (!AD) return;
    if (AD.ghost && AD.ghost.parentNode) AD.ghost.parentNode.removeChild(AD.ghost);
    AD.ghost = null;
    for (var i = 0; i < AD.rings.length; i++) if (AD.rings[i].parentNode) AD.rings[i].parentNode.removeChild(AD.rings[i]);
    AD.rings = [];
  }
  function adRing(uid, tgt) {
    var P = window.SOL3D.heroPoint(uid);
    if (!P) return;
    var r = document.createElement("div");
    r.className = "sol-ad-ring" + (tgt ? " tgt" : "");
    r.style.left = P.x + "px"; r.style.top = (P.y + 28) + "px";
    document.body.appendChild(r);
    AD.rings.push(r);
  }
  function adSwap(ua, ub) {
    var a = adIx(ua), b = adIx(ub);
    if (a < 0 || b < 0 || a === b || AD.busy) return;
    var pre = AD.order.slice(), C = AD.C;
    var no = AD.order.slice(); var t = no[a]; no[a] = no[b]; no[b] = t;
    AD.busy = true;
    refightWithOrder(no, AD.d.length, function (msg) {
      AD.order = pre; AD.busy = false;
      showToast(C, msg || "لم يُطبَّق الترتيب الآن — سيُطبَّق في معركتك القادمة");
    });
    setTimeout(function () { if (AD) AD.busy = false; }, 600);
  }
  function adBind() {
    function inStage(e) { return e.target && e.target.closest && e.target.closest(".s3d-stage"); }
    document.addEventListener("pointerdown", function (e) {
      if (!AD || AD.busy || AD.drag || !AD.C.ov || !AD.C.ov.isConnected) return;
      if (e.pointerType === "mouse" && e.button !== 0) return;
      if (!inStage(e) || !prepActive()) return;
      var hit = window.SOL3D.pickHero(e.clientX, e.clientY);
      if (!hit || adIx(hit.uid) < 0) { if (AD.sel != null) { AD.sel = null; adClear(); } return; }
      AD.drag = { uid: hit.uid, id: e.pointerId, x0: e.clientX, y0: e.clientY, moved: false };
      e.stopPropagation(); e.preventDefault();
    }, true);
    document.addEventListener("pointermove", function (e) {
      var g = AD && AD.drag;
      if (!g || e.pointerId !== g.id) return;
      e.stopPropagation(); e.preventDefault();
      var dx = e.clientX - g.x0, dy = e.clientY - g.y0;
      if (!g.moved) {
        if (dx * dx + dy * dy < 100) return;
        g.moved = true;
        AD.sel = null; adClear();
        var gh = document.createElement("div");
        gh.className = "sol-ad-ghost";
        gh.textContent = "⚔ " + (AD.d[adIx(g.uid)].name || "");
        document.body.appendChild(gh);
        AD.ghost = gh;
      }
      AD.ghost.style.left = e.clientX + "px"; AD.ghost.style.top = e.clientY + "px";
      for (var i = 0; i < AD.rings.length; i++) if (AD.rings[i].parentNode) AD.rings[i].parentNode.removeChild(AD.rings[i]);
      AD.rings = [];
      adRing(g.uid, false);
      var h = window.SOL3D.pickHero(e.clientX, e.clientY);
      if (h && h.uid !== g.uid && adIx(h.uid) >= 0) adRing(h.uid, true);
    }, true);
    function end(e, cancel) {
      var g = AD && AD.drag;
      if (!g || e.pointerId !== g.id) return;
      e.stopPropagation();
      AD.drag = null;
      var moved = g.moved;
      adClear();
      if (cancel) return;
      var h = window.SOL3D.pickHero(e.clientX, e.clientY);
      if (moved) {
        if (h && h.uid !== g.uid && adIx(h.uid) >= 0) adSwap(g.uid, h.uid);
        return;
      }
      /* لمسة: اختر بطلًا ثم المس بطلًا آخر للتبديل */
      if (AD.sel == null) { AD.sel = g.uid; adRing(g.uid, false); }
      else if (AD.sel === g.uid) { AD.sel = null; }
      else { var a = AD.sel; AD.sel = null; adSwap(a, g.uid); }
    }
    document.addEventListener("pointerup", function (e) { end(e, false); }, true);
    document.addEventListener("pointercancel", function (e) { end(e, true); }, true);
  }

  /* ============ إعادة خوض المعركة نفسها بترتيب جديد (بدون غنائم مزدوجة) ============ */
  function refightWithOrder(order, dLen, onFail) {
    var now = Date.now();
    var stt = window.__solGet ? window.__solGet() : null;
    if (!stt || typeof stt.setTeam !== "function") { onFail("تعذر الوصول للحفظ"); return; }
    var freshSnap = !!(window.__solBattleSnapshot && now - (window.__solSnapAt || 0) < 120000);
    var lf = window.__solLastFight, fm = window.__solLastFM;
    var viaAction = !!(freshSnap && lf && lf.action && typeof stt[lf.action] === "function" && now - lf.at < 120000);
    var viaFM = !!(fm && typeof window.__solFightMode === "function" && now - fm.at < 120000);
    if (!viaAction && !viaFM) { onFail("انتهت مهلة الترتيب — سيُطبَّق في معركتك القادمة"); return; }
    if (freshSnap) { try { window.__solSet(function () { return window.__solBattleSnapshot; }); } catch (e) {} }
    try { if (window.__solWorldRollback) window.__solWorldRollback(); } catch (e) {}
    try { stt.setTeam(order.slice(0, dLen)); } catch (e) { onFail("تعذر حفظ الترتيب"); return; }
    var o = null;
    try { o = viaAction ? stt[lf.action].apply(stt, lf.args) : window.__solFightMode(fm.m, fm.lv, fm.custom); } catch (e) {}
    if (!o || o.error) { onFail((o && o.error) || "تعذر إعادة المعركة"); return; }
    var lb = window.__solLastBattleArgs, opened = false;
    if (lb && typeof window.__solBattleOpenRefight === "function") {
      try { window.__solBattleOpenRefight(o, lb[1], lb[2], lb[3], lb[4]); opened = true; } catch (e) {}
    }
    if (!opened && typeof window.__solBattle === "function") {
      try { window.__solBattle(o, lb ? lb[1] : "", lb ? lb[2] : "", lb ? lb[3] : null, lb ? lb[4] : null); opened = true; } catch (e) {}
    }
    if (!opened) { onFail("تعذر إعادة فتح المعركة"); return; }
    if (typeof window.__solGaugeFor === "function") { try { window.__solGaugeFor(o); } catch (e) {} }
  }

  /* ============ رقاقة التشخيص ============ */
  function updateDbg(C) {
    if (!C.dbg || !C.dbgEl) return;
    var st = window.SOL3D && window.SOL3D.state ? window.SOL3D.state() : null;
    C.dbgEl.textContent = "FPS " + C.fps +
      (st ? " • GL " + (st.gl ? "نعم" : "CSS") + " • جودة " + st.low + " • dist " + st.dist + " • FX " + st.fx : "") +
      " • أحداث " + C.ei + "/" + C.ev.length;
  }

  /* ============ المزامنة الرئيسية ============ */
  var lastU = null;
  function sync(p, api) {
    if (!api || !api.root) return;
    if (!C || C.api.root !== api.root) {
      C = newCtx(api);
      lastU = p.u || null;
    }
    if (!api.root.isConnected) { destroy(); return; }
    if (!C.ready) { build(C); if (!C.ready) return; }
    lastU = p.u || lastU;

    /* فهرس الوحدات (مرة واحدة عند البدء) */
    if (!C.names._done) {
      var all = (p.d || []).concat(p.c || []);
      for (var i = 0; i < all.length; i++) {
        var u = all[i];
        C.names[u.uid] = u.name || ("وحدة " + u.uid);
        C.factions[u.uid] = u.faction;
        C.sides[u.uid] = u.side;
        C.roles[u.uid] = (p.LY && p.LY[u.uid] && p.LY[u.uid].role) || u.role || "ranger";
      }
      C.names._done = 1;
      C.ev = (p.EV || []).slice().sort(function (a, b) { return a.t - b.t; });
      buildSkillBar(C, p);
    }
    if (api.fresh && !C.prepDone) { C.prepDone = true; prepEditor(C, p); arenaDrag(C, p); }

    /* ساعة المعركة (نفس معادلة التلوّيح في المحرك) */
    var sp = Math.max(1, Math.min(4, api.speed() || 1));
    var now = (p.BT || 0) + (performance.now() - C.btWall) / 1000 * 3 * sp;
    C.btWall = performance.now();

    consume(C, p, now);
    updateTurn(C, p, now);

    /* حلقات الطاقة */
    if (!C.ended) {
      for (var uid in C.skillChips) {
        var chip = C.skillChips[uid];
        var s = p.u && p.u[uid];
        var en = s ? Math.max(0, Math.min(100, s.energy)) : 0;
        var rdy = en >= 100;
        if (chip.lastE !== en) {
          chip.lastE = en;
          chip.ring.style.setProperty("--e", en + "%");
        }
        if (chip.lastRdy !== rdy) {
          chip.lastRdy = rdy;
          chip.chip.classList.toggle("rdy", rdy);
        }
      }
    }
    renderLog(C);
    /* عدّاد FPS للتشخيص */
    C.fpsN++;
    var t2 = performance.now();
    if (t2 - C.fpsT >= 500) { C.fps = Math.round(C.fpsN * 1000 / (t2 - C.fpsT)); C.fpsN = 0; C.fpsT = t2; updateDbg(C); }
  }

  function destroy() {
    if (C && C.ov) { try { C.ov.remove(); } catch (e) {} }
    if (C && C.toastT) clearTimeout(C.toastT);
    if (C && C.cutinT) clearTimeout(C.cutinT);
    C = null;
  }

  window.SOLBTX = { sync: sync, destroy: destroy, version: "1-minitales" };
})();

