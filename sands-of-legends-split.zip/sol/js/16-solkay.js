
/* SOLKAY — KayKit GLB meshes + sampled skeletal clips adapted to SOL3D. */
(function(){
  "use strict";
  if(window.SOLKAY) return;
  var DATA=window.__SOLKAY_DATA||{}, CACHE={};
  function decode64(s){var raw=atob(s),bytes=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);return bytes;}
  function decode(key,gl){
    var d=DATA[key]; if(!d) return null;
    var c=CACHE[key]; if(c&&c.gl===gl) return c;
    var bytes=decode64(d.b), fbytes=d.v*6*4;
    var verts=new Float32Array(bytes.buffer,0,d.v*6), indices=new Uint16Array(bytes.buffer,fbytes,d.i);
    var vb=gl.createBuffer(), ib=gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER,vb); gl.bufferData(gl.ARRAY_BUFFER,verts, d.anims?gl.DYNAMIC_DRAW:gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,indices,gl.STATIC_DRAW);
    var mesh={vb:vb,ib:ib,n:d.i}, clips={};
    if(d.anims){
      for(var name in d.anims){var a=d.anims[name], ab=decode64(a.b);clips[name]={dur:a.dur,loop:!!a.loop,n:a.n,frames:new Int16Array(ab.buffer)};}
    }
    c={gl:gl,mesh:mesh,verts:verts,clips:clips};CACHE[key]=c;return c;
  }
  function characterKey(u,boss){
    if(u.side===1){if(boss)return "skeleton_warrior";var r=u.role||"dps",en=(u.name||"");if(/minion|تابع|خادم/i.test(en))return "skeleton_minion";return r==="control"||r==="support"?"skeleton_mage":r==="tank"?"skeleton_warrior":"skeleton_rogue";}
    var r=u.role||"dps",n=(u.name||"");
    if(r==="tank")return "knight";
    if(r==="support"||r==="control")return "mage";
    if(/صقر|ranger|archer/i.test(n))return "rogue_hooded";
    if(/مارد|barbar|berserk/i.test(n))return "barbarian";
    return "rogue";
  }
  function make(gl,u,boss){
    var key=characterKey(u,boss),data=decode(key,gl);if(!data)return null;
    function clipFor(name){return data.clips[name]||data.clips.idle;}
    function update(name,t){
      var c=clipFor(name),v=data.verts,nv=v.length/6;
      if(!c||!c.frames)return data.mesh;
      t=Math.max(0,Number(t)||0);
      var fp=c.loop?(((t%c.dur)+c.dur)%c.dur)/c.dur*c.n:Math.min(1,t/c.dur)*(c.n-1);
      var i0=Math.floor(fp),i1=c.loop?(i0+1)%c.n:Math.min(i0+1,c.n-1),mix=fp-i0;
      var base0=i0*nv*3,base1=i1*nv*3,fr=c.frames;
      for(var k=0;k<nv;k++){
        var src=k*3,dst=k*6;
        v[dst]=(fr[base0+src]*(1-mix)+fr[base1+src]*mix)/128;
        v[dst+1]=(fr[base0+src+1]*(1-mix)+fr[base1+src+1]*mix)/128;
        v[dst+2]=(fr[base0+src+2]*(1-mix)+fr[base1+src+2]*mix)/128;
      }
      gl.bindBuffer(gl.ARRAY_BUFFER,data.mesh.vb);gl.bufferSubData(gl.ARRAY_BUFFER,0,v);
      return data.mesh;
    }
    return {cls:key,mesh:data.mesh,gear:null,_clip:"idle",_time:0,
      update:function(clip,t){this._clip=clip||"idle";this._time=t||0;return update(this._clip,this._time);},
      dur:function(name){return clipFor(name).dur;},boneP:function(){return null;},kaykit:true};
  }
  function makeProp(gl,key){var d=decode(key,gl);return d&&d.mesh;}
  window.SOLKAY={ok:Object.keys(DATA).length>=15,make:make,makeProp:makeProp,keys:Object.keys(DATA),animated:true};
})();
