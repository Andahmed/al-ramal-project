
/* ============================================================
   SOL3D v3 — محرك القتال ثلاثي الأبعاد الحقيقي لأساطير الرمال
   WebGL مجسمات فوكسل: شخصيات مكعّبة مُجسّمة بأسلحة ودروع،
   كاميرا مسحوبة للوراء تُظهر الفريقين كاملين + سحب وإصبعين للتقريب،
   ضباب عمق، ظلال، حلقات تلويت، مؤثرات فضائية، أرقام ضرر.
   محسّن للهواتف الضعيفة: إضاءة مخبوزة في الألوان، draw calls قليلة،
   خفض تلقائي للجودة عند بطء الإطارات. بدون اهتزاز شاشة وبدون إضاءات.
   WebGL مطلوب؛ لا يوجد محرك CSS بديل حتى تظهر مشاكل WebGL بوضوح.
   v3: تركيز كاميرا على منفّذ النهائية (focus) + حلقة احتفالية (ringAt)
   + سرعة x4 + تنويع أسلحة وزينة + ديكور حسب الثيم + سحاب وقمر + نفخة سقوط
   + خطاف طبقة أسلوب Mini Tales (SOLBTX).
   ============================================================ */
(function () {
  "use strict";
  if (window.SOL3D) return;

  /* ============ كشف WebGL — بدونه يُفوَّض المحرك الاحتياطي CSS ============ */
  function canWebGL() {
    try {
      var c = document.createElement("canvas");
      var gl = c.getContext("webgl", { alpha: true }) || c.getContext("experimental-webgl", { alpha: true });
      if (!gl) return false;
      return !!(gl.createProgram && gl.getShaderParameter);
    } catch (e) { return false; }
  }
  var S = { ce: null };
  window.SOL3D = S;
  /* — API لطبقة أسلوب القتال (SOLBTX): تركيز كاميرا + حلقة احتفالية — */
  S.focus = function (uid, dur, tid) {
    if (!ST || ST.destroyed || !ST.units || !ST.units[uid]) return;
    var U = ST.units[uid];
    if (!U.alive) return;
    ST.focus = { uid: uid, tid: tid, t0: ST.fxClock, dur: Math.max(0.5, Math.min(2, dur || 1.1)) };
  };
  S.ringAt = function (uid, color, s) {
    if (!ST || ST.destroyed || !ST.R || ST.noGL || !ST.units || !ST.units[uid]) return;
    var U = ST.units[uid];
    addFx(ST, { kind: "ring", mesh: ST.R.shock, x: U.W.x, z: U.W.z, y: 1.6, c: rgb(color || "#ffd35a"), s: s || 2.2, t0: ST.fxClock, dur: 0.55 });
    for (var i = 0; i < 5; i++) {
      var an = i / 5 * Math.PI * 2;
      addFx(ST, { kind: "spark", mesh: ST.R.shard, x: U.W.x, z: U.W.z, y: 34, vx: Math.cos(an) * 60, vz: Math.sin(an) * 60, vy: 110, c: rgb(color || "#ffd35a"), s: 0.65, t0: ST.fxClock, dur: 0.5 });
    }
  };
  S.speedCap = function () { return 4; };
  /* — اختيار بطل اللاعب من نقطة على الشاشة (لسحب التبديل قبل المعركة) — */
  S.heroPoint = function (uid) {
    if (!ST || ST.destroyed || !ST.units || !ST.units[uid] || !ST.stage) return null;
    var U = ST.units[uid];
    var P = projectPoint(U.W.x, U.anchorY * 0.45, U.W.z);
    if (!P) return null;
    var r = ST.stage.getBoundingClientRect();
    return { x: r.left + P.x, y: r.top + P.y, s: clamp(1250 / P.w, 0.52, 1.42) };
  };
  S.pickHero = function (cx, cy) {
    if (!ST || ST.destroyed || !ST.units || !ST.stage) return null;
    var r = ST.stage.getBoundingClientRect(), best = null, bd = 1e9;
    for (var uid in ST.units) {
      var U = ST.units[uid];
      if (U.en || U.hidden || !U.alive) continue;
      var f = projectPoint(U.W.x, 0, U.W.z), h = projectPoint(U.W.x, U.anchorY * 0.8, U.W.z);
      if (!f || !h) continue;
      var x1 = r.left + f.x, y1 = r.top + f.y, x2 = r.left + h.x, y2 = r.top + h.y;
      var vx = x2 - x1, vy = y2 - y1, L2 = vx * vx + vy * vy || 1;
      var t = clamp(((cx - x1) * vx + (cy - y1) * vy) / L2, 0, 1);
      var dd = Math.hypot(cx - (x1 + vx * t), cy - (y1 + vy * t));
      var lim = 30 + Math.sqrt(L2) * 0.22;
      if (dd < lim && dd < bd) { bd = dd; best = uid; }
    }
    return best == null ? null : { uid: +best, key: best };
  };

  if (!canWebGL()) {
    S.scene = function () {
      var ce = S.ce || function () { return null; };
      return ce("div", {
        className: "s3d-webgl-required",
        style: { padding: "18px", textAlign: "center", color: "#f2d6a0", direction: "rtl" },
        children: "تعذر تشغيل ساحة القتال ثلاثية الأبعاد: WebGL غير متاح في هذا المتصفح أو الجهاز."
      });
    };
    S.hooks = function (h) { if (h && h.ce) S.ce = h.ce; };
    return;
  }

  /* ============ أدوات عامة ============ */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function fmtN(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + "م";
    if (n >= 1e4) return (n / 1e3).toFixed(n >= 1e5 ? 0 : 1) + "ألف";
    return Math.max(0, Math.round(n)).toLocaleString("en-US");
  }
  function hash(s) { var h = 7; s = s || "x"; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; }
  function hex2rgb(h) {
    h = String(h || "#fff").replace("#", "");
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }
  function mixc(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }

  /* ============ فصائل اللعبة ============ */
  var F = {
    guardians: { name: "حرّاس المدن", color: "#c46a3a", colorDark: "#7a3d1f", colorLight: "#f0a878", counters: ["plains"] },
    plains:    { name: "أهل السهول", color: "#8aa848", colorDark: "#4f6524", colorLight: "#c4dc8a", counters: ["oasis"] },
    oasis:     { name: "أهل الواحات", color: "#2fb8a6", colorDark: "#136b60", colorLight: "#7ee0d2", counters: ["shadow"] },
    shadow:    { name: "بني الظل", color: "#7b68b5", colorDark: "#423570", colorLight: "#b4a5e6", counters: ["guardians"] },
    light:     { name: "النور", color: "#e8c76a", colorDark: "#8f6f22", colorLight: "#fff3cf", counters: ["abyss"] },
    abyss:     { name: "الهاوية", color: "#b34a68", colorDark: "#6b1f35", colorLight: "#e29ab0", counters: ["light"] }
  };
  var SKINS = ["#f1c27d", "#e0ac69", "#c68642", "#9a6a3c"];

  /* ============ الثيمات ============ */
  var THEMES = {
    clay:   { g1: "#c9793f", g2: "#a45a2b", p: "#7f9440", d: "#8d4d24", sky: ["#e8b06a", "#a45a2b"], night: false, sun: "#fff3cf" },
    plains: { g1: "#d1a94c", g2: "#b08a34", p: "#8fb04a", d: "#96722a", sky: ["#f0cf8a", "#c08a3c"], night: false, sun: "#fffbe8" },
    oasis:  { g1: "#d8b974", g2: "#b89650", p: "#2ea597", d: "#9a7a3c", sky: ["#9be3d2", "#d8b974"], night: false, sun: "#ffffff" },
    shadow: { g1: "#4f4378", g2: "#352c58", p: "#6a52a8", d: "#271f44", sky: ["#241d38", "#171026"], night: true, sun: "#dfe0ff" },
    abyss:  { g1: "#8a2e40", g2: "#5e1c2c", p: "#d4532e", d: "#3d1019", sky: ["#3a1526", "#200812"], night: true, sun: "#ffb3a0" },
    boss:   { g1: "#6b1a2c", g2: "#3a0e1a", p: "#ff6b3a", d: "#200710", sky: ["#4a0e1c", "#1c060e"], night: true, sun: "#ff8a5e" },
    arena:  { g1: "#b99b66", g2: "#8c7347", p: "#d9c394", d: "#6e5a36", sky: ["#e8cf9a", "#b99b66"], night: false, sun: "#fff8dc" }
  };
  function themeBy(t, bg) {
    if (bg) {
      var b = String(bg);
      if (b.indexOf("#21163b") >= 0) return THEMES.shadow;
      if (b.indexOf("#0d0a18") >= 0) return THEMES.shadow;
      if (b.indexOf("#2e2b14") >= 0) return THEMES.plains;
      if (b.indexOf("#12332e") >= 0) return THEMES.oasis;
      if (b.indexOf("#241d38") >= 0) return THEMES.shadow;
      if (b.indexOf("#3a1526") >= 0) return THEMES.abyss;
    }
    return THEMES[t && t.n] || THEMES.clay;
  }

  /* ============ خريطة المواقع (نفس اللعبة الأصلية) ============ */
  var FLOOR_W = 820;
  function unitWorld(L) {
    /* v4: الفريقان يمين وشمال (الأبطال يسار، الأعداء يمين) كما في مرجع اللاعب */
    var gz = (clamp(L.y, 2, 98) - 50) / 100 * FLOOR_W * 0.50;
    var gx;
    if (L.big) { gx = 205; gz = 0; }
    else if (L.side === 0) { gx = -(92 + (34 - L.x) * 8.4); }
    else { gx = 92 + (L.x - 66) * 8.4; }
    return { x: gx, z: gz };
  }

  /* ============ مصفوفات 4×4 (عمودية) ============ */
  function M4() { return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); }
  function m4Mul(o, a, b) {
    for (var i = 0; i < 4; i++) {
      var b0 = b[i * 4], b1 = b[i * 4 + 1], b2 = b[i * 4 + 2], b3 = b[i * 4 + 3];
      o[i * 4]     = a[0] * b0 + a[4] * b1 + a[8] * b2 + a[12] * b3;
      o[i * 4 + 1] = a[1] * b0 + a[5] * b1 + a[9] * b2 + a[13] * b3;
      o[i * 4 + 2] = a[2] * b0 + a[6] * b1 + a[10] * b2 + a[14] * b3;
      o[i * 4 + 3] = a[3] * b0 + a[7] * b1 + a[11] * b2 + a[15] * b3;
    }
    return o;
  }
  function m4T(x, y, z) { var m = M4(); m[12] = x; m[13] = y; m[14] = z; return m; }
  function m4S(x, y, z) { var m = M4(); m[0] = x; m[5] = y; m[10] = z; return m; }
  function m4Rx(a) { var c = Math.cos(a), s = Math.sin(a), m = M4(); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; return m; }
  function m4Ry(a) { var c = Math.cos(a), s = Math.sin(a), m = M4(); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; return m; }
  function m4Rz(a) { var c = Math.cos(a), s = Math.sin(a), m = M4(); m[0] = c; m[1] = s; m[4] = -s; m[5] = c; return m; }
  function m4Persp(fovy, aspect, n, f) {
    var t = 1 / Math.tan(fovy / 2), m = new Float32Array(16);
    m[0] = t / aspect; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f);
    return m;
  }
  function m4LookAt(ex, ey, ez, cx, cy, cz) {
    var zx = ex - cx, zy = ey - cy, zz = ez - cz;
    var zl = Math.sqrt(zx * zx + zy * zy + zz * zz) || 1; zx /= zl; zy /= zl; zz /= zl;
    var ux = 0, uy = 1, uz = 0;
    var xX = uy * zz - uz * zy, xY = uz * zx - ux * zz, xZ = ux * zy - uy * zx;
    var xl = Math.sqrt(xX * xX + xY * xY + xZ * xZ) || 1; xX /= xl; xY /= xl; xZ /= xl;
    var yX = zy * xZ - zz * xY, yY = zz * xX - zx * xZ, yZ = zx * xY - zy * xX;
    var m = new Float32Array(16);
    m[0] = xX; m[1] = yX; m[2] = zx; m[3] = 0;
    m[4] = xY; m[5] = yY; m[6] = zy; m[7] = 0;
    m[8] = xZ; m[9] = yZ; m[10] = zz; m[11] = 0;
    m[12] = -(xX * ex + xY * ey + xZ * ez);
    m[13] = -(yX * ex + yY * ey + yZ * ez);
    m[14] = -(zx * ex + zy * ey + zz * ez);
    m[15] = 1;
    return m;
  }

  /* ============ باني الهندسة: صناديق ملوّنة + إضاءة مخبوزة ============ */
  var BRIGHT = { top: 1.0, bottom: 0.42, front: 0.88, back: 0.55, right: 0.76, left: 0.64 };
  function GB() { this.v = []; this.i = []; this.n = 0; }
  /* رباعي وجوه من 4 رؤوس (ترتيب مضاد لعقارب الساعة من الخارج) */
  GB.prototype.quad = function (a, b, c, d, col) {
    var V = this.v, I = this.i, n0 = this.n;
    V.push(a[0], a[1], a[2], col[0], col[1], col[2]);
    V.push(b[0], b[1], b[2], col[0], col[1], col[2]);
    V.push(c[0], c[1], c[2], col[0], col[1], col[2]);
    V.push(d[0], d[1], d[2], col[0], col[1], col[2]);
    I.push(n0, n0 + 1, n0 + 2, n0, n0 + 2, n0 + 3);
    this.n += 4;
  };
  /* صندوق مركزه cx,cy,cz بأبعاد w,h,d — مع دوران اختياري حول محور Y للصندوق نفسه */
  GB.prototype.box = function (cx, cy, cz, w, h, d, hex, opt) {
    var col = typeof hex === "string" ? hex2rgb(hex) : hex;
    var ry = opt && opt.ry || 0, cs = Math.cos(ry), sn = Math.sin(ry);
    var x0 = -w / 2, x1 = w / 2, y0 = -h / 2, y1 = h / 2, z0 = -d / 2, z1 = d / 2;
    var self = this;
    function rot(p) { return [cx + p[0] * cs - p[2] * sn, cy + p[1], cz + p[0] * sn + p[2] * cs]; }
    function shade(k) { return [col[0] * k, col[1] * k, col[2] * k]; }
    /* 6 أوجه بإضاءة مخبوزة */
    var A = [x0, y1, z1], B = [x1, y1, z1], C = [x1, y1, z0], D = [x0, y1, z0];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.top));
    A = [x0, y0, z0]; B = [x1, y0, z0]; C = [x1, y0, z1]; D = [x0, y0, z1];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.bottom));
    A = [x0, y0, z1]; B = [x1, y0, z1]; C = [x1, y1, z1]; D = [x0, y1, z1];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.front));
    A = [x1, y0, z0]; B = [x0, y0, z0]; C = [x0, y1, z0]; D = [x1, y1, z0];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.back));
    A = [x1, y0, z1]; B = [x1, y0, z0]; C = [x1, y1, z0]; D = [x1, y1, z1];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.right));
    A = [x0, y0, z0]; B = [x0, y0, z1]; C = [x0, y1, z1]; D = [x0, y1, z0];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.left));
  };
  /* حلقة أفقية على الأرض (XZ) */
  GB.prototype.ringY = function (cx, cy, cz, r0, r1, seg, hex) {
    var col = typeof hex === "string" ? hex2rgb(hex) : hex;
    for (var s = 0; s < seg; s++) {
      var a0 = s / seg * Math.PI * 2, a1 = (s + 1) / seg * Math.PI * 2;
      var p00 = [cx + Math.cos(a0) * r0, cy, cz + Math.sin(a0) * r0];
      var p01 = [cx + Math.cos(a1) * r0, cy, cz + Math.sin(a1) * r0];
      var p10 = [cx + Math.cos(a0) * r1, cy, cz + Math.sin(a0) * r1];
      var p11 = [cx + Math.cos(a1) * r1, cy, cz + Math.sin(a1) * r1];
      this.quad(p10, p11, p01, p00, col);
    }
  };
  /* قطاع قوس (للشرطة الحادة) */
  GB.prototype.arcY = function (cx, cy, cz, r0, r1, a0, a1, seg, hex) {
    var col = typeof hex === "string" ? hex2rgb(hex) : hex;
    for (var s = 0; s < seg; s++) {
      var b0 = a0 + (a1 - a0) * s / seg, b1 = a0 + (a1 - a0) * (s + 1) / seg;
      var p00 = [cx + Math.cos(b0) * r0, cy, cz + Math.sin(b0) * r0];
      var p01 = [cx + Math.cos(b1) * r0, cy, cz + Math.sin(b1) * r0];
      var p10 = [cx + Math.cos(b0) * r1, cy, cz + Math.sin(b0) * r1];
      var p11 = [cx + Math.cos(b1) * r1, cy, cz + Math.sin(b1) * r1];
      this.quad(p10, p11, p01, p00, col);
    }
  };
  /* ===== أدوات مجسمات المؤثرات ثلاثية الأبعاد الحقيقية (أوجه مظلّلة بحسب الاتجاه) ===== */
  GB.prototype.tri = function (a, b, c, col) {
    var V = this.v, I = this.i, n0 = this.n;
    V.push(a[0], a[1], a[2], col[0], col[1], col[2], b[0], b[1], b[2], col[0], col[1], col[2], c[0], c[1], c[2], col[0], col[1], col[2]);
    I.push(n0, n0 + 1, n0 + 2); this.n += 3;
  };
  /* وجه (3 أو 4 نقاط) يُظلَّل بحسب اتجاه عموده بالنسبة لمركز المجسم ctr */
  GB.prototype.face = function (pts, ctr, col) {
    var a = pts[0], b = pts[1], c = pts[2];
    var ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    var nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    var cx = (a[0] + c[0]) / 2 - ctr[0], cy = (a[1] + c[1]) / 2 - ctr[1], cz = (a[2] + c[2]) / 2 - ctr[2];
    if (nx * cx + ny * cy + nz * cz < 0) { nx = -nx; ny = -ny; nz = -nz; }
    var nl = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
    var k = 0.74 + 0.46 * ((nx * 0.35 + ny * 0.8 + nz * 0.5) / nl) / 0.995;
    k = k < 0.38 ? 0.38 : k > 1.25 ? 1.25 : k;
    var cc = [col[0] * k, col[1] * k, col[2] * k];
    if (pts.length === 3) this.tri(pts[0], pts[1], pts[2], cc); else this.quad(pts[0], pts[1], pts[2], pts[3], cc);
  };
  /* مجسم ماسي (هرمان متقابلان) على محور d */
  GB.prototype.bipyramid = function (dx, dy, dz, len, w, col) {
    var d = [dx, dy, dz], dl = Math.sqrt(dx * dx + dy * dy + dz * dz); d = [dx / dl, dy / dl, dz / dl];
    var ref = Math.abs(d[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
    var u = [d[1] * ref[2] - d[2] * ref[1], d[2] * ref[0] - d[0] * ref[2], d[0] * ref[1] - d[1] * ref[0]];
    var ul = Math.sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]); u = [u[0] / ul, u[1] / ul, u[2] / ul];
    var v = [d[1] * u[2] - d[2] * u[1], d[2] * u[0] - d[0] * u[2], d[0] * u[1] - d[1] * u[0]];
    var R = [[u[0] * w, u[1] * w, u[2] * w], [v[0] * w, v[1] * w, v[2] * w], [-u[0] * w, -u[1] * w, -u[2] * w], [-v[0] * w, -v[1] * w, -v[2] * w]];
    var T = [d[0] * len, d[1] * len, d[2] * len], B = [-T[0], -T[1], -T[2]], O = [0, 0, 0];
    for (var i = 0; i < 4; i++) {
      var p = R[i], q = R[(i + 1) % 4];
      this.face([T, p, q], O, col);
      this.face([B, q, p], O, col);
    }
  };
  /* حلقة قوسية ثلاثية الأبعاد على الأرض (موجة صدمة بسُمك وارتفاع حقيقيين) */
  GB.prototype.archRing = function (rc, hw, h, seg, col) {
    var prof = [[-hw, 0], [-hw * 0.62, h * 0.8], [0, h], [hw * 0.62, h * 0.8], [hw, 0]];
    for (var s = 0; s < seg; s++) {
      var a0 = s / seg * Math.PI * 2, a1 = (s + 1) / seg * Math.PI * 2;
      var am = (a0 + a1) / 2, ctr = [Math.cos(am) * rc, -h * 0.3, Math.sin(am) * rc];
      for (var k = 0; k < prof.length - 1; k++) {
        var p = prof[k], q = prof[k + 1];
        var A = [Math.cos(a0) * (rc + p[0]), p[1], Math.sin(a0) * (rc + p[0])];
        var B = [Math.cos(a1) * (rc + p[0]), p[1], Math.sin(a1) * (rc + p[0])];
        var C = [Math.cos(a1) * (rc + q[0]), q[1], Math.sin(a1) * (rc + q[0])];
        var D = [Math.cos(a0) * (rc + q[0]), q[1], Math.sin(a0) * (rc + q[0])];
        this.face([A, B, C, D], ctr, col);
      }
    }
  };
  /* هلال شرطة مجسّم بسُمك (حافة حادة للخارج وظهر سميك للداخل) */
  GB.prototype.blade = function (r0, r1, a0, a1, seg, thick, col) {
    var rm = (r0 + r1) / 2;
    for (var s = 0; s < seg; s++) {
      var b0 = a0 + (a1 - a0) * s / seg, b1 = a0 + (a1 - a0) * (s + 1) / seg, bm = (b0 + b1) / 2;
      var t0 = thick * Math.cos((b0 - (a0 + a1) / 2) / ((a1 - a0) / 2) * Math.PI / 2);
      var t1 = thick * Math.cos((b1 - (a0 + a1) / 2) / ((a1 - a0) / 2) * Math.PI / 2);
      var ctr = [Math.cos(bm) * rm * 0.8, 0, Math.sin(bm) * rm * 0.8];
      var iT0 = [Math.cos(b0) * r0, t0, Math.sin(b0) * r0], iT1 = [Math.cos(b1) * r0, t1, Math.sin(b1) * r0];
      var iB0 = [Math.cos(b0) * r0, -t0, Math.sin(b0) * r0], iB1 = [Math.cos(b1) * r0, -t1, Math.sin(b1) * r0];
      var o0 = [Math.cos(b0) * r1, 0, Math.sin(b0) * r1], o1 = [Math.cos(b1) * r1, 0, Math.sin(b1) * r1];
      this.face([iT0, iT1, o1, o0], ctr, col);
      this.face([iB0, iB1, o1, o0], ctr, col);
      this.face([iT0, iT1, iB1, iB0], ctr, col);
    }
  };
  /* كرة مظلّلة (وميض الاصطدام) */
  GB.prototype.sphere = function (r, lat, lon, col) {
    var O = [0, 0, 0];
    function P(i, j) { var th = i / lat * Math.PI, ph = j / lon * Math.PI * 2; return [r * Math.sin(th) * Math.cos(ph), r * Math.cos(th), r * Math.sin(th) * Math.sin(ph)]; }
    for (var i = 0; i < lat; i++) for (var j = 0; j < lon; j++) {
      var a = P(i, j), b = P(i, j + 1), c = P(i + 1, j + 1), d = P(i + 1, j);
      if (i === 0) this.face([a, c, d], O, col); else if (i === lat - 1) this.face([a, b, c], O, col); else this.face([a, b, c, d], O, col);
    }
  };
  /* ساق مخروطية (للعمود الضوئي) */
  GB.prototype.spire = function (sides, rBot, rTop, y0, y1, yTip, col) {
    var O = [0, (y0 + y1) / 2, 0];
    for (var i = 0; i < sides; i++) {
      var a0 = i / sides * Math.PI * 2, a1 = (i + 1) / sides * Math.PI * 2;
      var b0 = [Math.cos(a0) * rBot, y0, Math.sin(a0) * rBot], b1 = [Math.cos(a1) * rBot, y0, Math.sin(a1) * rBot];
      var t0 = [Math.cos(a0) * rTop, y1, Math.sin(a0) * rTop], t1 = [Math.cos(a1) * rTop, y1, Math.sin(a1) * rTop];
      this.face([b0, b1, t1, t0], O, col);
      this.face([t0, t1, [0, yTip, 0]], O, col);
    }
  };
  GB.prototype.count = function () { return this.i.length; };

  /* ============ عارض WebGL ============ */
  var VS = "attribute vec3 aP;attribute vec3 aC;uniform mat4 uM;uniform vec3 uT;varying vec3 vC;varying float vD;" +
    "void main(){vec4 p=uM*vec4(aP,1.0);gl_Position=p;vC=aC*uT;vD=p.w;}";
  var FS = "precision mediump float;varying vec3 vC;varying float vD;uniform float uA;uniform vec3 uFC;uniform vec2 uFF;" +
    "void main(){float f=clamp((vD-uFF.x)/(uFF.y-uFF.x),0.0,1.0);gl_FragColor=vec4(mix(vC,uFC,f*0.72),uA);}";

  function Renderer(canvas) {
    var gl = null;
    try {
      gl = canvas.getContext("webgl", { alpha: true, premultipliedAlpha: false, antialias: false, powerPreference: "low-power" }) ||
           canvas.getContext("experimental-webgl", { alpha: true, premultipliedAlpha: false, antialias: false });
    } catch (e) { gl = null; }
    if (!gl) return null;
    this.gl = gl;
    this.canvas = canvas;
    function sh(type, src) {
      var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || "shader");
      return s;
    }
    var prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog) || "link");
    gl.useProgram(prog);
    this.prog = prog;
    this.aP = gl.getAttribLocation(prog, "aP");
    this.aC = gl.getAttribLocation(prog, "aC");
    this.uM = gl.getUniformLocation(prog, "uM");
    this.uT = gl.getUniformLocation(prog, "uT");
    this.uA = gl.getUniformLocation(prog, "uA");
    this.uFC = gl.getUniformLocation(prog, "uFC");
    this.uFF = gl.getUniformLocation(prog, "uFF");
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.disable(gl.CULL_FACE);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    this.dpr = 1;
    this.w = 0; this.h = 0;
  }
  Renderer.prototype.upload = function (gb) {
    var gl = this.gl;
    var vb = gl.createBuffer(), ib = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vb);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(gb.v), gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(gb.i), gl.STATIC_DRAW);
    return { vb: vb, ib: ib, n: gb.i.length };
  };
  Renderer.prototype.resize = function (cssW, cssH, dpr) {
    var gl = this.gl;
    this.dpr = dpr; this.w = cssW; this.h = cssH;
    var pw = Math.max(2, Math.round(cssW * dpr)), ph = Math.max(2, Math.round(cssH * dpr));
    if (this.canvas.width !== pw || this.canvas.height !== ph) {
      this.canvas.width = pw; this.canvas.height = ph;
    }
    gl.viewport(0, 0, pw, ph);
  };
  Renderer.prototype.begin = function (fogC, fogN, fogF) {
    var gl = this.gl;
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniform3f(this.uFC, fogC[0], fogC[1], fogC[2]);
    gl.uniform2f(this.uFF, fogN, fogF);
  };
  Renderer.prototype.draw = function (mesh, mvp, tint, alpha, blended) {
    var gl = this.gl;
    if (!mesh || !mesh.n || alpha <= 0.01) return;
    gl.uniformMatrix4fv(this.uM, false, mvp);
    gl.uniform3f(this.uT, tint[0], tint[1], tint[2]);
    gl.uniform1f(this.uA, clamp(alpha, 0, 1));
    if (blended) { gl.enable(gl.BLEND); gl.depthMask(false); }
    else { gl.disable(gl.BLEND); gl.depthMask(true); }
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vb);
    gl.vertexAttribPointer(this.aP, 3, gl.FLOAT, false, 24, 0);
    gl.vertexAttribPointer(this.aC, 3, gl.FLOAT, false, 24, 12);
    gl.enableVertexAttribArray(this.aP);
    gl.enableVertexAttribArray(this.aC);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.ib);
    gl.drawElements(gl.TRIANGLES, mesh.n, gl.UNSIGNED_SHORT, 0);
  };

  /* ============ مجسمات مشتركة للمؤثرات ============ */
  function sharedMeshes(R) {
    var g;
    g = new GB(); g.ringY(0, 0, 0, 13, 21, 22, "#ffffff"); R.ring = R.upload(g);
    g = new GB(); g.ringY(0, 0, 0, 6, 9.5, 18, "#ffffff"); R.ringSmall = R.upload(g);
    g = new GB(); g.blade(12, 31, -0.95, 0.95, 12, 5.5, [1, 1, 1]); R.slashArc = R.upload(g);
    g = new GB(); g.box(0, 0, 0, 2.6, 2.6, 2.6, "#ffffff"); R.cube = R.upload(g);
    g = new GB(); g.box(0, 0, 0, 5.4, 5.4, 5.4, "#ffffff"); R.orbCube = R.upload(g);
    /* مجسمات مؤثرات ثلاثية الأبعاد حقيقية */
    g = new GB(); g.archRing(17, 4.2, 5.2, 24, [1, 1, 1]); R.shock = R.upload(g);
    g = new GB(); g.archRing(7.75, 2, 2.4, 18, [1, 1, 1]); R.shockSmall = R.upload(g);
    g = new GB(); g.bipyramid(0.25, 1, 0.15, 2.8, 1.05, [1, 1, 1]); R.shard = R.upload(g);
    g = new GB(); g.bipyramid(0, 0, 1, 6.2, 1.7, [1, 1, 1]); R.bolt = R.upload(g);
    g = new GB(); g.sphere(5, 6, 10, [1, 1, 1]); R.flash = R.upload(g);
    g = new GB(); g.spire(8, 1.6, 0.8, -1.3, 0.6, 1.3, [1, 1, 1]); R.pillar = R.upload(g);
    /* نجمة وميض مجسّمة: 3 محاور + 4 أقطار بأشواك ماسية */
    g = new GB();
    g.bipyramid(1, 0, 0, 8.5, 1.7, [1, 1, 1]); g.bipyramid(0, 1, 0, 8.5, 1.7, [1, 1, 1]); g.bipyramid(0, 0, 1, 8.5, 1.7, [1, 1, 1]);
    g.bipyramid(1, 1, 1, 6, 1.3, [1, 1, 1]); g.bipyramid(1, 1, -1, 6, 1.3, [1, 1, 1]); g.bipyramid(1, -1, 1, 6, 1.3, [1, 1, 1]); g.bipyramid(-1, 1, 1, 6, 1.3, [1, 1, 1]);
    R.star = R.upload(g);
    /* صليب شفاء رأسي */
    g = new GB();
    g.quad([-2.4, -6, 0], [2.4, -6, 0], [2.4, 6, 0], [-2.4, 6, 0], hex2rgb("#ffffff"));
    g.quad([-6, -1.8, 0], [6, -1.8, 0], [6, 1.8, 0], [-6, 1.8, 0], hex2rgb("#ffffff"));
    R.heal = R.upload(g);
    /* ظل بيضاوي (لوح أفقي) */
    g = new GB();
    g.ringY(0, 0, 0, 0.1, 24, 16, "#000000");
    R.shadow = R.upload(g);
  }

  /* ============ مصنع المجسمات — شخصيات فوكسل بشرية ============
     الإحداثيات المحلية: الأقدام عند y=0، الطول الكلي ≈ 94.
     كل part: هندسة ثابتة في فضاء الوحدة + نقطة ارتكاز للتحريك. */
  function mixHex(a, b, t) {
    var A = hex2rgb(a), B = hex2rgb(b);
    return "#" + [0, 1, 2].map(function (i) {
      var v = Math.round((A[i] + (B[i] - A[i]) * t) * 255).toString(16);
      return v.length < 2 ? "0" + v : v;
    }).join("");
  }
  function buildCharParts(R, spec) {
    var f = F[spec.faction] || F.guardians;
    var _SG = window.SOLFBX || null;
    var _TC = (_SG && _SG.gearTierColor) ? _SG.gearTierColor : function (t) { var m = {1:"#b8c0c9",2:"#4ade80",3:"#38bdf8",4:"#a855f7",5:"#d946ef",6:"#f59e0b",7:"#ef4444"}; return m[Math.max(1, Math.min(7, t || 1))] || m[1]; };
    var _GD = spec.gd || null;
    var _GG = _GD ? (_GD.gear || {}) : {};
    var enemy = spec.side === 1 && !spec.boss;
    var outfit = spec.boss ? "#8a2233" : (enemy ? mixHex(f.color, f.colorDark, 0.42) : f.color);
    var trim = spec.boss ? "#3a0e1a" : (enemy ? "#2a1b10" : f.colorDark);
    var lite = f.colorLight;
    var skin = SKINS[hash(spec.name || "x") % SKINS.length];
    var pants = enemy ? "#241a10" : "#3b2a1d";
    var boots = "#1d1208";
    var steel = "#aeb8c2", steelL = "#d7dde3", steelD = "#7c8790";
    var gold = "#d4a941", wood = "#7a4e2a", blade = "#e4e9ee";
    var role = spec.role || "dps";
    var parts = [];
    function part(name, gb, piv) { parts.push({ name: name, mesh: R.upload(gb), piv: piv }); }

    /* --- ساقان (ارتكاز الورك y=26 — الإحداثيات نسبية للارتكاز) --- */
    var gl1 = new GB();
    gl1.box(0, -13, 0, 6.6, 22, 7, pants);
    gl1.box(0, -22.5, 0.6, 7.6, 7, 8.8, boots);
    part("legL", gl1, [-5.5, 26, 0]);
    var gr1 = new GB();
    gr1.box(0, -13, 0, 6.6, 22, 7, pants);
    gr1.box(0, -22.5, 0.6, 7.6, 7, 8.8, boots);
    part("legR", gr1, [5.5, 26, 0]);

    /* --- الجذع (ارتكاز الورك y=26 — إحداثيات نسبية) --- */
    var gt = new GB();
    gt.box(0, 12, 0, 19, 24, 12.5, outfit);
    gt.box(0, 12.6, 0, 20, 5.5, 13.4, trim);
    gt.box(0, 2.2, 0, 19.6, 3.6, 13.2, gold);
    gt.box(0, 22, 0, 12.5, 4.5, 12.6, lite);
    gt.box(-11.4, 21.5, 0, 6, 6.2, 13.2, trim);
    gt.box(11.4, 21.5, 0, 6, 6.2, 13.2, trim);
    if (role === "support" || role === "control") {
      gt.box(0, 4, 0, 21, 10, 13.6, trim);           /* تنورة الرداء فوق الورك */
      gt.box(0, 18, 0, 7, 9, 1.6, lite);             /* وشاح أمامي */
    }
if (role === "dps" && !spec.boss) gt.box(0, 16, 0, 6.5, 8, 1.5, gold); /* شعار صدر */
    if (_GG.armor && !spec.boss) {       /* درع مُجهَّز بلون شطبه */
      var gac = hex2rgb(_TC(_GG.armor.tier));
      gt.box(0, 13.5, 0, 20.2, 8.5, 13.4, gac);
      gt.box(-11.8, 21.5, 0, 7.4, 7.6, 14.2, gac);
      gt.box(11.8, 21.5, 0, 7.4, 7.6, 14.2, gac);
      gt.box(0, 17.2, 0, 6.5, 3.4, 14.1, [Math.min(1, gac[0] * 1.4 + 0.2), Math.min(1, gac[1] * 1.4 + 0.2), Math.min(1, gac[2] * 1.4 + 0.2)]);
    }
    if (_GG.cloak && !spec.boss) {       /* عباءة مُجهَّزة خلف الظهر */
      var clc = hex2rgb(_TC(_GG.cloak.tier));
      gt.box(0, 10, -8.9, 22, 30, 2.6, clc);
      gt.box(0, 24.5, -8.9, 24, 5.4, 3.1, [Math.min(1, clc[0] * 1.4 + 0.2), Math.min(1, clc[1] * 1.4 + 0.2), Math.min(1, clc[2] * 1.4 + 0.2)]);
    }
    if (role !== "support" && role !== "control" && role !== "tank" && role !== "dps" && !spec.boss) {
      gt.box(-8.5, 16, -9.2, 5, 13, 3.4, wood);              /* جعبة الرماة على الظهر */
      gt.box(-8.5, 23.8, -9.2, 5, 2.4, 3.4, "#d8c49a");      /* أطراف السهام */
    }
    if (spec.boss) {
      gt.box(0, 10, -8.6, 26, 34, 2.8, "#4a0f1a");   /* عباءة خلفية */
      gt.box(0, 25, -8.6, 28, 5, 3.4, "#8f2233");
    }
    part("torso", gt, [0, 26, 0]);

    /* --- الرأس (ارتكاز الرقبة y=49 — إحداثيات نسبية) --- */
    var gh = new GB();
    gh.box(0, 7, 0, 13, 13, 12, skin);
    gh.box(0, 14.2, 0, 14.4, 5.4, 13, spec.boss ? "#3a0e1a" : trim);
    gh.box(0, 11, 0, 14.8, 2.6, 13.2, spec.boss ? "#8f2233" : outfit);
    var eyeC = spec.boss ? "#ff2b2b" : "#1a0f0a";
    gh.box(-2.7, 7.4, 6.2, 2.1, 2.5, 1.2, eyeC);
    gh.box(2.7, 7.4, 6.2, 2.1, 2.5, 1.2, eyeC);
    if (spec.boss) {
      gh.box(-8, 17, 0, 3.4, 10, 3.4, "#4a0f1a", { ry: 0.45 });
      gh.box(8, 17, 0, 3.4, 10, 3.4, "#4a0f1a", { ry: -0.45 });
      gh.box(-5.6, 19.4, 0, 3.2, 5, 3.2, "#4a0f1a", { ry: 0.9 });
      gh.box(5.6, 19.4, 0, 3.2, 5, 3.2, "#4a0f1a", { ry: -0.9 });
      gh.box(0, 19.6, 0, 15, 3.4, 14, gold);        /* تاج */
      gh.box(0, 23.4, 0, 3.2, 4.5, 3.2, gold);
    } else {
      gh.box(0, 19.6, 0, 2.6, 4.4, 5.2, enemy ? trim : lite); /* عُرفة الخوذة */
    }
    if (_GG.helmet && !spec.boss) {      /* خوذة مُجهَّزة بلون شطبه */
      var ghc = hex2rgb(_TC(_GG.helmet.tier));
      gh.box(0, 16.4, 0, 15.2, 5.8, 14.1, ghc);
      gh.box(0, 20.8, 0, 3, 5.4, 3, [Math.min(1, ghc[0] * 1.4 + 0.2), Math.min(1, ghc[1] * 1.4 + 0.2), Math.min(1, ghc[2] * 1.4 + 0.2)]);
      gh.box(0, 12.8, 7.1, 13.4, 2, 1.4, [Math.min(1, ghc[0] * 1.35 + 0.15), Math.min(1, ghc[1] * 1.35 + 0.15), Math.min(1, ghc[2] * 1.35 + 0.15)]);
    }
    part("head", gh, [0, 49, 0]);

    /* --- الذراع اليسرى (+ درع للمحارف) --- */
    var gl2 = new GB();
    gl2.box(0, -9, 0, 5.8, 19, 6.2, trim);
    gl2.box(0, -20, 0, 5.2, 4.8, 5.6, skin);
    if (role === "tank") {
      gl2.box(-1, -14, 9, 3.2, 24, 17, steelD);
      gl2.box(-1, -14, 11.2, 2, 18, 13, steel);
      gl2.box(-1, -14, 12.6, 5.5, 9, 1.8, lite);
    }
    if (role === "control") {
      gl2.box(0, -16, 7.5, 7.4, 7.4, 7.4, lite);       /* كرة متوهجة بلون الفصيلة */
      gl2.box(0, -16, 7.5, 3.4, 3.4, 3.4, "#ffffff");
    }
    part("armL", gl2, [-11.5, 45, 0]);

    /* --- الذراع اليمنى + السلاح حسب الدور --- */
    var gr2 = new GB();
    gr2.box(0, -9, 0, 5.8, 19, 6.2, trim);
    gr2.box(0, -20, 0, 5.2, 4.8, 5.6, skin);
    var gwq = (_GG.weapon && !spec.boss) ? _GG.weapon : null;
    var gwC = gwq ? hex2rgb(_TC(gwq.tier)) : null;
    var gwL = gwq ? [Math.min(1, gwC[0] * 1.4 + 0.2), Math.min(1, gwC[1] * 1.4 + 0.2), Math.min(1, gwC[2] * 1.4 + 0.2)] : null;
    if (spec.boss) {
      gr2.box(0, -13, 0, 3.6, 22, 3.6, wood);
      gr2.box(0, 4, 0, 15, 12, 13, steel);
      gr2.box(0, 4, 0, 16.6, 6, 14, steelL);
      gr2.box(0, 13, 0, 5, 6, 5, gold);
    } else if (role === "dps") {
      gr2.box(0, -22, 0, 2.8, 7, 2.8, wood);
      gr2.box(0, -15.6, 0, 7.6, 2.4, 3.2, gold);
      gr2.box(0, -15.6, 1.9, 2.2, 2.2, 1.5, lite);      /* جوهرة نصل بلون الفصيلة */
      gr2.box(0, -1.5, 0, 4, 27, 2, gwC || blade);
      gr2.box(0, 14.5, 0, 2.4, 6, 1.4, gwL || steelL);
      if (gwq && (gwq.stars || 0) >= 2) gr2.box(0, -1.5, 2.4, 4.7, 28, 1, gwL);
    } else if (role === "tank") {
      gr2.box(0, -21, 0, 3, 26, 3, wood);
      gr2.box(0, -8, 0, 12, 9, 3.8, gwC || steel);
      gr2.box(0, -8, 0, 13.6, 4.5, 4.2, gwL || steelL);
      gr2.box(0, -3.4, 2.0, 1.8, 3.2, 1.8, steelL);     /* أشواك الفأس */
      gr2.box(0, -12.8, 2.0, 1.8, 3.2, 1.8, steelL);
    } else if (role === "support") {
      gr2.box(0, -23, 0, 2.6, 34, 2.6, wood);
      gr2.box(0, -7.5, 0, 4.4, 4.4, 4.4, gwC || gold);
      gr2.box(0, -2.5, 0, 7, 7, 7, gwC || gold);
      gr2.box(0, -2.5, 0, 3.2, 3.2, 3.2, "#fff3cf");
      gr2.box(0, -2.5, 0, 9.8, 1.7, 1.7, lite);          /* هالة عصا بلون الفصيلة */
    } else if (role === "control") {
      gr2.box(0, -23, 0, 2.6, 34, 2.6, "#5a4632");
      gr2.box(0, -2.5, 0, 7, 7, 7, gwC || lite);
      gr2.box(0, -2.5, 0, 3.2, 3.2, 3.2, "#ffffff");
    } else { /* رماة */
      gr2.box(0, -14, 0, 2.8, 30, 2.8, wood);
      gr2.box(-4.5, -1, 0, 6.5, 2.8, 2.8, wood);
      gr2.box(4.5, -1, 0, 6.5, 2.8, 2.8, wood);
      gr2.box(0, 12.5, 0, 2.8, 5, 2.8, gwC || steelD);
      if (gwq && (gwq.stars || 0) >= 3) gr2.box(0, 12.5, 1.9, 3.3, 5.5, 1, gwL);
    }
part("armR", gr2, [11.5, 45, 0]);
    if (_GD && _SG && !spec.boss) {      /* أجنحة: من معدة الجناح أو من مستوى أجنحة الحدادة (2+) */
      var _wt = _SG.gearWingsTier ? _SG.gearWingsTier(_GD) : 0;
      if (_wt) {
        var wtc = hex2rgb(_TC(_wt));
        var wtl = [Math.min(1, wtc[0] * 1.4 + 0.2), Math.min(1, wtc[1] * 1.4 + 0.2), Math.min(1, wtc[2] * 1.4 + 0.2)];
        var gwg = new GB();
        for (var sdw = -1; sdw <= 1; sdw += 2) {
          gwg.box(sdw * 10, 12, -7.5, 16, 3, 20, wtc, sdw * 0.4);
          gwg.box(sdw * 19, 17, -10, 11, 2.6, 14, wtc, sdw * 0.68);
          gwg.box(sdw * 26.5, 21.5, -11, 7, 2.2, 9, wtl, sdw * 0.85);
        }
        parts.push({ name: "gearWings", mesh: R.upload(gwg), piv: [0, 30, -2], follow: "torso" });
      }
      var _at = _SG.gearAuraTierOf ? _SG.gearAuraTierOf(_GD) : 0;
      if (_at) {                         /* هالة الأرضية من أفضل قطعة زخرفية */
        var au3 = new GB();
        au3.ringY(0, 0.7, 0, 12, 18.5, 22, hex2rgb(_TC(_at)));
        parts.unshift({ name: "gearAura", mesh: R.upload(au3), piv: [0, 0, 0] });
      }
    }
    return parts;
  }

  /* ============ حالة المشهد ============ */
  var ST = null;
  function newSceneState() {
    return {
      root: null, stage: null, ui: null, R: null, noGL: false,
      units: {}, order: [], floatsSeen: null, floatsSeenLen: 0,
      aliveMap: {}, hpMap: {}, enMap: {}, shieldMap: {}, hitMin: {},
      speed: 1, bt: 0, btWall: 0, ev: null,
      warnUid: null, isBoss: false, raf: 0, destroyed: false,
      cam: { yaw: 0, pitch: 0.66, dist: 1200, tx: 0, ty: 26, tz: 0 },
      yawUser: 0, pitchUser: 0, zoomUser: 1,
      low: 0, frames: 0, acc: 0, needResize: true, w: 420, h: 800,
      fx: [], theme: null, lastT: 0, hidden: false, fxClock: 0, VP: null
    };
  }

  function el(tag, cls, css) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (css) for (var k in css) e.style[k] = css[k];
    return e;
  }

  /* ---------- السماء (CSS خلف الكانفس) ---------- */
  function buildSky(th, root) {
    var sky = el("div", "s3d-sky");
    sky.style.background = "linear-gradient(180deg," + th.sky[0] + " 0%," + th.sky[1] + " 72%," + th.g2 + " 100%)";
    var disc = el("div", "s3d-sun" + (th.night ? " moon" : ""));
    disc.style.background = th.night ? "#f2ead8" : th.sun;
    if (!th.night) disc.style.boxShadow = "0 0 30px " + th.sun + "55, 0 0 90px " + th.sun + "22";
    else disc.style.boxShadow = "0 0 24px rgba(240,230,200,.35)";
    sky.appendChild(disc);
    if (!th.night) {
      /* سحاب نهاري خفيف (CSS رخيص جدًا) */
      sky.appendChild(el("i", "s3d-cloud c1"));
      sky.appendChild(el("i", "s3d-cloud c2"));
    }
    sky.appendChild(el("div", "s3d-horizon"));
    sky.appendChild(el("div", "s3d-dunes far"));
    sky.appendChild(el("div", "s3d-dunes near"));
    if (th.night) {
      var stars = el("div", "s3d-stars");
      for (var i = 0; i < 42; i++) {
        var s = el("i");
        s.style.left = (hash("s" + i) % 100) + "%";
        s.style.top = (hash("t" + i) % 55) + "%";
        s.style.animationDelay = ((hash("d" + i) % 30) / 10) + "s";
        stars.appendChild(s);
      }
      sky.appendChild(stars);
    }
    root.appendChild(sky);
  }

  /* ---------- أرضية المعركة: شبكة رملية + صفّان ---------- */
  function buildFloor(th, isArena) {
    var g = new GB();
    var TS = 56, X0 = -588, X1 = 588, Z0 = -448, Z1 = 448;
    var base = hex2rgb(th.g1), alt = mixc(base, hex2rgb(th.g2), 0.16);
    var dark = mixc(base, [0, 0, 0], 0.24), light = mixc(base, [1, 1, 1], 0.12);
    var lane = mixc(base, hex2rgb(th.p), 0.10);
    var cols = Math.round((X1 - X0) / TS), rows = Math.round((Z1 - Z0) / TS);
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        var x0 = X0 + c * TS, z0 = Z0 + r * TS;
        var col = ((r + c) % 2) ? alt : base;
        var zz = z0 + TS / 2, xx = x0 + TS / 2;
        if (xx < -30 && xx > -330) col = mixc(col, lane, 0.5);           /* ممر الأبطال */
        if (xx > 120) col = mixc(col, dark, 0.45);                    /* أرض الأعداء */
        if (r === 0 || r === rows - 1 || c === 0 || c === cols - 1) col = dark;
        var k = 0.92 + hash("f" + r + "_" + c) % 9 / 60;
        var cc = [col[0] * k, col[1] * k, col[2] * k];
        var p00 = [x0, 0, z0], p10 = [x0 + TS, 0, z0], p11 = [x0 + TS, 0, z0 + TS], p01 = [x0, 0, z0 + TS];
        g.quad(p00, p10, p11, p01, cc);
      }
    }
    g.ringY(0, 0.6, 0, 318, 344, 48, hex2rgb("#d4a941"));
    g.ringY(0, 0.5, 0, 0, 24, 24, mixc(base, hex2rgb("#d4a941"), 0.35));
    return g;
  }
  /* ---------- عناصر الديكور: تختلف حسب الثيم (v3) ---------- */
  function buildProps(th) {
    var g = new GB();
    var rockC = hex2rgb(th.d), rockT = mixc(hex2rgb(th.d), [1, 1, 1], 0.18);
    var cacA = hex2rgb("#3f7a3a"), cacB = hex2rgb("#54994e");
    var obsC = hex2rgb("#5a4632"), obsT = hex2rgb("#d4a941");
    var oasis = th === THEMES.oasis, shadow = th === THEMES.shadow,
        dark = th === THEMES.abyss || th === THEMES.boss, arena = th === THEMES.arena;

    function rock(x, z, s) {
      g.box(x, 16 * s, z, 62 * s, 32 * s, 46 * s, rockC);
      g.box(x - 18 * s, 34 * s, z + 6 * s, 40 * s, 20 * s, 34 * s, rockT);
      g.box(x + 20 * s, 30 * s, z - 8 * s, 30 * s, 16 * s, 28 * s, rockC);
    }
    function cactus(x, z, s) {
      g.box(x, 34 * s, z, 16 * s, 68 * s, 16 * s, cacA);
      g.box(x - 20 * s, 52 * s, z, 26 * s, 10 * s, 10 * s, cacB);
      g.box(x - 30 * s, 60 * s, z, 10 * s, 24 * s, 10 * s, cacB);
      g.box(x + 20 * s, 44 * s, z, 24 * s, 10 * s, 10 * s, cacB);
      g.box(x + 29 * s, 52 * s, z, 10 * s, 20 * s, 10 * s, cacA);
    }
    function palm(x, z, s) {
      var tr = hex2rgb("#7a5a30"), fr = hex2rgb("#3f9a4a"), frL = hex2rgb("#57b55e");
      g.box(x, 42 * s, z, 11 * s, 84 * s, 11 * s, tr);
      g.box(x + 3 * s, 78 * s, z + 2 * s, 9 * s, 14 * s, 9 * s, tr);
      g.box(x, 86 * s, z + 20 * s, 52 * s, 5 * s, 9 * s, fr, { ry: 0.5 });
      g.box(x, 86 * s, z - 20 * s, 52 * s, 5 * s, 9 * s, frL, { ry: -0.5 });
      g.box(x + 20 * s, 86 * s, z, 9 * s, 5 * s, 44 * s, fr, { ry: 0.2 });
      g.box(x - 20 * s, 86 * s, z, 9 * s, 5 * s, 40 * s, frL);
      g.box(x, 81 * s, z + 6 * s, 7 * s, 7 * s, 7 * s, hex2rgb("#8a6a3a"));
    }
    function pillar(x, z, s, broken) {
      var c = hex2rgb("#6a5a92"), cL = hex2rgb("#8d7fc0"), cap = hex2rgb("#4a3f70");
      g.box(x, 8 * s, z, 40 * s, 16 * s, 40 * s, cap);
      g.box(x, 46 * s, z, 26 * s, 62 * s, 26 * s, c);
      g.box(x + (broken ? 5 * s : 0), 88 * s, z - (broken ? 4 * s : 0), 22 * s, 24 * s, 22 * s, broken ? c : cL);
      if (broken) g.box(x - 10 * s, 108 * s, z + 4 * s, 16 * s, 16 * s, 16 * s, c);
      else g.box(x, 106 * s, z, 34 * s, 10 * s, 34 * s, cap);
    }
    function brazier(x, z, s) {
      g.box(x, 12 * s, z, 22 * s, 24 * s, 22 * s, hex2rgb("#2c2340"));
      g.box(x, 26 * s, z, 30 * s, 8 * s, 30 * s, hex2rgb("#3a2f56"));
      g.box(x, 34 * s, z, 14 * s, 12 * s, 14 * s, hex2rgb("#ff7a3a"));
      g.box(x, 38 * s, z, 7 * s, 7 * s, 7 * s, hex2rgb("#ffce8a"));
    }
    function boneSpike(x, z, s) {
      var bone = hex2rgb("#e6ddcc"), boneD = hex2rgb("#c9bda6");
      g.box(x, 44 * s, z, 10 * s, 88 * s, 10 * s, bone, { ry: 0.3 });
      g.box(x + 6 * s, 30 * s, z + 5 * s, 7 * s, 60 * s, 7 * s, boneD, { ry: -0.5 });
      g.box(x, 6 * s, z, 26 * s, 12 * s, 26 * s, boneD);
    }
    function skull(x, z, s) {
      var bone = hex2rgb("#e6ddcc");
      g.box(x, 12 * s, z, 26 * s, 24 * s, 24 * s, bone);
      g.box(x - 5 * s, 14 * s, z + 12.6 * s, 5 * s, 6 * s, 2 * s, hex2rgb("#2a1218"));
      g.box(x + 5 * s, 14 * s, z + 12.6 * s, 5 * s, 6 * s, 2 * s, hex2rgb("#2a1218"));
    }
    function column(x, z, s) {
      var c = hex2rgb("#cbb894"), cL = hex2rgb("#e2d4ae"), base = hex2rgb("#a8946a");
      g.box(x, 6 * s, z, 36 * s, 12 * s, 36 * s, base);
      g.box(x, 76 * s, z, 24 * s, 128 * s, 24 * s, c);
      g.box(x, 78 * s, z, 26 * s, 8 * s, 26 * s, cL);
      g.box(x, 144 * s, z, 34 * s, 10 * s, 34 * s, base);
    }
    function banner(x, z, s) {
      g.box(x, 55 * s, z, 5 * s, 110 * s, 5 * s, hex2rgb("#6e5a36"));
      g.box(x + 14 * s, 96 * s, z, 28 * s, 18 * s, 3 * s, hex2rgb("#d4a941"));
      g.box(x + 14 * s, 96 * s, z + 2.4 * s, 20 * s, 10 * s, 1.4 * s, hex2rgb("#f4e3b2"));
      g.box(x, 112 * s, z, 7 * s, 7 * s, 7 * s, obsT);
    }
    if (oasis) {
      palm(-370, -420, 1.15); palm(300, -465, 0.95); palm(-395, 140, 0.9);
      rock(225, -240, 0.8); rock(420, -170, 0.75); cactus(-190, -300, 0.7);
      cactus(300, 370, 0.75); rock(-300, 330, 0.8); palm(0, -555, 1.05);
      rock(-430, -40, 0.7);
    } else if (shadow) {
      pillar(-350, -430, 1.2, true); pillar(310, -450, 1.0, false); brazier(-200, -290, 0.9);
      pillar(-380, 130, 1.0, true); brazier(370, 100, 0.85); rock(230, -240, 0.75);
      pillar(290, 380, 0.85, false); brazier(0, -560, 1.0); rock(-430, -50, 0.7);
      skull(150, -490, 0.9);
    } else if (dark) {
      boneSpike(-360, -430, 1.2); boneSpike(305, -465, 0.95); skull(-195, -300, 1.0);
      boneSpike(230, -240, 0.8); skull(-380, 130, 0.9); boneSpike(380, 95, 0.85);
      rock(-300, 330, 0.8); boneSpike(0, -555, 1.1); skull(290, 375, 0.8);
      rock(-430, -40, 0.7);
    } else if (arena) {
      column(-340, -440, 1.25); column(330, -450, 1.1); banner(-210, -300, 0.9);
      banner(230, -245, 0.85); column(-390, 140, 1.0); column(385, 100, 0.95);
      banner(-300, 340, 0.8); banner(290, 390, 0.8); column(0, -560, 1.15);
      rock(430, -170, 0.7); rock(-435, -40, 0.7);
    } else {
      rock(-360, -430, 1.15); rock(305, -470, 0.9); cactus(-190, -300, 0.7);
      rock(225, -235, 0.8); rock(-385, 120, 1.0); cactus(375, 90, 0.9);
      rock(-300, 330, 0.8); cactus(285, 380, 0.7); rock(0, -560, 1.2);
      rock(430, -160, 0.75); cactus(-435, -30, 0.7);
    }
    for (var pv = 0; pv < g.v.length; pv += 6) { var ox_ = g.v[pv], oz_ = g.v[pv + 2]; g.v[pv] = -oz_; g.v[pv + 2] = ox_; }
    return g;
  }

  /* ---------- واجهة الوحدة (شريط الصحة يُسقط من الفضاء إلى الشاشة) ---------- */
  var ANCHOR_Y = 84, ANCHOR_Y_BOSS = 150;

  /* ---------- احتياطي بلا WebGL: شخصية SVG مسطحة ---------- */
  function pxOutline(rects) {
    var out = '<g fill="#1a0f0a" stroke="#1a0f0a" stroke-width="0.9" stroke-linejoin="round">';
    rects.forEach(function (r) {
      out += '<rect x="' + r[0] + '" y="' + r[1] + '" width="' + r[2] + '" height="' + r[3] + '"/>';
    });
    out += '</g>';
    rects.forEach(function (r) {
      out += '<rect x="' + r[0] + '" y="' + r[1] + '" width="' + r[2] + '" height="' + r[3] + '" fill="' + r[4] + '"/>';
    });
    return out;
  }
  function spriteSVG(u) {
    var f = F[u.faction] || F.guardians;
    var hs = hash(u.name || "x");
    var skin = SKINS[hs % 4], dk = "#1a0f0a", en = u.side === 1, boss = !!u.isBoss, role = u.role || "dps";
    var out = en && !boss ? f.colorDark : f.color;
    var outD = en && !boss ? "#3a1d12" : f.colorDark, outL = f.colorLight;
    var steel = "#aeb8c2", steelL = "#d7dde3", steelD = "#7c8790", gold = "#d4a941", blade = "#e4e9ee", wood = "#7a4e2a";
    var r = [];
    if (boss) { r.push([1, 6, 3, 13, "#4a0f1a"], [2, 7, 1, 11, "#6b1626"], [12, 6, 3, 13, "#4a0f1a"]); }
    else if (role === "tank" && !en) { r.push([2, 7, 1, 10, outD]); }
    r.push([5, 15, 2, 3, outD], [9, 15, 2, 3, outD], [5, 16, 2, 1, outL], [9, 16, 2, 1, outL]);
    r.push([4, 18, 4, 2, dk], [8, 18, 4, 2, dk], [4, 18, 4, 1, "#3b2a1d"], [8, 18, 4, 1, "#3b2a1d"]);
    r.push([2, 9, 2, 5, outD], [2, 13, 2, 2, skin]);
    r.push([4, 8, 8, 7, out], [4, 8, 8, 1, outL], [4, 14, 8, 1, outD], [4, 13, 8, 1, "#2a1b10"], [7, 13, 2, 1, gold]);
    r.push([3, 9, 2, 5, outD], [11, 9, 2, 5, outD]);
    if (role === "tank") { r.push([3, 8, 2, 2, steelL], [11, 8, 2, 2, steelL], [3, 8, 2, 1, steel], [11, 8, 2, 1, steel]); }
    else { r.push([3, 8, 2, 1, outL], [11, 8, 2, 1, outL]); }
    r.push([5, 2, 6, 6, skin], [5, 2, 6, 1, "#3b2a1d"], [4, 3, 1, 3, "#3b2a1d"], [11, 3, 1, 3, "#3b2a1d"]);
    r.push([7, 4, 1, 1, dk], [9, 4, 1, 1, dk]);
    if (boss) { r.push([7, 4, 1, 1, "#ff2b2b"], [9, 4, 1, 1, "#ff2b2b"]); }
    if (boss) {
      r.push([14, 6, 3, 3, "#c9a8ff"], [14, 6, 1, 1, "#fff"], [15, 9, 1, 3, "#c9a8ff55"]);
      r.push([3, 5, 10, 1, "#8f2233"]);
    } else if (en) {
      r.push([4, 1, 8, 1, f.colorDark], [5, 0, 6, 1, "#2a1b10"]);
      r.push([15, 2, 2, 9, blade], [15, 2, 1, 9, "#f4f8fb"], [14, 6, 4, 1, "#8a5a2a"], [15, 7, 2, 2, "#5a3720"]);
      r.push([0, 8, 3, 7, "#4a3020"], [0, 8, 3, 1, "#6b4a30"], [1, 10, 1, 3, f.colorDark]);
      r.push([4, 14, 8, 1, "#1d1208"]);
    } else {
      if (role === "support") {
        r.push([14, 3, 2, 2, gold], [14, 5, 1, 6, wood], [13, 2, 4, 1, gold]);
        r.push([4, 10, 8, 1, outD], [6, 10, 4, 1, outL]);
      } else if (role === "control") {
        r.push([14, 2, 3, 3, "#9be3ff"], [15, 5, 1, 5, "#5aa7e8"], [13, 1, 5, 1, "#9be3ff"]);
        r.push([4, 10, 8, 1, outD], [6, 10, 4, 1, outL]);
      } else if (role === "dps") {
        r.push([4, 1, 8, 1, outL], [3, 0, 1, 3, outL], [3, 0, 1, 1, gold]);
        r.push([15, 1, 2, 11, blade], [15, 1, 1, 11, "#f4f8fb"], [17, 1, 1, 11, steelD], [14, 6, 4, 1, gold], [15, 7, 2, 2, "#5a3720"], [15, 9, 2, 1, gold]);
        r.push([4, 10, 8, 1, outD], [6, 10, 4, 1, outL]);
      } else {
        r.push([14, 4, 3, 9, steel], [14, 4, 1, 9, steelL], [13, 3, 5, 1, steelD], [14, 13, 3, 1, gold]);
        r.push([4, 10, 8, 1, outD], [6, 10, 4, 1, outL]);
      }
    }
    var flip = en ? ' transform="scale(-1,1) translate(-21,0)"' : "";
    return '<svg class="s3d-sprite" viewBox="-1 -5 22 27" shape-rendering="crispEdges" preserveAspectRatio="xMidYMax meet" style="overflow:visible"><g' + flip + '>' + pxOutline(r) + '</g></svg>';
  }

  /* ---------- رسم معدات البطل على المجسم ثلاثي الأبعاد (FBX) ---------- */
  var WHITE_T = [1, 1, 1];
  function drawGear3D(st, U, VP, t, tint, ox, oz) {
    var gm = U.fx.gear;
    if (!gm) return;
    var a = U.alphaGL !== undefined ? U.alphaGL : 1;
    if (a <= 0.02) return;
    var s = U.scale;
    /* هالة الأرضية من أفضل قطعة زخرفية */
    if (gm.aura) {
      var pu = 0.7 + 0.3 * Math.sin(t * 3.1 + U.phase);
      var ac = gm.auraC || [1, 0.85, 0.35];
      m4Mul(OFF1, m4T(U.W.x + ox, 0.8, U.W.z + oz), m4S(s, s, s));
      m4Mul(MVP_M, VP, OFF1);
      st.R.draw(gm.aura, MVP_M, [ac[0] * pu, ac[1] * pu, ac[2] * pu], a * 0.72, true);
      if (gm.aura2) st.R.draw(gm.aura2, MVP_M, ac, a * 0.5 * pu, true);
    }
    if (!U.alive && st.fxClock - U.dieT > 0.5) return;
    /* الخوذة تتبع عظمة الرأس */
    if (gm.helmet) {
      var hay = (gm.helmAnchorY != null) ? gm.helmAnchorY : null;
      if (hay != null) {
        m4Mul(OFF1, UNIT_M, m4T(0, hay, 0));
        m4Mul(MVP_M, VP, OFF1);
        st.R.draw(gm.helmet, MVP_M, WHITE_T, a, false);
      } else {
        var hp = U.fx.boneP("Head");
        if (hp) {
          m4Mul(OFF1, UNIT_M, m4T(hp[0], hp[1] + (gm.helmUp || 4), hp[2]));
          m4Mul(MVP_M, VP, OFF1);
          st.R.draw(gm.helmet, MVP_M, WHITE_T, a, false);
        }
      }
    }
    /* الجناحان خلف الظهر برفرفة حية */
    if (gm.wings) {
      var way = (gm.wingAnchorY != null) ? gm.wingAnchorY : null;
      var tp = way != null ? [0, way, 0] : (U.fx.boneP("Torso") || U.fx.boneP("Body") || U.fx.boneP("Abdomen") || U.fx.boneP("Hips"));
      if (tp) {
        var flap = Math.sin(t * 3.15 + U.phase) * (0.17 + (U.lunge ? 0.16 : 0.03));
        var wpu = U.ready ? 1.16 : 1;
        m4Mul(OFF1, UNIT_M, m4T(tp[0], tp[1] + (way != null ? 0 : (gm.wingUp || 0)), tp[2]));
        m4Mul(OFF1, OFF1, m4Rx(flap));
        m4Mul(MVP_M, VP, OFF1);
        st.R.draw(gm.wings, MVP_M, [wpu, wpu, wpu * 0.97], a * 0.97, false);
      }
    }
    /* الدرع والقفازات والأحذية مجسمات ثلاثية الأبعاد مثبتة على الجسم. */
    if (gm.chest) { m4Mul(OFF1, UNIT_M, m4T(0, gm.chestY || 0, gm.chestZ || 0)); m4Mul(MVP_M, VP, OFF1); st.R.draw(gm.chest, MVP_M, WHITE_T, a, false); }
    if (gm.gloves) {
      var ghR = U.fx.boneP("Hand.R") || U.fx.boneP("Weapon.R"), ghL = U.fx.boneP("Hand.L") || U.fx.boneP("Weapon.L");
      if (ghR) { m4Mul(OFF1, UNIT_M, m4T(ghR[0], ghR[1], ghR[2])); m4Mul(MVP_M, VP, OFF1); st.R.draw(gm.gloves, MVP_M, WHITE_T, a, false); }
      if (ghL) { m4Mul(OFF1, UNIT_M, m4T(ghL[0], ghL[1], ghL[2])); m4Mul(MVP_M, VP, OFF1); st.R.draw(gm.gloves, MVP_M, WHITE_T, a, false); }
      if (!ghR && !ghL) { m4Mul(OFF1, UNIT_M, m4T(0, gm.gloveY || 0, 0)); m4Mul(MVP_M, VP, OFF1); st.R.draw(gm.gloves, MVP_M, WHITE_T, a, false); }
    }
    if (gm.boots) { m4Mul(OFF1, UNIT_M, m4T(0, gm.bootY || 0, 0)); m4Mul(MVP_M, VP, OFF1); st.R.draw(gm.boots, MVP_M, WHITE_T, a, false); }
    if (gm.offhand) {
      var ohP = U.fx.boneP("Weapon.L") || U.fx.boneP("Hand.L");
      m4Mul(OFF1, UNIT_M, ohP ? m4T(ohP[0], ohP[1], ohP[2]) : m4T(-U.scale * 12, U.scale * 38, U.scale * 5));
      m4Mul(MVP_M, VP, OFF1); st.R.draw(gm.offhand, MVP_M, WHITE_T, a, false);
    }
    /* توهج السلاح عند اليد */
    if (gm.cape1) { m4Mul(OFF1, UNIT_M, m4T(0, 0, 0)); m4Mul(MVP_M, VP, OFF1); st.R.draw(gm.cape1, MVP_M, WHITE_T, a, false); }
    if (gm.kweapon && U.alive && U.fx.boneM) {
      var kbm = U.fx.boneM("Weapon.R");
      if (kbm) {
        KW_M.set([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, kbm[3], kbm[7], kbm[11], 1]);
        m4Mul(OFF1, UNIT_M, KW_M); m4Mul(MVP_M, VP, OFF1); st.R.draw(gm.kweapon, MVP_M, WHITE_T, a, false);
      }
    }
    if (gm.wglow && U.alive && !gm.kweapon) {
      var wp = U.fx.boneP("Weapon.R");
      if (wp) {
        var wsp = 0.5 + 0.5 * Math.sin(t * 5.2 + U.phase * 2);
        var wc = gm.wc || [1, 0.85, 0.35];
        m4Mul(OFF1, UNIT_M, m4T(wp[0], wp[1], wp[2] + 2.5));
        m4Mul(MVP_M, VP, OFF1);
        st.R.draw(gm.wglow, MVP_M, wc, a * (0.5 + 0.38 * wsp), true);
      }
    }
  }

  function buildUnit(st, u, L) {
    var en = u.side === 1, boss = !!u.isBoss;
    var slot = el("div", "s3d-uslot");
    slot.setAttribute("data-uid", u.uid);
    var bill = el("div", "s3d-bill" + (en ? " s3d-en" : "") + (boss ? " s3d-boss" : ""));
    bill.style.width = (boss ? 190 : 112) + "px";
    if (!st.noGL) bill.style.marginLeft = (-(boss ? 190 : 112) / 2) + "px"; /* توسيط الشريط على الشخصية */
    var bar = el("div", "s3d-hud");
    var nameP = el("div", "s3d-name");
    nameP.textContent = u.name;
    var adv = el("span", "s3d-adv"); adv.style.display = "none"; nameP.appendChild(adv);
    bar.appendChild(nameP);
    var track = el("div", "s3d-bar-track");
    var fill = el("div", "s3d-bar-fill" + (en ? " e" : ""));
    var hpT = el("b"); hpT.textContent = fmtN(u.maxHp);
    track.appendChild(fill); track.appendChild(hpT);
    bar.appendChild(track);
    var enT = el("div", "s3d-en-track");
    var enF = el("div", "s3d-en-fill");
    enT.appendChild(enF);
    bar.appendChild(enT);
    var shield = el("div", "s3d-shield"); shield.style.display = "none";
    bar.appendChild(shield);
    bill.appendChild(bar);
    var fhost = el("div", "s3d-float-host");
    bill.appendChild(fhost);
    slot.appendChild(bill);
    st.ui.appendChild(slot);

    var spec = { faction: u.faction, role: (L && L.role) || u.role || "dps", side: en ? 1 : 0, boss: boss, name: u.name };
    spec.gd = (!en && window.SOLFBX && window.SOLFBX.gearProvider) ? (function () { try { return window.SOLFBX.gearProvider(u.name); } catch (e) { return null; } })() : null;
    if (st.noGL) {
      var body = el("div", "s3d-body");
      body.style.setProperty("--bob-d", ((u.uid % 5) * 0.17) + "s");
      body.innerHTML = spriteSVG({ faction: u.faction, name: u.name, side: en ? 1 : 0, role: spec.role, isBoss: boss, uid: u.uid });
      bill.appendChild(body);
    }
    var U = {
      slot: slot, bill: bill, fill: fill, hpT: hpT, enF: enF, shield: shield,
      name: nameP, adv: adv, fhost: fhost,
      en: en, boss: boss, L: L, W: unitWorld(L),
      spec: spec, parts: null, scale: boss ? 2.2 : 1.45,
      anchorY: (boss ? 66 * 2.2 + 26 : 66 * 1.45 + 20),
      face: en ? -Math.PI / 2 : Math.PI / 2,
      phase: (u.uid % 7) * 0.9,
      flash: 0, alive: true, dieT: 0, fadeT: 0, hidden: false, ready: false,
      lunge: null, fall: 0, hop: 0
    };
    /* مسار موحّد للشخصيات: SOLFBX هو المصدر الأساسي للمجسم والتحريك.
       لا ننشئ هندسة GB القديمة إلا عند تعذّر تحميل نموذج FBX؛ هذا يمنع
       رفع مجسمين لكل وحدة واستهلاك ذاكرة GPU بلا استخدام. */
    U.fx = null;
    if (st.R && !st.noGL && en && window.SOLMOB && window.SOLMOB.ok) {
      try {
        U.fx = window.SOLMOB.make(
          st.R.gl,
          { name: u.name, role: spec.role, faction: u.faction, side: u.side },
          boss
        );
      } catch (e) { U.fx = null; }
    }
    /* KayKit characters are now loaded into the same SOL3D draw pipeline.
       SOLMOB remains first for creature-specific monsters; SOLFBX stays as a
       safe fallback if a KayKit mesh is unavailable. */
    if (st.R && !st.noGL && !U.fx && window.SOLKAY && window.SOLKAY.ok) {
      try { U.fx = window.SOLKAY.make(st.R.gl, { name:u.name, role:spec.role, faction:u.faction, side:u.side }, boss); }
      catch (e) { U.fx = null; }
    }
    if (st.R && !st.noGL && !U.fx && window.SOLFBX && window.SOLFBX.ok) {
      try { U.fx = window.SOLFBX.make(st.R.gl, { name:u.name, role:spec.role, faction:u.faction, side:u.side }, boss); }
      catch (e) { U.fx = null; }
    }
    /* توافق خلفي: هندسة Low-Poly المحلية عند فشل SOLFBX فقط. */
    if (st.R && !st.noGL && !U.fx) U.parts = buildCharParts(st.R, spec);
    /* ===== المطيات: تُركّب على الأبطال المسجلين فقط ===== */
    U.mnt = null;
    /* المطيات للأبطال فقط: لا يكفي استبعاد الزعيم، لأن الوحوش العادية قد لا تكون Boss. */
    var heroRegistry = window.__solHeroes || {};
    var unitBaseName = String(u.name || "").split("·")[0].trim();
    var isHeroUnit = Object.keys(heroRegistry).some(function (heroKey) {
      var heroDef = heroRegistry[heroKey];
      var heroName = heroDef && String(heroDef.name || "").trim();
      return heroName && (heroName === String(u.name || "").trim() || heroName === unitBaseName);
    });
    if (st.R && !st.noGL && U.fx && !boss && isHeroUnit && window.SOLMNT && window.SOLMNT.ok) {
      try {
        U.mnt = window.SOLMNT.build(st.R.gl, u.name, en);
        if (U.mnt) U.anchorY += U.mnt.lift * U.scale;
      } catch (e) { U.mnt = null; }
    }
    st.units[u.uid] = U;
    st.order.push(u.uid);
    return U;
  }

  /* ---------- الكاميرا: إطار يُظهر الجميع + سحب وإصبعين ---------- */
  function fitCamera(st) {
    var minx = 1e9, maxx = -1e9, minz = 1e9, maxz = -1e9, any = false;
    for (var uid in st.units) {
      var W = st.units[uid].W; any = true;
      if (W.x < minx) minx = W.x; if (W.x > maxx) maxx = W.x;
      if (W.z < minz) minz = W.z; if (W.z > maxz) maxz = W.z;
    }
    if (!any) { minx = -300; maxx = 300; minz = -250; maxz = 250; }
    var spanX = (maxx - minx) / 2 + 120, spanZ = (maxz - minz) / 2 + 90;
    var tF = Math.tan(25 * Math.PI / 180);
    var aspect = Math.max(0.35, st.w / Math.max(1, st.h));
    var needX = spanX / (tF * aspect);
    var needZ = spanZ * Math.sin(st.cam.pitch) / tF;
    /* مسحوبة للوراء لتظهر الشخصيات كلها كما طلب اللاعب */
    st.cam.dist = clamp(Math.max(needX, needZ) * 0.95 + 40, 600, 2700);
    st.cam.tx = (minx + maxx) / 2;
    st.cam.tz = (minz + maxz) / 2;
    st.cam.ty = 24;
  }
  function bindCameraInput(st) {
    var stage = st.stage;
    var ptrs = {}, pinch0 = 0, zoom0 = 1, moved = 0, downT = 0, lastTap = 0;
    stage.addEventListener("pointerdown", function (e) {
      ptrs[e.pointerId] = [e.clientX, e.clientY];
      moved = 0; downT = performance.now();
      st.focus = null; /* لمسة اللاعب تلغي تركيز المهارة فورًا */
      var ks = Object.keys(ptrs);
      if (ks.length === 2) { pinch0 = pdist(); zoom0 = st.zoomUser; }
    });
    function pdist() {
      var ks = Object.keys(ptrs);
      var a = ptrs[ks[0]], b = ptrs[ks[1]];
      return Math.hypot(a[0] - b[0], a[1] - b[1]);
    }
    stage.addEventListener("pointermove", function (e) {
      var p = ptrs[e.pointerId];
      if (!p) return;
      var dx = e.clientX - p[0], dy = e.clientY - p[1];
      p[0] = e.clientX; p[1] = e.clientY;
      moved += Math.abs(dx) + Math.abs(dy);
      var ks = Object.keys(ptrs);
      if (ks.length === 1) {
        st.yawUser = clamp(st.yawUser + dx * 0.0042, -0.62, 0.62);
        st.pitchUser = clamp(st.pitchUser + dy * 0.0032, -0.20, 0.24);
      } else if (ks.length === 2 && pinch0 > 0) {
        var d = pdist();
        if (d > 8) st.zoomUser = clamp(zoom0 * pinch0 / d, 0.55, 2.0);
      }
    });
    function up(e) {
      delete ptrs[e.pointerId];
      if (moved < 12 && performance.now() - downT < 260) {
        var now = performance.now();
        if (now - lastTap < 340) { /* نقر مزدوج: إعادة الكاميرا */
          st.yawUser = 0; st.pitchUser = 0; st.zoomUser = 1; lastTap = 0;
        } else lastTap = now;
      }
      if (Object.keys(ptrs).length < 2) pinch0 = 0;
    }
    stage.addEventListener("pointerup", up);
    stage.addEventListener("pointercancel", up);
    stage.addEventListener("wheel", function (e) {
      e.preventDefault();
      st.zoomUser = clamp(st.zoomUser * (e.deltaY > 0 ? 1.07 : 0.93), 0.55, 2.0);
    }, { passive: false });
  }

  /* ---------- مؤثرات ثلاثية الأبعاد ---------- */
  var FXCAP = 260;
  var FXS = 1.45; /* تكبير المؤثرات لتُرى بوضوح من الكاميرا البعيدة */
  var rgbCache = {};
  function rgb(h) { if (!rgbCache[h]) rgbCache[h] = hex2rgb(h); return rgbCache[h]; }
  function worldFromLayout(L) {
    return unitWorld({ x: L.x, y: L.y, side: L.side, big: L.big, isBoss: L.big });
  }
  function addFx(st, e) {
    if (st.fx.length >= (st.low === 2 ? 40 : FXCAP)) st.fx.shift();
    st.fx.push(e);
  }
  function spawnFxBase(st, f) {
    st.fxTotal = (st.fxTotal || 0) + 1;
    if (!st.R || st.noGL) return;
    var to = f.to || f.from, from = f.from || f.to;
    if (!to) return;
    var P2 = worldFromLayout(to), P1 = worldFromLayout(from);
    var sp = clamp(st.speed || 1, 1, 4);
    var dl = (st.fxClock || 0) + (f.delay || 0) / sp, c = f.c || "#ffffff";
    var kind = f.t;
    if ((kind === "impact" && f.v !== "hit") || kind === "ring") {
      addFx(st, { kind: "ring", mesh: st.R.shock, x: P2.x, z: P2.z, y: 1.6, c: rgb(c), s: (f.s || 1) * (kind === "ring" ? 1.5 : 1), t0: dl, dur: 0.5 / sp });
    } else if (kind === "slash") {
      addFx(st, { kind: "slash", mesh: st.R.slashArc, x: P2.x * 0.65 + P1.x * 0.35, z: P2.z * 0.65 + P1.z * 0.35, y: 42, c: rgb(c), s: (f.s || 1), roll: (hash("sl" + f.id) % 100) / 100 * Math.PI * 2, t0: dl, dur: 0.3 / sp });
    } else if (kind === "bullet" || kind === "orb") {
      var orb = kind === "orb";
      var FLY = function (o) { var r = { kind: "fly", P1: P1, P2: P2, h: f.h === undefined ? (orb ? 62 : 26) : f.h, y0: f.y0 || 0, t0: dl, dur: 0.36 / sp }, k2; for (k2 in o) r[k2] = o[k2]; addFx(st, r); };
      if (f.v === "arrow") {            /* سهم: عود + رأس معدني + ريش متصالب */
        FLY({ mesh: st.R.bolt, c: rgb("#d9b98a"), s: 1, sx: 0.2, sy: 0.2, sz: 2.2, pitch: 1 });
        FLY({ mesh: st.R.bolt, c: rgb("#f4f8fb"), s: 1, sx: 0.5, sy: 0.5, sz: 0.85, off: 13.5, pitch: 1 });
        FLY({ mesh: st.R.bolt, c: rgb(c), s: 1, sx: 1.8, sy: 0.12, sz: 0.6, off: -11, pitch: 1 });
        FLY({ mesh: st.R.bolt, c: rgb(c), s: 1, sx: 0.12, sy: 1.8, sz: 0.6, off: -11, pitch: 1 });
      } else if (f.v === "fire") {      /* كرة نار: نواة برتقالية + قلب ساخن */
        FLY({ mesh: st.R.flash, c: rgb("#ff5a14"), s: 1.3 });
        FLY({ mesh: st.R.flash, c: rgb("#ffd35a"), s: 0.85, off: 1.5 });
        FLY({ mesh: st.R.flash, c: rgb("#fff6c8"), s: 0.45, off: 2.2 });
      } else {
        FLY({ mesh: orb ? st.R.flash : st.R.bolt, c: rgb(c), s: orb ? 0.85 : 0.85, spin: orb ? 6 : 0 });
        if (orb) FLY({ mesh: st.R.flash, c: rgb("#ffffff"), s: 0.42 });
      }
    } else if (kind === "muzzle") {
      addFx(st, { kind: "star", mesh: st.R.star, x: P1.x, z: P1.z, y: 52, c: rgb(c || "#ffd35a"), s: (f.s || 1), t0: dl, dur: 0.24 / sp });
    } else if (kind === "dust") {
      for (var i = 0; i < 5; i++) {
        var an = (hash("d" + f.id + i) % 628) / 100;
        addFx(st, { kind: "dust", mesh: st.R.cube, x: P2.x, z: P2.z, y: 4, vx: Math.cos(an) * 46, vz: Math.sin(an) * 46, vy: 26, c: rgb(thDust(st)), s: 1.1, t0: dl, dur: 0.6 / sp });
      }
    } else if (kind === "spark") {
      for (var j = 0; j < 6; j++) {
        var a2 = (hash("k" + f.id + j) % 628) / 100;
        addFx(st, { kind: "spark", mesh: st.R.shard, x: P2.x, z: P2.z, y: 30, vx: Math.cos(a2) * 74, vz: Math.sin(a2) * 74, vy: 90 + (hash("v" + j) % 50), c: rgb(c || "#ffd35a"), s: 0.7, t0: dl, dur: 0.55 / sp });
      }
    } else if (kind === "heal") {
      for (var m = 0; m < 4; m++) {
        addFx(st, { kind: "heal", mesh: st.R.heal, x: P2.x + (hash("h" + m) % 40 - 20), z: P2.z + (hash("g" + m) % 30 - 15), y: 8, c: rgb(f.c || "#5dff9a"), s: 1, t0: dl + m * 0.05, dur: 0.7 / sp });
      }
    }
  }
  function spawnFx(st, f) {
    spawnFxBase(st, f);
    try { pxDispatch(st, f); } catch (ePX) {}
    if (!st.R || st.noGL) return;
    var to = f.to || f.from, from = f.from || f.to;
    if (!to) return;
    var P2 = worldFromLayout(to), P1 = worldFromLayout(from);
    var sp = clamp(st.speed || 1, 1, 4), dl = (st.fxClock || 0) + (f.delay || 0) / sp;
    var c = f.c || "#ffffff", cc = rgb(c), pw = f.s || 1, kind = f.t, i, an;
    function spark(n, spd, up, sz, col, dur) {
      for (var k = 0; k < n; k++) {
        an = (hash("x" + f.id + k) % 628) / 100;
        addFx(st, { kind: "spark", mesh: st.R.shard, x: P2.x, z: P2.z, y: 26, vx: Math.cos(an) * spd, vz: Math.sin(an) * spd, vy: up + (hash("u" + k) % 40), c: col, s: sz, t0: dl, dur: dur / sp });
      }
    }
    if (kind === "impact") {
      addFx(st, { kind: "star", mesh: st.R.flash, x: P2.x, z: P2.z, y: 34, c: mixc(cc, [1, 1, 1], 0.55), s: 0.55 + pw * 0.5, t0: dl, dur: 0.26 / sp });
      if (f.v === "hit") {
        spark(6, 55, 80, 1.3, mixc(cc, [1, 1, 1], 0.35), 0.5);
        addFx(st, { kind: "ring", mesh: st.R.shockSmall, x: P2.x, z: P2.z, y: 1.4, c: cc, s: 1.2, t0: dl, dur: 0.38 / sp });
      }
      if (f.v !== "hit") {
        addFx(st, { kind: "ring", mesh: st.R.shock, x: P2.x, z: P2.z, y: 1.4, c: cc, s: pw * 2.1, t0: dl + 0.05 / sp, dur: 0.6 / sp });
        spark(Math.round(5 + pw * 4), 40 + pw * 26, 70, 1.5, cc, 0.6);
        spark(3, 30, 40, 1.9, rgb(thDust(st)), 0.7);
      }
      if (pw >= 1.5) {
        addFx(st, { kind: "star", mesh: st.R.star, x: P2.x, z: P2.z, y: 62, c: rgb("#ffe9a0"), s: pw * 1.2, t0: dl, dur: 0.32 / sp });
        addFx(st, { kind: "ring", mesh: st.R.shock, x: P2.x, z: P2.z, y: 1.6, c: rgb("#ffd35a"), s: pw * 1.4, t0: dl + 0.1 / sp, dur: 0.55 / sp });
      }
      if (pw >= 2) {
        addFx(st, { kind: "beam", mesh: st.R.pillar, x: P2.x, z: P2.z, y: 0, c: cc, s: 8 + pw * 2, sy: 52, t0: dl, dur: 0.65 / sp });
        addFx(st, { kind: "ring", mesh: st.R.shock, x: P2.x, z: P2.z, y: 1.8, c: rgb("#ffffff"), s: pw * 1.1, t0: dl + 0.18 / sp, dur: 0.6 / sp });
        spark(10, 60, 120, 1.8, rgb("#ffd35a"), 0.8);
      }
      if (f.v === "fire") {            /* انفجار كرة النار */
        addFx(st, { kind: "star", mesh: st.R.flash, x: P2.x, z: P2.z, y: 30, c: rgb("#ff7a1a"), s: pw * 1.4 + 0.9, t0: dl, dur: 0.4 / sp });
        addFx(st, { kind: "ring", mesh: st.R.shock, x: P2.x, z: P2.z, y: 1.5, c: rgb("#ff5a1f"), s: pw * 2.4, t0: dl + 0.04 / sp, dur: 0.62 / sp });
        var EC = [rgb("#ff4d12"), rgb("#ff8a2b"), rgb("#ffc94a")];
        for (var ei = 0; ei < 9; ei++) { var ea = (hash("e" + f.id + ei) % 628) / 100; addFx(st, { kind: "spark", mesh: st.R.shard, x: P2.x, z: P2.z, y: 28, vx: Math.cos(ea) * 70, vz: Math.sin(ea) * 70, vy: 100 + (ei % 4) * 25, c: EC[ei % 3], s: 1.9, t0: dl, dur: 0.65 / sp }); }
      } else if (f.v === "arrow") {    /* شظايا غرز السهم */
        spark(5, 34, 55, 1.0, rgb("#d9b98a"), 0.45);
      }
      /* ارتداد سلس للهدف بعيدًا عن المهاجم */
      for (var uid in st.units) {
        var U = st.units[uid];
        if (Math.abs(U.W.x - P2.x) < 0.6 && Math.abs(U.W.z - P2.z) < 0.6) {
          var nx = P2.x - P1.x, nz = P2.z - P1.z, nl = Math.hypot(nx, nz) || 1, mag = 5 + pw * 5;
          U.rec = { t0: dl, dur: 0.3 / sp, dx: nx / nl * mag, dz: nz / nl * mag };
          break;
        }
      }
    } else if (kind === "slash") {
      addFx(st, { kind: "slash", mesh: st.R.slashArc, x: P2.x, z: P2.z, y: 36, c: rgb("#ffffff"), s: (f.s || 1) * 0.8, roll: (hash("sb" + f.id) % 100) / 100 * Math.PI * 2 + 0.6, t0: dl + 0.06 / sp, dur: 0.26 / sp });
    } else if (kind === "ring") {
      if (pw >= 2.4) {
        addFx(st, { kind: "beam", mesh: st.R.pillar, x: P2.x, z: P2.z, y: 0, c: rgb("#ffe27a"), s: 6, sy: 46, t0: dl, dur: 0.7 / sp });
        spark(8, 20, 110, 1.6, rgb("#ffe27a"), 0.8);
      } else {
        spark(6, 14, 70, 1.4, cc, 0.7);
      }
    } else if (kind === "heal") {
      addFx(st, { kind: "ring", mesh: st.R.shockSmall, x: P2.x, z: P2.z, y: 1.6, c: cc, s: 1.7, t0: dl, dur: 0.6 / sp });
      addFx(st, { kind: "beam", mesh: st.R.pillar, x: P2.x, z: P2.z, y: 0, c: cc, s: 5, sy: 30, t0: dl, dur: 0.55 / sp });
    } else if (kind === "beam") {
      addFx(st, { kind: "beam", mesh: st.R.pillar, x: P2.x, z: P2.z, y: 0, c: cc, s: 5 + pw * 4, sy: 34 + pw * 20, t0: dl, dur: 0.7 / sp });
      spark(Math.round(3 + pw * 2), 16, 100, 1.4, cc, 0.7);
    } else if (kind === "aura") {
      var aN = Math.max(3, Math.round(8 * pw));
      for (i = 0; i < aN; i++) {
        an = i / aN * Math.PI * 2;
        addFx(st, { kind: "heal", mesh: st.R.heal, x: P2.x + Math.cos(an) * 17, z: P2.z + Math.sin(an) * 13, y: 6, c: cc, s: 0.9, t0: dl + i * 0.035 / sp, dur: 0.8 / sp });
      }
      addFx(st, { kind: "ring", mesh: st.R.shockSmall, x: P2.x, z: P2.z, y: 1.5, c: cc, s: 1.5, t0: dl, dur: 0.6 / sp });
    } else if (kind === "sk") {
      try { skFx(st, f, P1, P2, dl, sp, cc, pw); } catch (eSk) { try { console.warn("skFx", eSk); } catch (e9) {} }
    } else if (kind === "bullet" || kind === "orb") {
      var big = kind === "orb", isF = f.v === "fire", isA = f.v === "arrow";
      var dur0 = (isF ? 0.4 : 0.36) / sp, h0 = f.h === undefined ? (big ? 62 : 26) : f.h, nT = isF ? 12 : (isA ? 4 : 6);
      var FCOL = [rgb("#ff4d12"), rgb("#ff8a2b"), rgb("#ffc94a")];
      for (i = 1; i <= nT; i++) {
        var qq = i / (nT + 1);
        addFx(st, { kind: "spark", mesh: st.R.shard, x: P1.x + (P2.x - P1.x) * qq, z: P1.z + (P2.z - P1.z) * qq, y: 46 + (f.y0 ? f.y0 * (1 - qq) : 0) + Math.sin(Math.PI * qq) * h0, vx: 0, vz: 0, vy: isF ? 34 : 6, c: isF ? FCOL[i % 3] : (isA ? rgb("#ffffff") : cc), s: isF ? 2.2 : (isA ? 0.8 : (big ? 1.7 : 1.1)), t0: dl + dur0 * qq, dur: (isF ? 0.5 : 0.3) / sp });
      }
      if (isF) addFx(st, { kind: "star", mesh: st.R.flash, x: P1.x, z: P1.z, y: 52, c: rgb("#ffb347"), s: 1.2, t0: dl, dur: 0.26 / sp });
    }
  }
  /* ---------- مؤثرات المهارات المميّزة: لكل مهارة شكل خاص (سلسلة كرة النار) ---------- */
  function skFx(st, f, P1, P2, dl, sp, cc, pw) {
    var R = st.R, v = f.v, id = f.id, lt = f.lite ? 0.5 : 1, big = pw >= 1.8;
    var X = P2.x, Z = P2.z, X1 = P1.x, Z1 = P1.z, i, j, a, n, dx, dz;
    var yw = Math.atan2(X - X1, Z - Z1);
    var WH = [1, 1, 1], DK = rgb("#1a0f2a"), GRN = rgb("#5dff9a");
    var CE = [rgb("#ff4d12"), rgb("#ff8a2b"), rgb("#ffc94a")];
    var ROCK = mixc(cc, [0.22, 0.14, 0.07], 0.5);
    function rn(k, m) { return (hash("k" + id + v + k + "_" + (m || 0)) % 1000) / 1000; }
    function N(k) { return Math.max(2, Math.round(k * lt)); }
    function T0(d) { return dl + (d || 0) / sp; }
    function mk(o, ex) { var r = {}, k; for (k in o) r[k] = o[k]; for (k in ex) r[k] = ex[k]; return r; }
    function ring(x, z, y, col, s, d, dur, mesh) { addFx(st, { kind: "ring", mesh: mesh || R.shock, x: x, z: z, y: y, c: col, s: s, t0: T0(d), dur: (dur || 0.55) / sp }); }
    function star(x, z, y, col, s, d, dur, mesh) { addFx(st, { kind: "star", mesh: mesh || R.star, x: x, z: z, y: y, c: col, s: s, t0: T0(d), dur: (dur || 0.3) / sp }); }
    function beam(x, z, col, w, h, d, dur, am) { addFx(st, { kind: "beam", mesh: R.pillar, x: x, z: z, y: 0, c: col, s: w, sy: h, am: am, t0: T0(d), dur: (dur || 0.6) / sp }); }
    function pose(o, d, dur) { o.kind = "pose"; o.t0 = T0(d); o.dur = (dur || 0.5) / sp; addFx(st, o); }
    function part(kind, mesh, x, z, y, vx, vz, vy, col, s, d, dur, am) { addFx(st, { kind: kind, mesh: mesh, x: x, z: z, y: y, vx: vx, vz: vz, vy: vy, c: col, s: s, am: am, t0: T0(d), dur: dur / sp }); }
    function burst(k, spd, up, sz, col, d, dur, ox, oz, y, mesh) {
      for (var q = 0; q < k; q++) {
        var an = rn(q, 1) * 6.2832, sv = spd * (0.55 + rn(q, 2) * 0.7);
        part("spark", mesh || R.shard, X + (ox || 0), Z + (oz || 0), y || 26, Math.cos(an) * sv, Math.sin(an) * sv, up * (0.6 + rn(q, 3) * 0.8), col, sz, d, dur);
      }
    }
    function fly(o, d, dur) { var r = { kind: "fly", P1: P1, P2: P2, h: 0, y0: 0, t0: T0(d), dur: (dur || 0.34) / sp }, k; for (k in o) r[k] = o[k]; addFx(st, r); }
    function trail(k, col, sz, d, dur, h, mesh, vy) {
      for (var q = 1; q <= k; q++) {
        var qq = q / (k + 1);
        part("spark", mesh || R.shard, X1 + (X - X1) * qq, Z1 + (Z - Z1) * qq, 46 + Math.sin(Math.PI * qq) * (h || 0), 0, 0, vy || 10, col, sz, d + dur * qq, 0.42);
      }
    }
    function arrow(Pa, Pb, d, fd, h, y0) {
      var b = { P1: Pa, P2: Pb, h: h, y0: y0 || 0, pitch: 1, s: 1 };
      fly(mk(b, { mesh: R.bolt, c: rgb("#d9b98a"), sx: 0.2, sy: 0.2, sz: 2.2 }), d, fd);
      fly(mk(b, { mesh: R.bolt, c: rgb("#f4f8fb"), sx: 0.5, sy: 0.5, sz: 0.85, off: 13.5 }), d, fd);
      fly(mk(b, { mesh: R.bolt, c: cc, sx: 1.8, sy: 0.12, sz: 0.6, off: -11 }), d, fd);
      fly(mk(b, { mesh: R.bolt, c: cc, sx: 0.12, sy: 1.8, sz: 0.6, off: -11 }), d, fd);
    }
    /* قطعة صاعقة/شق بين نقطتين في الفضاء */
    function seg(A, B, col, th, d, dur, am, hold) {
      var sx = B.x - A.x, sy = B.y - A.y, sz = B.z - A.z, L = Math.sqrt(sx * sx + sy * sy + sz * sz) || 1, hz = Math.sqrt(sx * sx + sz * sz);
      pose({ mesh: R.bolt, x: (A.x + B.x) / 2, y: (A.y + B.y) / 2, z: (A.z + B.z) / 2, yaw: Math.atan2(sx, sz), pitch: Math.atan2(-sy, hz), c: col, sx0: th, sy0: th, sz0: L / 12.4 * 1.08, am: am, hold: hold }, d, dur);
    }

    switch (v) {
      case "slam": {                         /* ضربة أرض: حلقات + أشواك طين + حطام */
        ring(X, Z, 1.5, WH, 1.4 * pw, 0, 0.5);
        ring(X, Z, 1.6, cc, 2.3 * pw, 0.08, 0.65);
        n = N(7);
        for (i = 0; i < n; i++) {
          a = i / n * 6.2832 + rn(i) * 0.5;
          beam(X + Math.cos(a) * 17 * (big ? 1.3 : 1), Z + Math.sin(a) * 14 * (big ? 1.3 : 1), ROCK, 3.6 * (big ? 1.3 : 1), (20 + rn(i, 4) * 16) * (big ? 1.4 : 1), 0.04 + i * 0.02, 0.55, 0.95);
        }
        for (i = 0; i < N(8); i++) { a = rn(i, 5) * 6.2832; part("spark", R.cube, X, Z, 12, Math.cos(a) * 48, Math.sin(a) * 48, 110 + rn(i, 6) * 60, ROCK, 1.3 + rn(i, 7) * 0.9, 0.02, 0.75); }
        for (i = 0; i < N(6); i++) { a = rn(i, 8) * 6.2832; part("dust", R.cube, X + Math.cos(a) * 8, Z + Math.sin(a) * 8, 4, Math.cos(a) * 44, Math.sin(a) * 44, 28, rgb(thDust(st)), 1.5, 0.04, 0.6); }
        break;
      }
      case "spear": {                        /* رمح ناري طويل بذيل لهب */
        var fd1 = 0.3;
        fly({ mesh: R.bolt, c: rgb("#ff7a2a"), s: 1, sx: 0.55, sy: 0.55, sz: 3.6, pitch: 1, h: 8 }, 0, fd1);
        fly({ mesh: R.bolt, c: rgb("#fff1c8"), s: 1, sx: 0.28, sy: 0.28, sz: 3.0, pitch: 1, h: 8, off: 3 }, 0, fd1);
        fly({ mesh: R.flash, c: rgb("#ff9a3a"), s: 0.75, h: 8, off: 24 }, 0, fd1);
        trail(N(9), CE[1], 1.3, 0, fd1, 8, null, 24);
        star(X1, Z1, 52, CE[2], 1.3, 0, 0.22);
        star(X, Z, 40, rgb("#ffe6a8"), 1.1 + 0.4 * (pw - 1), fd1, 0.28);
        ring(X, Z, 1.5, rgb("#ff7a2a"), 1.5 * pw, fd1 + 0.03, 0.5);
        burst(N(8), 60, 110, 1.4, CE[1], fd1, 0.55);
        break;
      }
      case "volley": {                       /* ثلاثة سهام متتالية بمروحة */
        var px = Math.cos(yw), pz = -Math.sin(yw), na = N(3), offs = na === 3 ? [-15, 0, 15] : [-9, 9];
        for (i = 0; i < na; i++) {
          var o1 = offs[i], Pa = { x: X1 + px * o1, z: Z1 + pz * o1 }, Pb = { x: X + px * o1 * 0.55, z: Z + pz * o1 * 0.55 };
          arrow(Pa, Pb, i * 0.07, 0.3, 10, 0);
          burst(3, 30, 55, 0.9, rgb("#d9b98a"), 0.3 + i * 0.07, 0.45, px * o1 * 0.55, pz * o1 * 0.55, 30);
        }
        star(X1, Z1, 52, cc, 1.2, 0, 0.22);
        ring(X, Z, 1.5, cc, 1.3 * pw, 0.3, 0.5);
        break;
      }
      case "rain": {                         /* مطر سهام: دائرة تحذير ثم سهام من السماء */
        ring(X, Z, 1.3, cc, 1.2 * pw, 0, 0.5);
        var spr = big ? 1.6 : 1, nA = f.lite ? 3 : (big ? 9 : 6);
        for (i = 0; i < nA; i++) {
          var jx = (rn(i, 1) - 0.5) * 34 * spr, jz = (rn(i, 2) - 0.5) * 26 * spr, dd = 0.12 + i * 0.05;
          arrow({ x: X + jx, z: Z + jz - 3 }, { x: X + jx, z: Z + jz }, dd, 0.26, 0, 175);
          burst(2, 30, 50, 1.0, rgb("#d9b98a"), dd + 0.26, 0.4, jx, jz, 8);
          part("dust", R.cube, X + jx, Z + jz, 3, 0, 0, 26, rgb(thDust(st)), 1.0, dd + 0.26, 0.45);
        }
        ring(X, Z, 1.5, cc, 1.6 * pw, 0.35, 0.55);
        break;
      }
      case "crescent": {                     /* هلالان يدوران ويشقّان نحو الهدف */
        var fd2 = 0.3;
        fly({ mesh: R.slashArc, c: cc, s: 0.85 * (big ? 1.3 : 1), spin: 18, h: 0 }, 0, fd2);
        fly({ mesh: R.slashArc, c: WH, s: 0.55 * (big ? 1.3 : 1), spin: -24, h: 0 }, 0.04, fd2);
        trail(N(8), cc, 1.4, 0, fd2, 0, null, 6);
        addFx(st, { kind: "slash", mesh: R.slashArc, x: X, z: Z, y: 40, c: cc, s: 1.9 * (big ? 1.4 : 1), roll: rn(1) * 6.28, t0: T0(fd2), dur: 0.3 / sp });
        addFx(st, { kind: "slash", mesh: R.slashArc, x: X, z: Z, y: 36, c: WH, s: 1.4 * (big ? 1.4 : 1), roll: rn(2) * 6.28 + 2, t0: T0(fd2 + 0.07), dur: 0.26 / sp });
        ring(X, Z, 1.4, cc, 1.5, fd2, 0.5);
        burst(N(6), 55, 90, 1.2, cc, fd2, 0.5);
        break;
      }
      case "shadow": {                       /* كرة ظلام تنهار فوق الهدف */
        var fd3 = 0.34, bs = big ? 1.5 : 1;
        fly({ mesh: R.flash, c: cc, s: 2.0 * bs, am: 0.45, h: 14 }, 0, fd3);
        fly({ mesh: R.flash, c: DK, s: 1.2 * bs, h: 14 }, 0, fd3);
        fly({ mesh: R.flash, c: rgb("#e8d8ff"), s: 0.45, h: 14 }, 0, fd3);
        trail(N(8), cc, 1.9, 0, fd3, 14, R.cube, 14);
        pose({ mesh: R.flash, x: X, z: Z, y: 40, c: DK, sx0: 1.5, sy0: 1.5, sz0: 1.5, sx1: 6.5 * bs, sy1: 6.5 * bs, sz1: 6.5 * bs, am: 0.55, hold: 0.45 }, fd3, 0.7);
        for (i = 0; i < N(3); i++) beam(X + (rn(i, 1) - 0.5) * 22, Z + (rn(i, 2) - 0.5) * 16, cc, 3.2, 40 + rn(i, 3) * 24, fd3 + i * 0.06, 0.6, 0.8);
        burst(N(7), 26, 110, 1.6, cc, fd3, 0.7, 0, 0, 20, R.cube);
        ring(X, Z, 1.5, cc, 2.0 * pw, fd3, 0.6);
        break;
      }
      case "water": {                        /* قطرة كبيرة ثم رشّة تاج */
        var fd4 = 0.34;
        fly({ mesh: R.flash, c: cc, s: 1.35, am: 0.8, h: 30 }, 0, fd4);
        fly({ mesh: R.flash, c: WH, s: 0.55, h: 30 }, 0, fd4);
        trail(N(8), cc, 1.1, 0, fd4, 30, null, -10);
        ring(X, Z, 1.5, cc, 1.5 * pw, fd4, 0.5);
        ring(X, Z, 1.6, WH, 2.3 * pw, fd4 + 0.1, 0.6);
        for (i = 0; i < N(10); i++) { a = i / N(10) * 6.2832; part("spark", R.shard, X + Math.cos(a) * 8, Z + Math.sin(a) * 8, 22, Math.cos(a) * 34, Math.sin(a) * 34, 120 + rn(i, 2) * 50, i % 2 ? cc : WH, 1.5, fd4, 0.7); }
        pose({ mesh: R.flash, x: X, z: Z, y: 2, c: cc, sx0: 1.5, sy0: 0.12, sz0: 1.5, sx1: 6, sy1: 0.12, sz1: 6, am: 0.35, hold: 0.5 }, fd4, 0.8);
        break;
      }
      case "sun": {                          /* عمود شمس من السماء + أشعة على الأرض */
        var bd = 0.12, sw = big ? 1.3 : 1;
        beam(X, Z, rgb("#ffe27a"), 15 * sw, 95, bd, 0.75, 0.7);
        beam(X, Z, WH, 6 * sw, 95, bd + 0.02, 0.6);
        star(X, Z, 96, rgb("#fff4c0"), 1.3 * pw, bd, 0.4);
        ring(X, Z, 1.6, rgb("#ffd35a"), 2.0 * pw, bd + 0.1, 0.6);
        ring(X, Z, 1.8, WH, 2.8 * pw, bd + 0.22, 0.65);
        n = N(6);
        for (i = 0; i < n; i++) {
          a = i / n * 6.2832; dx = Math.cos(a); dz = Math.sin(a);
          pose({ mesh: R.bolt, x: X + dx * 19, z: Z + dz * 19, y: 3, yaw: Math.atan2(dx, dz), c: rgb("#ffd35a"), sx0: 0.5, sy0: 0.12, sz0: 0.4, sx1: 0.5, sy1: 0.12, sz1: 3.0, am: 0.8, hold: 0.5 }, bd + 0.12, 0.6);
        }
        burst(N(12), 18, 150, 1.6, rgb("#ffd35a"), bd + 0.05, 0.9, 0, 0, 10);
        break;
      }
      case "maw": {                          /* أنياب سوداء تنغلق + فقاعة فراغ */
        n = N(big ? 8 : 6);
        var mr = 19 * (big ? 1.3 : 1);
        for (i = 0; i < n; i++) {
          a = i / n * 6.2832;
          beam(X + Math.cos(a) * mr, Z + Math.sin(a) * mr, DK, 5.2, 34 + rn(i, 1) * 18, 0.06 + i * 0.025, 0.6, 0.95);
          beam(X + Math.cos(a) * mr, Z + Math.sin(a) * mr, cc, 2.4, 40 + rn(i, 1) * 18, 0.08 + i * 0.025, 0.55, 0.8);
        }
        pose({ mesh: R.flash, x: X, z: Z, y: 34, c: DK, sx0: 1.2, sy0: 1.2, sz0: 1.2, sx1: big ? 7 : 5, sy1: big ? 7 : 5, sz1: big ? 7 : 5, am: 0.6, hold: 0.5 }, 0.1, 0.75);
        ring(X, Z, 1.4, cc, 2.0 * pw, 0.05, 0.6);
        ring(X, Z, 1.6, DK, 2.8 * pw, 0.18, 0.7);
        burst(N(8), 22, 90, 1.7, cc, 0.25, 0.7, 0, 0, 16, R.cube);
        break;
      }
      case "quake": {                        /* موجات + شقوق مضيئة تتفرّع على الأرض */
        for (j = 0; j < 3; j++) ring(X, Z, 1.4, j ? cc : WH, (1.3 + j * 0.8) * pw * 0.8, j * 0.1, 0.6);
        n = N(6);
        for (i = 0; i < n; i++) {
          a = i / n * 6.2832 + rn(i) * 0.4; dx = Math.cos(a); dz = Math.sin(a);
          var ya = Math.atan2(dx, dz);
          pose({ mesh: R.bolt, x: X + dx * 18, z: Z + dz * 18, y: 2, yaw: ya, c: rgb("#120a05"), sx0: 0.5, sy0: 0.12, sz0: 0.4, sx1: 0.9, sy1: 0.12, sz1: 3.4, hold: 0.7 }, 0.04 + i * 0.02, 0.9);
          pose({ mesh: R.bolt, x: X + dx * 18, z: Z + dz * 18, y: 3, yaw: ya, c: cc, sx0: 0.3, sy0: 0.1, sz0: 0.4, sx1: 0.4, sy1: 0.1, sz1: 3.4, am: 0.9, hold: 0.6 }, 0.04 + i * 0.02, 0.85);
        }
        for (i = 0; i < N(8); i++) { a = i / N(8) * 6.2832; part("dust", R.cube, X + Math.cos(a) * 10, Z + Math.sin(a) * 10, 4, Math.cos(a) * 40, Math.sin(a) * 40, 30, rgb(thDust(st)), 1.5, 0.1, 0.6); }
        burst(N(6), 50, 100, 1.3, ROCK, 0.15, 0.7, 0, 0, 12, R.cube);
        break;
      }
      case "thunder": {                      /* صاعقة متعرّجة من السماء + وميض + فروع */
        var tx = X + (rn(1) - 0.5) * 40, pts = [], K = 6;
        for (i = 0; i <= K; i++) {
          var tq = i / K, jt = (i > 0 && i < K) ? 1 : 0;
          pts.push({ x: tx + (X - tx) * tq + jt * (rn(i, 5) - 0.5) * 26, y: 200 - 154 * tq, z: Z + jt * (rn(i, 6) - 0.5) * 14 });
        }
        for (i = 0; i < K; i++) { seg(pts[i], pts[i + 1], cc, 2.2, 0.08, 0.42, 0.55, 0.35); seg(pts[i], pts[i + 1], WH, 0.9, 0.08, 0.38, 1, 0.4); }
        for (j = 0; j < 2; j++) {
          var sg = j ? 1 : -1, FB = { x: pts[2].x + sg * 40, y: pts[2].y - 55, z: pts[2].z + sg * 18 };
          seg(pts[2], FB, cc, 1.3, 0.1, 0.34, 0.6, 0.35); seg(pts[2], FB, WH, 0.5, 0.1, 0.3, 1, 0.4);
        }
        pose({ mesh: R.flash, x: X, z: Z, y: 46, c: WH, sx0: 1, sy0: 1, sz0: 1, sx1: 6, sy1: 6, sz1: 6, am: 0.6 }, 0.1, 0.2);
        star(X, Z, 46, WH, 2.2, 0.1, 0.25);
        ring(X, Z, 1.5, cc, 2.2 * pw, 0.1, 0.6);
        ring(X, Z, 1.7, WH, 3.0 * pw, 0.2, 0.6);
        burst(N(12), 70, 140, 1.6, cc, 0.1, 0.7);
        pose({ mesh: R.flash, x: X, z: Z, y: 2, c: DK, sx0: 1.5, sy0: 0.1, sz0: 1.5, sx1: 5, sy1: 0.1, sz1: 5, am: 0.5, hold: 0.7 }, 0.1, 1.0);
        break;
      }
      case "dome": {                         /* قبّة حماية من الطين + جدار أعمدة */
        pose({ mesh: R.flash, x: X, z: Z, y: 42, c: cc, sx0: 2, sy0: 2.4, sz0: 2, sx1: 9, sy1: 10, sz1: 9, am: 0.3, hold: 0.6 }, 0, 0.95);
        pose({ mesh: R.flash, x: X, z: Z, y: 42, c: WH, sx0: 2, sy0: 2.4, sz0: 2, sx1: 9.4, sy1: 10.4, sz1: 9.4, am: 0.12, hold: 0.5 }, 0.05, 0.9);
        ring(X, Z, 1.4, cc, 1.5, 0, 0.6);
        ring(X, Z, 1.5, WH, 2.3, 0.1, 0.7);
        n = N(6);
        for (i = 0; i < n; i++) { a = i / n * 6.2832; beam(X + Math.cos(a) * 26, Z + Math.sin(a) * 26, ROCK, 5.5, 22 + rn(i, 2) * 8, 0.05 + i * 0.03, 0.7, 0.9); }
        for (i = 0; i < N(6); i++) { a = rn(i, 3) * 6.2832; part("dust", R.cube, X + Math.cos(a) * 12, Z + Math.sin(a) * 12, 4, Math.cos(a) * 20, Math.sin(a) * 20, 40, ROCK, 1.4, 0.05, 0.7); }
        break;
      }
      case "oath": {                         /* قسم الحارس: حلقات ذهبية متراصّة وتاج وميض */
        for (j = 0; j < 3; j++) ring(X, Z, 4 + j * 26, j === 1 ? WH : cc, 1.2 + j * 0.15, j * 0.1, 0.55);
        pose({ mesh: R.flash, x: X, z: Z, y: 44, c: cc, sx0: 3, sy0: 3.4, sz0: 3, sx1: 8, sy1: 9, sz1: 8, am: 0.22, hold: 0.6 }, 0, 0.9);
        star(X, Z, 100, rgb("#fff1b8"), 1.0, 0.05, 0.4);
        burst(N(8), 16, 130, 1.5, rgb("#ffe27a"), 0.05, 0.8, 0, 0, 12);
        break;
      }
      case "mend": {                         /* شفاء: ذرّات مضيئة صاعدة + صلبان */
        for (i = 0; i < N(8); i++) part("heal", R.flash, X + (rn(i, 1) - 0.5) * 30, Z + (rn(i, 2) - 0.5) * 22, 6 + rn(i, 3) * 10, 0, 0, 0, i % 2 ? GRN : cc, 0.38 + rn(i, 4) * 0.2, i * 0.06, 0.9, 0.8);
        for (i = 0; i < 2; i++) part("heal", R.heal, X + (i ? 8 : -8), Z, 8, 0, 0, 0, GRN, 1.1, i * 0.12, 0.9);
        beam(X, Z, GRN, 4.5, 32, 0, 0.6, 0.5);
        ring(X, Z, 1.5, cc, 1.3, 0, 0.6, R.shockSmall);
        ring(X, Z, 1.4, GRN, 1.4, 0.05, 0.6);
        break;
      }
      case "spring": {                       /* نبع الحياة: نافورة ترتفع وتسقط */
        burst(N(10), 16, 150, 1.4, cc, 0, 0.9, 0, 0, 8);
        burst(N(6), 12, 170, 1.2, WH, 0.04, 0.9, 0, 0, 8);
        pose({ mesh: R.flash, x: X, z: Z, y: 2, c: cc, sx0: 1, sy0: 0.12, sz0: 1, sx1: 5.5, sy1: 0.12, sz1: 5.5, am: 0.35, hold: 0.5 }, 0, 0.9);
        ring(X, Z, 1.4, cc, 1.6 * (big ? 1.3 : 1), 0, 0.7);
        ring(X, Z, 1.5, WH, 2.2 * (big ? 1.3 : 1), 0.1, 0.7);
        for (i = 0; i < N(3); i++) part("heal", R.heal, X + (i - 1) * 12, Z, 8, 0, 0, 0, GRN, 1.0, 0.1 + i * 0.1, 0.9);
        beam(X, Z, cc, 6.5, 38, 0, 0.7, 0.45);
        break;
      }
      case "venom": {                        /* سمّ: قارورة تنكسر وبركة سامة وفقاعات */
        var GR = rgb("#7ee05a"), fd5 = 0;
        if (f.rg) {
          fly({ mesh: R.flash, c: GR, s: 1.0, h: 30, am: 0.85 }, 0, 0.32);
          fly({ mesh: R.flash, c: WH, s: 0.4, h: 30 }, 0, 0.32);
          fd5 = 0.3;
        }
        pose({ mesh: R.flash, x: X, z: Z, y: 2, c: GR, sx0: 1.5, sy0: 0.12, sz0: 1.5, sx1: 6.5, sy1: 0.12, sz1: 6.5, am: 0.42, hold: 0.75 }, fd5, 1.1);
        ring(X, Z, 1.4, GR, 1.6, fd5, 0.6);
        for (i = 0; i < N(7); i++) part("heal", R.flash, X + (rn(i, 1) - 0.5) * 30, Z + (rn(i, 2) - 0.5) * 22, 4, 0, 0, 0, i % 2 ? GR : rgb("#c8ff9a"), 0.35 + rn(i, 3) * 0.25, fd5 + i * 0.07, 1.0, 0.85);
        burst(N(5), 12, 40, 1.3, GR, fd5, 0.8, 0, 0, 50);
        break;
      }
      case "rally": {                        /* نشيد الهجوم: أسهم ذهبية صاعدة */
        var OR = rgb("#ffb347");
        for (j = 0; j < N(3); j++) pose({ mesh: R.bolt, x: X + (j - 1) * 14, z: Z, y: 8, pitch: -Math.PI / 2, c: OR, sx0: 0.8, sy0: 0.8, sz0: 1.6, rise: 66, hold: 0.3 }, j * 0.08, 0.7);
        ring(X, Z, 1.4, OR, 1.5, 0, 0.6);
        ring(X, Z, 1.5, cc, 2.1, 0.1, 0.6);
        pose({ mesh: R.flash, x: X, z: Z, y: 44, c: OR, sx0: 2, sy0: 2.4, sz0: 2, sx1: 6.5, sy1: 7, sz1: 6.5, am: 0.18, hold: 0.5 }, 0, 0.8);
        burst(N(6), 12, 110, 1.3, OR, 0, 0.8, 0, 0, 10);
        break;
      }
      case "drain": {                        /* سحب الطاقة: ذرّات تطير من الهدف إلى المهاجم */
        for (j = 0; j < N(4); j++) fly({ P1: P2, P2: P1, mesh: R.flash, c: j % 2 ? cc : rgb("#e8d8ff"), s: 0.55 + rn(j, 1) * 0.2, h: 20 + j * 14, am: 0.9 }, j * 0.07, 0.4);
        ring(X, Z, 1.5, cc, 1.3, 0, 0.5);
        burst(N(5), 26, 60, 1.2, cc, 0, 0.5, 0, 0, 40);
        star(X1, Z1, 52, cc, 1.1, 0.3, 0.3);
        ring(X1, Z1, 1.5, cc, 1.2, 0.32, 0.5);
        break;
      }
      default:
        ring(X, Z, 1.5, cc, 1.5, 0, 0.55);
    }
  }

  function thDust(st) { return st.theme ? st.theme.g2 : "#8d4d24"; }
  var TMP_A = M4(), TMP_B = M4(), TMP_M = M4(), TMP_P = M4(), TMP_Q = M4(), TMP_Z = M4(), TMP_Y = M4();
  function fxModel(e, q, out) {
    /* يبني مصفوفة المؤثر حسب نوعه — q من 0 إلى 1 */
    if (e.kind === "ring") {
      var s = e.s * FXS * (0.35 + 1.5 * q);
      m4Mul(out, TMP_A = m4T(e.x, e.y, e.z), TMP_B = m4S(s, s, s));
    } else if (e.kind === "slash") {
      var s2 = e.s * FXS * 1.15 * (0.8 + 0.7 * q);
      m4Mul(TMP_M, m4T(e.x, e.y + q * 16, e.z), m4Ry(e.roll));
      m4Mul(TMP_M, TMP_M, m4Rx(Math.PI / 2));
      m4Mul(out, TMP_M, m4S(s2, s2, s2));
    } else if (e.kind === "fly") {
      var x = e.P1.x + (e.P2.x - e.P1.x) * q;
      var z = e.P1.z + (e.P2.z - e.P1.z) * q;
      var y = 46 + (e.y0 ? e.y0 * (1 - q) : 0) + Math.sin(Math.PI * q) * e.h;
      var yaw = Math.atan2(e.P2.x - e.P1.x, e.P2.z - e.P1.z);
      m4Mul(TMP_M, m4T(x, y, z), m4Ry(yaw + (e.spin ? q * e.spin : 0)));
      if (e.pitch) { m4Mul(TMP_Z, TMP_M, m4Rx(Math.atan2(-((e.y0 ? -e.y0 : 0) + Math.PI * e.h * Math.cos(Math.PI * q)), Math.max(1, Math.hypot(e.P2.x - e.P1.x, e.P2.z - e.P1.z))))); TMP_M.set(TMP_Z); }
      if (e.off) { m4Mul(TMP_Z, TMP_M, m4T(0, 0, e.off)); TMP_M.set(TMP_Z); }
      m4Mul(out, TMP_M, m4S(e.s * 1.25 * (e.sx || 1), e.s * 1.25 * (e.sy || 1), e.s * 1.25 * (e.sz || 1)));
    } else if (e.kind === "beam") {
      var bh = e.sy * 1.15 * Math.min(1, q * 3.2), bw = e.s * 1.3 * (1 - 0.65 * q);
      m4Mul(out, m4T(e.x, e.y + 1.3 * bh, e.z), m4S(bw, bh, bw));
    } else if (e.kind === "star") {
      var s3 = e.s * FXS * (0.5 + 1.4 * q);
      m4Mul(TMP_M, m4T(e.x, e.y, e.z), m4Ry(q * 2));
      m4Mul(out, TMP_M, m4S(s3, s3, s3));
    } else if (e.kind === "pose") {
      var pg = 1 - (1 - q) * (1 - q);
      var psx = e.sx1 === undefined ? e.sx0 : e.sx0 + (e.sx1 - e.sx0) * pg;
      var psy = e.sy1 === undefined ? e.sy0 : e.sy0 + (e.sy1 - e.sy0) * pg;
      var psz = e.sz1 === undefined ? e.sz0 : e.sz0 + (e.sz1 - e.sz0) * pg;
      m4Mul(TMP_M, m4T(e.x, e.y + (e.rise || 0) * pg, e.z), m4Ry(e.yaw || 0));
      m4Mul(TMP_Y, TMP_M, m4Rx(e.pitch || 0));
      m4Mul(out, TMP_Y, m4S(psx, psy, psz));
    } else { /* dust / spark / heal */
      var t = q * e.dur;
      var dy = e.kind === "heal" ? q * 52 : e.vy * t - (e.kind === "spark" ? 160 * t * t : 0);
      var dx2 = e.kind === "heal" ? 0 : e.vx * t;
      var dz2 = e.kind === "heal" ? 0 : e.vz * t;
      var s4 = e.kind === "dust" ? e.s * (0.7 + q) : e.s * (e.kind === "spark" ? 1.55 : 1.2);
      m4Mul(TMP_M, m4T(e.x + dx2, Math.max(1, e.y + dy), e.z + dz2), m4Ry(t * 5));
      if (e.kind === "spark") m4Mul(TMP_M, TMP_M, m4Rx(t * 9 + e.x));
      m4Mul(out, TMP_M, m4S(s4, s4, s4));
    }
    return out;
  }

  /* ---------- مؤثرات Pixelfx: طبقة بكسل-آرت حيّة فوق المشهد ---------- */
  var PXOVER = null, PXOCTX = null;
  function pxEnsure(st) {
    if (!st.stage) return false;
    if (!PXOVER || !PXOVER.isConnected) {
      PXOVER = document.createElement("canvas");
      PXOVER.style.cssText = "position:absolute;left:0;top:0;pointer-events:none;z-index:29500;image-rendering:pixelated;border:0;margin:0;padding:0";
      st.stage.appendChild(PXOVER);
      PXOCTX = PXOVER.getContext("2d");
      PXOVER._w = 0; PXOVER._h = 0;
    }
    if (PXOVER._w !== st.w || PXOVER._h !== st.h) {
      PXOVER.width = Math.max(2, Math.round(st.w));
      PXOVER.height = Math.max(2, Math.round(st.h));
      PXOVER.style.width = st.w + "px";
      PXOVER.style.height = st.h + "px";
      PXOVER._w = st.w; PXOVER._h = st.h;
    }
    return true;
  }
  function pxBuf(key) {
    var meta = window.PXFX.meta(key);
    if (!meta) return null;
    var sz = meta.size || [160, 120];
    var BW = sz[0] + 40, BH = sz[1] + 48;
    var cvs = document.createElement("canvas");
    cvs.width = BW; cvs.height = BH;
    var ictx = cvs.getContext("2d");
    return { meta: meta, BW: BW, BH: BH, cvs: cvs, ictx: ictx, idata: ictx.createImageData(BW, BH), frame: window.PXFX.core.createFrame(BW, BH) };
  }
  function pxSpawn(st, key, o) {
    if (!window.PXFX) return;
    if (st.px === undefined) st.px = [];
    var CAP = st.low === 2 ? 5 : [7, 6, 5][st.pxLvl || 0];
    if (st.px.length >= CAP) { var old = st.px.shift(); try { old.b.cvs.width = 0; } catch (e1) {} }
    var b = pxBuf(key);
    if (!b) return;
    var fx = window.PXFX.make(key, { x: b.BW / 2, y: b.BH - 14, flip: !!o.flip, angle: o.angle || 0, seed: o.seed || ((o._h || 7) * 13 + 5) % 89 });
    if (!fx) return;
    st.px.push({ fx: fx, b: b, x: o.x, y: o.y, z: o.z,
      t0: (o.t0 !== undefined ? o.t0 : (st.fxClock || 0)) + (o.delay || 0),
      s: o.s || 1, fly: o.fly || null, started: false });
  }
  function pxFrame(st, t) {
    if (!window.PXFX || !st.stage) return;
    if (st.px === undefined) st.px = [];
    st.pxTick = (st.pxTick || 0) + 1;
    var RATE = st.low === 2 ? 4 : [3, 3, 4][(st.pxLvl || 0) - 1 < 0 ? 0 : (st.pxLvl || 0) - 1] || 3;
    if ((st.pxTick % RATE) !== 0) return; /* بين اللوحات: تبقى آخر لوحة مرسومة فوق الساحة */
    if (!pxEnsure(st)) return;
    var octx = PXOCTX;
    octx.setTransform(1, 0, 0, 1, 0, 0);
    octx.clearRect(0, 0, PXOVER.width, PXOVER.height);
    octx.imageSmoothingEnabled = false;
    /* دخول الوحدات: بوّابة استدعاء بكسل تحت كل وحدة تظهر أول مرة */
    if (st.pxSeen === undefined) st.pxSeen = {};
    for (var uid in st.units) {
      var U = st.units[uid];
      if (U.hidden || !U.alive || st.pxSeen[uid]) continue;
      st.pxSeen[uid] = 1;
      var dly = ((uid * 37) % 10) * 0.05;
      try {
        if (U.boss) {
          pxSpawn(st, "spawn/respawn-beam", { x: U.W.x, y: 2, z: U.W.z, t0: st.fxClock, delay: dly, s: 2.6 });
          pxSpawn(st, "shadow/hex-sigil", { x: U.W.x, y: 2, z: U.W.z, t0: st.fxClock, delay: dly, s: 2.3 });
        } else if (st.low !== 2) {
          pxSpawn(st, "spawn/spawn-portal", { x: U.W.x, y: 2, z: U.W.z, t0: st.fxClock, delay: dly, s: U.en ? 1.1 : 1.4 });
        }
      } catch (eEnt) {}
    }
    var sp = clamp(st.speed || 1, 1, 4);
    var dt = Math.min(0.05, (st.frameDt || 0.016) * sp);
    var tms = performance.now();
    for (var i = st.px.length - 1; i >= 0; i--) {
      var e = st.px[i];
      if (st.fxClock < e.t0) continue;
      e.started = true;
      if (e.fx.done()) { try { e.b.cvs.width = 0; } catch (e2) {} st.px.splice(i, 1); continue; }
      e.fx.update(dt * RATE);
      if (e.fx.done()) { try { e.b.cvs.width = 0; } catch (e2c) {} st.px.splice(i, 1); continue; }
      var ax = e.x, ay = e.y, az = e.z;
      if (e.fly) {
        var q = clamp((st.fxClock - e.t0) / e.fly.dur, 0, 1);
        ax = e.fly.x0 + (e.fly.x1 - e.fly.x0) * q;
        az = e.fly.z0 + (e.fly.z1 - e.fly.z0) * q;
        ay = e.fly.h0 + (e.fly.h1 - e.fly.h0) * q + Math.sin(Math.PI * q) * (e.fly.arc || 0);
      }
      var P = projectPoint(ax, ay, az);
      if (!P) continue;
      var sc = clamp(1250 / P.w, 0.5, 1.5) * (st.low === 2 ? 0.85 : 1.12) * e.s;
      PXFX.core.clearFrame(e.b.frame);
      e.fx.draw(e.b.frame, "front");
      PXFX.core.composite(e.b.frame, e.b.idata.data, null, 1);
      e.b.ictx.putImageData(e.b.idata, 0, 0);
      octx.drawImage(e.b.cvs, P.x - (e.b.BW / 2) * sc, P.y - (e.b.BH - 14) * sc, e.b.BW * sc, e.b.BH * sc);
    }
    var ms = performance.now() - tms;
    st.pxMs = st.pxMs ? (st.pxMs * 0.92 + ms * 0.08) : ms;
    if (!(st.pxTick % 45)) {
      if (st.pxMs > 12 && (st.pxLvl || 0) < 2) st.pxLvl = (st.pxLvl || 0) + 1;
      else if (st.pxMs > 7 && (st.pxLvl || 0) < 1) st.pxLvl = 1;
    }
  }
  function pxDeath(st, U) {
    if (!window.PXFX) return;
    if (st.px === undefined) st.px = [];
    var W = U.W, boss = !!U.boss, t0 = st.fxClock;
    try {
      if (U.en) {
        pxSpawn(st, boss ? "spawn/shatter-death" : "spawn/poof", { x: W.x, y: 4, z: W.z, t0: t0, s: boss ? 2.7 : 1.3, seed: (U.W.x | 0) % 71 });
        pxSpawn(st, "spawn/coin-drop", { x: W.x, y: boss ? 84 : 44, z: W.z, t0: t0, delay: 0.12, s: boss ? 1.8 : 1.05 });
        pxSpawn(st, "pickups/coin-spin", { x: W.x, y: boss ? 92 : 50, z: W.z, t0: t0, delay: 0.32, s: boss ? 1.5 : 0.95 });
        if (boss) pxSpawn(st, "spawn/soul-rise", { x: W.x, y: 2, z: W.z, t0: t0, delay: 0.22, s: 2.6 });
      } else {
        pxSpawn(st, "spawn/poof", { x: W.x, y: 4, z: W.z, t0: t0, s: 1.15 });
        pxSpawn(st, "spawn/soul-rise", { x: W.x, y: 2, z: W.z, t0: t0, delay: 0.2, s: 1.6 });
      }
    } catch (eD) {}
  }
  var PXMELEE = ["melee/sword-slash", "melee/spin-slash", "melee/thrust", "melee/uppercut", "melee/dagger-flurry", "melee/heavy-cleave", "melee/spear-sweep", "melee/claw-swipe"];
  function pxFlip(P1, P2) {
    try {
      var a = projectPoint(P1.x, 40, P1.z), b = projectPoint(P2.x, 40, P2.z);
      if (a && b && Math.abs(b.x - a.x) > 4) return b.x < a.x;
    } catch (eF) {}
    return false;
  }
  function pxDispatch(st, f) {
    if (!window.PXFX || st.noGL) return;
    if (st.px === undefined) st.px = [];
    var to = f.to || f.from, from = f.from || f.to;
    if (!to) return;
    var P2 = worldFromLayout(to), P1 = worldFromLayout(from);
    var sp = clamp(st.speed || 1, 1, 4);
    var t0 = (st.fxClock || 0) + (f.delay || 0) / sp;
    var pw = f.s || 1, kind = f.t, v = f.v || "";
    var big = !!to.big || pw >= 1.8;
    var GY = 3, CH = big ? 82 : 40;
    var FL = pxFlip(P1, P2), hid = (f.id || 0) % 997;
    function G(k) { var m = window.PXFX.meta(k); return m ? m : null; }
    function put(key, dy, s, d, x2) {
      if (!G(key)) return;
      var T = worldFromLayout(x2 || to);
      pxSpawn(st, key, { x: T.x, y: dy, z: T.z, t0: t0, delay: (d || 0) / sp, s: s, flip: FL, seed: hid });
    }
    function fly(key, h0, h1, arc, d, s) {
      if (!G(key)) return;
      pxSpawn(st, key, { x: P1.x, y: h0, z: P1.z, t0: t0, delay: (d || 0) / sp, s: s || 0.95,
        fly: { x0: P1.x, z0: P1.z, x1: P2.x, z1: P2.z, h0: h0, h1: h1, arc: arc, dur: 0.36 / sp }, seed: hid });
    }
    try {
      if (kind === "sk") {
        var two = !f.lite && pw >= 1.5;
        switch (v) {
          case "slam": put("impacts/ground-slam", GY, pw * 1.2, 0); if (two) put("explosions/dirt-explosion", GY, pw * 0.9, 0.1); break;
          case "quake": put("nature/quake", GY, pw * 1.15, 0); break;
          case "thunder": put("lightning/lightning-strike", GY, pw * 1.2, 0.05); if (two) put("lightning/zap-hit", CH, pw * 0.9, 0.3); break;
          case "spear": put("fire/flame-pillar", GY, pw * 1.1, 0.16); if (two) put("fire/spirit-flame", CH, pw * 0.8, 0.2); break;
          case "sun": put("holy/sunburst", CH, pw * 1.15, 0.12); break;
          case "crescent": put("melee/double-slash", CH, pw * 1.25, 0.14); if (two) put("melee/heavy-cleave", CH, pw * 0.8, 0.3); break;
          case "shadow": put("shadow/dark-explosion", CH, pw * 1.15, 0.24); if (two) put("shadow/shadow-flames", GY, pw * 0.9, 0.3); break;
          case "maw": put("shadow/shadow-tendrils", 6, pw * 1.2, 0.26); break;
          case "venom": put("nature/poison-cloud", 8, pw * 1.15, 0.2); break;
          case "water": put("water/wave-crash", GY, pw * 1.15, 0.24); break;
          case "volley": put("moves/arrow-shot", CH, pw * 0.95, 0.22); break;
          case "rain": put("moves/arrow-shot", CH, pw * 0.9, 0.3); if (two) put("explosions/small-explosion", GY, pw * 0.7, 0.42); break;
          case "dome": put("holy/divine-shield", CH, pw * 1.1, 0.1); break;
          case "mend": put(f.lite ? "holy/heal-aoe" : "holy/heal", f.lite ? GY : CH, pw * 1.15, 0.1); break;
          case "spring": put("nature/healing-bloom", GY, pw * 1.1, 0.1); break;
          case "oath": put("holy/blessing", CH, pw * 1.1, 0.1); if (two) put("holy/feather-burst", CH, pw * 0.8, 0.25); break;
          case "rally": put("pickups/power-star", CH, pw * 1.1, 0.1); break;
          case "drain": put("shadow/soul-drain", CH, pw * 1.15, 0.16); break;
          default: put("arcane/mana-burst", CH, pw * 0.9, 0.1); break;
        }
      } else if (kind === "impact") {
        if (f.v === "hit") {
          if (pw >= 1.6) { put("impacts/crit-hit", CH, pw * 1.05, 0); }
          else put("impacts/hit-spark", CH, 0.85 + pw * 0.3, 0);
          if (pw >= 1.4 && !f.lite) put("impacts/hit-flash", CH, pw * 0.9, 0.02);
        } else {
          put("impacts/heavy-landing", GY, pw * 1.15, 0);
          if (pw >= 2) put("explosions/big-explosion", GY, pw * 0.95, 0.05);
          else if (!f.lite) put("explosions/plasma-explosion", CH, pw * 0.8, 0.04);
        }
      } else if (kind === "slash") {
        put(PXMELEE[hid % PXMELEE.length], CH, pw * 1.2, 0);
      } else if (kind === "bullet" || kind === "orb") {
        if (v === "fire") fly("fire/fireball", CH, CH + 6, 26, 0, 1);
        else if (v === "ice" || v === "frost") fly("ice/ice-lance", CH, CH + 4, 20, 0, 1);
        else if (v === "dark" || v === "shadow") fly("shadow/void-orb", CH, CH + 8, 30, 0, 1);
        else if (v === "arcane" || v === "magic" || kind === "orb") fly("arcane/arcane-orb", CH, CH + 6, 24, 0, 0.9);
      } else if (kind === "muzzle") {
        put("arcane/spell-charge", CH, Math.max(0.7, pw * 0.7), 0, from);
        if (pw >= 1.9) put("arcane/magic-circle-cast", GY, 1.9, 0.02, from);
        if (pw >= 1.9) put("arcane/star-fall", CH, 1.1, 0.15);
      } else if (kind === "heal") {
        put("holy/heal", CH, 1, 0);
      }
    } catch (eM) {}
  }
  window.PXFXPOP = function (el, key, opts) {
    try {
      if (!window.PXFX || !el || !el.getBoundingClientRect) return;
      opts = opts || {};
      var meta = window.PXFX.meta(key);
      if (!meta) return;
      var sz = meta.size || [160, 120], BW = sz[0] + 40, BH = sz[1] + 48, SC = opts.s || 1.3;
      var r = el.getBoundingClientRect();
      var cvs = document.createElement("canvas");
      cvs.width = BW; cvs.height = BH;
      cvs.style.cssText = "position:fixed;z-index:99999;pointer-events:none;image-rendering:pixelated;width:" + (BW * SC) + "px;height:" + (BH * SC) + "px;left:" + (r.left + r.width / 2 - BW * SC / 2) + "px;top:" + (r.top + r.height / 2 - (BH - 12) * SC) + "px";
      document.body.appendChild(cvs);
      var ictx = cvs.getContext("2d"), idata = ictx.createImageData(BW, BH);
      var frame = window.PXFX.core.createFrame(BW, BH);
      var fx = window.PXFX.make(key, { x: BW / 2, y: BH - 12, seed: opts.seed || 3 });
      if (!fx) { if (cvs.parentNode) cvs.parentNode.removeChild(cvs); return; }
      var last = performance.now(), t0 = performance.now() + (opts.delay || 0) * 1000;
      function tick() {
        if (!cvs.isConnected) return;
        var now = performance.now();
        if (now >= t0) {
          fx.update(Math.min(0.05, (now - last) / 1000));
          if (fx.done()) { if (cvs.parentNode) cvs.parentNode.removeChild(cvs); return; }
          window.PXFX.core.clearFrame(frame);
          fx.draw(frame, "front");
          window.PXFX.core.composite(frame, idata.data, null, 1);
          ictx.putImageData(idata, 0, 0);
        }
        last = now;
        requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    } catch (e) {}
  };

  function drawFx(st, VP) {
    for (var i = st.fx.length - 1; i >= 0; i--) {
      var e = st.fx[i];
      var t = st.fxClock - e.t0;
      if (t < 0) continue;
      var q = t / e.dur;
      if (q >= 1) { st.fx.splice(i, 1); continue; }
      var alpha = e.kind === "fly" || e.kind === "heal" ? 1 : Math.min(1, (1 - q) * 1.5);
      if (e.hold) alpha = (q < e.hold ? 1 : (1 - q) / (1 - e.hold)) * 0.92;
      if (e.am) alpha *= e.am;
      fxModel(e, q, TMP_Q);
      m4Mul(TMP_P, VP, TMP_Q);
      FXT[0] = e.c[0] + (1 - e.c[0]) * 0.22; FXT[1] = e.c[1] + (1 - e.c[1]) * 0.22; FXT[2] = e.c[2] + (1 - e.c[2]) * 0.22;
      st.R.draw(e.mesh, TMP_P, FXT, alpha, true);
    }
  }
  var FXT = [1, 1, 1];

  /* ---------- أرقام الضرر (DOM فوق الرأس) ---------- */
  function spawnFloat(st, fl) {
    if (!st.floatsSeen) { st.floatsSeen = {}; st.floatsSeenLen = 0; }
    if (st.floatsSeen[fl.id]) return;
    if (st.floatsSeenLen > 900) { st.floatsSeen = {}; st.floatsSeenLen = 0; }
    st.floatsSeen[fl.id] = 1; st.floatsSeenLen++;
    var U = st.units[fl.uid];
    if (!U) return;
    var live = U.fhost.childElementCount;
    if (live > 3 && U.fhost.firstChild) U.fhost.removeChild(U.fhost.firstChild);
    var e = el("span", "s3d-dfloat " + fl.kind);
    e.textContent = fl.kind === "crit" ? "⚡" + fl.text : fl.text;
    e.style.setProperty("--dx", (((fl.id % 5) - 2) * 20) + "px");
    U.fhost.appendChild(e);
    setTimeout(function () { if (e.parentNode) e.parentNode.removeChild(e); }, 1050);
  }

  /* ---------- حركة الوحدة ---------- */
  function easeOut(q) { return 1 - (1 - q) * (1 - q); }
  function doLunge(st, U, act, LY) {
    var melee = !U.boss && window.__solRanged && window.__solRanged(U.spec.name, U.spec.role, U.en ? 1 : 0, false) ? false : (U.boss || U.spec.role === "tank" || U.spec.role === "dps" || U.spec.role === "ranger");
    var dx = 0, dz = 0, cast = true;
    if (act.to !== undefined && LY && LY[act.to] && LY[act.to].side !== U.L.side && melee) {
      var T = unitWorld(LY[act.to]);
      dx = (T.x - U.W.x) * (U.boss ? 0.5 : 0.82);
      dz = (T.z - U.W.z) * (U.boss ? 0.5 : 0.82);
      cast = false;
    }
    U.lunge = { t0: st.fxClock, dur: (cast ? 0.85 : 0.95) / clamp(st.speed || 1, 1, 4), dx: dx, dz: dz, cast: cast };
    /* ضربة قاطعة: خطا سيف يظهران لحظة الاصطدام + شرارات بلون الفصيلة */
    if (!cast && st.R && !st.noGL && LY && LY[act.to]) {
      var TT = unitWorld(LY[act.to]);
      var FC2 = { guardians: "#c46a3a", plains: "#8aa848", oasis: "#2fb8a6", shadow: "#7b68b5", light: "#e8c76a", abyss: "#b34a68" };
      var fcol2 = FC2[U.spec.faction] || "#ffd35a";
      var yaw2 = Math.atan2(TT.x - U.W.x, TT.z - U.W.z);
      addFx(st, { kind: "slash", mesh: st.R.slashArc, x: TT.x, z: TT.z, y: 34, c: rgb(fcol2), s: 1.5, roll: yaw2, t0: st.fxClock + U.lunge.dur * 0.36, dur: 0.3 });
      addFx(st, { kind: "slash", mesh: st.R.slashArc, x: TT.x, z: TT.z, y: 30, c: rgb("#fff6d8"), s: 1.05, roll: yaw2 + 0.85, t0: st.fxClock + U.lunge.dur * 0.4, dur: 0.24 });
      for (var sp3 = 0; sp3 < 4; sp3++) {
        addFx(st, { kind: "spark", mesh: st.R.shard, x: TT.x + (Math.random() - 0.5) * 26, z: TT.z + (Math.random() - 0.5) * 26, y: 12,
          vx: (Math.random() - 0.5) * 70, vz: (Math.random() - 0.5) * 70, vy: 70, c: rgb(fcol2), s: 0.85, t0: st.fxClock + U.lunge.dur * 0.42 + sp3 * 0.02, dur: 0.45 });
      }
    }
    if (cast && st.R && !st.noGL) {
      addFx(st, { kind: "ring", mesh: st.R.shockSmall, x: U.W.x, z: U.W.z, y: 1.4, c: rgb("#ffd35a"), s: 1.1, t0: st.fxClock, dur: 0.42 });
      addFx(st, { kind: "ring", mesh: st.R.shock, x: U.W.x, z: U.W.z, y: 1.4, c: rgb("#fff1b8"), s: 1.5, t0: st.fxClock + 0.12, dur: 0.55 });
      for (var ca = 0; ca < 7; ca++) {
        var can = ca / 7 * Math.PI * 2;
        addFx(st, { kind: "spark", mesh: st.R.shard, x: U.W.x + Math.cos(can) * 22, z: U.W.z + Math.sin(can) * 22, y: 8, vx: 0, vz: 0, vy: 85 + (ca % 3) * 18, c: rgb("#ffd35a"), s: 1.1, t0: st.fxClock + ca * 0.03, dur: 0.6 });
      }
    }
  }

  /* ---------- تلوين الوحدة حسب حالتها ---------- */
  function unitTint(U, t) {
    var fl = U.flash;
    if (!U.alive) return [0.52, 0.47, 0.44];
    if (fl > 0) return [1 + 1.7 * fl, 1 + 1.15 * fl, 1 + 0.85 * fl];
    if (U.ready) { var p = 1 + 0.09 * Math.sin(t * 6.5 + U.phase); return [p * 1.16, p * 1.1, p * 0.82]; }
    return [1, 1, 1];
  }

  /* ---------- بناء مصفوفة الوحدة + أجزائها ---------- */
  var KW_M = M4();
  var UNIT_M = M4(), PART_M = M4(), MVP_M = M4(), ROT_M = M4(), OFF1 = M4(), OFF2 = M4(), MNT_M = M4();
  /* ---------- رسم المطية: أرجل تهرول، ذيل يتمايل، رأس حي، غبار حوافر ---------- */
  function drawMount(st, U, VP, t, mRun, actorOx, actorOz) {
    var M = U.mnt;
    if (!M || !M.parts) return;
    var a = U.alphaGL !== undefined ? U.alphaGL : 1;
    if (a <= 0.02) return;
    var deadQ = U.alive ? 0 : clamp((st.fxClock - U.dieT) / 0.6, 0, 1);
    var fallR = U.alive ? 0 : -1.05 * easeOut(deadQ);
    var gait = (window.SOLMNT && window.SOLMNT.sampleStride)
      ? window.SOLMNT.sampleStride(st.fxClock, U.phase, mRun) : null;
    U._gait = gait;
    var gp = gait ? (gait.runBlend > 0.5 ? gait.runPhase : gait.walkPhase) * Math.PI * 2 : st.fxClock * 11 + U.phase;
    var amp = 0.05 + 0.6 * mRun;
    var bounce = gait ? gait.bounce * mRun : Math.abs(Math.sin(gp * 0.5)) * 2.6 * mRun;
    var by = U.alive ? (Math.sin(t * 2.15 + U.phase) * 0.55 + bounce) : -3 * deadQ;
    m4Mul(MNT_M, m4T(U.W.x + (actorOx || 0), by, U.W.z + (actorOz || 0)), m4Ry(U.face));
    m4Mul(MNT_M, MNT_M, m4S(U.scale, U.scale, U.scale));
    if (fallR !== 0) m4Mul(MNT_M, MNT_M, m4Rx(fallR));
    for (var i = 0; i < M.parts.length; i++) {
      var P2 = M.parts[i], rx = 0, ry = 0, nm = P2.name;
      var foot = gait && gait.legs ? gait.legs[nm] : null;
      if (foot) rx = foot.angle * mRun;
      else if (nm === "legFL" || nm === "legBR") rx = Math.sin(gp) * amp;
      else if (nm === "legFR" || nm === "legBL") rx = Math.sin(gp + Math.PI) * amp;
      if (nm === "mbody") rx = -0.055 * mRun + 0.014 * Math.sin(t * 2.1 + U.phase) + (gait ? gait.bodyPitch * mRun : 0);
      else if (nm === "mneck") ry = Math.sin(t * 0.8 + U.phase) * 0.06;
      else if (nm === "mhead") { rx += mRun > 0.05 ? -0.1 * mRun : 0.05 * Math.sin(t * 1.7 + U.phase); ry = Math.sin(t * 0.8 + U.phase) * 0.08; }
      else if (nm === "mtail") ry = Math.sin(t * 3.4 + U.phase) * (0.3 + 0.3 * mRun);
      else if (nm === "mwingL") rx = Math.sin(t * 6.4) * 0.55;
      else if (nm === "mwingR") rx = Math.sin(t * 6.4 + Math.PI) * 0.55;
      var pivotY = P2.piv[1] + (foot ? foot.lift * mRun * 7 : 0);
      m4Mul(OFF1, MNT_M, m4T(P2.piv[0], pivotY, P2.piv[2]));
      if (ry !== 0) m4Mul(OFF1, OFF1, m4Ry(ry));
      if (rx !== 0) m4Mul(OFF1, OFF1, m4Rx(rx));
      PART_M.set(OFF1);
      m4Mul(MVP_M, VP, PART_M);
      st.R.draw(P2.mesh, MVP_M, WHITE_T, a, false);
    }
    /* غبار الحوافر أثناء الاندفاع */
    if (mRun > 0.35 && st.low !== 2 && st.fxClock - (U._mdT || 0) > 0.09) {
      U._mdT = st.fxClock;
      var bx = U.W.x - Math.sin(U.face) * 28, bz = U.W.z - Math.cos(U.face) * 28;
      for (var d2 = 0; d2 < 2; d2++) {
        addFx(st, { kind: "dust", mesh: st.R.cube, x: bx + (d2 - 0.5) * 16, z: bz + (d2 - 0.5) * 12, y: 5,
          vx: (Math.random() - 0.5) * 30 - Math.sin(U.face) * 42, vz: (Math.random() - 0.5) * 30 - Math.cos(U.face) * 42,
          vy: 26 + Math.random() * 16, c: rgb(thDust(st)), s: 0.75 + Math.random() * 0.4, t0: st.fxClock, dur: 0.5 });
      }
    }
  }

  function drawUnit(st, U, VP, t) {
    var lq = -1;
    var ox = 0, oz = 0, hop = 0;
    if (U.lunge) {
      lq = (st.fxClock - U.lunge.t0) / U.lunge.dur;
      if (lq >= 1) U.lunge = null;
      else {
        var e = Math.sin(Math.PI * lq);
        hop = Math.sin(Math.PI * lq) * (U.lunge.cast ? 5 : (U.mnt ? 4 : 15));
        ox = U.lunge.dx * e; oz = U.lunge.dz * e;
      }
    }
    if (U.rec) {
      var rq = (st.fxClock - U.rec.t0) / U.rec.dur;
      if (rq >= 1) U.rec = null;
      else if (rq >= 0) { var re2 = Math.sin(Math.PI * rq); ox += U.rec.dx * re2; oz += U.rec.dz * re2; }
    }
    var fall = 0, bob = 0;
    if (!U.alive) {
      var dq = clamp((st.fxClock - U.dieT) / 0.6, 0, 1);
      fall = -1.45 * easeOut(dq);
    } else {
      bob = Math.sin(t * 2.15 + U.phase) * 1.4;
    }
    m4Mul(UNIT_M, m4T(U.W.x + ox, hop + bob, U.W.z + oz), m4Ry(U.face));
    if (fall !== 0 && !U.fx) { m4Mul(UNIT_M, UNIT_M, m4Rx(fall)); }
    /* KayKit bind-pose meshes receive SOL3D root-level action posing while
       their source skeletal clips are being retargeted in a later pass. */
    if (U.fx && U.fx.kaykit) {
      if (!U.alive) {
        var kDie = clamp((st.fxClock - U.dieT) / 0.58, 0, 1);
        m4Mul(UNIT_M, UNIT_M, m4Rx(-1.28 * easeOut(kDie)));
      } else if (U.lunge && lq >= 0 && lq < 1) {
        var kAtk = Math.sin(Math.PI * lq);
        m4Mul(UNIT_M, UNIT_M, m4Rx(-0.2 * kAtk));
        m4Mul(UNIT_M, UNIT_M, m4Ry((U.en ? -1 : 1) * 0.13 * kAtk));
      } else if (U.hitT !== undefined && st.fxClock - U.hitT >= 0 && st.fxClock - U.hitT < 0.42) {
        var kHit = (st.fxClock - U.hitT) / 0.42;
        m4Mul(UNIT_M, UNIT_M, m4Rx(0.11 * Math.sin(kHit * Math.PI * 2)));
      } else {
        m4Mul(UNIT_M, UNIT_M, m4Ry(Math.sin(t * 1.35 + U.phase) * 0.025));
      }
    }
    var s = U.scale;
    m4Mul(UNIT_M, UNIT_M, m4S(s, s, s));
    var tint = unitTint(U, t);
    /* ظل */
    var shScale = (U.boss ? 1.9 : (U.mnt ? 1.85 : 1.45)) * (1 - clamp(hop, 0, 20) / 46);
    m4Mul(PART_M, m4T(U.W.x + ox, 1.1, U.W.z + oz), m4S(shScale, 1, shScale));
    m4Mul(MVP_M, VP, PART_M);
    st.R.draw(st.R.shadow, MVP_M, [0, 0, 0], U.hidden ? 0 : (U.alive ? 0.4 : 0.3), true);
    /* المطية تُرسم أولًا تحت البطل */
    var mRun = 0, mLift = 0, riderPose = null;
    if (U.mnt) {
      /* Drive the horse from actual actor travel as well as attacks. The previous
         version only animated it during a lunge, so it appeared frozen while
         the mounted unit was moving through its turn. */
      var motionNow = st.fxClock || 0;
      var motionPrev = U._mountMotion || { x: U.W.x, z: U.W.z, t: motionNow };
      var motionDt = Math.max(0.001, motionNow - motionPrev.t);
      var motionSpeed = Math.hypot(U.W.x - motionPrev.x, U.W.z - motionPrev.z) / motionDt;
      U._mountMotion = { x: U.W.x, z: U.W.z, t: motionNow };
      mRun = clamp(motionSpeed / 115, 0, 1);
      if (U.alive && U.lunge && lq >= 0 && lq < 1) {
        var attackDrive = U.lunge.cast ? 0.28 : Math.max(0.72, Math.sin(Math.PI * lq));
        mRun = Math.max(mRun, attackDrive);
      }
      drawMount(st, U, VP, t, mRun, ox, oz);
      mLift = U.mnt.lift;
      if (U._gait && window.SOLMNT && window.SOLMNT.sampleRiderMotion) {
        riderPose = window.SOLMNT.sampleRiderMotion({
          walkPhase: U._gait.walkPhase, runPhase: U._gait.runPhase,
          walkWeight: 1 - U._gait.runBlend, runWeight: U._gait.runBlend
        });
        /* Convert the source engine's metre offsets to this renderer's 66-unit actor scale. */
        mLift += riderPose.seatLift * (66 / 1.9) * U.scale;
      }
    }
    /* الأجزاء */
    if (U.fx) {
      var fclip = "idle", ftt = t + U.phase;
      if (U.flash > 0.95 && !(U.fxF > 0.95)) U.hitT = st.fxClock;
      U.fxF = U.flash;
      if (!U.alive) { fclip = "die"; ftt = st.fxClock - U.dieT; }
      else if (U.lunge && lq >= 0 && lq < 1) { fclip = U.lunge.cast ? "cast" : "atk"; ftt = lq * U.fx.dur(fclip); }
      else if (U.hitT !== undefined && st.fxClock >= U.hitT && st.fxClock - U.hitT < 0.5) { fclip = "hit"; ftt = (st.fxClock - U.hitT) / 0.5 * U.fx.dur("hit"); }
      var fmesh = U.fx.update(fclip, ftt);
      if (U.mnt) {
        m4Mul(UNIT_M, UNIT_M, m4T(0, mLift, riderPose ? riderPose.seatForward * (66 / 1.9) * U.scale : 0));
        if (riderPose) {
          var riderAttackLean = (U.lunge && lq >= 0 && lq < 1 && !U.lunge.cast) ? 0.16 * Math.sin(Math.PI * lq) : 0;
          m4Mul(UNIT_M, UNIT_M, m4Rx(riderPose.lean * 0.22 + riderPose.pelvisPitch * 0.35 + riderAttackLean));
        }
      }
      m4Mul(MVP_M, VP, UNIT_M);
      st.R.draw(fmesh, MVP_M, tint, U.alphaGL !== undefined ? U.alphaGL : 1, false);
      /* هالة الاستعداد الدوّارة بلون الفصيلة */
      if (U.ready && U.alive && st.R.ringSmall) {
        var fc3 = hex2rgb((F[U.spec.faction] && F[U.spec.faction].color) || "#ffd35a");
        var rp2 = 1 + 0.09 * Math.sin(t * 5.4 + U.phase);
        m4Mul(OFF1, m4T(U.W.x + ox, 1.0, U.W.z + oz), m4S(s * 1.22 * rp2, s, s * 1.22 * rp2));
        m4Mul(MVP_M, VP, OFF1);
        st.R.draw(st.R.ringSmall, MVP_M, fc3, (U.alphaGL !== undefined ? U.alphaGL : 1) * 0.55, true);
      }
      if (U.fx.gear) drawGear3D(st, U, VP, t, tint, ox, oz);
      return;
    }
    var armSwing = 0, legA = 0, legB = 0, castPose = 0;
    if (U.lunge && lq >= 0 && lq < 1) {
      if (U.lunge.cast) { castPose = -2.3 * Math.sin(Math.PI * lq); }
      else { armSwing = -1.35 * Math.sin(Math.PI * lq); legA = 0.5 * Math.sin(Math.PI * lq * 2); legB = -legA; }
    } else {
      armSwing = Math.sin(t * 2.15 + U.phase) * 0.06;
    }
    for (var i = 0; i < U.parts.length; i++) {
      var P = U.parts[i];
      var pn = P.follow || P.name;
      var rx = 0;
      if (pn === "armR") rx = castPose !== 0 ? castPose : armSwing - 0.05;
      else if (pn === "armL") rx = -armSwing + 0.05;
      else if (pn === "legL") rx = legA;
      else if (pn === "legR") rx = legB;
      else if (pn === "torso" && castPose !== 0) rx = 0.10 * Math.sin(Math.PI * lq);
      else if (pn === "head" && castPose !== 0) rx = -0.14 * Math.sin(Math.PI * lq);
      if (rx !== 0) {
        m4Mul(OFF1, UNIT_M, m4T(P.piv[0], P.piv[1], P.piv[2]));
        m4Mul(OFF1, OFF1, m4Rx(rx));
        PART_M.set(OFF1);
      } else {
        m4Mul(OFF1, UNIT_M, m4T(P.piv[0], P.piv[1], P.piv[2]));
        PART_M.set(OFF1);
      }
      m4Mul(MVP_M, VP, PART_M);
      st.R.draw(P.mesh, MVP_M, tint, U.alphaGL !== undefined ? U.alphaGL : 1, false);
    }
  }

  /* ---------- المزامنة مع React ---------- */
  function sync(p) {
    if (!ST || ST.destroyed) return;
    ST.speed = p.speed || 1;
    ST.bt = p.BT || 0; ST.btWall = performance.now();
    if (p.EV && p.EV.length) ST.ev = p.EV;

    var all = (p.d || []).concat(p.c || []);
    for (var i = 0; i < all.length; i++) {
      var u = all[i], U = ST.units[u.uid];
      if (!U) continue;
      var s = p.u ? p.u[u.uid] : null;
      var alive = !s || s.alive !== false;
      if (ST.aliveMap[u.uid] !== undefined && ST.aliveMap[u.uid] !== alive) {
        U.bill.classList.toggle("dead", !alive);
        if (!alive) {
          U.alive = false; U.dieT = ST.fxClock; U.ready = false;
          try { pxDeath(ST, U); } catch (ePD) {}
          U.fadeT = U.en ? ST.fxClock + 1.05 : 0;
          U.lunge = null;
          /* نفخة غبار عند السقوط */
          if (ST.R && !ST.noGL && ST.units[u.uid]) {
            for (var dp = 0; dp < 6; dp++) {
              var dan = dp / 6 * Math.PI * 2;
              addFx(ST, { kind: "dust", mesh: ST.R.cube, x: U.W.x, z: U.W.z, y: 6, vx: Math.cos(dan) * 55, vz: Math.sin(dan) * 55, vy: 36, c: rgb(thDust(ST)), s: 1.2, t0: ST.fxClock, dur: 0.6 });
            }
          }
        }
      }
      ST.aliveMap[u.uid] = alive;
      if (s) {
        if (ST.hpMap[u.uid] !== s.hp) {
          ST.hpMap[u.uid] = s.hp;
          var pct = clamp(s.hp / u.maxHp * 100, 0, 100);
          U.fill.style.width = pct + "%";
          U.hpT.textContent = fmtN(s.hp);
          U.fill.classList.toggle("low", pct < 30);
          if (alive && s.hp < (ST.hitMin[u.uid] === undefined ? Infinity : ST.hitMin[u.uid])) U.flash = 1;
          ST.hitMin[u.uid] = Math.min(ST.hitMin[u.uid] === undefined ? s.hp : ST.hitMin[u.uid], s.hp);
        }
        if (ST.enMap[u.uid] !== s.energy) {
          ST.enMap[u.uid] = s.energy;
          U.enF.style.width = clamp(s.energy, 0, 100) + "%";
          U.ready = s.energy >= 100 && alive;
          U.bill.classList.toggle("ready", U.ready);
        }
        if (ST.shieldMap[u.uid] !== s.shield) {
          ST.shieldMap[u.uid] = s.shield;
          U.shield.style.display = s.shield > 0 ? "inline-block" : "none";
          if (s.shield > 0) U.shield.textContent = "🛡 " + fmtN(s.shield);
        }
      }
    }
    /* هجمات */
    if (p.g) {
      for (var uid in p.g) {
        var act = p.g[uid];
        if (!act || !act.on) continue;
        var key = uid + ":" + act.id;
        if (ST.lungeSeen === undefined) ST.lungeSeen = {};
        if (ST.lungeSeen[key]) continue;
        ST.lungeSeen[key] = 1;
        var U2 = ST.units[uid];
        if (U2 && U2.alive) doLunge(ST, U2, act, p.LY);
      }
    }
    /* مؤثرات */
    if (p.PJ && p.PJ.length) {
      if (!ST.fxSeen) ST.fxSeen = {};
      for (var k = 0; k < p.PJ.length; k++) {
        var fx = p.PJ[k];
        if (ST.fxSeen[fx.id]) continue;
        ST.fxSeen[fx.id] = 1;
        spawnFx(ST, fx);
      }
    }
    /* أرقام */
    if (p.h && p.h.length) spawnFloatFor(ST, p.h);
    /* زعيم */
    if (ST.isBoss && p.c && p.c[0]) {
      var b = p.c[0], bs = p.u ? p.u[b.uid] : null;
      var bp = clamp((bs ? bs.hp / b.maxHp : 1) * 100, 0, 100);
      ST.bossBar.style.width = bp + "%";
      ST.bossPct.textContent = bp.toFixed(1) + "%";
      ST.bossDmg.textContent = fmtN(Math.max(0, b.maxHp - (bs ? bs.hp : b.maxHp)));
    }
    updateTelegraph(p);
    btxSync(p, false);
  }
  function spawnFloatFor(st, list) { for (var i = 0; i < list.length; i++) spawnFloat(st, list[i]); }

  /* ---------- خطاف طبقة أسلوب Mini Tales (SOLBTX) ---------- */
  function btxSync(p, fresh) {
    if (!window.SOLBTX || !window.SOLBTX.sync) return;
    try {
      window.SOLBTX.sync(p, {
        root: ST.root, fresh: !!fresh, gl: !ST.noGL,
        speed: function () { return clamp(ST.speed || 1, 1, 4); },
        focus: S.focus, ringAt: S.ringAt,
        state: S.state
      });
    } catch (e) {}
  }

  /* ---------- التلوّيح المسبق ---------- */
  function updateTelegraph(p) {
    if (!ST.tele || !ST.ev || !ST.ev.length) return;
    var now = ST.bt + (performance.now() - ST.btWall) / 1000 * 3 * ST.speed;
    var best = null;
    var enemies = p.c || [];
    for (var i = 0; i < ST.ev.length; i++) {
      var e = ST.ev[i];
      if (e.t <= now) continue;
      if (e.kind !== "ultimate" && e.kind !== "skill") continue;
      var src = null;
      for (var j = 0; j < enemies.length; j++) if (enemies[j].uid === e.source) { src = enemies[j]; break; }
      if (!src) continue;
      if (!best || e.t < best.e.t) best = { e: e, src: src };
      if (best && e.t > now + 6) break;
    }
    if (best && best.e.t - now < 3.4) {
      var sk = best.e.skillName || "هجوم قادم";
      var aoe = (best.e.targets || []).length > 1;
      ST.tele.innerHTML = "<b>☠ " + (best.src.name || "العدو") + "</b><span>✦ " + sk + (aoe ? " — جماعي!" : "") + "</span><i>" + Math.max(0, best.e.t - now).toFixed(1) + " ث</i>";
      ST.tele.classList.add("on");
      ST.warnUid = best.src.uid;
    } else {
      ST.tele.classList.remove("on");
      ST.warnUid = null;
    }
  }

  /* ---------- حلقة العرض ---------- */
  var EYE = [0, 0, 0], VIEW = M4(), PROJ = M4();
  function renderScene(t) {
    var st = ST, R = st.R;
    if (!R || st.noGL) { updateDOMSlots(t); return; }
    var th = st.theme;
    /* الكاميرا (+ تركيز المهارة النهائية: اقتراب مؤقت من منفّذها) */
    var yaw = st.cam.yaw + st.yawUser + Math.sin(t * 0.13) * 0.014;
    var pitch = clamp(st.cam.pitch + st.pitchUser, 0.42, 1.1);
    var dist = st.cam.dist * st.zoomUser + Math.sin(t * 0.08) * 6;
    /* لا تقريب سينمائي أثناء الضربة القاضية أو المهارة النهائية؛ الكاميرا ثابتة. */
    var fK = 0, fxT = 0, fyT = 0, fzT = 0;
    st.focus = null;
    var cx = st.cam.tx + fxT, cy = st.cam.ty + fyT, cz = st.cam.tz + fzT;
    var cp = Math.cos(pitch);
    EYE[0] = cx + Math.sin(yaw) * cp * dist;
    EYE[1] = cy + Math.sin(pitch) * dist;
    EYE[2] = cz + Math.cos(yaw) * cp * dist;
    VIEW = m4LookAt(EYE[0], EYE[1], EYE[2], cx, cy, cz);
    PROJ = m4Persp(50 * Math.PI / 180, Math.max(0.3, st.w / Math.max(1, st.h)), 30, 5200);
    var VP = m4Mul(M4(), PROJ, VIEW);
    st.VP = VP;
    /* جودة الهاتف */
    var dpr = st.low === 2 ? 1 : (st.low === 1 ? Math.min(window.devicePixelRatio || 1, 1.2) : Math.min(window.devicePixelRatio || 1, 1.5));
    R.resize(st.w, st.h, dpr);
    var fogC = rgb(th.sky[1]);
    R.begin(fogC, dist * 0.82, dist * 1.8);
    R.draw(st.floorMesh, VP, [1, 1, 1], 1, false);
    R.draw(st.propsMesh, VP, [1, 1, 1], 1, false);
    if (st.kayProps && st.kayProps.length) {
      for (var kpi=0;kpi<st.kayProps.length;kpi++) {
        var KP=st.kayProps[kpi];
        m4Mul(PART_M,m4T(KP.x,0,KP.z),m4Ry(KP.rot));
        m4Mul(PART_M,PART_M,m4S(KP.s,KP.s,KP.s));
        m4Mul(MVP_M,VP,PART_M);
        R.draw(KP.mesh,MVP_M,[1,1,1],1,false);
      }
    }
    /* أرواح الساحة: جزيئات ضوء تسبح في الهواء */
    if (!st.motes) {
      st.motes = [];
      var mn2 = st.low === 2 ? 6 : 14;
      for (var mi = 0; mi < mn2; mi++) st.motes.push({ x: (Math.random() - 0.5) * 980, z: (Math.random() - 0.5) * 760, y0: 24 + Math.random() * 96, sp: 5 + Math.random() * 9, ph: Math.random() * 6.283, s: 1.1 + Math.random() * 1.7 });
    }
    var mc2 = rgb(th.sky[1]);
    for (var mi2 = 0; mi2 < st.motes.length; mi2++) {
      var MO = st.motes[mi2];
      var myy = MO.y0 + ((t * MO.sp + MO.ph * 22) % 120);
      var mxx = MO.x + Math.sin(t * 0.45 + MO.ph) * 46;
      m4Mul(PART_M, m4T(mxx, myy, MO.z + Math.cos(t * 0.4 + MO.ph) * 30), m4S(MO.s, MO.s, MO.s));
      m4Mul(MVP_M, VP, PART_M);
      R.draw(R.cube, MVP_M, mc2, 0.13, true);
    }
    /* حلقة تحذير التلوّيح */
    if (st.warnUid && st.units[st.warnUid]) {
      var WU = st.units[st.warnUid];
      var ws = 1 + 0.14 * Math.sin(t * 9);
      m4Mul(PART_M, m4T(WU.W.x, 1.3, WU.W.z), m4S(ws, 1, ws));
      m4Mul(MVP_M, VP, PART_M);
      R.draw(R.ring, MVP_M, rgb("#ff4a3a"), 0.55 + 0.3 * Math.sin(t * 9), true);
    }
    /* الوحدات: البعيد أولًا */
    var ord = st.order.slice().sort(function (a, b) { return st.units[a].W.z - st.units[b].W.z; });
    for (var i = 0; i < ord.length; i++) {
      var U = st.units[ord[i]];
      if (U.hidden) continue;
      /* تلاشي الأعداء بعد سقوطهم */
      if (!U.alive && U.en && U.fadeT && st.fxClock > U.fadeT) {
        var fq = clamp((st.fxClock - U.fadeT) / 0.75, 0, 1);
        U.alphaGL = 1 - fq;
        if (fq >= 1) { U.hidden = true; U.slot.style.display = "none"; continue; }
      }
      drawUnit(st, U, VP, t);
    }
    drawFx(st, VP);
    updateDOMSlots(t);
    try { pxFrame(st, t); } catch (ePF) {}
    st.fxClock += st.frameDt || 0.016;
  }

  /* ---------- إسقاط الواجهة من الفضاء إلى الشاشة ---------- */
  function projectPoint(x, y, z) {
    var VP = ST.VP;
    if (!VP) return null;
    var vw = VP[3] * x + VP[7] * y + VP[11] * z + VP[15];
    if (vw <= 0.001) return null;
    var vx = VP[0] * x + VP[4] * y + VP[8] * z + VP[12];
    var vy = VP[1] * x + VP[5] * y + VP[9] * z + VP[13];
    return {
      x: (vx / vw * 0.5 + 0.5) * ST.w,
      y: (0.5 - vy / vw * 0.5) * ST.h,
      w: vw
    };
  }
  function updateDOMSlots(t) {
    var st = ST;
    for (var uid in st.units) {
      var U = st.units[uid];
      if (U.hidden) continue;
      var P = projectPoint(U.W.x, U.anchorY, U.W.z);
      if (!P) continue;
      var s = clamp(1250 / P.w, 0.52, 1.42);
      U.slot.style.transform = "translate(" + P.x.toFixed(1) + "px," + P.y.toFixed(1) + "px) scale(" + s.toFixed(3) + ")";
      U.slot.style.zIndex = String(Math.max(1, Math.round(30000 - P.w * 10)));
    }
  }

  function loop(ts) {
    if (!ST || ST.destroyed) return;
    ST.raf = requestAnimationFrame(loop);
    if (document.hidden) return;
    var t = ts / 1000;
    var dt = Math.min(0.06, t - (ST.lastT || t));
    ST.lastT = t; ST.frameDt = dt;
    /* قياس الأداء: خفض تلقائي للهواتف الضعيفة */
    ST.frames++; ST.acc += dt;
    if (ST.frames === 80) {
      var avg = ST.acc / 80;
      if (avg > 0.031) { ST.low = 2; resizeST(); }
      else if (avg > 0.022) { ST.low = 1; resizeST(); }
    } else if (ST.frames > 80 && (ST.frames % 240) === 0) {
      ST.acc = Math.max(0, ST.acc - 0); /* دورة قياس جديدة */
      ST.frames = 0;
    }
    if (ST.needResize) { resizeST(); }
    renderScene(t);
  }
  function resizeST() {
    var st = ST;
    if (!st || !st.stage) return;
    var r = st.stage.getBoundingClientRect();
    if (r.width > 2 && r.height > 2) {
      st.w = r.width; st.h = r.height;
      st.needResize = false;
    } else {
      /* العنصر لم يُقاس بعد (مُلحق لاحقًا) — أعد المحاولة في الإطار التالي */
      st.needResize = true;
    }
  }

  /* ---------- بناء المشهد ---------- */
  function mount(root, p) {
    var usig = "";
    try { usig = (p.d || []).map(function (u) { return u.uid + ":" + u.name; }).join("|") + "#" + (p.c || []).map(function (u) { return u.uid + ":" + u.name; }).join("|"); } catch (e) {}
    if (ST && ST.root === root) {
      if (ST.unitSig && usig && ST.unitSig !== usig) { try { destroy(); } catch (e) {} }
      else { ST.unitSig = usig; sync(p); return; }
    }
    if (ST && !ST.destroyed) destroy();
    ST = newSceneState();
    ST.unitSig = usig;
    ST.root = root;
    var th = themeBy(p.theme, p.BG);
    ST.theme = th;
    ST.isBoss = !!p.R;

    root.innerHTML = "";
    buildSky(th, root);

    var stage = el("div", "s3d-stage");
    var canvas = el("canvas", "s3d-gl");
    stage.appendChild(canvas);
    var ui = el("div", "s3d-ui");
    stage.appendChild(ui);
    root.appendChild(stage);
    ST.stage = stage; ST.ui = ui;
    try { ST.R = new Renderer(canvas); } catch (e) { ST.R = null; }
    if (!ST.R) {
      ST.noGL = true;
      var floorCss = el("div", "s3d-viewport");
      var camCss = el("div", "s3d-cam");
      var fl = el("div", "s3d-floor");
      fl.style.background = "linear-gradient(180deg," + th.g1 + "," + th.g2 + ")";
      camCss.appendChild(fl); floorCss.appendChild(camCss); root.appendChild(floorCss);
    }
    root.classList.add("s3d-root", ST.R ? "s3d-glroot" : "s3d-nogl");

    var tele = el("div", "s3d-tele");
    root.appendChild(tele);
    ST.tele = tele;

    if (ST.isBoss && p.c && p.c[0]) {
      var hud = el("div", "s3d-bosshud");
      var nm = el("div", "s3d-bossname"); nm.textContent = "☠ " + p.c[0].name;
      var track = el("div", "s3d-bosstrack");
      var fill = el("div", "s3d-bossfill");
      var pct = el("b", "s3d-bosspct"); pct.textContent = "100%";
      track.appendChild(fill); track.appendChild(pct);
      var dmgRow = el("div", "s3d-bossdmg");
      dmgRow.innerHTML = 'الضرر: <span>0</span>';
      hud.appendChild(nm); hud.appendChild(track); hud.appendChild(dmgRow);
      root.appendChild(hud);
      ST.bossBar = fill; ST.bossPct = pct;
      ST.bossDmg = dmgRow.querySelector("span");
    }

    var all = (p.d || []).concat(p.c || []);
    all.forEach(function (u) { if (p.LY && p.LY[u.uid]) buildUnit(ST, u, p.LY[u.uid]); });

    /* أسهم تفوق الفصائل */
    all.forEach(function (u) {
      var U = ST.units[u.uid]; if (!U) return;
      var f = F[u.faction]; if (!f) return;
      var up = 0, dn = 0;
      all.forEach(function (z) {
        if (z.side === u.side || !F[z.faction]) return;
        if ((f.counters || []).indexOf(z.faction) >= 0) up++;
        if ((F[z.faction].counters || []).indexOf(u.faction) >= 0) dn++;
      });
      if (up || dn) {
        U.adv.style.display = "inline-block";
        U.adv.textContent = up ? "▲" : "▼";
        U.adv.className = "s3d-adv " + (up ? "up" : "dn");
        U.adv.title = up ? "تفوق فصيلي على هذا الخصم" : "تحذير: فصيلة الخصم تتفوق عليك";
      }
    });

    /* أرضية وديكور */
    if (ST.R) {
      ST.floorMesh = ST.R.upload(buildFloor(th, (p.theme && p.theme.n) === "arena"));
      ST.propsMesh = ST.R.upload(buildProps(th));
      sharedMeshes(ST.R);
      /* KayKit dungeon architecture and set dressing around the arena perimeter. */
      ST.kayProps = [];
      if (window.SOLKAY && window.SOLKAY.ok) {
        var kp = [
          ["prop_wall_archedwindow_open",0,-245,0,30],
          ["prop_pillar",-245,-120,0,34],["prop_pillar",245,-120,0,34],
          ["prop_torch_lit",-205,165,0,38],["prop_torch_lit",205,165,0,38],
          ["prop_chest_gold",0,235,0,32],
          ["prop_crates_stacked",-250,175,0,25],["prop_barrel_large_decorated",250,175,0,25]
        ];
        for (var kpi=0;kpi<kp.length;kpi++) {
          var km=window.SOLKAY.makeProp(ST.R.gl,kp[kpi][0]);
          if(km) ST.kayProps.push({mesh:km,x:kp[kpi][1],z:kp[kpi][2],rot:kp[kpi][3],s:kp[kpi][4]});
        }
      }
      /* دخول سينمائي: دوخة ظهور لكل وحدة (ذهبية للأبطال وحمراء للأعداء) */
      var _si = 0;
      for (var _suid in ST.units) {
        var _SU = ST.units[_suid];
        _si++;
        addFx(ST, { kind: "ring", mesh: ST.R.ring, x: _SU.W.x, z: _SU.W.z, y: 1.2, c: rgb(_SU.en ? "#e0805a" : "#e8c98a"), s: 1.5, t0: 0.12 * _si, dur: 0.55 });
        addFx(ST, { kind: "dust", mesh: ST.R.cube, x: _SU.W.x, z: _SU.W.z, y: 6, vx: 0, vz: 0, vy: 30, c: rgb(_SU.en ? "#c9a68a" : "#e8d8a8"), s: 1.1, t0: 0.12 * _si, dur: 0.6 });
      }
    }

    fitCamera(ST);
    bindCameraInput(ST);
    ST.needResize = true;
    resizeST();
    fitCamera(ST);

    /* تلميح الكاميرا */
    var hint = el("div", "s3d-camhint");
    hint.textContent = "🖐 اسحب بطلًا فوق بطل آخر لتبديل مكانيهما • اسحب الأرض للتدوير • إصبعان للتقريب";
    root.appendChild(hint);
    setTimeout(function () { hint.style.opacity = "0"; }, 7000);

    window.addEventListener("resize", onWinResize);

    sync(p);
    btxSync(p, true);
    if (!ST.raf) ST.raf = requestAnimationFrame(loop);
  }
  function onWinResize() { if (ST) ST.needResize = true; }
  function unmount() {
    setTimeout(function () {
      if (ST && ST.root && !ST.root.isConnected) destroy();
    }, 80);
  }
  function destroy() {
    if (!ST) return;
    ST.destroyed = true;
    try { if (window.SOLBTX && window.SOLBTX.destroy) window.SOLBTX.destroy(); } catch (e) {}
    if (ST.raf) cancelAnimationFrame(ST.raf);
    window.removeEventListener("resize", onWinResize);
    if (ST.root) ST.root.innerHTML = "";
    ST = null;
  }

  /* ---------- واجهة bxScene ---------- */
  S.scene = function (p) {
    var ce = S.ce || function (t, a) { return null; };
    return ce("div", {
      className: "s3d-react-root",
      ref: function (elm) { if (elm) mount(elm, p); else unmount(); }
    });
  };
  S.hooks = function (h) { if (h && h.ce) S.ce = h.ce; };
  /* فحص حالة للمطوّر والاختبارات */
  S.state = function () {
    return ST ? {
      gl: !ST.noGL, units: Object.keys(ST.units).length, fx: ST.fx.length,
      fxTotal: ST.fxTotal || 0,
      dist: Math.round(ST.cam.dist * ST.zoomUser), low: ST.low,
      warn: ST.warnUid, boss: ST.isBoss, focus: ST.focus ? ST.focus.uid : null
    } : null;
  };
  S.version = "3-webgl";
})();


