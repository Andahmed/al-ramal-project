

/* ============================================================
   sol-plus — طبقة الأنظمة الكاملة للعبة أساطير الرمال
   كل الأنظمة هنا حقيقية: قتال فعلي، إحصاءات فعلية، حفظ محلي.
   ============================================================ */
(function(){
"use strict";
if(window.__solPlusLoaded)return;
window.__solPlusLoaded=1;

/* ==================== الحالة والحفظ Offline ==================== */
var KEY="sol-plus-v1";
function defaults(){return{
 v:1,tokens:100,
 discovered:{dune:!0},
 atlas:{},                                  /* regionId -> {lv:{1:true,2:true,3:true}} */
 journey:null,journeyRuns:0,
 presets:[null,null,null],
 friendship:{},bonds:{},box:{summoned:{}},
 skills:{attack:0,defense:0,support:0,speed:0},
 wingLevel:1,
 style:"balanced",
 inventory:[],                              /* {slot,tier,stars,src} */
 buildings:{smith:0,academy:0,temple:0,market:0,tales:0},
 relics:[],
 bestiary:{},                               /* name -> {n:count,last:ts,kind:"mob|boss|secret|rare|story"} */
 secret:{},                                 /* regionId -> wins count */
 caravan:{wave:0,best:0},
 rare:{date:"",count:0,caught:0},
 story:{chapter:1,branch:null,flags:{},done:[],rewards:{}},
 achievements:{},
 counters:{crafts:0,merges:0,discovers:0,waveBest:0},
 phase:"auto",
 event:null,                                /* {id, done} */
 buff:null,                                 /* {atk:.2,label} */
 login:{last:"",streak:0},
 wheel:{date:"",spins:0},
 loot:[],
 flags:{},
 abyss:{depth:0,best:0,runs:0,curse:null},
 auction:{item:null,price:0,heat:0,stage:"",wins:0,rival:0},
 tide:{meter:0,surges:0,pearls:0,last:""},
 trial:{date:"",won:0,tries:0},
 advTab:"abyss",
 curseFlag:null
}}
function deepMerge(a,b){for(var k in b){if(b[k]&&typeof b[k]==="object"&&!Array.isArray(b[k])&&a[k]&&typeof a[k]==="object"&&!Array.isArray(a[k]))deepMerge(a[k],b[k]);else a[k]=b[k]}return a}
var S=null;
function st(){if(!S)S=(function(){try{var x=JSON.parse(localStorage.getItem(KEY)||"{}");return deepMerge(defaults(),x)}catch(e){return defaults()}})();return S}
function save(){try{localStorage.setItem(KEY,JSON.stringify(st()))}catch(e){}}
function resetPlus(){S=defaults();save()}

/* ==================== جسر المحرك ==================== */
function G(){return window.__solGet?window.__solGet():null}
function SET(fn){if(window.__solSet)window.__solSet(fn)}
function addRes(d){SET(function(s){var r=Object.assign({},s.resources);["gems","gold","xp","shards","mats","tickets"].forEach(function(k){if(d[k])r[k]=(r[k]||0)+d[k]});var o={resources:r};if(d.energy)o.energy={value:Math.min(120,(s.energy?s.energy.value:0)+d.energy),updatedAt:Date.now()};return o})}

/* ==================== ثوابت المحتوى ==================== */
var FACTIONS={guardians:{name:"حرّاس المدن",icon:"🏰",color:"#c46a3a"},plains:{name:"أهل السهول",icon:"🌾",color:"#8aa848"},oasis:{name:"أهل الواحات",icon:"💧",color:"#2fb8a6"},shadow:{name:"بني الظل",icon:"🌑",color:"#7b68b5"},light:{name:"أبناء الفجر",icon:"✨",color:"#e0c75e"},abyss:{name:"جيش الطوفان",icon:"🌊",color:"#e05252"}};
var GEAR_THUMB={weapon:"weapon",weapon2:"weapon2",armor:"armor",helmet:"helmet",gloves:"gloves",boots:"boots",talisman:"talisman",wing:"wing",shoulder:"shoulder",belt:"belt",legs:"legs",necklace:"necklace",ring:"ring",ring2:"ring2",bracer:"bracer",cloak:"cloak",trinket:"trinket",relic:"relic"};
function gearThumbHTML(slot, size, tier, role, ranged, drag){
 var K=window.SOLKGEAR;
 if(K&&K.ok&&tier){var kt=K.thumbHTML(slot,tier,size,role,ranged,drag);if(kt)return kt}
 var key=GEAR_THUMB[slot]||"weapon",em=(SLOTS.filter(function(x){return x[0]===slot})[0]||[0,0,"⚙️"])[2];
 return '<span style="font-size:'+Math.round(size*.7)+'px;line-height:1;filter:drop-shadow(0 2px 3px #000);pointer-events:none">'+em+'</span>'}
var SLOTS=[["weapon","السلاح","🗡️"],["armor","الدرع","🛡️"],["talisman","التميمة","🧿"],["helmet","الخوذة","⛑️"],["gloves","القفازات","🧤"],["boots","الحذاء","🥾"],["ring","الخاتم","💍"],["wing","الجناح","🪽"],["weapon2","السلاح الثانوي","🏹"],["shoulder","الكتفية","🦺"],["belt","الحزام","🥋"],["legs","السروال","👖"],["necklace","القلادة","📿"],["ring2","الخاتم الثاني","💠"],["bracer","السوار","🔗"],["cloak","العباءة","🧥"],["trinket","الحلية","🔮"],["relic","الأثر","📜"]];
var REGIONS=[
 {id:1,name:"حصون الطين",tag:"أسوار منسية تحت مطرقة الرمال",mobs:["طيني هائم","طيني هائم القديم","طيني هائم الغاضب","طيني هائم المنسي","حارس متآكل","حارس متآكل القديم","حارس متآكل الغاضب","حارس متآكل المنسي","رمّاح الوادي","رمّاح الوادي القديم","رمّاح الوادي الغاضب","رمّاح الوادي المنسي","ساعاتي عجوز","ساعاتي عجوز القديم","ساعاتي عجوز الغاضب","ساعاتي عجوز المنسي","خرّاز الجدران","خرّاز الجدران القديم","خرّاز الجدران الغاضب","خرّاز الجدران المنسي","غول الطمي","غول الطمي القديم","غول الطمي الغاضب","غول الطمي المنسي","كلب الأطلال","كلب الأطلال القديم","كلب الأطلال الغاضب","كلب الأطلال المنسي","حامل الدرع المشقّ","حامل الدرع المشقّ القديم","حامل الدرع المشقّ الغاضب","حامل الدرع المشقّ المنسي","حاكّ الأسوار","حاكّ الأسوار القديم","حاكّ الأسوار الغاضب","حاكّ الأسوار المنسي","طائر الجرن","طائر الجرن القديم","طائر الجرن الغاضب","طائر الجرن المنسي","نجّار الرماد","نجّار الرماد القديم","نجّار الرماد الغاضب","نجّار الرماد المنسي","غراب الحصن","غراب الحصن القديم","غراب الحصن الغاضب","غراب الحصن المنسي","عملاق الطوب","عملاق الطوب القديم","عملاق الطوب الغاضب","عملاق الطوب المنسي","طفح الطين","طفح الطين القديم","طفح الطين الغاضب","طفح الطين المنسي","حرس البوابة","حرس البوابة القديم","حرس البوابة الغاضب","حرس البوابة المنسي"],bosses:["غول الطين الأزلي","والي الحصن المنسي","أفعى الأسوار الكبرى","سيدة الطين الأولى"],secret:"والى الحصن الأزلي"},
 {id:2,name:"السهول الذهبية",tag:"عشب يهمس بصدى الخيل البعيدة",mobs:["راعٍ مرّار","راعٍ مرّار المتوحش","راعٍ مرّار السريع","راعٍ مرّار الجائع","فرسان طليعة","فرسان طليعة المتوحش","فرسان طليعة السريع","فرسان طليعة الجائع","صيّاد خفيّ","صيّاد خفيّ المتوحش","صيّاد خفيّ السريع","صيّاد خفيّ الجائع","عقّار الربى","عقّار الربى المتوحش","عقّار الربى السريع","عقّار الربى الجائع","حرّاس القطيع","حرّاس القطيع المتوحش","حرّاس القطيع السريع","حرّاس القطيع الجائع","ذئب العشب","ذئب العشب المتوحش","ذئب العشب السريع","ذئب العشب الجائع","نسر الذهب","نسر الذهب المتوحش","نسر الذهب السريع","نسر الذهب الجائع","خيل بلا فارس","خيل بلا فارس المتوحش","خيل بلا فارس السريع","خيل بلا فارس الجائع","قنّاص الريح","قنّاص الريح المتوحش","قنّاص الريح السريع","قنّاص الريح الجائع","ثور البراري","ثور البراري المتوحش","ثور البراري السريع","ثور البراري الجائع","حارس الرايات","حارس الرايات المتوحش","حارس الرايات السريع","حارس الرايات الجائع","رامي الحجارة","رامي الحجارة المتوحش","رامي الحجارة السريع","رامي الحجارة الجائع","غزّال الفجر","غزّال الفجر المتوحش","غزّال الفجر السريع","غزّال الفجر الجائع","عرّاب الخيل","عرّاب الخيل المتوحش","عرّاب الخيل السريع","عرّاب الخيل الجائع","سارق القطعان","سارق القطعان المتوحش","سارق القطعان السريع","سارق القطعان الجائع"],bosses:["شيخ الفرسان المغيب","وحش السهول الأكبر","مطرقة الربى المتوهّجة","فارس الكثبان الذهبي"],secret:"شيخ الفرسان الأزلي"},
 {id:3,name:"الواحات المسحورة",tag:"ماءٌ يرى ويُرى، ونخيل يحفظ الأسماء",mobs:["ساحر جدول","ساحر جدول المسحور","ساحر جدول الغائب","ساحر جدول العجوز","قابلة مسحورة","قابلة مسحورة المسحور","قابلة مسحورة الغائب","قابلة مسحورة العجوز","ظبي الواحات","ظبي الواحات المسحور","ظبي الواحات الغائب","ظبي الواحات العجوز","حكواتي أعمى","حكواتي أعمى المسحور","حكواتي أعمى الغائب","حكواتي أعمى العجوز","حارس الغدير","حارس الغدير المسحور","حارس الغدير الغائب","حارس الغدير العجوز","روح النبع","روح النبع المسحور","روح النبع الغائب","روح النبع العجوز","نخلة غريبة","نخلة غريبة المسحور","نخلة غريبة الغائب","نخلة غريبة العجوز","سُحّار الماء","سُحّار الماء المسحور","سُحّار الماء الغائب","سُحّار الماء العجوز","قمر الواحة","قمر الواحة المسحور","قمر الواحة الغائب","قمر الواحة العجوز","ضفدع الغدير","ضفدع الغدير المسحور","ضفدع الغدير الغائب","ضفدع الغدير العجوز","تمساح الرمل","تمساح الرمل المسحور","تمساح الرمل الغائب","تمساح الرمل العجوز","بائعة الندى","بائعة الندى المسحور","بائعة الندى الغائب","بائعة الندى العجوز","غول القصب","غول القصب المسحور","غول القصب الغائب","غول القصب العجوز","عصفور السدر","عصفور السدر المسحور","عصفور السدر الغائب","عصفور السدر العجوز","حامل الجرة","حامل الجرة المسحور","حامل الجرة الغائب","حامل الجرة العجوز"],bosses:["أمّ الجداول المسحورة","هيّة الواحة الغائبة","ثعلب القمر العجوز","ملكة الندى السمراء"],secret:"هيّة الواحة الأزلية"},
 {id:4,name:"ظلال الليل",tag:"هنا تنام الشمس وتغفر الذنوب",mobs:["منسلٍّ غامض","منسلٍّ غامض الصامت","منسلٍّ غامض القاسي","منسلٍّ غامض البارد","قنّاع عتمة","قنّاع عتمة الصامت","قنّاع عتمة القاسي","قنّاع عتمة البارد","كاهن الليل","كاهن الليل الصامت","كاهن الليل القاسي","كاهن الليل البارد","خاطف الأصوات","خاطف الأصوات الصامت","خاطف الأصوات القاسي","خاطف الأصوات البارد","ابن السديم","ابن السديم الصامت","ابن السديم القاسي","ابن السديم البارد","ظلّ بلا صاحب","ظلّ بلا صاحب الصامت","ظلّ بلا صاحب القاسي","ظلّ بلا صاحب البارد","سارق النفَس","سارق النفَس الصامت","سارق النفَس القاسي","سارق النفَس البارد","عين الغيبة","عين الغيبة الصامت","عين الغيبة القاسي","عين الغيبة البارد","همّاج العتمة","همّاج العتمة الصامت","همّاج العتمة القاسي","همّاج العتمة البارد","غول الليل","غول الليل الصامت","غول الليل القاسي","غول الليل البارد","خيّاط الأحلام","خيّاط الأحلام الصامت","خيّاط الأحلام القاسي","خيّاط الأحلام البارد","ربّاب السراب","ربّاب السراب الصامت","ربّاب السراب القاسي","ربّاب السراب البارد","جنديّ الظلال","جنديّ الظلال الصامت","جنديّ الظلال القاسي","جنديّ الظلال البارد","جاسوس القمر","جاسوس القمر الصامت","جاسوس القمر القاسي","جاسوس القمر البارد","حارس الأسرار","حارس الأسرار الصامت","حارس الأسرار القاسي","حارس الأسرار البارد"],bosses:["سيد الأقنعة الأبدي","ذي الظلال الجائع","همّاج العتمة الأكبر","عرّافة الليل الباردة"],secret:"سيد الأقنعة الأزلي"},
 {id:5,name:"حافة الطوفان",tag:"حيث تذوب الأساطير وتولد من جديد",mobs:["رمادي منسيّ","رمادي منسيّ الأعمى","رمادي منسيّ الأبدي","رمادي منسيّ الجائع","صدى أسطورة","صدى أسطورة الأعمى","صدى أسطورة الأبدي","صدى أسطورة الجائع","قادم من تحت","قادم من تحت الأعمى","قادم من تحت الأبدي","قادم من تحت الجائع","همس الرمال","همس الرمال الأعمى","همس الرمال الأبدي","همس الرمال الجائع","طاغية الطوفان","طاغية الطوفان الأعمى","طاغية الطوفان الأبدي","طاغية الطوفان الجائع","موج الطوفان","موج الطوفان الأعمى","موج الطوفان الأبدي","موج الطوفان الجائع","حامل القناع","حامل القناع الأعمى","حامل القناع الأبدي","حامل القناع الجائع","حارس الرماد","حارس الرماد الأعمى","حارس الرماد الأبدي","حارس الرماد الجائع","ثور الطوفان","ثور الطوفان الأعمى","ثور الطوفان الأبدي","ثور الطوفان الجائع","طائر الرماد","طائر الرماد الأعمى","طائر الرماد الأبدي","طائر الرماد الجائع","عملاق الغبار","عملاق الغبار الأعمى","عملاق الغبار الأبدي","عملاق الغبار الجائع","جرس الطوفان","جرس الطوفان الأعمى","جرس الطوفان الأبدي","جرس الطوفان الجائع","تمثال متشقّق","تمثال متشقّق الأعمى","تمثال متشقّق الأبدي","تمثال متشقّق الجائع","عين الطوفان","عين الطوفان الأعمى","عين الطوفان الأبدي","عين الطوفان الجائع","ساعة الغياب","ساعة الغياب الأعمى","ساعة الغياب الأبدي","ساعة الغياب الجائع"],bosses:["قائد الطوفان الرمادي","الأسطورة المنسية الأعظم","فم الهاوية الأزلي","نبض الطوفان الأخير"],secret:"فم الهاوية الأزلي"}];
var ATLAS=[
 {id:"dune",icon:"🏜️",name:"كثبان النسيان",req:1,cost:0,fac:"plains",desc:"آثار مدفونة ووحوش الرمال",relic:"بلورة النسيان",mobs:["هائم الكثبان","ذئب الرمال","قنّاص الكثبان","همّال الأطلال","أفعى الكثبان"],boss:"أفعى الكثبان الكبرى"},
 {id:"crystal",icon:"💎",name:"وادي البلور",req:12,cost:5,fac:"light",desc:"بلورات ترفع ندرة الغنائم",relic:"قلب البلور",mobs:["حامل البلور","رمّاح قزحين","متأمل مشع","حكيم بلوري","قائد قزحين"],boss:"قلب البلور"},
 {id:"hollow",icon:"🌑",name:"السراديب الخفية",req:30,cost:5,fac:"shadow",desc:"ممرات ليلية ووحوش ظل",relic:"تميمة السراديب",mobs:["فأر السراديب","سارق الظلال","عنكب العتمة","حارس سجين","راهب أعمى"],boss:"طاغية السراديب"},
 {id:"storm",icon:"🌪️",name:"عين العاصفة",req:60,cost:8,fac:"light",desc:"منطقة سرية لا تظهر إلا للمستكشفين",relic:"ريشة العاصفة",mobs:["دوّامة صغيرة","طافٍ عاصف","راقص البرق","حامل المطرقة","نابض الرعد"],boss:"عين العاصفة"},
 {id:"sunken",icon:"🗿",name:"مدينة الغرقى",req:100,cost:10,fac:"guardians",desc:"قصة قديمة وجناح أسطوري",relic:"فراغ المدينة",mobs:["غريق مستحيل","حاملة الجدران","صيّاد أعماق","كاهن الغرق","نديم الأميرة"],boss:"سفير المدينة الغرقى"},
 {id:"abyss",icon:"🐉",name:"بوابة الطوفان",req:150,cost:12,fac:"abyss",desc:"آخر أسرار أطلس الرمال",relic:"مفتاح البوابة",mobs:["رمادي متقدّم","مذبح رمادي","طاغية رمادي","منادي الطوفان","فم ثانوي"],boss:"حارس بوابة الطوفان"}];
var RELICS=[
 {id:"r1",name:"قلب الطين الأزلي",src:"الزعيم السري — حصون الطين",lore:"اللبّ الذي شكّل أول سور ردّ الطوفان."},
 {id:"r2",name:"سموّ الراية الذهبية",src:"الزعيم السري — السهول الذهبية",lore:"راية رُفعت يومًا ولم تنحنِ للرماد."},
 {id:"r3",name:"دمعة الواحة",src:"الزعيم السري — الواحات المسحورة",lore:"قطرة كريمة تروي ما لا يرويه النهر."},
 {id:"r4",name:"قناع العتمة الأصلي",src:"الزعيم السري — ظلال الليل",lore:"وجه بني الظل قبل أن يتعلموا الاختفاء."},
 {id:"r5",name:"صمّاء الطوفان",src:"الزعيم السري — حافة الطوفان",lore:"حجر يلتقط همس الموج قبل أن يصير غرقًا."},
 {id:"r6",name:"بلورة النسيان",src:"أطلس الرمال — كثبان النسيان",lore:"تحفظ الأسماء عن نسيان الرمال."},
 {id:"r7",name:"فراغ المدينة",src:"أطلس الرمال — مدينة الغرقى",lore:"فراغٌ على شكل مدينة، يزن كالذاكرة."},
 {id:"r8",name:"ريشة العاصفة",src:"أطلس الرمال — عين العاصفة",lore:"سُرقت من قلب العاصفة وعينها مفتوحة."},
 {id:"r9",name:"عقد الحماة",src:"القصة — فرع الحماة",lore:"عقدٌ ربطته بيدين لا تعرف الفرار."},
 {id:"r10",name:"سهم الصياد",src:"القصة — فرع الصيادين",lore:"سهم لا يخطئ إلا قلبًا خان."},
 {id:"r11",name:"كأس القوافل",src:"حماية القافلة — الموجة 7",lore:"شُرب منه في كل ليلة نجاة."},
 {id:"r12",name:"منجل الصياد",src:"صيد الوحوش النادرة — اصطياد 5",lore:"يحصد الأسماء النادرة من الرمال."},
 {id:"r13",name:"تاج الرمال",src:"نهاية القصة",lore:"لا يُلبس إلا من أطفأ الطوفان."}];
var BUILDINGS=[
 {id:"smith",name:"الحدادة",icon:"⚒️",desc:"يخفض تكلفة التصنيع 8% لكل مستوى ويرفع سقف شطب القطع المصنوعة.",cost:function(l){return{gold:1200+900*l,mats:8+4*l}}},
 {id:"academy",name:"أكاديمية المهارات",icon:"📚",desc:"يخفض تكلفة شجرة المهارات 10% لكل مستوى ويزيد كتب المعارك الخاصة.",cost:function(l){return{gold:1500+1100*l,mats:6+3*l}}},
 {id:"temple",name:"معبد الأجنحة",icon:"🪽",desc:"يقوي كل الأجنحة +10% خصائص لكل مستوى.",cost:function(l){return{gold:1800+1400*l,mats:10+5*l}}},
 {id:"market",name:"السوق",icon:"🏪",desc:"+6% ذهب من كل معارك الأنظمة لكل مستوى.",cost:function(l){return{gold:1000+800*l,mats:5+3*l}}},
 {id:"tales",name:"دار الحكايات",icon:"📖",desc:"+15% مكافآت فصول القصة لكل مستوى، ويسمح بإعادة الفصول المنتهية.",cost:function(l){return{gold:1400+1000*l,mats:6+4*l}}}];
var RARES=[
 {name:"الأسد الرملي الأبهر",faction:"plains",role:"dps"},
 {name:"العنقاء الرملية",faction:"light",role:"support"},
 {name:"سلحفاة الحاتم",faction:"guardians",role:"tank"},
 {name:"حرباء الألوان السبع",faction:"oasis",role:"control"},
 {name:"ذيب النسناس",faction:"shadow",role:"dps"}];
var WING_STAGES=[[1,"جناح السراب","🪽"],[2,"جناح الرماد","🕊️"],[3,"جناح الظلال","🕊️"],[4,"جناح الفجر","🌤️"],[5,"جناح العاصفة","🌪️"],[7,"جناح الأسطورة","🌌"]];
var EVENTS=[
 {id:"caravan-siege",icon:"🐪",name:"قافلة تحت الحصار",text:"لصوص الرمال طوّقوا قافلة عند منحدر الغرب. إن لم تتدخل الآن فستضيع البضاعة والروايات معها.",kind:"battle"},
 {id:"cursed-box",icon:"🎁",name:"صندوق ملعون",text:"صندوق من أطلال قديمة، النقوش تحذّر: «من فتحه آثاره بمن فتحه». قد يخرج منه خير قد يخرج شر.",kind:"choice"},
 {id:"rare-sighting",icon:"✨",name:"وحش نادر يظهر",text:"عين الصيادين التقطت وحشًا نادرًا يرعى قرب الواحة. فرصة لا تتكرر — لكنه ليس ضعيفًا.",kind:"battle"},
 {id:"secret-merchant",icon:"🧳",name:"تاجر سري",text:"تاجر بوجه مغطى يهمس: «عندي قطعة لم يرَ مثلها حدّ… والثمن بسيط».",kind:"choice"},
 {id:"wounded-hero",icon:"🩹",name:"بطل مصاب",text:"وجدتم بطلًا من قرية مجاورة ملقى في الرمال، جرحه عميق والذئاب تقترب.",kind:"choice"}];

/* ==================== خطافات المحرك المعدّل ==================== */
window.__solPlusState=function(){return st()};
window.__solPlusBuff=function(){var b=st().buff;st().buff=null;save();return b?b.atk:0};
window.__solPlusTokens=function(n){st().tokens+=(n||0);save()};
window.__solPlusRecordOn=function(names){var s=st(),ch=0;(names||[]).forEach(function(n){if(!n)return;var b=s.bestiary[n];if(!b){s.bestiary[n]={n:1,last:Date.now(),kind:kindOf(n)};ch++}else{b.n++;b.last=Date.now()}});if(ch)save();return ch};
window.__solPlusPhase=function(){var p=st().phase;if(p!=="auto")return p;var h=new Date().getHours();return h>=19||h<6?"night":"day"};
window.__solPlusScale=function(){var b=st().buildings,ph=window.__solPlusPhase(),gr=0;try{var g2=G();(g2&&g2.team||[]).forEach(function(id){var hr=g2.heroes[id];Object.keys(hr.gear||{}).forEach(function(kk){(hr.gear[kk].runes||[]).forEach(function(rn){if(rn.t==="greed")gr+=(rn.lvl||1)})})})}catch(e){}return{gold:(1+.06*(b.market||0))*(1+.10*gr)*(ph==="night"?1.25:1),xp:ph==="night"?1.25:1,books:Math.floor((b.academy||0)/2)}};
window.__solPlusQ=function(h){
 var s=st(),f=s.friendship[h.defId]||0;
 var hpM=1,atkM=1,defM=1,spdA=0;
 var fr=f*.012;hpM+=fr;atkM+=fr;
 var cm=1+.03*s.story.done.length;hpM*=cm;atkM*=cm;defM*=cm;
 var rl=s.relics.length;hpM+=.01*rl;atkM+=.01*rl;
 atkM+=.02*(s.skills.attack||0);defM+=.02*(s.skills.defense||0);hpM+=.02*(s.skills.support||0);spdA+=1.5*(s.skills.speed||0);
 var wingM=(1+.10*(s.buildings.temple||0))*(1+.06*(s.wingLevel-1));
 if(s.style==="attack")atkM*=1.08;
 else if(s.style==="defense")defM*=1.10;
 else if(s.style==="speed")spdA+=4;
 else{hpM*=1.02;atkM*=1.02;defM*=1.02}
 /* نقوش الرمال — أثر حقيقي من تجهيز البطل */
 try{var gg=h.gear||{};Object.keys(gg).forEach(function(kk){var it=gg[kk];(it.runes||[]).forEach(function(rn){var M2=RN[rn.t];if(!M2)return;var L2=rn.lvl||1;if(M2.atk)atkM*=(1+M2.atk*L2);if(M2.def)defM*=(1+M2.def*L2);if(M2.hp)hpM*=(1+M2.hp*L2);if(M2.spd)spdA+=M2.spd*L2})})}catch(e){}
 /* روابط الأبطال — إذا اجتمع الثنائي في الفريق */
 try{var tm=(window.__solGet?window.__solGet().team:[])||[];BONDS.forEach(function(bd){if(tm.indexOf(bd.a)>=0&&tm.indexOf(bd.b)>=0&&(h.defId===bd.a||h.defId===bd.b)){if(bd.atk)atkM*=(1+bd.atk);if(bd.def)defM*=(1+bd.def);if(bd.hp)hpM*=(1+bd.hp);if(bd.spd)spdA+=bd.spd}})}catch(e){}
 /* لعنة الهاوية المؤقتة على الأبطال */
 try{if(s.curseFlag==="slow")spdA-=4;else if(s.curseFlag==="weaken")atkM*=.92;else if(s.curseFlag==="brittle")defM*=.92}catch(e){}
 try{var _bn=Object.keys((s.box&&s.box.summoned)||{}).length;if(_bn){var _bm=1+.002*_bn;atkM*=_bm;hpM*=_bm}}catch(e){}
 /* خصائص المطية المجهّزة للبطل */
 try{var _md=window.SOLMNT&&window.SOLMNT.defOf?window.SOLMNT.defOf(h.defId||h.name):null;if(_md){if(_md.atk)atkM*=(1+_md.atk);if(_md.hp)hpM*=(1+_md.hp);if(_md.def)defM*=(1+_md.def)}}catch(e){}
 return{hpM:hpM,atkM:atkM,defM:defM,spdA:spdA,wingM:wingM}
};
window.__solPlusRecord=function(title,names,won){
 var s=st(),ch=0;
 (names||[]).forEach(function(n){if(!n)return;var b=s.bestiary[n];if(!b){s.bestiary[n]={n:1,last:Date.now(),kind:kindOf(n)};ch++}else{b.n++;b.last=Date.now()}});
 if(ch){save()}
};
function kindOf(n){
 var i;if((i=REGIONS.findIndex(function(r){return r.secret===n}))>=0)return"secret";
 if((i=REGIONS.findIndex(function(r){return r.boss===n}))>=0||(i=REGIONS.findIndex(function(r){return r.bosses&&r.bosses.indexOf(n)>=0}))>=0)return"boss";
 if(ATLAS.findIndex(function(r){return r.boss===n})>=0)return"boss";
 if(RARES.findIndex(function(r){return r.name===n})>=0)return"rare";
 return"mob";
}

/* ==================== واجهة: أدوات مشتركة ==================== */
var CSS=document.createElement("style");
CSS.textContent=[
".sp-ui{font-family:Cairo,'Noto Kufi Arabic',sans-serif}",
".sp-panel{margin:10px 12px 84px;padding:14px;border:1px solid rgba(212,169,65,.4);border-radius:18px;background:linear-gradient(180deg,#1f1712,#141017);box-shadow:0 8px 30px rgba(0,0,0,.55);color:#ffedb0;scroll-margin-top:104px}",
".sp-panel>div:first-child{padding-bottom:9px;border-bottom:1px dashed rgba(212,169,65,.22)}",
".sp-tabs{display:flex;gap:4px;margin:0 0 8px;padding:0;scrollbar-width:none}",
".sp-tabs::-webkit-scrollbar{display:none}",
".sp-tab{flex:1 1 0;min-width:0;white-space:normal;line-height:1.3;text-align:center;border:1px solid rgba(212,169,65,.4);border-radius:12px;padding:7px 2px;background:#241a10;color:#ffe9a3;font:700 9.5px Cairo;cursor:pointer;transition:.15s}",
".sp-tab.on{background:linear-gradient(135deg,#f0c75e,#d4a941);color:#17100a;border-color:#ffd236;box-shadow:0 0 14px rgba(240,199,94,.35)}",
".sp-tab.tower{border-color:#8b5cf688;background:#2e1b55;color:#ddd6fe}",
".sp-tab.tower.on{background:linear-gradient(135deg,#8b5cf6,#6d28d9);color:#fff}",
".sp-card{border:1px solid rgba(212,169,65,.28);border-radius:13px;padding:10px;background:rgba(0,0,0,.22);margin-top:8px}",
".sp-h{font:900 14px Cairo;color:#fde68a}",
".sp-sub{font:10px Cairo;color:rgba(255,234,176,.6);margin:2px 0 7px}",
".sp-btn{border:1px solid rgba(212,169,65,.45);border-radius:9px;padding:7px 10px;background:#241a10;color:#ffe9a3;font:700 10.5px Cairo;cursor:pointer;transition:.15s}",
".sp-btn:hover{filter:brightness(1.2)}",
".sp-btn:disabled{opacity:.4;cursor:not-allowed}",
".sp-btn.gold{background:linear-gradient(135deg,#f0c75e,#d4a941);color:#17100a;border-color:#ffd236;font-weight:900}",
".sp-btn.purple{background:linear-gradient(135deg,#8b5cf6,#6d28d9);color:#fff;border-color:#c4b5fd88}",
".sp-btn.red{background:rgba(224,82,82,.15);color:#fecaca;border-color:rgba(224,82,82,.4)}",
".sp-btn.green{background:rgba(16,185,129,.15);color:#86efac;border-color:rgba(16,185,129,.4)}",
".sp-chip{display:inline-flex;align-items:center;gap:4px;border:1px solid rgba(212,169,65,.3);border-radius:99px;padding:4px 9px;font:700 10px Cairo;color:#fde68a;background:rgba(0,0,0,.3);white-space:nowrap}",
".sp-bar{height:8px;border-radius:99px;background:rgba(0,0,0,.5);overflow:hidden;border:1px solid rgba(212,169,65,.2)}",
".sp-bar>i{display:block;height:100%;background:linear-gradient(90deg,#f0c75e,#d4a941)}",
".sp-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:7px}",
".sp-grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}",
".sp-modal{position:fixed;inset:0;z-index:200;display:none;align-items:flex-end;justify-content:center;background:rgba(0,0,0,.6);backdrop-filter:blur(2px)}",
".sp-modal.open{display:flex}",
".sp-modal-box{width:100%;max-width:440px;max-height:88vh;overflow-y:auto;border-radius:22px 22px 0 0;border:1px solid rgba(212,169,65,.4);background:linear-gradient(180deg,#241a10,#17100a);padding:16px;color:#ffedb0;animation:spUp .22s ease}",
".sp-modal-box::-webkit-scrollbar{width:4px}.sp-modal-box::-webkit-scrollbar-thumb{background:rgba(212,169,65,.3);border-radius:99px}",
"@keyframes spUp{from{transform:translateY(30px);opacity:0}to{transform:none;opacity:1}}",
".sp-toast{position:fixed;bottom:74px;top:auto;left:50%;transform:translateX(-50%);max-width:340px;width:calc(100% - 48px);z-index:95;text-align:center;border:1px solid rgba(212,169,65,.6);border-radius:99px;background:rgba(36,26,16,.96);color:#fde68a;padding:9px 14px;font:700 11.5px Cairo;opacity:0;transition:.25s;pointer-events:none;box-shadow:0 8px 24px rgba(0,0,0,.6)}",
".sp-talk{border-radius:14px;padding:10px 12px;font:600 12.5px/1.8 Cairo;position:relative;margin-top:10px;border:1px solid rgba(212,169,65,.25);background:rgba(0,0,0,.3)}",
".sp-talk b{color:#fde68a}",
".sp-narr{border-radius:14px;padding:10px 12px;font:italic 600 12.5px/1.8 Cairo;color:rgba(255,237,176,.85);margin-top:10px;background:rgba(240,199,94,.06);border:1px dashed rgba(212,169,65,.3)}",
".sp-arena{display:flex;justify-content:space-between;gap:8px;align-items:flex-end;padding:8px;border-radius:14px;background:linear-gradient(180deg,rgba(0,0,0,.35),rgba(0,0,0,.15));border:1px solid rgba(212,169,65,.2);margin-top:8px}",
".sp-unit{text-align:center;width:72px}",
".sp-unit .em{font-size:24px;filter:drop-shadow(0 2px 6px rgba(0,0,0,.6))}",
".sp-unit .nm{font:700 8.5px Cairo;color:rgba(255,237,176,.85);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
".sp-row{display:flex;gap:6px;align-items:center;flex-wrap:wrap}",
".sp-boxhead{display:flex;align-items:center;justify-content:space-between;gap:8px;width:calc(100% - 24px);margin:10px 12px 0;padding:12px 14px;border:1px solid rgba(212,169,65,.45);border-radius:16px;background:linear-gradient(180deg,#2a1d12,#171017);color:#fde68a;font:900 14px Cairo;cursor:pointer;box-shadow:0 4px 16px rgba(0,0,0,.4)}",
".sp-boxhead small{display:block;font:600 10px Cairo;color:rgba(255,234,176,.6);margin-top:2px}",
".sp-boxhead .ch{font-size:16px;transition:.2s}",
".sp-boxhead.open{border-color:#f0c75e;box-shadow:0 0 16px rgba(240,199,94,.25)}",
".sp-boxhead.open .ch{transform:rotate(180deg)}",
".sp-box-in{margin:8px 12px 0}",
".sp-forge-box,.sp-fx-box{margin:10px 12px 2px;padding:12px;border:1px solid rgba(212,169,65,.4);border-radius:18px;background:linear-gradient(180deg,#1f1712,#141017);color:#ffedb0;box-shadow:0 8px 30px rgba(0,0,0,.55)}"
].join("");
document.head.appendChild(CSS);

var toastEl=null,toastT=null;
function toast(msg){
 if(!toastEl||!toastEl.isConnected){toastEl=document.createElement("div");toastEl.className="sp-toast";document.body.appendChild(toastEl)}
 toastEl.textContent=msg;toastEl.style.opacity="1";
 clearTimeout(toastT);toastT=setTimeout(function(){toastEl.style.opacity="0"},2200)
}
function fmt(n){n=Math.round(n||0);if(n>=1e6)return(n/1e6).toFixed(n>=1e7?0:1)+"م";if(n>=1e4)return(n/1e3).toFixed(n>=1e5?0:1)+"ألف";return n.toLocaleString("en-US")}
function esc(x){return String(x==null?"":x).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function hh(){var d=new Date();return d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()}

/* ==================== نظام النوافذ ==================== */
/* ملاحظة: Next.js يمسح عناصر body المضافة يدويًا عند فشل الترطيب — لذا الإنشاء كسول وإرجاع تلقائي */
var modal=null;
function ensureModal(){
 if(!modal||!modal.isConnected){
  modal=document.createElement("div");
  modal.className="sp-modal sp-ui";
  modal.innerHTML='<div class="sp-modal-box" id="sp-modal-box"></div>';
  document.body.appendChild(modal);
  modal.addEventListener("click",function(e){if(e.target===modal)closeModal()})
 }
 return modal
}
function openModal(html,opts){
 ensureModal();
 document.getElementById("sp-modal-box").innerHTML=html;
 modal.classList.add("open");
 if(opts&&opts.dark)modal.style.background="rgba(0,0,0,.78)";else modal.style.background="rgba(0,0,0,.6)";
 return modal
}
function closeModal(){if(modal){modal.classList.remove("open");var bx=document.getElementById("sp-modal-box");if(bx)bx.innerHTML=""}}
function modalOpen(){return !!(modal&&modal.classList.contains("open"))}

/* تفويض النقر العام لكل أزرار sp-act */
document.addEventListener("click",function(e){
 var b=e.target.closest("[data-sp]");
 if(!b)return;
 var k=b.getAttribute("data-sp");
 if(modal&&modal.contains(b)){ /* allowed anywhere */ }
 var fn=ACT[k];
 if(fn){e.preventDefault();fn(b,b.getAttribute("data-arg"))}
});
var ACT={};
ACT["sp-close"]=function(){closeModal()};

/* ==================== لوحة الأدمن (من الترس) ==================== */
window.__solAdmin=function(){adminOpen()};
function adminOpen(){
 var g=G();if(!g){toast("انتظر تحميل اللعبة…");return}
 var R=g.resources||{};
 var rows=[["gems","💎","الجواهر"],["gold","🪙","الذهب"],["xp","📜","الخبرة"],["mats","⚙️","خامات صنع المعدات"],["shards","🔷","الشظايا"],["tickets","🎫","التذاكر"],["energy","⚡","الطاقة"]];
 var h='<div style="direction:rtl;font-family:Cairo"><div style="font:900 17px Cairo;color:#ffedb0;text-align:center;margin-bottom:8px">🛠 لوحة الأدمن</div>';
 h+='<div style="display:flex;gap:6px;align-items:center;margin-bottom:8px;font:700 11px Cairo;color:#ffe9b0">الكمية: <input id="adm-amt" type="number" value="10000" style="flex:1;background:#120c06;color:#ffe9b0;border:1px solid rgba(212,169,65,.4);border-radius:8px;padding:6px;font:700 13px Cairo"></div>';
 rows.forEach(function(r){
  h+='<div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin:4px 0;padding:6px 8px;border-radius:10px;background:rgba(0,0,0,.3)"><span style="font:800 12px Cairo;color:#ffe9b0">'+r[1]+' '+r[2]+'</span><button class="sp-btn gold" style="padding:6px 14px" data-sp="adm-add" data-arg="'+r[0]+'">+ زوّد</button></div>';
 });
 h+='<div style="font:900 13px Cairo;color:#ffedb0;margin:12px 0 6px">🗡 إضافة معدات للمخزن</div>';
 h+='<div style="display:flex;gap:6px;margin-bottom:6px"><select id="adm-slot" style="flex:1;background:#120c06;color:#ffe9b0;border:1px solid rgba(212,169,65,.4);border-radius:8px;padding:6px;font:700 12px Cairo">'+SLOTS.map(function(x){return '<option value="'+x[0]+'">'+x[2]+' '+x[1]+'</option>'}).join("")+'</select>';
 h+='<select id="adm-tier" style="width:80px;background:#120c06;color:#ffe9b0;border:1px solid rgba(212,169,65,.4);border-radius:8px;padding:6px;font:700 12px Cairo">'+[1,2,3,4,5,6,7].map(function(t){return '<option value="'+t+'"'+(t===7?" selected":"")+'>'+TNm(t)+'</option>'}).join("")+'</select>';
 h+='<select id="adm-stars" style="width:70px;background:#120c06;color:#ffe9b0;border:1px solid rgba(212,169,65,.4);border-radius:8px;padding:6px;font:700 12px Cairo">'+[0,1,2,3,4,5].map(function(t){return '<option value="'+t+'">'+t+'★</option>'}).join("")+'</select></div>';
 h+='<div style="display:grid;gap:6px"><button class="sp-btn gold" style="padding:9px" data-sp="adm-gear">➕ أضف القطعة المحددة</button><button class="sp-btn purple" style="padding:9px" data-sp="adm-gear-all">🎁 أضف قطعة من كل خانة بالدرجة المحددة</button><button class="sp-btn" style="padding:9px" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0});
}
function admAmt(){var e=document.getElementById("adm-amt");var n=e?parseInt(e.value,10):0;return isFinite(n)&&n>0?n:0}
ACT["adm-add"]=function(b,k){
 var n=admAmt();if(!n){toast("اكتب كمية صحيحة");return}
 var d={};d[k]=n;addRes(d);
 toast("✅ تمت زيادة "+n.toLocaleString("en-US"))
};
function admPush(slot,tier,stars){st().inventory.push({slot:slot,tier:tier,stars:stars,src:"الأدمن"})}
ACT["adm-gear"]=function(){
 var sl=document.getElementById("adm-slot").value,t=+document.getElementById("adm-tier").value,sr=+document.getElementById("adm-stars").value;
 admPush(sl,t,sr);save();toast("✅ أُضيفت القطعة للمخزن")
};
ACT["adm-gear-all"]=function(){
 var t=+document.getElementById("adm-tier").value,sr=+document.getElementById("adm-stars").value;
 SLOTS.forEach(function(x){admPush(x[0],t,sr)});save();toast("✅ أُضيفت "+SLOTS.length+" قطعة للمخزن")
};

/* ==================== قاذف المعارك (محرك القتال الحقيقي) ==================== */
function ensureCampaign(cb){
 var g=G();
 if(!g){toast("انتظر تحميل اللعبة…");return}
 if(g.screen==="campaign"&&window.__solBattle){cb();return}
 SET(function(){return{screen:"campaign"}});
 var n=0;
 (function wait(){var g2=G();if(g2&&g2.screen==="campaign"&&window.__solBattle){setTimeout(cb,80)}else if(n++<25){setTimeout(wait,120)}})()
}
function goPlusTab(tab){
 
 ensureCampaign(function(){setActiveTab(tab)})
}
/* مراقبة نهاية المعركة: ننتظر اختفاء شاشة القتال من DOM ونقرأ النتيجة */
function watchBattle(title,onDone){
 var seen=!1,vic=!1,t0=Date.now(),upEver=!1,started=Date.now();
 var pollT=setInterval(function(){
  try{
   var els=document.querySelectorAll("div.fixed.inset-0.z-50"),up=!1;
   for(var i=0;i<els.length;i++){if((els[i].innerText||"").indexOf(title)>=0){up=!0;break}}
   if(up){
    upEver=!0;
    var txt=document.body.innerText||"";
    if(txt.indexOf("نصرٌ حاسم")>=0){seen=!0;vic=!0}
    else if(txt.indexOf("هزيمة")>=0||txt.indexOf("انتهى الوقت")>=0){seen=!0;vic=!1}
    t0=Date.now()
   } else {
    if(!upEver&&Date.now()-started<2500)return;
    clearInterval(pollT);onDone(vic,seen);return
   }
   if(Date.now()-t0>420000){clearInterval(pollT);onDone(!1,!1);return}
  }catch(e){}
 },300)
}
function launch(custom,title,bg,onClose){
 ensureCampaign(function(){
  if(!window.__solFightMode||!window.__solBattle){toast("محرك القتال لم يجهز بعد");return}
  var bf=window.__solPlusBuff?window.__solPlusBuff():0;
  if(bf)custom.buff=bf;
  window.__solBattleSnapshot=window.__solGet?window.__solGet():null;window.__solSnapAt=Date.now();
  var o=window.__solFightMode("custom",1,custom);
  if(o.error){window.__solBattleSnapshot=null;toast(o.error);return}
  var pend={names:custom.enemies.map(function(z){return z.name}),tokens:(o.rewards&&o.rewards.tokens)||0,onWin:custom.onWin};
  var bg2=bg||"linear-gradient(180deg,#3a2317 0%,#241610 100%)";
  var finish=function(vic,seen){
   if(!seen){
    toast("رجعت — لم يُحسب شيء من هذه المعركة");
    refreshOpen();
    if(onClose)onClose(!1,{back:!0});
    return
   }
   if(pend.tokens){window.__solPlusTokens(pend.tokens);toast("🎯 +"+pend.tokens+" توكن")}
   if(pend.names)window.__solPlusRecordOn(pend.names);
   if(pend.onWin)pend.onWin(!!vic);
   refreshOpen();
   if(onClose)onClose(!!vic,{})
  };
  window.__solBattle(o,title,bg2,function(){
   window.__solBattleSnapshot=window.__solGet?window.__solGet():null;window.__solSnapAt=Date.now();
   var o2=window.__solFightMode("custom",1,custom);
   if(o2.error){window.__solBattleSnapshot=null;toast(o2.error);return}
   o=o2;
   pend={names:custom.enemies.map(function(z){return z.name}),tokens:(o2.rewards&&o2.rewards.tokens)||0,onWin:custom.onWin};
   window.__solBattle(o2,title,bg2,null)
  });
  watchBattle(title,function(vic,seen){finish(vic,seen)})
 })
}
/* بناء عدو سريع */
function mkEnemy(name,faction,role,level,opts){
 opts=opts||{};
 return{name:name,faction:faction,role:role,level:level,powerMult:opts.powerMult||(0.92+Math.random()*.16),isBoss:!!opts.isBoss,hpM:opts.hpM||1,atkM:opts.atkM||1,defM:opts.defM||1,variant:opts.variant}
}
function enemyRowHTML(list){
 return '<div class="sp-arena">'+list.map(function(e){
  var em=FACTIONS[e.faction]?FACTIONS[e.faction].icon:"🌊";
  return '<div class="sp-unit"><div class="em">'+(e.isBoss?"☠️":em)+'</div><div class="nm">'+esc(e.name)+'</div><div style="font:700 8px Cairo;color:#fca5a5">م'+e.level+(e.isBoss?" ☠":"")+'</div></div>'
 }).join("")+"</div>"
}


/* ============================================================
   الجزء الثاني — القصة التفاعلية «حكايات الرمال»
   ============================================================ */
var CH_COLORS={};REGIONS.forEach(function(r){CH_COLORS[r.id]=["#c46a3a","#8aa848","#2fb8a6","#7b68b5","#e05252"][r.id-1]});
function lvl(base){var bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;return Math.max(base,Math.round(bs*.8)+1)}
function bossLvl(base){var bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;return Math.max(base,Math.round(bs*.85)+2)}
function storyRewards(g,xp,mat,gem,tok){
 var t=1+.15*(st().buildings.tales||0);
 return{gold:Math.round(g*t),xp:Math.round(xp*t),mats:Math.round(mat*t),gems:Math.round(gem*t),tokens:Math.round(tok*t)}
}
var CH=[
{id:1,title:"وعد الحائط",regionName:"حصون الطين",req:0,
 hook:"القرية الطينية الأولى تسمع خطى تحت الرمال — الوقت يبحث عن حائطٍ يثق به.",
 steps:function(){
  var L=lvl(1),B=bossLvl(3);
  return[
   {t:"narr",text:"يقول الحكواتي إن الطوفان الرمادي لم يأتِ من السماء ولا من البحر… بل من نسيان الناس. فكل اسم يُنسى في الرمال يصير طبقة رماد، وكل حكاية تُروى تصير سورًا."},
   {t:"talk",who:"سدّيم الحصن",text:"افتح عينيك يا صاحبي… الرمل يهتز تحت القرية. هذه ليست ريحًا، هذه خطى تحت الرمال. إن سقطت القرية اليوم، غدًا تسقط الطرق، وبعد غدٍ تُنسى أساطيرنا كلها."},
   {t:"talk",who:"ندى الواحة",text:"الماء يقول إن الأسوار تذكّر أسماء من حموها. فلنجعل اسمك أول اسم تحفظه هذه الأرض."},
   {t:"battle",name:"الفصل ١ — كشافة الرماد",bg:"linear-gradient(180deg,#3a2317,#241610)",enemies:[mkEnemy("طيني هائم","guardians","tank",L),mkEnemy("رمّاح الوادي","guardians","dps",L)],rewards:storyRewards(700,600,4,25,2)},
   {t:"talk",who:"صقر السهول",text:"جئتُ خلفهم من السهول. ليسوا آخر من سيمشي في هذا الاتجاه… شيءٌ يلتهم الأسماء يتقدم، وكل قرية يصطدم بها يصير «كانت»."},
   {t:"choice",q:"وقبل أن يمتد الانهيار… كيف تريد أن يعرفك حصون الطين؟",options:[
     {label:"🛡️ درعًا للقرية — لن يعبث الطوفان بما أحبه",hint:"فرع الحماة: مكافآت دفاعية وأثر العقد",set:{branch:"defend"}},
     {label:"⚔️ سيفًا في الظلام — سأطاردوا قبل أن يلحظونا",hint:"فرع الصيادين: مكافآت هجومية وأثر السهم",set:{branch:"hunt"}}]},
   {t:"battle",name:"الفصل ١ — تحتم الأسوار",bg:"linear-gradient(180deg,#3a2317,#241610)",enemies:[mkEnemy("حارس متآكل","guardians","tank",L+1),mkEnemy("خرّاز الجدران","guardians","dps",L+1)],rewards:storyRewards(900,800,5,30,2)},
   {t:"narr",text:"ثم خرج من تحت الأسوار ما لا يخرج إلا حين تُنسى القرية: غولٌ من طين الأجداد، يحمل في جسده أسماء بيوت لم يعد لها أصحاب."},
   {t:"battle",name:"الفصل ١ — ☠ غول الطين",bg:"linear-gradient(180deg,#3a2317,#241610)",enemies:[mkEnemy("غول الطين","guardians","dps",B,{isBoss:!0,hpM:1.15}),mkEnemy("حارس متآكل","guardians","tank",L)],rewards:storyRewards(1600,1400,10,60,4),gear:{slot:"armor",tier:2}},
   {t:"talk",who:"سدّيم الحصن",text:"قمتَ فوق حائطٍ كان نعشًا، وصار منزلًا. خذ هذا… كان سلاح أول من حاميها، وسيرافق من يحمل الحكاية."},
   {t:"end",text:"حُفظ اسمك في طين الحصون. والطوفان… يعرف اسمك الآن أيضًا."}
  ]}},
{id:2,title:"أنفاس السهول",regionName:"السهول الذهبية",req:10,
 hook:"القطيع لا ينام، والغزاة يعرفون الطريق. هنا يُختبر وعدك الذي حملته من الطين.",
 steps:function(){
  var L=lvl(11),B=bossLvl(14),br=st().story.branch;
  var s=[
   {t:"narr",text:"السهول الذهبية تشبه بحرًا نائمًا. لكن الليلة، العشب يقف على أطرافه: غزاة الرماد يعرفون طريق القطيع."},
   {t:"talk",who:"صقر السهول",text:"سمعت خيلهم قبل أن أرى رايتهم. هذا ليس غزوًا… هذا مطاردة. هم يتبعون رائحة الأسماء مثل الكلاب."},
   {t:"battle",name:"الفصل ٢ — طلائع الغزاة",bg:"linear-gradient(180deg,#2e2b14,#1d1c0d)",enemies:[mkEnemy("راعٍ مرّار","plains","support",L),mkEnemy("فرسان طليعة","plains","dps",L)],rewards:storyRewards(1100,1000,6,35,2)}
  ];
  if(br==="defend"){
   s.push({t:"talk",who:"بركة الريح",text:"إن كنت قادمًا كدرعٍ كما قلت في الطين… فساعدنا في تحصين المعسكر، فالقطيع لا يقاتل، القطيع يُحمى."},
    {t:"battle",name:"الفصل ٢ — حماية القطيع",bg:"linear-gradient(180deg,#2e2b14,#1d1c0d)",enemies:[mkEnemy("حرّاس القطيع المنقلبون","plains","tank",L+1),mkEnemy("صيّاد خفيّ","plains","dps",L+1)],rewards:storyRewards(1300,1100,7,40,3),gear:{slot:"helmet",tier:2}})
  }else{
   s.push({t:"talk",who:"عاصف الخيل",text:"قيل إنك سيفٌ في الظلام… فاذبح معي طريق الغزاة إلى عرينهم، فالفرس لا ينتظر."},
    {t:"battle",name:"الفصل ٢ — مطاردة العرين",bg:"linear-gradient(180deg,#2e2b14,#1d1c0d)",enemies:[mkEnemy("فرسان طليعة","plains","dps",L+1),mkEnemy("رمّاح الوادي التائب","guardians","dps",L+1)],rewards:storyRewards(1300,1100,7,40,3),gear:{slot:"weapon",tier:2}})
  }
  s.push(
   {t:"narr",text:"وعند تلال الربى، جلس شيخ الفرسان وحده بعيدًا… لم يعد يعرف اسمه. الطوفان لم يهزمه، بل جعله ينسى من الذي يحمي."},
   {t:"talk",who:"شيخ الفرسان المغيب",text:"من الذي يمشي على أرضي؟… ما اسمي؟ لماذا حصانية تنبض حين أتذكر؟"},
   {t:"battle",name:"الفصل ٢ — ☠ شيخ الفرسان المغيب",bg:"linear-gradient(180deg,#2e2b14,#1d1c0d)",enemies:[mkEnemy("شيخ الفرسان المغيب","plains","dps",B,{isBoss:!0,hpM:1.2}),mkEnemy("فرسان طليعة","plains","dps",L)],rewards:storyRewards(2200,1900,12,70,4),gear:{slot:"ring",tier:2}},
   {t:"talk",who:"صقر السهول",text:"أعادت معركتك إليه اسمه. صرخ خيله فرحًا — هذه أول معركة رأيتها تُعيد شيئًا بدل أن تحرقه."},
   {t:"end",text:br==="defend"?"عُقد في السهول عقد الحماة، ومن يحمل عقدًا لا يفرّق عنه رمل.":"في السهول صار اسمك سهمًا لا يعود دون خبر… أو دون أثر."}
  );
  return s
 }},
{id:3,title:"ماءٌ يرى ويُرى",regionName:"الواحات المسحورة",req:30,
 hook:"النهر يكتب أسماء من يشرب منه — واسمك ظهر مكتوبًا بالمقلوب.",
 steps:function(){
  var L=lvl(31),B=bossLvl(34);
  return[
   {t:"narr",text:"في الواحات المسحورة يوجد نهر لا يُرى إلا لمن حمل اسمًا محفوظًا. الماء يكتب أسماء العابرين على رماله… واسمك ظهر مكتوبًا بالمقلوب."},
   {t:"talk",who:"ندى الواحة",text:"حين يكتب الماء اسمًا بالمقلوب فمعناه أن الرماد حاول سرقته. شيئًا ما هنا يشرب الأسماء ولا يشبع."},
   {t:"battle",name:"الفصل ٣ — جنود الماء العكِس",bg:"linear-gradient(180deg,#12332e,#0c211d)",enemies:[mkEnemy("ساحر جدول","oasis","control",L),mkEnemy("حارس الغدير","oasis","tank",L)],rewards:storyRewards(1500,1300,8,45,3)},
   {t:"choice",q:"الرماد المجهول يسير نحو الغدير الكبير. لديك ساعتان فقط. ماذا تفعل؟",options:[
     {label:"🌊 أتابع أثر الرماد — أريد رؤية وجهه",hint:"مواجهة مباشرة، مكافأة أكبر",set:{flag:"chase"},bonus:{tokens:3}},
     {label:"⛲ أنقذ القابلة المسحورة — الماء أمانة",hint:"طريق أكثر أمانًا، مكافأة دعم",set:{flag:"rescue"},bonus:{gems:20}}]},
   {t:"battle",name:"الفصل ٣ — ظل عند الجدول",bg:"linear-gradient(180deg,#12332e,#0c211d)",enemies:[mkEnemy("قابلة مسحورة المنسية","oasis","support",L+1),mkEnemy("ظبي الواحات","oasis","dps",L+1)],rewards:storyRewards(1700,1500,9,50,3)},
   {t:"narr",text:"في قلب الواحة جلست هيّة الواحة على عرش من نخيل جامد، وعيناها ماءٌ لم يجد طريقًا للبكاء. حُفرت في جسدها مخطوطات لا تخصها."},
   {t:"talk",who:"هيّة الواحة",text:"الرماد يكتب عليّ كل ليلة اسمًا جديدًا… لو نسيت اسمي، فمن سيروي النهر أين يجري؟"},
   {t:"battle",name:"الفصل ٣ — ☠ هيّة الواحة المسحورة",bg:"linear-gradient(180deg,#12332e,#0c211d)",enemies:[mkEnemy("هيّة الواحة المسحورة","oasis","control",B,{isBoss:!0,hpM:1.2}),mkEnemy("حارس الغدير","oasis","tank",L)],rewards:storyRewards(2600,2200,14,80,4),gear:{slot:"talisman",tier:3}},
   {t:"talk",who:"ندى الواحة",text:"شاهد الماء… عاد يكتب أسماء الناس صحيحة. الواحة تعرف الآن أن حكايتها في يد أمينة."},
   {t:"end",text:"النهر يكتب الآن اسمك بلا قلبان. قال الحكواتي: «من مرّ بماءٍ يرى، فلن يكون أبدًا غريبًا في الرمال»."}
  ]}},
{id:4,title:"ليلٌ طويل",regionName:"ظلال الليل",req:60,
 hook:"سيد الأقنعة يجمع الأسماء المسروقة في قناعٍ واحد… وقناعه ينقصه قناعك.",
 steps:function(){
  var L=lvl(61),B=bossLvl(64);
  return[
   {t:"narr",text:"في ظلال الليل لا ينام أحد لأن الأحلام تُسرق قبل النوم. سيد الأقنعة يجمع الأسماء المسروقة، ويخيطها في قناع واحد يقول إنه سيصير به «كل الناس»."},
   {t:"talk",who:"ظفر الليل",text:"إن سمعت امرأة تنادي باسمك من خلف الجدار فلا تجب… الأسماء هنا عملة، وكل إجابة صرقة."},
   {t:"battle",name:"الفصل ٤ — خيّاطو الأقنعة",bg:"linear-gradient(180deg,#241d38,#171226)",enemies:[mkEnemy("قنّاع عتمة","shadow","control",L),mkEnemy("خاطف الأصوات","shadow","dps",L)],rewards:storyRewards(1900,1700,10,55,3)},
   {t:"choice",q:"بابان أمامك: واحد صارخ وواحد صامت. كيف تدخل قاعة سيد الأقنعة؟",options:[
     {label:"🔥 مواجهة صارخة — ليسمع الليل كل اسمه",hint:"معركة أصعب ومكافأة أعلى",set:{flag:"loud"},bonus:{tokens:3}},
     {label:"🌫️ تسللٌ وهمس — الأسماء تُستعاد بهدوء",hint:"معركة أسهل ومكافأة طاقة",set:{flag:"quiet"},bonus:{energy:30}}]},
   {t:"battle",name:"الفصل ٤ — حرّاس القناع",bg:"linear-gradient(180deg,#241d38,#171226)",enemies:[mkEnemy("منسلٌّ غامض","shadow","control",L+1),mkEnemy("ابن السديم","shadow","dps",L+1),mkEnemy("كاهن الليل","shadow","support",L+1)],rewards:storyRewards(2100,1800,11,60,3)},
   {t:"narr",text:"قاعة القناع: آلاف الأسماء معلقة كفانوس. وفي المنتصف، جلسٌ يأخذ الأسماء واحدًا واحدًا ويعطي الناس صمتًا مقابل كل اسم."},
   {t:"talk",who:"سيد الأقنعة",text:"أعط الناس راحة النسيان… وأنت؟ تريد أن تُحمَل الحكاية؟ أعطني اسمك، وسأعطيك غفوة جميلة."},
   {t:"battle",name:"الفصل ٤ — ☠ سيد الأقنعة",bg:"linear-gradient(180deg,#241d38,#171226)",enemies:[mkEnemy("سيد الأقنعة","shadow","control",B,{isBoss:!0,hpM:1.3}),mkEnemy("قنّاع عتمة","shadow","dps",L)],rewards:storyRewards(3200,2600,16,90,5),gear:{slot:"wing",tier:4}},
   {t:"talk",who:"سدّيم الحصن",text:"ألقى الأسماء من فانوسه فطار فوق الظلال كطير… وقناعه سقط ولم يبقَ فيه إلا مكان اسمه هو."},
   {t:"end",text:"من رماد القناع استخرجتم «جناح السراب» — أول جناح يعرف الرمال منذ زمن. كل جناح يُطوَّر لاحقًا سيحمل هذا الأصل."}
  ]}},
{id:5,title:"همسٌ تحت الرمال",regionName:"حافة الطوفان",req:100,
 hook:"تحت الرمال يوجد صوت لا يجيب إلا من حمل أسماءً محفوظة — والزعيم المنسي يستيقظ.",
 steps:function(){
  var L=lvl(101),B=bossLvl(108);
  return[
   {t:"narr",text:"حافة الطوفان: مكان تنتهي فيه الخرائط وتبدأ الذاكرة. هنا يوجد صوت تحت الرمال لا يجيب إلا من حمل أسماءً محفوظة."},
   {t:"talk",who:"صوت العمق",text:"…أخيرًا، اسمٌ يحمل حكاية. الطوفان الرمادي ليس ماءً يا صاحب الحكاية، إنه نسيانٌ يجد طريقه بالجوع. لقد أطعمتموه أسماء كثيرة…"},
   {t:"battle",name:"الفصل ٥ — حرس الرماد المتقدم",bg:"linear-gradient(180deg,#3a1526,#220d18)",enemies:[mkEnemy("رمادي منسيّ","abyss","tank",L),mkEnemy("همس الرمال","abyss","dps",L),mkEnemy("قادم من تحت","abyss","control",L)],rewards:storyRewards(2400,2000,13,70,4)},
   {t:"talk",who:"زهراء الفجر",text:"النور يخترق الرماد هنا فقط عبر ثغرة صغيرة… أغلقوا عينيك وقولوا أسماء من تحبون، فالنور يمر عبر الأسماء المحفوظة."},
   {t:"battle",name:"الفصل ٥ — بقايا أسطورة",bg:"linear-gradient(180deg,#3a1526,#220d18)",enemies:[mkEnemy("بقايا أسطورة","abyss","dps",L+2),mkEnemy("طاغية الطوفان","abyss","tank",L+2),mkEnemy("رمادي منسيّ","abyss","control",L+2)],rewards:storyRewards(2800,2300,15,80,4),gear:{slot:"boots",tier:3}},
   {t:"narr",text:"ثم فتحت الرمال عينها الكبرى: الأسطورة المنسية — أول بطل قاوم الطوفان قبل عصور، نسيَ اسمه فصار هو نفسه غطاء للرماد."},
   {t:"talk",who:"الأسطورة المنسية",text:"أنا؟ كنتُ… كنـتُ؟ لديّ سيف… ولديّ قوم… كيف يُنسى كل هذا في ليلة؟"},
   {t:"battle",name:"الفصل ٥ — ☠ الأسطورة المنسية",bg:"linear-gradient(180deg,#3a1526,#220d18)",enemies:[mkEnemy("الأسطورة المنسية","abyss","dps",B,{isBoss:!0,hpM:1.4}),mkEnemy("همس الرمال","abyss","support",L),mkEnemy("قادم من تحت","abyss","control",L)],rewards:storyRewards(3800,3200,20,110,5),gear:{slot:"gloves",tier:3}},
   {t:"talk",who:"صوت العمق",text:"أعادتَ له اسمه فتفتّت الرماد عن وجهه. الآن يستطيع الصوت أن يجيبك… البوابة الأخيرة تفتح لمن يجمع التاج."},
   {t:"end",text:"تحت الرمال الآن يُروى اسمك كحكاية. ومثل كل الحكايات — سيجعل الوحوش تأتي إليه."}
  ]}},
{id:6,title:"الطوفان الرمادي",regionName:"نهاية الحكاية",req:140,
 hook:"المواجهة الأخيرة: فم الهاوية يفتح، والرمال كلها تتوقف لتسمع نهاية الحكاية.",
 steps:function(){
  var L=lvl(141),B=bossLvl(150);
  return[
   {t:"narr",text:"اجتمع كل فصائل الرمال فوق آخر تلة: حرّاس الطين، فرسان السهول، سحرة الواحات، بني الظل، وأبناء الفجر. والطوفان يقف أمامهم كنسيانٍ بحجم العالم."},
   {t:"talk",who:"سدّيم الحصن",text:"كل حائط بنيناه، كل قطيع حميناه، كل اسم أنقذناه — كلها الآن صفوف في جيشك يا صاحب الحكاية."},
   {t:"talk",who:"ندى الواحة",text:"الماء يكتب اسمك آخر سطر قبل أن يجمَد… «هنا بدأت الحكاية التي أطفأت الطوفان»."},
   {t:"battle",name:"الفصل ٦ — أمواج الطوفان الأولى",bg:"linear-gradient(180deg,#43101f,#1c0a12)",enemies:[mkEnemy("موجة رماديه","abyss","dps",L),mkEnemy("موجة رماديه","abyss","tank",L),mkEnemy("همس الرمال","abyss","control",L)],rewards:storyRewards(3200,2600,16,90,4)},
   {t:"narr",text:"ثم انشقّت الأرض، وخرج مما يشبه فمًا من رمال لا نهاية لها صوتٌ لا يشبه صوتًا… آخر ما يسمعه الاسم قبل أن يُنسى."},
   {t:"talk",who:"فم الهاوية",text:"أنا آخر ما تبقى من كل حكاية لم تُروَ… أعطني أسماءكم، فالرمال تخجل من الأسماء المحفوظة."},
   {t:"battle",name:"الفصل ٦ — ☠ فم الهاوية",bg:"linear-gradient(180deg,#43101f,#1c0a12)",enemies:[mkEnemy("فم الهاوية","abyss","dps",B,{isBoss:!0,hpM:1.6,atkM:1.15}),mkEnemy("قادم من تحت","abyss","tank",L),mkEnemy("رمادي منسيّ","abyss","support",L)],rewards:storyRewards(5200,4200,26,150,8),timeLimit:200,gear:{slot:"ring",tier:5}},
   {t:"talk",who:"الحكواتي",text:"وهكذا، لم يُهزم الطوفان بجيش… بل بحكاية لم تُنسَ. ارفعوا تاج الرمال، فمن يملك تاجًا يحمل على رأسه كل الأسماء التي أنقذها."},
   {t:"end",text:"انتهت الحكاية الأولى… لكن الحكواتي قال: «كل نهاية رملية بداية حكاية». أطلس الرمال بانتظار مستكشف لم ينتهِ بعد."}
  ]}
 }];

/* ==================== محرك عرض القصة ==================== */
var storySceneIdx=0,storyCh=null,storyList=[];
function chapterUnlocked(ch){
 var s=st().story,done=s.done.indexOf(ch.id)>=0;
 if(ch.id===1)return!0;
 var prev=CH[ch.id-2];
 return done||(s.done.indexOf(prev.id)>=0&&((G()&&G().campaign?G().campaign.bestStage:0)>=ch.req))
}
function startChapter(id){
 var ch=CH.find(function(c){return c.id===id});
 if(!ch)return;
 var s=st().story;
 var replay=s.done.indexOf(id)>=0;
 if(replay&&!(st().buildings.tales>0)){toast("افتح دار الحكايات في المدينة لإعادة الفصول");return}
 storyCh=ch;storyList=ch.steps();
 var pos=(st().flags["pos"+id]||0);
 if(replay)pos=0;
 if(pos>=storyList.length)pos=0;
 storySceneIdx=pos;
 renderStoryScene()
}
function storyBg(){return storyCh&&storyCh.id?"linear-gradient(180deg,#221708,#120c14)":"linear-gradient(180deg,#221708,#120c14)"}
function renderStoryScene(){
 var sc=storyList[storySceneIdx];
 if(!sc){endChapter();return}
 var h='<div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:900 17px Cairo;color:#fde68a">📖 الفصل '+storyCh.id+' — '+esc(storyCh.title)+'</b><div style="font:10px Cairo;color:rgba(255,234,176,.55)">'+esc(storyCh.regionName)+' • مشهد '+(storySceneIdx+1)+'/'+storyList.length+'</div></div><button class="sp-btn red" data-sp="story-exit">✕ خروج</button></div>';
 if(sc.t==="talk"){
  h+='<div class="sp-talk"><b style="color:'+(FACTIONS[sc.fc]?FACTIONS[sc.fc].color:"#fde68a")+'">'+esc(sc.who)+':</b><br>'+esc(sc.text)+'</div>';
  h+='<div style="margin-top:12px"><button class="sp-btn gold" style="width:100%;padding:11px" data-sp="story-next">التالي ›</button></div>'
 }else if(sc.t==="narr"){
  h+='<div class="sp-narr">'+esc(sc.text)+'</div>';
  h+='<div style="margin-top:12px"><button class="sp-btn gold" style="width:100%;padding:11px" data-sp="story-next">التالي ›</button></div>'
 }else if(sc.t==="choice"){
  h+='<div class="sp-narr">'+esc(sc.q)+'</div><div style="margin-top:12px;display:grid;gap:8px">';
  sc.options.forEach(function(o,i){
   h+='<button class="sp-btn" style="text-align:right;padding:10px" data-sp="story-choice" data-arg="'+i+'"><b>'+esc(o.label)+'</b><div style="font:9.5px Cairo;color:rgba(255,234,176,.6);margin-top:3px">'+esc(o.hint||"")+'</div></button>'
  });
  h+='</div>'
 }else if(sc.t==="battle"){
  h+='<div class="sp-card"><div class="sp-h">⚔️ '+esc(sc.name)+'</div>'+enemyRowHTML(sc.enemies);
  var rw=sc.rewards||{};
  h+='<div class="sp-row" style="margin-top:6px"><span class="sp-chip">🪙 '+fmt(rw.gold||0)+'</span><span class="sp-chip">📜 '+fmt(rw.xp||0)+'</span><span class="sp-chip">💎 '+(rw.gems||0)+'</span><span class="sp-chip">⚙️ '+(rw.mats||0)+'</span>'+(rw.tokens?'<span class="sp-chip">🪙 توكن '+rw.tokens+'</span>':"")+(sc.gear?'<span class="sp-chip">⚔️ قطعة قصة</span>':"")+'</div>';
  h+='<div style="margin-top:10px"><button class="sp-btn gold" style="width:100%;padding:11px" data-sp="story-battle">⚔️ خُض معركة الفصل</button></div></div>'
 }else if(sc.t==="end"){
  h+='<div class="sp-narr" style="border-color:rgba(240,199,94,.5)">'+esc(sc.text)+'</div>';
  h+='<div style="margin-top:12px"><button class="sp-btn gold" style="width:100%;padding:11px" data-sp="story-finish">إتمام الفصل ✓</button></div>'
 }
 openModal(h,{dark:!0})
}
ACT["story-exit"]=function(){st().flags["pos"+storyCh.id]=storySceneIdx;save();closeModal();refreshOpen()};
ACT["story-next"]=function(){st().flags["pos"+storyCh.id]=++storySceneIdx;save();renderStoryScene()};
ACT["story-choice"]=function(btn,arg){
 var sc=storyList[storySceneIdx],o=sc.options[+arg];
 var f=st().story.flags;f["ch"+storyCh.id]=o.set&&o.set.branch?o.set.branch:o.set&&o.set.flag?o.set.flag:null;
 st().story.branch=f["ch"+storyCh.id];
 if(o.bonus){addRes({gems:o.bonus.gems,energy:o.bonus.energy,gold:o.bonus.gold});if(o.bonus.tokens){st().tokens+=o.bonus.tokens;save()}}
 toast("تم اختيار الطريق: "+o.label);
 st().flags["pos"+storyCh.id]=++storySceneIdx;save();renderStoryScene()
};
ACT["story-battle"]=function(){
 var sc=storyList[storySceneIdx];
 var custom={mode:"story",enemies:sc.enemies,title:sc.name,recordTitle:sc.name,timeLimit:sc.timeLimit||150,
  rewards:function(){return Object.assign({},sc.rewards)},
  onWin:function(vic){
   if(!vic)return;
   if(sc.gear){st().inventory.push({slot:sc.gear.slot,tier:sc.gear.tier,stars:0,src:"قصة — "+storyCh.title});save();toast("⚔️ قطعة القصة أُضيفت للمخزن")}
  }};
 launch(custom,sc.name,sc.bg,function(vic,info){
  if(info&&info.back){renderStoryScene();return}
  if(vic){st().flags["pos"+storyCh.id]=++storySceneIdx;save();renderStoryScene()}
  else{toast("هُزمت المعركة — لا شيء يعادل محاولة أخرى");openStoryRetry(sc)}
 })
};
function openStoryRetry(sc){
 openModal('<div style="text-align:center"><div style="font-size:40px">💀</div><b style="font:900 16px Cairo;color:#fca5a5">لم تكفِ القوة هذه المرة</b><div style="font:11px Cairo;color:rgba(255,234,176,.7);margin:8px 0">طوّر أبطالك والمعدات، أو أعد المحاولة — الرمال لا تنسى المثابرين.</div><div style="display:flex;gap:8px;margin-top:10px"><button class="sp-btn gold" style="flex:1;padding:10px" data-sp="story-retry">🔄 إعادة المحاولة</button><button class="sp-btn" style="flex:1;padding:10px" data-sp="story-exit">خروج</button></div></div>',{dark:!0})
}
ACT["story-retry"]=function(){ACT["story-battle"]()};
ACT["story-finish"]=function(){endChapter()};
function endChapter(){
 var s=st().story,ch=storyCh;
 var first=s.done.indexOf(ch.id)<0;
 if(first){
  s.done.push(ch.id);
  if(ch.id===2){var rel=s.branch==="defend"?"r9":"r10";addRelic(rel);toast("🗿 أثر جديد: "+(RELICS.find(function(r){return r.id===rel})||{}).name)}
  if(ch.id===6)addRelic("r13");
  if(ch.id>=s.chapter)s.chapter=Math.min(CH.length+1,ch.id+1);
 }
 st().flags["pos"+ch.id]=0;save();
 openModal('<div style="text-align:center"><div style="font-size:42px">'+(first?"🏆":"📖")+'</div><b style="font:900 17px Cairo;color:#fde68a">'+(first?"اكتمل الفصل "+ch.id+" — "+esc(ch.title):"أعدت قراءة الفصل "+ch.id)+'</b><div style="font:11px Cairo;color:rgba(255,234,176,.7);margin-top:6px">'+(first?"أُضيفت مكافآت الفصل سابقًا أثناء المعارك، والقصة تفتح الفصل التالي مع تقدم الحملة.":"دار الحكايات أضاءت الفصل من جديد — المكافآت في الإعادة رمزية.")+'</div><div style="margin-top:12px;display:flex;gap:8px"><button class="sp-btn gold" style="flex:1;padding:10px" data-sp="story-close-open">📖 فتح الفصل التالي</button><button class="sp-btn" style="flex:1;padding:10px" data-sp="sp-close">إغلاق</button></div></div>',{dark:!0});
 renderStoryTab()
}
ACT["story-close-open"]=function(){closeModal();renderStoryTab();setActiveTab("story")};
function addRelic(id){var s=st();if(s.relics.indexOf(id)>=0)return;s.relics.push(id);save()}


/* ============================================================
   الجزء الثالث-أ — لوحات: البرج، الأطلس، الرحلة، القصة
   ============================================================ */
var activeTab=null; /* tower|story|atlas|hub|forge */

/* ---------- معاينة البرج ---------- */
function towerStageOf(n){var bs=(G()&&G().campaign?G().campaign.bestStage:0)||1;return Math.max(1,Math.min(200,Math.round(.55*bs+1.6*n)))}
function regionOfStage(sg){return REGIONS[Math.min(4,Math.floor((sg-1)/40))]}
function renderTowerPanel(md){
 var sel=st().flags.selFloor||(md+1>100?100:md+1);
 var done=(G()&&G().modes?G().modes.tower:0)||0;
 var h='<div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:900 19px Cairo;color:#ddd6fe">🏰 برج الرمال</b><div style="font:10px Cairo;color:rgba(196,181,253,.6)">100 طابق — معركة حقيقية لكل طابق، ومكافآت متصاعدة</div></div><span class="sp-chip" style="border-color:#8b5cf666">التقدم: '+Math.min(done,100)+'/100</span></div>';
 h+='<div style="display:grid;grid-template-columns:repeat(10,1fr);gap:4px;margin-top:11px">'+Array.from({length:100},function(_,i){var n=i+1,isDone=n<=done,open=n<=done+1;
  return '<button data-sp="tower-sel" data-arg="'+n+'" style="aspect-ratio:1;border-radius:8px;border:1px solid '+(sel===n?'#ffd236':isDone?'#0284c733':open?'#c4b5fd88':'#ffffff15')+';background:'+(sel===n?'linear-gradient(135deg,#8b5cf6,#6d28d9)':isDone?'#05445e':open?'#2e1b55':'#120f1a')+';color:'+(open?'#fff':'#ffffff40')+';font:900 10px Cairo;cursor:pointer;opacity:'+(open||isDone?'1':'.55')+'">'+n+(isDone?'✓':'')+'</button>'}).join("")+"</div>";
 var sg=towerStageOf(sel),rg=regionOfStage(sg);
 h+='<div class="sp-card" style="border-color:#8b5cf655;background:rgba(139,92,246,.06)"><div class="sp-h" style="color:#ddd6fe">الطابق المحدد: '+sel+'</div><div class="sp-sub">وحوش برمجية معادَة من '+esc(rg.name)+' بمستوى تكافؤ '+sg+(sel%10===0?' — ☠ طابق زعيم':'')+'</div>';
 h+='<div class="sp-row"><span class="sp-chip">🪙 ذهب '+(1800+220*sel).toLocaleString("en-US")+'</span><span class="sp-chip">📜 خبرة '+(1200+180*sel).toLocaleString("en-US")+'</span><span class="sp-chip">⚙️ '+(8+Math.floor(sel/3))+'</span><span class="sp-chip">⚔️ قطعة '+(sel%8===0?'مضمونة':'فرصة')+'</span></div>';
 h+='<div style="margin-top:9px">'+(sel<=done+1?'<button class="sp-btn purple" style="width:100%;padding:11px" data-sp="tower-fight">⚔️ خُض معركة الطابق '+sel+'</button>':'<button class="sp-btn" style="width:100%;padding:11px" disabled>🔒 اكمل الطابق '+done+' أولًا</button>')+'</div></div>';
 h+='<div style="font:10px Cairo;color:rgba(196,181,253,.5);margin-top:8px;text-align:center">اختيار الطابق لا يبدأ القتال — القتال يبدأ من زر المعركة فقط. مكافأة القتال الفعلي أكبر من المعاينة.</div>';
 return h
}
ACT["tower-sel"]=function(b,arg){st().flags.selFloor=+arg;save();renderPanel()};
ACT["tower-fight"]=function(){
 var n=st().flags.selFloor||(((G()&&G().modes?G().modes.tower:0)||0)+1);
 ensureCampaign(function(){
  window.__solBattleSnapshot=window.__solGet?window.__solGet():null;window.__solSnapAt=Date.now();
  var o=window.__solFightMode("tower",n);
  if(o.error){window.__solBattleSnapshot=null;toast(o.error);return}
  var bg="linear-gradient(180deg,#21163b,#0d0a18)",title="برج الرمال — الطابق "+n;
  window.__solBattle(o,title,bg,function(){window.__solBattleSnapshot=window.__solGet?window.__solGet():null;window.__solSnapAt=Date.now();var o2=window.__solFightMode("tower",n);if(o2.error){window.__solBattleSnapshot=null;toast(o2.error);return}window.__solBattle(o2,title,bg,null)});
  watchBattle(title,function(){refreshOpen()})
 })
};

/* ---------- لوحة الأطلس ---------- */
function renderAtlasPanel(){
 var s=st(),h="";
 h+='<div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:900 19px Cairo;color:#ffedb0">🗺️ أطلس الرمال</b><div style="font:10px Cairo;color:rgba(255,234,176,.55)">مناطق مخفية + رحلة السراب — يُحفظ كل شيء على جهازك</div></div><span class="sp-chip">🪙 '+s.tokens+' توكن</span></div>';
 h+='<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:7px;margin-top:10px">';
 var bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 ATLAS.forEach(function(r){
  var open=!!s.discovered[r.id],ready=bs>=r.req;
  h+='<button data-sp="atlas-region" data-arg="'+r.id+'" style="text-align:right;border:1px solid '+(open?'rgba(212,169,65,.55)':'#ffffff1c')+';border-radius:13px;padding:9px;background:'+(open?'linear-gradient(135deg,#3d2d18,#21160e)':'#0c0a12')+';color:'+(open?'#ffe9a3':'#8a8a95')+';cursor:pointer;opacity:'+(ready||open?'1':'.55')+'">';
  h+='<div style="font-size:22px">'+(open?r.icon:'🔒')+'</div><b style="font:700 11px Cairo">'+(open?r.name:'منطقة مخفية')+'</b><div style="font:9px Cairo;opacity:.75;margin-top:2px">'+(open?r.desc:'تُكتشف عند المرحلة '+r.req)+'</div>';
  if(open){var c=(s.atlas[r.id]||{});var cl=[1,2,3].filter(function(i){return c[i]}).length;h+='<div style="margin-top:4px"><span class="sp-chip" style="font-size:8.5px;padding:2px 7px">استكشاف '+cl+'/3</span></div>'}
  h+='</button>'
 });
 h+='</div>';
 /* بطاقة المنطقة المفتوحة */
 var open=ATLAS.filter(function(r){return s.discovered[r.id]&&st().flags.openAtlas===r.id});
 if(open.length){
  var r=open[0],c=s.atlas[r.id]||{};
  h+='<div class="sp-card"><div class="sp-h">'+r.icon+' '+esc(r.name)+' — الاستكشاف</div><div class="sp-sub">'+esc(r.desc)+' • الأثر: '+esc(r.relic)+'</div>';
  [[1,"استكشاف خفيف",2,1],[2,"استكشاف متوسط",3,2],[3,"عمق المنطقة",4,3]].forEach(function(z){
   var i=z[0],cnt=z[1],n=z[2],tok=z[3],lv=Math.max(r.req+i*6,Math.round(bs*.4)+i*5);
   h+='<div style="display:flex;justify-content:space-between;align-items:center;gap:6px;border-top:1px solid rgba(212,169,65,.15);padding:7px 0"><div><b style="font:700 11px Cairo">'+cnt+'</b><div style="font:9px Cairo;color:rgba(255,234,176,.55)">'+n+' وحوش • مستوى '+lv+' • '+tok+' توكن</div></div>'+
     (c[i]?'<span class="sp-chip" style="border-color:#05966966;color:#86efac">مُستكشف ✓</span>':'<button class="sp-btn gold" data-sp="atlas-fight" data-arg="'+r.id+':'+i+':'+lv+':'+tok+'">⚔️ استكشف</button>')+'</div>'
  });
  h+='</div>'
 } else {st().flags.openAtlas=null;save()}
 /* رحلة السراب */
 h+='<div class="sp-card" style="border-color:#8b5cf655;background:rgba(139,92,246,.05)"><div style="display:flex;justify-content:space-between;align-items:center"><div><b class="sp-h" style="color:#d8b4fe">🌀 رحلة السراب</b><div class="sp-sub">6 غرف متغيرة — قتال حقيقي، مزار، تاجر، بوابة، وزعيم</div></div>'+(s.journey?'<button class="sp-btn red" data-sp="journey-end">إنهاء الرحلة</button>':'')+'</div>';
 if(s.journey){
  var jr=s.journey;
  h+='<div style="display:grid;grid-template-columns:repeat(6,1fr);gap:5px;margin-top:9px">';
  jr.rooms.forEach(function(rm,i){
   var cur=i===jr.room,doneR=rm.done;
   h+='<button data-sp="'+(cur?'journey-room':'noop')+'" data-arg="'+i+'" style="border-radius:10px;border:1px solid '+(cur?'#c4b5fd':doneR?'#05966966':'#ffffff15')+';padding:7px 2px;background:'+(doneR?'#047857':cur?'#6d28d9':'#171329')+';color:#fff;font:700 9px Cairo;cursor:'+(cur?'pointer':'default')+';opacity:'+(cur||doneR?'1':'.5')+'"><div style="font-size:17px">'+rm.icon+'</div>'+(doneR?'✓ ':'' )+esc(rm.name)+'</button>'
  });
  h+='</div><div style="font:10px Cairo;color:rgba(216,180,254,.7);margin-top:7px">الغرفة '+Math.min(jr.room+1,6)+' من 6 — الغرف المكتملة أُنجزت، والقتال يبدأ من الغرفة الحالية</div>'
 } else {
  h+='<div style="margin-top:8px;font:10.5px Cairo;color:rgba(255,234,176,.7);background:rgba(0,0,0,.3);border-radius:10px;padding:9px">كل رحلة تكلفة <b>10 توكنات</b>. تكسب التوكنات من الاستكشاف والزعماء السرية والإنجازات والعجلة والحضور اليومي.</div>';
  h+='<div style="margin-top:8px"><button class="sp-btn purple" style="width:100%;padding:10px" data-sp="journey-start">🌀 ابدأ رحلة بـ 10 توكن</button></div>'
 }
 h+='</div>';
 return h
}
ACT["atlas-region"]=function(b,arg){var id=arg,s=st(),r=ATLAS.find(function(x){return x.id===id}),bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 if(s.discovered[id]){s.flags.openAtlas=id;save();renderPanel();return}
 if(bs<r.req){toast("تحتاج تقدم الحملة إلى المرحلة "+r.req);return}
 if(s.tokens<r.cost){toast("تحتاج "+r.cost+" توكن لاكتشاف "+r.name);return}
 s.tokens-=r.cost;s.discovered[id]=!0;s.counters.discovers++;save();toast("🗺️ اكتشفت "+r.name+" — +"+r.cost+" توكن أُنفقوا");s.flags.openAtlas=id;save();renderPanel();evalAch()
};
ACT["atlas-fight"]=function(b,arg){
 var p=arg.split(":"),id=p[0],i=+p[1],lv=+p[2],tok=+p[3];
 var r=ATLAS.find(function(x){return x.id===id});
 var n=i===1?2:i===2?3:4;
 var roles=["tank","dps","support","control"],en=[];
 for(var k=0;k<n;k++){var rl=roles[k%4];en.push(mkEnemy(r.mobs[k%r.mobs.length],r.fac||"abyss",rl,lv+(k===n-1&&i===3?2:0),i===3&&k===n-1?{isBoss:!0,hpM:1.2}:{}))}
 var firstClear=!(st().atlas[id]||{})[i];
 launch({mode:"atlas",enemies:en,recordTitle:r.name,timeLimit:150,
   rewards:function(){var rw=storyRewards(1600+400*i,1200+300*i,5+2*i,15+5*i,tok);return rw},
   onWin:function(vic){if(!vic)return;var s=st();s.atlas[id]=s.atlas[id]||{};s.atlas[id][i]=1;save();
     if(firstClear&&i===3&&(id==="dune"||id==="sunken"||id==="storm")){var map={dune:"r6",sunken:"r7",storm:"r8"};if(addRelic(map[id]))toast("🗿 أثر جديد: "+(RELICS.find(function(x){return x.id===map[id]})||{}).name)}
     evalAch()}},
  "استكشاف "+r.name,"linear-gradient(180deg,#2a2012,#140f0a)",
  function(){renderPanel()})
};

/* ---------- رحلة السراب ---------- */
var JR_ROOMS=[{k:"combat",icon:"⚔️",name:"كمين الرمال"},{k:"rnd",icon:"🎲",name:"غرفة متغيرة"},{k:"rnd",icon:"🎲",name:"غرفة متغيرة"},{k:"rnd",icon:"🎲",name:"غرفة متغيرة"},{k:"combat",icon:"⚔️",name:"حارس الأثر"},{k:"boss",icon:"👹",name:"زعيم السراب"}];
var JR_RND=[{k:"shrine",icon:"🛕",name:"مزار السراب"},{k:"merchant",icon:"🧳",name:"تاجر تائه"},{k:"event",icon:"🌀",name:"بوابة غامضة"}];
ACT["journey-start"]=function(){
 var s=st();
 if(s.journey){toast("لديك رحلة جارية بالفعل");return}
 if(s.tokens<10){toast("تحتاج 10 توكن لبدء الرحلة — اكسبها من الاستكشاف والإنجازات");return}
 s.tokens-=10;
 s.journey={room:0,rooms:JR_ROOMS.map(function(r,i){
   if(r.k==="rnd"){var z=JR_RND[Math.floor(Math.random()*JR_RND.length)];return{k:z.k,icon:z.icon,name:z.name}}
   return{k:r.k,icon:r.icon,name:r.name}
 })};
 save();toast("🌀 بدأت رحلة السراب");renderPanel()
};
ACT["journey-end"]=function(){
 var s=st();
 if(!s.journey)return;
 var cleared=s.journey.rooms.filter(function(r){return r.done}).length;
 s.journey=null;s.journeyRuns++;save();
 toast("انتهت الرحلة — أنجزت "+cleared+" غرف");renderPanel();evalAch()
};
ACT["journey-room"]=function(b,arg){
 var s=st();if(!s.journey)return;
 var i=+arg;if(i!==s.journey.room){toast("أكمل الغرفة الحالية أولًا");return}
 var rm=s.journey.rooms[i],bs=(G()&&G().campaign?G().campaign.bestStage:0)||0,base=Math.max(3+i*3,Math.round(bs*.55)+i*2);
 if(rm.k==="combat"||rm.k==="boss"){
  var isB=rm.k==="boss",n=isB?2:2+(i%2);
  var roles=["tank","dps","control","support","dps"],en=[];
  for(var k=0;k<n;k++)en.push(mkEnemy(isB?"زعيم السراب الأعظم":"كمين الرمال — "+(k+1),"abyss",roles[k%roles.length],isB?base+2:base,isB&&k===0?{isBoss:!0,hpM:1.3}:{}));
  launch({mode:"journey2",enemies:en,recordTitle:"رحلة السراب",timeLimit:isB?180:150,
    rewards:function(){return isB?{gold:5200,xp:4200,mats:18,gems:60,tokens:6,shards:15}:{gold:1500+300*i,xp:1200+250*i,mats:6+i,tokens:2}},
    onWin:function(vic){if(!vic)return;var s2=st();if(s2.journey&&s2.journey.room===i){s2.journey.rooms[i].done=!0;if(i<5){s2.journey.room=i+1}else{s2.journey=null;s2.journeyRuns++;toast("🏆 أكملت رحلة السراب كاملة!")}save();evalAch()}renderPanel()}},
   "رحلة السراب — "+rm.name,"linear-gradient(180deg,#30204e,#17112a)",
   function(){renderPanel()});return
 }
 if(rm.k==="shrine"){
  addRes({energy:25});st().buff={atk:.15,label:"بركة المزار +15% هجوم للمعركة القادمة"};save();
  st().journey.rooms[i].done=!0;if(st().journey.room<5)st().journey.room++;save();
  openModal('<div style="text-align:center"><div style="font-size:42px">🛕</div><b style="font:900 15px Cairo;color:#fde68a">بركة المزار</b><div style="font:11px Cairo;color:rgba(255,234,176,.75);margin-top:6px">شربت من الماء المزروع: +25 طاقة، وحملت بركة +15% هجوم لمعركتك القادمة.</div><button class="sp-btn gold" style="width:100%;margin-top:10px;padding:10px" data-sp="journey-advanced">التالي ›</button></div>');
  renderPanel();return
 }
 if(rm.k==="merchant"){
  var offers=[{k:"gold",icon:"🪙",name:"كيس الذهب",desc:"+4000 ذهب"},{k:"mats",icon:"⚙️",name:"حزمة الخامات",desc:"+25 خامة"},{k:"gear",icon:"⚔️",name:"قطعة غامضة",desc:"قطعة معدات للمخزن"}];
  var oh='<div style="text-align:center"><div style="font-size:40px">🧳</div><b style="font:900 15px Cairo;color:#fde68a">تاجر تائه</b><div style="font:11px Cairo;color:rgba(255,234,176,.75);margin:6px 0">«رحلتي طويلة… خذ واحدة مجانًا، فالرمال تعطي من يسير فيها»</div><div style="display:grid;gap:7px;margin-top:8px">';
  offers.forEach(function(o,j){oh+='<button class="sp-btn" style="text-align:right;padding:10px" data-sp="journey-merchant" data-arg="'+j+'"><b>'+o.icon+' '+o.name+'</b><div style="font:9.5px Cairo;opacity:.7">'+o.desc+'</div></button>'});
  oh+='</div></div>';openModal(oh);return
 }
 /* event room */
 var oh='<div style="text-align:center"><div style="font-size:40px">🌀</div><b style="font:900 15px Cairo;color:#fde68a">بوابة غامضة</b><div style="font:11px Cairo;color:rgba(255,234,176,.75);margin:6px 0">بوابة تهمس بخيارين: «الطريق الآمن يعرف اسمك»… و«الطريق الخطر يعرف قيمتك».</div><div style="display:grid;gap:7px;margin-top:8px"><button class="sp-btn" style="padding:10px" data-sp="journey-event" data-arg="safe"><b>🛡️ الطريق الآمن</b><div style="font:9.5px Cairo;opacity:.7">+3 توكن مؤكد</div></button><button class="sp-btn purple" style="padding:10px" data-sp="journey-event" data-arg="risky"><b>🔥 الطريق الخطر</b><div style="font:9.5px Cairo;opacity:.8">50%: 45 جوهرة — 50%: بركة +25% هجوم</div></button></div></div>';
 openModal(oh)
};
ACT["journey-advanced"]=function(){closeModal();renderPanel()};
ACT["journey-merchant"]=function(b,arg){
 var s=st(),j=+arg;
 if(j===0)addRes({gold:4000});
 else if(j===1)addRes({mats:25});
 else{var slots=["weapon","armor","talisman","helmet","gloves","boots","ring","wing"],sl=slots[Math.floor(Math.random()*8)],bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
   s.inventory.push({slot:sl,tier:Math.max(2,Math.min(7,2+Math.floor(bs/50))),stars:0,src:"تاجر السراب"});toast("⚔️ قطعة غامضة أُضيفت للمخزن")}
 s.journey.rooms[s.journey.room].done=!0;if(s.journey.room<5)s.journey.room++;save();closeModal();renderPanel()
};
ACT["journey-event"]=function(b,arg){
 var s=st();
 if(arg==="safe"){s.tokens+=3;toast("🛡️ الطريق الآمن: +3 توكن")}
 else if(Math.random()<.5){addRes({gems:45});toast("🔥 خاطرت وربحت 45 جوهرة!")}
 else{s.buff={atk:.25,label:"بركة البوابة +25% هجوم للمعركة القادمة"};toast("🔥 خاطرت… وخرجت ببركة +25% هجوم")}
 s.journey.rooms[s.journey.room].done=!0;if(s.journey.room<5)s.journey.room++;save();closeModal();renderPanel()
};

/* ---------- لوحة القصة ---------- */
function renderStoryTab(){
 var s=st(),bs=(G()&&G().campaign?G().campaign.bestStage:0)||0,h="";
 h+='<div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:900 19px Cairo;color:#ffedb0">📖 حكايات الرمال</b><div style="font:10px Cairo;color:rgba(255,234,176,.55)">القصة الرئيسية — 6 فصول بخيارات متفرعة ومعارك حقيقية</div></div><span class="sp-chip">الفصل '+Math.min(s.story.chapter,CH.length)+'/'+CH.length+'</span></div>';
 CH.forEach(function(ch){
  var done=s.story.done.indexOf(ch.id)>=0,open=chapterUnlocked(ch);
  h+='<div class="sp-card" style="'+(open?"":"opacity:.55")+'"><div style="display:flex;justify-content:space-between;align-items:center"><div><b class="sp-h">'+(done?"✓ ":open?"📖 ":"🔒 ")+'الفصل '+ch.id+' — '+esc(ch.title)+'</b><div class="sp-sub">'+esc(ch.hook)+'</div></div>'+(done?'<span class="sp-chip" style="border-color:#05966966;color:#86efac">منتهٍ</span>':"")+'</div>';
  if(open){h+='<div style="margin-top:8px"><button class="sp-btn gold" style="width:100%;padding:10px" data-sp="story-open" data-arg="'+ch.id+'">'+(done?"📖 إعادة القراءة (تحتاج دار الحكايات)":"📖 تابع الحكاية")+'</button></div>'}
  else{h+='<div style="font:9.5px Cairo;color:rgba(255,234,176,.5);margin-top:6px">يُفتح بعد إتمام الفصل '+ (ch.id-1) +' والوصول للمرحلة '+ch.req+' في الحملة</div>'}
  h+='</div>'
 });
 h+='<div style="font:10px Cairo;color:rgba(255,234,176,.5);margin-top:8px;text-align:center">اختياراتك في الفصول تحفظ أثرًا مختلفًا ومكافآت مختلفة — الطوفان ينتظر نهاية الحكاية.</div>';
 return h
}
ACT["story-open"]=function(b,arg){startChapter(+arg)};


/* ============================================================
   الجزء الثالث-ب — مركز الأنظمة العشرين + الحدادة + النوافذ
   ============================================================ */
function renderHubPanel(){
 var s=st(),bs=(G()&&G().campaign?G().campaign.bestStage:0)||0,ph=window.__solPlusPhase();
 var night=ph==="night";
 function card(icon,title,sub,body){
  return '<div class="sp-card"><div class="sp-h">'+icon+' '+title+'</div><div class="sp-sub">'+sub+'</div>'+body+"</div>"
 }
 var h='<div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:900 19px Cairo;color:#ffedb0">🌍 مركز عالم الرمال</b><div style="font:10px Cairo;color:rgba(255,234,176,.55)">20 نظامًا حقيقيًا — كل زر يفتح لعبًا فعلية أو أثرًا حقيقيًا</div></div><span class="sp-chip">'+(night?"🌙 ليل":"☀️ نهار")+'</span></div>';
 /* 1+2 الخريطة والليل */
 h+=card("🗺️","خريطة العالم والمناطق المخفية","أطلس الرمال — اكتشاف ب التوكن واستكشاف بمعارك حقيقية",
  '<button class="sp-btn gold" style="width:100%;padding:9px" data-sp="go-atlas">افتح الأطلس ('+Object.keys(s.discovered).length+'/6)</button>');
 h+=card((night?"🌙":"☀️"),"الليل والنهار","الليل يضاعف الذهب والخبرة من كل معارك الأنظمة +25%",
  '<div class="sp-row"><span class="sp-chip">الوضع الحالي: '+(s.phase==="auto"?"تلقائي ("+(night?"ليل":"نهار")+")":s.phase==="night"?"ليل مفعّل":"نهار مفعّل")+'</span><button class="sp-btn" data-sp="phase-toggle">تبديل الوقت</button></div>');
 /* 3 الأحداث */
 var ev=s.event?EVENTS.find(function(e){return e.id===s.event.id}):null;
 h+=card("🎲","الأحداث العشوائية","حدود تظهر في العالم وتُحلّ بمعارك أو اختيارات حقيقية",
  ev?'<div class="sp-row"><span class="sp-chip" style="border-color:#f0c75e66">'+ev.icon+' '+esc(ev.name)+'</span><button class="sp-btn gold" data-sp="event-open">افتح الحدث</button><button class="sp-btn" data-sp="event-reroll">🎲 توليد غيره</button></div>'
    :'<button class="sp-btn gold" data-sp="event-roll">🎲 توليد حدث عشوائي</button>');
 /* 4 الرحلة */
 h+=card("🌀","رحلة السراب (Roguelike)","رحلات متغيرة بالتوكن — غرف قتال ومزار وتاجر وبوابات",
  '<div class="sp-row"><span class="sp-chip">رحلات مكتملة: '+s.journeyRuns+'</span><button class="sp-btn purple" data-sp="go-atlas">إلى الرحلة</button></div>');
 /* 5+6 المعسكر والروابط */
 var fTotal=Object.values(s.friendship).reduce(function(a,b){return a+b},0);
 h+=card("🏕️","معسكر الأبطال والروابط","دردشة مع أبطالك ترفع الصداقة — كل مستوى +1.2% صحة وهجوم للبطل",
  '<div class="sp-row"><span class="sp-chip">مجموع الصداقة: '+fTotal+'</span><button class="sp-btn gold" data-sp="open-camp">افتح المعسكر</button></div>');
 /* 7 المهارات */
 var skTot=s.skills.attack+s.skills.defense+s.skills.support+s.skills.speed,bk=(G()&&G().books)||0;
 h+=card("🌿","شجرة المهارات","كتب المعارك الخاصة تفتح مستويات دائمة: ضرر، صمود، حياة، سرعة",
  '<div class="sp-row"><span class="sp-chip">مستويات: '+skTot+'</span><span class="sp-chip">📚 كتب: '+bk+'</span><button class="sp-btn gold" data-sp="open-skills">افتح الشجرة</button></div>');
 /* 8 التطور البصري */
 var stars=(G()?Math.max.apply(null,[1].concat(Object.values(G().heroes||{}).map(function(x){return x.stars}))):1);
 h+=card("✨","التطور البصري للأبطال","النجوم والصداقة تغيّر ألقاب البطل وهالة القتال",
  '<div class="sp-row"><span class="sp-chip">أعلى تطور: '+'★'.repeat(stars)+'</span><span class="sp-chip">أبطال متطورون: '+Object.values(G()?(G().heroes||{}):{}).filter(function(x){return x.stars>=3}).length+'</span></div>');
 /* 9 الأجنحة */
 var ws=WING_STAGES.filter(function(w){return s.wingLevel>=w[0]}).pop();
 h+=card("🪽","الأجنحة القابلة للتطور","الجناح الأصلي من الفصل ٤ — يتطور ويتأثر بمعبد الأجنحة",
  '<div class="sp-row"><span class="sp-chip">'+ws[2]+' '+ws[1]+' — مستوى '+s.wingLevel+'</span><button class="sp-btn gold" data-sp="open-forge" data-arg="wing">تطوير الجناح</button></div>');
 /* 10+11 الحدادة والأساليب */
 h+=card("⚒️","الحدادة — تصنيع ودمج المعدات","مخزن قطع حقيقي: صناعة، دمج، تجهيز على الأبطال، وبيع",
  '<div class="sp-row"><span class="sp-chip">مخزن: '+s.inventory.length+'</span><span class="sp-chip">تصنيع: '+s.counters.crafts+'</span><span class="sp-chip">دمج: '+s.counters.merges+'</span><button class="sp-btn gold" data-sp="go-forge">افتح الحدادة</button></div>');
 h+=card("⚔️","أساليب المعدات","أسلوبك يوزع قوة الفريق: هجومي، دفاعي، سرعة، أو متوازن",
  '<div class="sp-row">'+[["attack","⚔️ هجومي"],["defense","🛡️ دفاعي"],["speed","💨 سرعة"],["balanced","⚖️ متوازن"]].map(function(x){return '<button class="sp-btn'+(s.style===x[0]?" gold":"")+'" data-sp="style-set" data-arg="'+x[0]+'">'+x[1]+'</button>'}).join("")+'</div>');
 /* 12 القصة */
 h+=card("📖","القصص المتفرعة","حكاية الطوفان الرمادي — 6 فصول بخيارات ومعارك",
  '<div class="sp-row"><span class="sp-chip">فصول منتهية: '+s.story.done.length+'/6</span><button class="sp-btn gold" data-sp="go-story">افتح الحكايات</button></div>');
 /* 13 الوحوش */
 h+=card("📚","كتاب الوحوش","كل وحش واجهته يُسجل هنا — من الطين إلى الطوفان",
  '<div class="sp-row"><span class="sp-chip">مكتشفون: '+Object.keys(s.bestiary).length+'</span><span class="sp-chip">🔮 +'+boxBoostPct().toFixed(1)+'% قوة</span><button class="sp-btn gold" data-sp="open-bestiary">افتح الكتاب</button></div>');
 /* 14 الزعماء السرية */
 var secWins=Object.values(s.secret).reduce(function(a,b){return a+b},0);
 h+=card("👹","الزعماء السريون","لكل منطقة زعيم أزلي يظهر بعد إثبات قوتك — أثر مضمون أول مرة",
  '<div class="sp-row"><span class="sp-chip">انتصارات: '+secWins+'</span><button class="sp-btn gold" data-sp="open-secret">الزعماء السريون</button></div>');
 /* 15 الأبراج بقواعد */
 h+=card("🏯","الأبراج ذات القواعد المختلفة","برج اللهب، برج السموم، وبرج الثنائي — 20 طابقًا لكل برج",
  '<div class="sp-row"><span class="sp-chip">🔥 '+(G()&&G().modes?G().modes.twFire||0:0)+'/20</span><span class="sp-chip">☠️ '+(G()&&G().modes?G().modes.twPoison||0:0)+'/20</span><span class="sp-chip">👥 '+(G()&&G().modes?G().modes.twDuo||0:0)+'/20</span><button class="sp-btn gold" data-sp="open-rtowers">افتح الأبراج</button></div>');
 /* 16 القوافل */
 h+=card("🐪","حماية القوافل بالموجات","موجات متصاعدة — كل موجة أقوى وأعلى مكافأة، والسجل محفوظ",
  '<div class="sp-row"><span class="sp-chip">الموجة القادمة: '+(s.caravan.wave+1)+'</span><span class="sp-chip">أفضل سجل: '+s.caravan.best+'</span><button class="sp-btn gold" data-sp="open-caravan">افتح القافلة</button></div>');
 /* 17 الصيد النادر */
 var rd=s.rare.date===hh();
 h+=card("✨","صيد الوحوش النادرة","3 فرص يوميًا لاصطياد وحش نادر — خامات وجواهر ضخمة",
  '<div class="sp-row"><span class="sp-chip">محاولات اليوم: '+((rd?s.rare.count:0))+'/3</span><span class="sp-chip">مصطادات: '+s.rare.caught+'</span><button class="sp-btn gold" data-sp="open-rare">اذهب للصيد</button></div>');
 /* 18 المدينة */
 var bt=Object.values(s.buildings).reduce(function(a,b){return a+b},0);
 h+=card("🏙️","المدينة القابلة للترقية","حدادة، أكاديمية، معبد أجنحة، سوق، دار حكايات — أثر دائم لكل مبنى",
  '<div class="sp-row"><span class="sp-chip">مستويات: '+bt+'</span><button class="sp-btn gold" data-sp="open-city">افتح المدينة</button></div>');
 /* 19 الآثار */
 h+=card("🗿","جمع الآثار القديمة",s.relics.length+" من 13 أثرًا — كل أثر +1% صحة وهجوم دائم للفريق كله",
  '<div class="sp-row"><span class="sp-chip">🗿 '+s.relics.length+'/13</span><button class="sp-btn gold" data-sp="open-relics">خزانة الآثار</button></div>');
 /* 20 الإنجازات */
 var achCount=Object.keys(s.achievements).length;
 h+=card("🏆","الإنجازات والألقاب","تنفتح تلقائيًا من لعبك الحقيقي — ومعها مكافآت فورية",
  '<div class="sp-row"><span class="sp-chip">🏆 '+achCount+'/'+ACH.length+'</span><button class="sp-btn gold" data-sp="open-ach">سجل الإنجازات</button></div>');
 return h
}
ACT["go-atlas"]=function(){setActiveTab("atlas")};
ACT["go-story"]=function(){setActiveTab("story")};
ACT["go-forge"]=function(){try{SET(function(){return{screen:"summon"}})}catch(e){}window.__solHubOpen="forge"};ACT["open-forge"]=function(){try{SET(function(){return{screen:"summon"}})}catch(e){}window.__solHubOpen="forge"};
ACT["phase-toggle"]=function(){var s=st();s.phase=s.phase==="night"?"day":s.phase==="day"?"auto":"night";save();toast(s.phase==="night"?"🌙 ليل مفعّل — المكافآت +25%":s.phase==="day"?"☀️ نهار مفعّل":"🕰️ تلقائي — يتبع ساعة جهازك");renderPanel()};
ACT["style-set"]=function(b,arg){st().style=arg;save();toast("أسلوب المعدات: "+({attack:"هجومي — السلاح والخاتم يزدادان أثرًا",defense:"دفاعي — الدرع والخوذة تزدادان أثرًا",speed:"سرعة — الحذاء والقفازات والتميمة تزداد",balanced:"متوازن — كل الخصائص +2%"}[arg]));renderPanel()};

/* ---------- الأحداث العشوائية ---------- */
ACT["event-roll"]=function(){
 var ev=EVENTS[Math.floor(Math.random()*EVENTS.length)];
 st().event={id:ev.id};save();toast("🎲 حدث جديد: "+ev.name);renderPanel()
};
ACT["event-reroll"]=function(){st().event=null;save();ACT["event-roll"]()};
ACT["event-open"]=function(){
 var s=st();if(!s.event)return;
 var ev=EVENTS.find(function(e){return e.id===s.event.id});if(!ev){s.event=null;save();renderPanel();return}
 var bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 if(ev.kind==="battle"&&ev.id==="caravan-siege"){
  openModal('<div style="text-align:center"><div style="font-size:40px">🐪</div><b style="font:900 15px Cairo;color:#fde68a">'+esc(ev.name)+'</b><div style="font:11.5px Cairo;color:rgba(255,234,176,.8);margin:8px 0;line-height:1.9">'+esc(ev.text)+'</div>'+enemyRowHTML([mkEnemy("قائد اللصوص","shadow","dps",Math.max(15,Math.round(bs*.8)+6)),mkEnemy("لص الرمال","shadow","tank",Math.max(14,Math.round(bs*.8)+4))])+'<div style="margin-top:10px"><button class="sp-btn gold" style="width:100%;padding:10px" data-sp="event-fight" data-arg="caravan-siege">⚔️ دافع عن القافلة</button></div></div>');
  return
 }
 if(ev.kind==="battle"&&ev.id==="rare-sighting"){
  openModal('<div style="text-align:center"><div style="font-size:40px">✨</div><b style="font:900 15px Cairo;color:#fde68a">'+esc(ev.name)+'</b><div style="font:11.5px Cairo;color:rgba(255,234,176,.8);margin:8px 0;line-height:1.9">'+esc(ev.text)+'</div>'+enemyRowHTML([mkEnemy(RARES[Math.floor(Math.random()*RARES.length)].name,"abyss","dps",Math.max(20,Math.round(bs*.85)+8),{hpM:1.5})])+'<div style="margin-top:10px"><button class="sp-btn gold" style="width:100%;padding:10px" data-sp="event-fight" data-arg="rare-sighting">⚔️ اصطده</button></div></div>');
  return
 }
 if(ev.id==="cursed-box"){
  openModal('<div style="text-align:center"><div style="font-size:40px">🎁</div><b style="font:900 15px Cairo;color:#fde68a">'+esc(ev.name)+'</b><div style="font:11.5px Cairo;color:rgba(255,234,176,.8);margin:8px 0;line-height:1.9">'+esc(ev.text)+'</div><div style="display:grid;gap:7px;margin-top:10px"><button class="sp-btn purple" style="padding:10px" data-sp="event-choice" data-arg="box-open"><b>🔓 افتح الصندوق</b><div style="font:9.5px Cairo;opacity:.8">50%: 70 جوهرة — 50%: لعنة (تخسر 400 ذهب لكن تلهمك +20% هجوم لمعركتك القادمة)</div></button><button class="sp-btn" style="padding:10px" data-sp="event-choice" data-arg="box-leave"><b>🚶 اتركه وشمّ رائحته</b><div style="font:9.5px Cairo;opacity:.7">+2 توكن</div></button></div></div>');
  return
 }
 if(ev.id==="secret-merchant"){
  openModal('<div style="text-align:center"><div style="font-size:40px">🧳</div><b style="font:900 15px Cairo;color:#fde68a">'+esc(ev.name)+'</b><div style="font:11.5px Cairo;color:rgba(255,234,176,.8);margin:8px 0;line-height:1.9">'+esc(ev.text)+'</div><div style="display:grid;gap:7px;margin-top:10px"><button class="sp-btn gold" style="padding:10px" data-sp="event-choice" data-arg="mer-buy"><b>💰 اشترِ القطعة — 400 ذهب</b><div style="font:9.5px Cairo;opacity:.8">قطعة معدات عشوائية للمخزن</div></button><button class="sp-btn" style="padding:10px" data-sp="event-choice" data-arg="mer-info"><b>👂 اسمع سرّه بدل الذهب</b><div style="font:9.5px Cairo;opacity:.7">+2 توكن</div></button></div></div>');
  return
 }
 openModal('<div style="text-align:center"><div style="font-size:40px">🩹</div><b style="font:900 15px Cairo;color:#fde68a">'+esc(ev.name)+'</b><div style="font:11.5px Cairo;color:rgba(255,234,176,.8);margin:8px 0;line-height:1.9">'+esc(ev.text)+'</div><div style="display:grid;gap:7px;margin-top:10px"><button class="sp-btn green" style="padding:10px" data-sp="event-choice" data-arg="hero-help"><b>🩹 عالجه — 200 ذهب</b><div style="font:9.5px Cairo;opacity:.8">صداقة بطل +2 وثبت له اسمك</div></button><button class="sp-btn" style="padding:10px" data-sp="event-choice" data-arg="hero-learn"><b>👂 تعلّم من قصته بدل مساعدته</b><div style="font:9.5px Cairo;opacity:.7">+600 خبرة</div></button></div></div>')
};
ACT["event-fight"]=function(b,arg){
 var s=st(),bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 var evId=(s.event&&s.event.id)||arg;
 var custom;
 if(evId==="caravan-siege"){
  custom={mode:"event",enemies:[mkEnemy("قائد اللصوص","shadow","dps",Math.max(15,Math.round(bs*.8)+6)),mkEnemy("لص الرمال","shadow","tank",Math.max(14,Math.round(bs*.8)+4))],recordTitle:"أحداث العالم",rewards:function(){return storyRewards(2600,1800,10,45,3)},onWin:function(){toast("🐪 نجات القافلة بفضل شما")}};
 }else{
  var r=RARES[Math.floor(Math.random()*RARES.length)];
  custom={mode:"event",enemies:[mkEnemy(r.name,r.faction,r.role,Math.max(20,Math.round(bs*.85)+8),{hpM:1.5})],recordTitle:"أحداث العالم",rewards:function(){return{gold:3000,xp:2200,mats:16,gems:14,tokens:2}},onWin:function(v){var s2=st();if(v){s2.rare.caught++;save()}}}
 }
 s.event={id:arg,done:1};save();
 launch(custom,"حدث — "+arg,"linear-gradient(180deg,#2a1c2e,#150e18)",function(){s.event=null;save();renderPanel();evalAch()})
};
ACT["event-choice"]=function(b,arg){
 var s=st();
 if(arg==="box-open"){Math.random()<.5?(addRes({gems:70}),toast("🔓 الصندوق كان كنزًا: +70 جوهرة")):(addRes({gold:-400}),st().buff={atk:.2,label:"لعنة ملهمة +20% هجوم للمعركة القادمة"},toast("🔒 لعنة! خسرت 400 ذهب… لكن نارها تلهمك +20% هجوم"))}
 else if(arg==="box-leave"){s.tokens+=2;toast("🚶 تُركت الصندوق: +2 توكن")}
 else if(arg==="mer-buy"){
  var r=(G()&&G().resources)?G().resources.gold:0;
  if(r<400){toast("الذهب لا يكفي");return}
  addRes({gold:-400});
  var slots=["weapon","armor","talisman","helmet","gloves","boots","ring","wing"],sl=slots[Math.floor(Math.random()*8)],bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
  st().inventory.push({slot:sl,tier:Math.max(2,Math.min(7,2+Math.floor(bs/50))),stars:0,src:"تاجر سري"});toast("⚔️ قطعة التاجر في المخزن")
 }
 else if(arg==="mer-info"){s.tokens+=2;toast("👂 قال: «برج الرمال يحب من يحمل أسماء محفوظة» — +2 توكن")}
 else if(arg==="hero-help"){
  var g=G();
  if(!g||g.resources.gold<200){toast("الذهب لا يكفي");return}
  addRes({gold:-200});
  var ids=Object.keys(g.heroes);var hid=ids[Math.floor(Math.random()*ids.length)];
  var f=st().friendship;s.friendship[hid]=Math.min(10,(f[hid]||0)+2);save();
  toast("🩹 عولج البطل — صداقته صارت "+s.friendship[hid])
 }
 else if(arg==="hero-learn"){addRes({xp:600});toast("👂 تعلمت من قصته: +600 خبرة")}
 s.event=null;save();closeModal();renderPanel();evalAch()
};

/* ---------- الزعماء السرية ---------- */
ACT["open-secret"]=function(){
 var s=st(),bs=(G()&&G().campaign?G().campaign.bestStage:0)||0,h='<div style="text-align:center"><b style="font:900 17px Cairo;color:#fca5a5">👹 الزعماء السريون</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">زعيم أزلي لكل منطقة — أول هزيمة له يمنحك أثرًا أزليًا</div>';
 REGIONS.forEach(function(r,i){
  var st_=r.id*40-39,open=bs>=st_+9,wins=s.secret[r.id]||0,relic=RELICS.find(function(x){return x.id==="r"+(i+1)});
  h+='<div class="sp-card" style="'+(open?"":"opacity:.55")+'"><div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:800 12px Cairo;color:#fde68a">☠ '+esc(r.secret)+'</b><div style="font:9px Cairo;color:rgba(255,234,176,.55)">'+esc(r.name)+' • يُفتح عند المرحلة '+(st_+9)+(wins?' • هُزم '+wins+' مرة':'')+'</div></div>'+(open?'<button class="sp-btn red" data-sp="secret-fight" data-arg="'+r.id+'">⚔️ واجهه</button>':'<span class="sp-chip">🔒 المرحلة '+(st_+9)+'</span>')+'</div>';
  if(open)h+='<div style="font:9px Cairo;color:rgba(255,234,176,.5);margin-top:5px">الأثر: '+esc(relic.name)+' — '+(s.relics.indexOf(relic.id)>=0?"مملوك ✓":"بانتظار انتصارك الأول")+'</div>';
  h+="</div>"
 });
 h+='<div style="margin-top:10px"><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["secret-fight"]=function(b,arg){
 var rid=+arg,r=REGIONS.find(function(x){return x.id===rid}),s=st(),bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 var firstClear=!s.relics.includes("r"+rid);
 var lv=r.id*40-39+14+Math.round(bs*.12);
 var en=[mkEnemy(r.secret,r.faction,"dps",lv,{isBoss:!0,hpM:1.5,atkM:1.12}),mkEnemy(r.mobs[0],r.faction,"tank",lv-4),mkEnemy(r.mobs[1],r.faction,"control",lv-4)];
 launch({mode:"secret",enemies:en,recordTitle:"الزعماء السرية",timeLimit:180,
   rewards:function(){return{gold:6500+rid*800,xp:5200+rid*600,mats:18,gems:85,tokens:3,shards:10}},
   onWin:function(vic){if(!vic)return;var s2=st();s2.secret[rid]=(s2.secret[rid]||0)+1;
     if(firstClear){addRelic("r"+rid);toast("🗿 أثر أزلي: "+(RELICS.find(function(x){return x.id==="r"+rid})||{}).name+" — +1% صحة وهجوم دائم")}
     save();evalAch()}},
  "زعيم سري — "+r.secret,"linear-gradient(180deg,#3d0f16,#1a080c)",
  function(){closeModal();renderPanel()})
};

/* ---------- الأبراج ذات القواعد ---------- */
ACT["open-rtowers"]=function(){
 var m=(G()&&G().modes)||{},h='<div style="text-align:center"><b style="font:900 17px Cairo;color:#fde68a">🏯 الأبراج ذات القواعد المختلفة</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">ثلاثة أبراج × 20 طابقًا — كل برج يغيّر قواعد المعركة ومكافآته</div>';
 [{k:"twFire",id:"fire",icon:"🔥",name:"برج اللهب",desc:"وحوش مشتعلة بهجوم +15% وضرر جماعي ناري",rw:"جواهر ضخمة"},{k:"twPoison",id:"poison",icon:"☠️",name:"برج السموم",desc:"وحوش ببزة مستمرة تستنزف صحتك",rw:"خامات ضخمة"},{k:"twDuo",id:"duo",icon:"👥",name:"برج الثنائي",desc:"أول بطلين فقط من فريقك يقاتلان",rw:"شظايا وجواهر"}].forEach(function(t){
  var prog=m[t.k]||0;
  h+='<div class="sp-card"><div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:800 13px Cairo;color:#fde68a">'+t.icon+' '+t.name+'</b><div style="font:9.5px Cairo;color:rgba(255,234,176,.6);margin-top:2px">'+t.desc+'</div><div style="font:9px Cairo;color:rgba(255,234,176,.45);margin-top:2px">التقدم: '+prog+'/20 • المكافأة: '+t.rw+'</div></div><button class="sp-btn purple" data-sp="rtower-fight" data-arg="'+t.id+'">⚔️ الطابق '+(prog+1>20?20:prog+1)+'</button></div></div>'
 });
 h+='<div style="margin-top:10px"><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["rtower-fight"]=function(b,arg){
 var m=(G()&&G().modes)||{},prog=m["tw"+arg.charAt(0).toUpperCase()+arg.slice(1)]||0;
 var fl=Math.min(20,prog+1),bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 var lv=Math.max(20+fl*3,Math.round(bs*.7)+fl*2.5);
 var roles=["tank","dps","support","control"],n=fl%5===0?2:3,en=[];
 for(var k=0;k<n;k++){var o=fl%5===0&&k===0?{isBoss:!0,hpM:1.3}:{},rl=roles[k%4];
  if(arg==="fire")o.variant="fire",o.atkM=1.15;
  if(arg==="poison")o.variant="poison";
  en.push(mkEnemy(fl%5===0&&k===0?"حارس "+({fire:"اللهب",poison:"السموم",duo:"الثنائي"})[arg]:"وحش البرج",["abyss","shadow","abyss","abyss"][k%4],rl,lv,o))}
 var custom={mode:"rtower",enemies:en,recordTitle:"أبراج القواعد",timeLimit:160,
  modeProg:"tw"+arg.charAt(0).toUpperCase()+arg.slice(1)};
 if(arg==="duo"){var g=G();custom.teamOverride=(g&&g.team||[]).slice(0,2)}
 custom.rewards=function(){
  if(arg==="fire")return{gold:2200+fl*180,xp:1600+fl*140,gems:16+3*fl,tokens:fl%5===0?2:0};
  if(arg==="poison")return{gold:2000+fl*150,xp:1500+fl*120,mats:9+fl,tokens:fl%5===0?2:0};
  return{gold:2200+fl*180,xp:1600+fl*140,shards:5+fl,gems:8,tokens:fl%5===0?2:0}
 };
 launch(custom,"برج "+({fire:"اللهب",poison:"السموم",duo:"الثنائي"})[arg]+" — الطابق "+fl,"linear-gradient(180deg,#3b1208,#1d0a05)",function(){
  closeModal();var s=st(),key="rt"+arg;
  if((G()&&G().modes?G().modes["tw"+arg.charAt(0).toUpperCase()+arg.slice(1)]:0)>=20&&!s.flags[key]){s.flags[key]=1;s.tokens+=5;save();toast("🏯 أكملت البرج! +5 توكن")}
  renderPanel();evalAch()})
};

/* ---------- القافلة ---------- */
ACT["open-caravan"]=function(){
 var s=st(),w=s.caravan.wave+1,bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 var lv=Math.max(15+w*5,Math.round(bs*.75)+w*4);
 var hasRelic=s.relics.indexOf("r11")>=0;
 openModal('<div style="text-align:center"><div style="font-size:40px">🐪</div><b style="font:900 16px Cairo;color:#fde68a">حماية القافلة — الموجة '+w+'</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.65);margin:5px 0">أفضل سجل: '+s.caravan.best+' — كل موجة أقوى، والخسارة تعيدك موجة واحدة للخلف فقط</div>'+enemyRowHTML([mkEnemy("زعيم القطيع المتوحش","abyss","tank",lv),mkEnemy("مهاجم الرمال","abyss","dps",lv),mkEnemy("قائد الهجمة","abyss","control",lv)])+'<div class="sp-row" style="justify-content:center;margin-top:6px"><span class="sp-chip">🪙 '+(2000+600*w).toLocaleString("en-US")+'</span><span class="sp-chip">📜 '+(1500+450*w).toLocaleString("en-US")+'</span><span class="sp-chip">⚙️ '+(6+2*w)+'</span><span class="sp-chip">🪙 توكن 1</span></div>'+(w===7&&!hasRelic?'<div style="font:10px Cairo;color:#fde68a;margin-top:6px">🗿 الموجة 7 تمنح كأس القوافل لأول مرة</div>':"")+'<div style="margin-top:10px"><button class="sp-btn gold" style="width:100%;padding:11px" data-sp="caravan-fight">⚔️ دافع عن القافلة</button><button class="sp-btn" style="width:100%;margin-top:7px" data-sp="sp-close">إغلاق</button></div></div>',{dark:!0})
};
ACT["caravan-fight"]=function(){
 var s=st(),w=s.caravan.wave+1,bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 var lv=Math.max(15+w*5,Math.round(bs*.75)+w*4);
 launch({mode:"caravan",enemies:[mkEnemy("زعيم القطيع المتوحش","abyss","tank",lv),mkEnemy("مهاجم الرمال","abyss","dps",lv),mkEnemy("قائد الهجمة","abyss","control",lv)],
   recordTitle:"حماية القوافل",timeLimit:170,
   rewards:function(){return{gold:2000+600*w,xp:1500+450*w,mats:6+2*w,tokens:1}},
   onWin:function(vic){var s2=st();if(vic){s2.caravan.wave=w;s2.caravan.best=Math.max(s2.caravan.best,w);if(w===7)addRelic("r11");evalAch()}else{s2.caravan.wave=Math.max(0,w-2);save()}}},
  "القافلة — الموجة "+w,"linear-gradient(180deg,#33230e,#180f06)",
  function(){closeModal();renderPanel()})
};

/* ---------- الصيد النادر ---------- */
ACT["open-rare"]=function(){
 var s=st(),rd=s.rare.date===hh(),cnt=rd?s.rare.count:0,bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 if(cnt>=3){openModal('<div style="text-align:center"><div style="font-size:40px">🌄</div><b style="font:900 15px Cairo;color:#fde68a">انتهت محاولات اليوم</b><div style="font:11px Cairo;color:rgba(255,234,176,.7);margin:6px 0">اصطدت '+s.rare.caught+' وحشًا نادرًا حتى الآن. عد غدًا — الوحوش النادرة لا تنتظر طويلًا.</div><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div>',{dark:!0});return}
 var r=RARES[Math.floor(Math.random()*RARES.length)],lv=Math.max(bs+10,40);
 openModal('<div style="text-align:center"><div style="font-size:40px">🎯</div><b style="font:900 16px Cairo;color:#fde68a">صيد الوحوش النادرة</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.65);margin:5px 0">محاولات اليوم: '+cnt+'/3 • مصطادات: '+s.rare.caught+'</div>'+enemyRowHTML([{name:r.name,faction:r.faction,role:r.role,level:lv,hpM:1.7,isBoss:!0}])+'<div class="sp-row" style="justify-content:center;margin-top:6px"><span class="sp-chip">⚙️ 22</span><span class="sp-chip">💎 18</span><span class="sp-chip">🪙 3,500</span><span class="sp-chip">🪙 توكن 2</span></div><div style="font:10px Cairo;color:rgba(255,234,176,.5);margin-top:5px">الوحش النادر قوي — إن فشلت تحاول لاحقًا، لكن المحاولة تُحسب.</div><div style="margin-top:10px"><button class="sp-btn gold" style="width:100%;padding:11px" data-sp="rare-fight">🎯 ابدأ الصيد</button><button class="sp-btn" style="width:100%;margin-top:7px" data-sp="sp-close">إغلاق</button></div></div>',{dark:!0})
};
ACT["rare-fight"]=function(){
 var s=st(),rd=s.rare.date===hh(),cnt=rd?s.rare.count:0;
 if(cnt>=3){toast("انتهت محاولات اليوم");return}
 var r=RARES[Math.floor(Math.random()*RARES.length)],bs=(G()&&G().campaign?G().campaign.bestStage:0)||0,lv=Math.max(bs+10,40);
 s.rare={date:hh(),count:cnt+1,caught:s.rare.caught};save();
 launch({mode:"rare",enemies:[mkEnemy(r.name,r.faction,r.role,lv,{hpM:1.7,atkM:1.1,isBoss:!0})],
   recordTitle:"الوحوش النادرة",timeLimit:170,
   rewards:function(){return{gold:3500,xp:2600,mats:22,gems:18,tokens:2,shards:8}},
   onWin:function(vic){var s2=st();if(vic){s2.rare.caught++;if(s2.rare.caught===5)addRelic("r12");evalAch()}save()}},
  "صيد نادر — "+r.name,"linear-gradient(180deg,#2e2410,#171204)",
  function(){closeModal();renderPanel();ACT["open-rare"]()})
};

/* ---------- الآثار ---------- */
ACT["open-relics"]=function(){
 var s=st(),h='<div style="text-align:center"><b style="font:900 17px Cairo;color:#fde68a">🗿 خزانة الآثار</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">'+s.relics.length+'/13 — كل أثر يمنح الفريق كله +1% صحة وهجوم دائم</div><div class="sp-grid">';
 RELICS.forEach(function(r){
  var own=s.relics.indexOf(r.id)>=0;
  h+='<div class="sp-card" style="margin-top:0'+(own?"":"")+';'+(own?"border-color:rgba(240,199,94,.6);background:rgba(240,199,94,.06)":"opacity:.5")+'"><div style="font-size:20px">'+(own?"🗿":"🔒")+'</div><b style="font:700 11px Cairo;color:'+(own?"#fde68a":"rgba(255,237,176,.6)")+'">'+esc(r.name)+'</b><div style="font:9px Cairo;color:rgba(255,234,176,.55);margin-top:3px">'+esc(r.src)+'</div><div style="font:9px Cairo;color:rgba(255,234,176,.4);margin-top:3px;font-style:italic">«'+esc(r.lore)+'»</div></div>'
 });
 h+='</div><div style="margin-top:10px"><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};

/* ---------- المدينة ---------- */
ACT["open-city"]=function(){
 var s=st(),h='<div style="text-align:center"><b style="font:900 17px Cairo;color:#fde68a">🏙️ مدينة الرمال</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">خمسة مبانٍ — كل مستوى أثر دائم حقيقي على أنظمة العالم</div>';
 BUILDINGS.forEach(function(b){
  var l=s.buildings[b.id]||0,c=b.cost(l),g=G(),ok=g&&g.resources.gold>=c.gold&&g.resources.mats>=c.mats;
  h+='<div class="sp-card"><div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:800 12.5px Cairo;color:#fde68a">'+b.icon+' '+b.name+' — مستوى '+l+'</b><div style="font:9.5px Cairo;color:rgba(255,234,176,.6);margin-top:3px">'+b.desc+'</div><div style="font:9.5px Cairo;color:rgba(255,234,176,.5);margin-top:4px">الترقية: 🪙 '+c.gold.toLocaleString("en-US")+' + ⚙️ '+c.mats+'</div></div><button class="sp-btn'+(ok?" gold":"")+'" '+(ok?"":"disabled")+' data-sp="city-up" data-arg="'+b.id+'">ترقية</button></div></div>'
 });
 h+='<div style="margin-top:10px"><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["city-up"]=function(b,arg){
 var s=st(),b2=BUILDINGS.find(function(x){return x.id===arg}),l=s.buildings[arg]||0,c=b2.cost(l),g=G();
 if(!g||g.resources.gold<c.gold||g.resources.mats<c.mats){toast("الموارد لا تكفي");return}
 addRes({gold:-c.gold,mats:-c.mats});
 s.buildings[arg]=l+1;save();toast("🏛️ "+b2.name+" — المستوى "+(l+1));ACT["open-city"]();evalAch()
};

/* ---------- المعسكر ---------- */
ACT["open-camp"]=function(){
 var g=G();if(!g)return;
 var s=st(),ids=Object.keys(g.heroes),h='<div style="text-align:center"><b style="font:900 17px Cairo;color:#fde68a">🏕️ معسكر الأبطال</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">كل مستوى صداقة = +1.2% صحة وهجوم دائم للبطل — وعند 3/6/10 مكافأة روابط</div>';
 ids.forEach(function(id){
  var def=(window.__solHeroes&&window.__solHeroes[id])||{name:id,faction:"abyss"},f=s.friendship[id]||0;
  var cost=150*(f+1),ok=g.resources.gold>=cost&&f<10;
  h+='<div class="sp-card"><div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:800 12px Cairo;color:'+((FACTIONS[def.faction]||{}).color||"#fde68a")+'">'+(FACTIONS[def.faction]?FACTIONS[def.faction].icon:"🌊")+' '+esc(def.name)+'</b><div style="font:9px Cairo;color:rgba(255,234,176,.55)">الصداقة: '+f+'/10 — دردشة: 🪙 '+cost+'</div><div class="sp-bar" style="width:150px;margin-top:4px"><i style="width:'+(f*10)+'%"></i></div></div><button class="sp-btn'+(ok?" gold":"")+'" '+(ok?"":"disabled")+' data-sp="camp-chat" data-arg="'+id+'">'+(f>=10?"مكتملة":"💬 دردشة")+'</button></div></div>'
 });
 h+='<div style="margin-top:10px"><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["camp-chat"]=function(b,id){
 var g=G();if(!g)return;
 var s=st(),f=s.friendship[id]||0,cost=150*(f+1);
 if(f>=10)return;
 if(g.resources.gold<cost){toast("الذهب لا يكفي");return}
 addRes({gold:-cost});
 s.friendship[id]=f+1;
 var key=id+"-"+(f+1);
 if(!s.bonds[key]&&[3,6,10].indexOf(f+1)>=0){
  s.bonds[key]=1;
  if(f+1===3){addRes({mats:8});toast("🤝 رابط جديد: +8 خامات")}
  else if(f+1===6){addRes({gems:15});toast("🤝 رابط جديد: +15 جوهرة")}
  else{s.tokens+=2;toast("🤝 رابط الأسماء: +2 توكن — البطل يحفظ حكايتك")}
 }
 save();toast("💬 زادت الصداقة إلى "+(f+1));ACT["open-camp"]();evalAch()
};

/* ---------- شجرة المهارات ---------- */
ACT["open-skills"]=function(){
 var s=st(),bk=(G()&&G().books)||0,ac=s.buildings.academy||0;
 var paths=[["attack","⚔️ مسار الضرر","+2% هجوم دائم لكل مستوى"],["defense","🛡️ مسار الصمود","+2% دفاع دائم لكل مستوى"],["support","❤️ مسار الحياة","+2% صحة دائمة لكل مستوى"],["speed","💨 مسار السرعة","+1.5 سرعة دائمة لكل مستوى"]];
 var h='<div style="text-align:center"><b style="font:900 17px Cairo;color:#fde68a">🌿 شجرة المهارات</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">📚 كتبك: '+bk+' — كل مستوى يحتاج كتبًا أكثر'+(ac?" (خصم الأكاديمية "+(ac*10)+"%)":"")+'</div>';
 paths.forEach(function(p){
  var l=s.skills[p[0]],cost=Math.max(3,Math.round(6*(l+1)*(1-.1*ac)));
  h+='<div class="sp-card"><div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:800 12.5px Cairo;color:#fde68a">'+p[1]+' — مستوى '+l+'</b><div style="font:9.5px Cairo;color:rgba(255,234,176,.6)">'+p[2]+'</div><div style="font:9.5px Cairo;color:rgba(255,234,176,.5);margin-top:3px">التالي: 📚 '+cost+' كتب</div></div><button class="sp-btn gold" data-sp="skill-up" data-arg="'+p[0]+'">ترقية</button></div></div>'
 });
 h+='<div style="font:10px Cairo;color:rgba(255,234,176,.5);margin-top:6px">الكتب تسقط من رحلة السراب ومعارك الأنظمة الخاصة.</div><div style="margin-top:8px"><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["skill-up"]=function(b,arg){
 var s=st(),ac=s.buildings.academy||0,l=s.skills[arg]||0,cost=Math.max(3,Math.round(6*(l+1)*(1-.1*ac))),g=G();
 if(!g)return;
 if(((g.books)||0)<cost){toast("الكتب لا تكفي — احصل عليها من الرحلة والأنظمة");return}
 SET(function(st2){return{books:(st2.books||0)-cost}});
 s.skills[arg]=l+1;save();toast("🌿 ترقّى المسار إلى "+(l+1));ACT["open-skills"]();evalAch()
};

/* ---------- كتاب الوحوش ---------- */

/* ---------- بوكس استحضار الوحوش: اقتل لتفتح — استحضر لتزيد القوة ---------- */
function boxCount(){var sp=st();return Object.keys((sp.box&&sp.box.summoned)||{}).length}
function boxBoostPct(){return .2*boxCount()}
window.SOLBOX_REC=function(names){var sp=st(),ch=0;(names||[]).forEach(function(n){if(!n)return;var b=sp.bestiary[n];if(!b){sp.bestiary[n]={n:1,last:Date.now(),kind:kindOf(n)};ch++}else{b.n++;b.last=Date.now()}});if(ch)save();return ch};
function chipN(n,b){
 if(!b)return '<span class="sp-chip" style="opacity:.45">؟ '+esc(n)+'</span>';
 var sm=(st().box&&st().box.summoned&&st().box.summoned[n])||0;
 var av='';
 try{
  if(window.SOLMOB&&window.SOLMOB.ok&&window.SOLMOB.classify(n)) av=window.SOLMOB.avHTML(n,62);
  else if(window.SOLFBX&&window.SOLFBX.ok&&window.SOLFBX.avHTML) av=window.SOLFBX.avHTML(n,"abyss","dps",54);
 }catch(e){}
 if(av){
  return '<button class="sp-chip" style="cursor:pointer;display:flex;flex-direction:column;align-items:center;min-width:96px;max-width:122px;padding:5px 6px 6px;gap:3px;'+(sm?'border-color:#2fb8a6;color:#7ee0d2':'')+'" data-sp="box-summon" data-arg="'+esc(n)+'" title="اضغط لاستحضار الوحش وزيادة القوة الدائمة">'+av+'<span style="font:700 9.5px Cairo;line-height:1.3;text-align:center">'+(sm?'🔮 ':'☠ ')+esc(n)+' ×'+b.n+(sm?' ✓':'')+'</span></button>'
 }
 return '<button class="sp-chip" style="cursor:pointer;'+(sm?'border-color:#2fb8a6;color:#7ee0d2':'')+'" data-sp="box-summon" data-arg="'+esc(n)+'" title="اضغط لاستحضار الوحش وزيادة القوة الدائمة">'+(sm?'🔮':'☠')+' '+esc(n)+' ×'+b.n+(sm?' ✓':'')+'</button>'
}
ACT["box-summon"]=function(btn,arg){
 var sp=st();if(!arg)return;var b=sp.bestiary[arg];
 if(!b){toast("🔒 لم تقتل هذا الوحش في المعارك بعد");return}
 if(!sp.box)sp.box={summoned:{}};
 if(!sp.box.summoned)sp.box.summoned={};
 if(sp.box.summoned[arg]){toast("⭐ استحضرت "+arg+" من قبل — القوة مفعّلة");return}
 sp.box.summoned[arg]=1;save();
 try{window.PXFXPOP(btn,"pickups/chest-open",{s:1.6});window.PXFXPOP(btn,"pickups/collect-burst",{delay:.32,s:1.4});}catch(e){}
 toast("🔮 استُحضر "+arg+" — قوة أبطالك الآن +"+boxBoostPct().toFixed(1)+"%");
 renderBestiary()
};
ACT["open-bestiary"]=function(){
 renderBestiary()
};
function renderBestiary(){
 var s=st(),bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;
 /* الوحوش تُفتح بالقتل فقط — بوكس الاستحضار */ var h='<div style="text-align:center"><b style="font:900 17px Cairo;color:#fde68a">📚 كتاب الوحوش</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">كل وحش واجهته في المعارك يُسجل بمجسم ثلاثي الأبعاد — '+Object.keys(s.bestiary).length+' مكتشف حتى الآن</div><div style="font:11px Cairo;font-weight:700;color:#7ee0d2;margin:2px 0 8px">🔮 اضغط على وحش مفتوح لاستحضاره — القوة الحالية: +'+(.2*Object.keys((s.box&&s.box.summoned)||{}).length).toFixed(1)+'% هجوم وصحة دائمة</div>';
 REGIONS.forEach(function(r){
  h+='<div class="sp-card"><div class="sp-h" style="font-size:12px">'+REGIONS.indexOf(r)+1+'. '+esc(r.name)+'</div><div class="sp-row" style="margin-top:5px">';
  r.mobs.concat(r.bosses,[r.secret]).forEach(function(n){
   var b=s.bestiary[n];
   h+=chipN(n,b)
  });
  h+="</div></div>"
 });
 ATLAS.forEach(function(r){
  h+='<div class="sp-card"><div class="sp-h" style="font-size:12px">'+r.icon+' '+esc(r.name)+'</div><div class="sp-row" style="margin-top:5px">';
  r.mobs.concat([r.boss]).forEach(function(n){
   var b=s.bestiary[n];
   h+=chipN(n,b)
  });
  h+="</div></div>"
 });
 var others=Object.keys(s.bestiary).filter(function(n){return kindOf(n)==="rare"});
 if(others.length){h+='<div class="sp-card"><div class="sp-h" style="font-size:12px">✨ وحوش نادرة</div><div class="sp-row" style="margin-top:5px">'+others.map(function(n){return '<span class="sp-chip">☠ '+esc(n)+' ×'+s.bestiary[n].n+'</span>'}).join("")+"</div></div>"}
 h+='<div style="margin-top:10px"><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
}

/* ---------- الإنجازات ---------- */
var ACH=[
 {id:"a_first",icon:"🔥",name:"أول شرارة",desc:"اربح أول معركة",cur:function(){var g=G();return g?g.stats.battlesWon:0},t:1,rw:{gems:20}},
 {id:"a_b25",icon:"⚔️",name:"محارب مداوم",desc:"اربح 25 معركة",cur:function(){var g=G();return g?g.stats.battlesWon:0},t:25,rw:{gems:40}},
 {id:"a_b100",icon:"🎖️",name:"قائد المئة",desc:"اربح 100 معركة",cur:function(){var g=G();return g?g.stats.battlesWon:0},t:100,rw:{gems:100,tokens:10}},
 {id:"a_t10",icon:"🏰",name:"فتّاح البرج",desc:"اكمل طابق 10 في برج الرمال",cur:function(){var g=G();return g&&g.modes?g.modes.tower||0:0},t:10,rw:{gems:40,tokens:2}},
 {id:"a_t50",icon:"🏰",name:"ساكن البرج",desc:"اكمل طابق 50 في برج الرمال",cur:function(){var g=G();return g&&g.modes?g.modes.tower||0:0},t:50,rw:{gems:80,tokens:5}},
 {id:"a_t100",icon:"👑",name:"ملك البرج",desc:"اكمل الطابق 100 من برج الرمال",cur:function(){var g=G();return g&&g.modes?g.modes.tower||0:0},t:100,rw:{gems:200,tokens:10}},
 {id:"a_s1",icon:"👹",name:"قاهر الخفايا",desc:"اهزم زعيمًا سريًا",cur:function(){var s=st();return Object.values(s.secret).reduce(function(a,b){return a+b},0)},t:1,rw:{gems:50,tokens:3}},
 {id:"a_s15",icon:"💀",name:"مبيد الأزليين",desc:"اهزم الزعماء السرية 15 مرة",cur:function(){var s=st();return Object.values(s.secret).reduce(function(a,b){return a+b},0)},t:15,rw:{gems:150,tokens:8}},
 {id:"a_c3",icon:"🐪",name:"حامي القافلة",desc:"صل إلى الموجة 3 من القوافل",cur:function(){return st().caravan.best},t:3,rw:{gems:50}},
 {id:"a_c7",icon:"🏺",name:"صانع الطريق",desc:"صل إلى الموجة 7 من القوافل",cur:function(){return st().caravan.best},t:7,rw:{gems:120,tokens:4}},
 {id:"a_rare1",icon:"🎯",name:"أول فريسة",desc:"اصطد وحشًا نادرًا",cur:function(){return st().rare.caught},t:1,rw:{gems:40}},
 {id:"a_rare5",icon:"✨",name:"منجل الرمال",desc:"اصطد 5 وحوش نادرة",cur:function(){return st().rare.caught},t:5,rw:{gems:120,tokens:5}},
 {id:"a_craft10",icon:"⚒️",name:"حدّاد المبتدئين",desc:"اصنع 10 قطع معدات",cur:function(){return st().counters.crafts},t:10,rw:{gems:50}},
 {id:"a_merge10",icon:"🔨",name:"ناقل الذخيرة",desc:"ادمج 10 مرات",cur:function(){return st().counters.merges},t:10,rw:{gems:50}},
 {id:"a_atlas3",icon:"🗺️",name:"رأس الخرائط",desc:"اكتشف 3 مناطق في الأطلس",cur:function(){return Object.keys(st().discovered).length},t:3,rw:{gems:60,tokens:5}},
 {id:"a_atlas6",icon:"🧭",name:"الأطلس اكتمل",desc:"اكتشف كل مناطق الأطلس الست",cur:function(){return Object.keys(st().discovered).length},t:6,rw:{gems:150,tokens:12}},
 {id:"a_j3",icon:"🌀",name:"سالك السراب",desc:"أكمل 3 رحلات سراب",cur:function(){return st().journeyRuns},t:3,rw:{gems:60,tokens:4}},
 {id:"a_story3",icon:"📖",name:"راوٍ واعد",desc:"أكمل 3 فصول من القصة",cur:function(){return st().story.done.length},t:3,rw:{gems:80}},
 {id:"a_story6",icon:"✒️",name:"صاحب الحكاية",desc:"أكمل الفصول الستة كلها",cur:function(){return st().story.done.length},t:6,rw:{gems:200,tokens:10}},
 {id:"a_city10",icon:"🏙️",name:"مهندس الرمال",desc:"اجمع 10 مستويات في مباني المدينة",cur:function(){var s=st();return Object.values(s.buildings).reduce(function(a,b){return a+b},0)},t:10,rw:{gems:80}},
 {id:"a_fr10",icon:"🤝",name:"روح الرمال",desc:"بلغ صداقة أي بطل المستوى 10",cur:function(){var s=st();return Math.max.apply(null,[0].concat(Object.values(s.friendship)))},t:10,rw:{gems:60}},
 {id:"a_gear8",icon:"🧰",name:"بطل مجهّز بالكامل",desc:"جهّز بطلًا واحدًا في الخانات الثمانية كلها",cur:function(){var g=G();if(!g)return 0;var m=0;Object.values(g.heroes).forEach(function(h){m=Math.max(m,Object.keys(h.gear||{}).filter(function(k){return h.gear[k]}).length)});return m},t:8,rw:{gems:100,tokens:5}},
 {id:"a_relic5",icon:"🗿",name:"جامع الآثار",desc:"اجمع 5 آثار",cur:function(){return st().relics.length},t:5,rw:{gems:80,tokens:4}},
 {id:"a_relic13",icon:"🏛️",name:"أرشيف الرمال",desc:"اجمع الآثار الثلاثة عشر كلها",cur:function(){return st().relics.length},t:13,rw:{gems:250,tokens:10}},
 {id:"a_wing5",icon:"🪽",name:"أجنحة الرماد",desc:"بلغ الجناح المستوى 5",cur:function(){return st().wingLevel},t:5,rw:{gems:80}},
 {id:"a_skill8",icon:"🌿",name:"باحث الحكمة",desc:"اجمع 8 مستويات في شجرة المهارات",cur:function(){var s=st();return s.skills.attack+s.skills.defense+s.skills.support+s.skills.speed},t:8,rw:{gems:60}},
 {id:"a_rich",icon:"💰",name:"خزنة الرمال",desc:"اجمع 150 ألف ذهب في وقت واحد",cur:function(){var g=G();return g?g.resources.gold:0},t:150000,rw:{gems:60,tokens:3}},
 {id:"a_power",icon:"⚡",name:"أسطورة قوية",desc:"بلغ قوة الفريق 80 ألف",cur:function(){var g=G();if(!g||!window.__solPower||!window.__solHeroes)return 0;var t=0;Object.keys(g.heroes).forEach(function(id){if(g.team.indexOf(id)>=0&&window.__solHeroes[id]){t+=window.__solPower(window.__solHeroes[id],g.heroes[id]).power}});return t},t:80000,rw:{gems:120,tokens:5}}
];
ACT["open-ach"]=function(){
 var s=st(),h='<div style="text-align:center"><b style="font:900 17px Cairo;color:#fde68a">🏆 الإنجازات والألقاب</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">'+Object.keys(s.achievements).length+"/"+ACH.length+' — تنفتح من لعبك الحقيقي وتُكافأ فورًا</div>';
 ACH.forEach(function(a){
  var got=!!s.achievements[a.id],cur=Math.min(a.cur(),a.t);
  h+='<div class="sp-card" style="'+(got?"border-color:rgba(240,199,94,.55);background:rgba(240,199,94,.05)":"")+'"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><div style="flex:1"><b style="font:800 12px Cairo;color:'+(got?"#fde68a":"rgba(255,237,176,.75)")+'">'+a.icon+' '+esc(a.name)+'</b><div style="font:9.5px Cairo;color:rgba(255,234,176,.55)">'+esc(a.desc)+'</div><div class="sp-bar" style="margin-top:4px"><i style="width:'+(cur/a.t*100)+'%"></i></div><div style="font:8.5px Cairo;color:rgba(255,234,176,.4);margin-top:2px">'+cur.toLocaleString("en-US")+' / '+a.t.toLocaleString("en-US")+'</div></div>'+(got?'<span class="sp-chip" style="border-color:#05966966;color:#86efac">✓</span>':"")+'</div></div>'
 });
 h+='<div style="margin-top:10px"><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};
function evalAch(){
 var s=st(),g=G();
 ACH.forEach(function(a){
  if(s.achievements[a.id])return;
  var c=0;try{c=a.cur()}catch(e){}
  if(c>=a.t){
   s.achievements[a.id]=1;
   var rw=a.rw||{};
   if(rw.tokens){s.tokens+=rw.tokens}
   var d={};["gems","gold","mats","shards","xp"].forEach(function(k){if(rw[k])d[k]=rw[k]});
   if(Object.keys(d).length)addRes(d);
   var parts=[];if(rw.gems)parts.push("💎"+rw.gems);if(rw.gold)parts.push("🪙"+rw.gold);if(rw.mats)parts.push("⚙️"+rw.mats);if(rw.tokens)parts.push("🪙"+rw.tokens+" توكن");
   toast("🏆 إنجاز: "+a.name+(parts.length?" — "+parts.join(" "):""))
  }
 });
 save();
 updateDataSol()
}
function updateDataSol(){
 var s=st(),n=Object.keys(s.achievements).length;
 var el=document.querySelector('[data-sol="ach"]');
 if(el)el.textContent="إنجازاتك: "+n+" مفتوحة — ومكافآتها فورية";
 var lg=document.querySelector('[data-sol="login"]');
 if(lg)lg.textContent="سلسلة حضورك: "+(s.login.streak||0)+" يوم — ادّعي مكافأة اليوم";
 var wf=document.querySelector('[data-sol="gift"]');
 if(wf)wf.textContent=s.wheel.date===hh()?"عجلة اليوم انحصت — عد غدًا":"عجلة الحظ مجانية كل يوم";
}


/* ============================================================
   الجزء الثالث-ج — الحدادة، التشكيلات، العجلة، الحضور، التركيب
   ============================================================ */
function pieceName(p){return(SLOTS.find(function(x){return x[0]===p.slot})||["","قطعة","⚙️"])[2]+" "+(SLOTS.find(function(x){return x[0]===p.slot})||["","قطعة","⚙️"])[1]+" — "+TNm(p.tier)+(p.stars?" "+"+".repeat(p.stars):"")}
function craftCost(){var sm=st().buildings.smith||0;return{mats:Math.round((25+6*sm)*(1-.08*sm)),gold:Math.round((1200+300*sm)*(1-.08*sm))}}
function renderForgePanel(){
 var s=st(),g=G(),sm=s.buildings.smith||0,cc=craftCost();
 var ws=WING_STAGES.filter(function(w){return s.wingLevel>=w[0]}).pop();
 var wc={mats:30+20*(s.wingLevel-1),gold:2500+1500*(s.wingLevel-1)};
 var h='<div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:900 19px Cairo;color:#ffedb0">⚒️ الحدادة والمخزن</b><div style="font:10px Cairo;color:rgba(255,234,176,.55)">تصنيع ودمج وتجهيز — كل قطعة تُحسب في القتال فعليًا</div></div><span class="sp-chip">مخزن: '+s.inventory.length+'</span></div>';
 h+='<div class="sp-card"><div class="sp-h">التصنيع — مستوى الحدادة '+sm+'</div><div class="sp-sub">تكلفة القطعة: ⚙️ '+cc.mats+' + 🪙 '+cc.gold.toLocaleString("en-US")+' — القطعة تبدأ عادي — ادمج قطعتين متشابهتين لترقيتها</div>';
 h+='<div class="sp-grid3">'+SLOTS.map(function(sl){return '<button class="sp-btn" style="font-size:9.5px;padding:6px 2px" data-sp="forge-craft" data-arg="'+sl[0]+'">'+sl[2]+'<br>'+sl[1]+'</button>'}).join("")+'</div>';
 h+='<div style="margin-top:7px"><button class="sp-btn gold" style="width:100%;padding:9px" data-sp="forge-craft">🎲 قطعة عشوائية</button></div></div>';
 var ma=s.flags.mergeA,mb=s.flags.mergeB;
 h+='<div class="sp-card"><div class="sp-h">الدمج — قطعتان بنفس النوع والشطب تصيران شطبًا أعلى</div>';
 if(ma!=null&&mb!=null){h+='<div style="margin-top:6px"><button class="sp-btn gold" style="width:100%;padding:9px" data-sp="forge-merge">🔨 ادمج القطعتين المحددتين</button></div>'}
 else h+='<div class="sp-sub">اضغط على أي قطعة في المخزن ثم «دمج» — ستظهر لك القطع المشابهة لتختار منها</div>';
 h+='</div>';
 h+='<div class="sp-card"><div class="sp-h">أسلوب المعدات: '+({attack:"هجومي",defense:"دفاعي",speed:"سرعة",balanced:"متوازن"}[s.style])+'</div><div class="sp-row">'+[["attack","⚔️ هجومي"],["defense","🛡️ دفاعي"],["speed","💨 سرعة"],["balanced","⚖️ متوازن"]].map(function(x){return '<button class="sp-btn'+(s.style===x[0]?" gold":"")+'" data-sp="style-set" data-arg="'+x[0]+'">'+x[1]+'</button>'}).join("")+'</div></div>';
 h+='<div class="sp-card"><div class="sp-h">🪽 الأجنحة — '+ws[1]+' ('+ws[2]+')</div><div class="sp-sub">المستوى '+s.wingLevel+' — كل مستوى +6% لخصائص الجناح لكل الأبطال'+(sm?" • معبد الأجنحة: +"+(s.buildings.temple||0)*10+"%":"")+'</div>';
 h+='<div style="margin-top:6px"><button class="sp-btn purple" style="width:100%;padding:9px" '+(g&&g.resources.mats>=wc.mats&&g.resources.gold>=wc.gold?"":"disabled")+' data-sp="wing-up">تطوير الجناح — ⚙️ '+wc.mats+' + 🪙 '+wc.gold.toLocaleString("en-US")+'</button></div></div>';
 h+='<div class="sp-card"><div class="sp-h">المخزن ('+s.inventory.length+')</div>';
 if(!s.inventory.length)h+='<div class="sp-sub">المخزن فارغ — قطع البرج والرحلة والتصنيع تُضاف هنا</div>';
 else{
  h+='<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:6px">';
  s.inventory.forEach(function(p,i){
   var sel=(ma===i||mb===i);
   h+='<button data-sp="forge-piece" data-arg="'+i+'" style="text-align:center;border:1px solid '+(sel?"#ffd236":"rgba(212,169,65,.3)")+';border-radius:10px;padding:7px 3px;background:'+(sel?"rgba(240,199,94,.1)":"rgba(0,0,0,.3)")+';color:#ffe9a3;cursor:pointer"><div style="font-size:17px">'+(SLOTS.find(function(x){return x[0]===p.slot})||["","⚙️"])[2]+'</div><div style="font:800 9px Cairo">'+TNm(p.tier)+(p.stars?"+"+p.stars:"")+'</div><div style="font:8px Cairo;color:rgba(255,234,176,.55)">'+(SLOTS.find(function(x){return x[0]===p.slot})||["","قطعة"])[1]+'</div></button>'
  });
  h+="</div>"
 }
 h+="</div>";
 return h
}
ACT["forge-craft"]=function(b,arg){
 var s=st(),g=G(),cc=craftCost(),sm=s.buildings.smith||0;
 if(!g)return;
 if(g.resources.mats<cc.mats||g.resources.gold<cc.gold){toast("الموارد لا تكفي — تحتاج ⚙️"+cc.mats+" و 🪙"+cc.gold);return}
 addRes({mats:-cc.mats,gold:-cc.gold});
 var slots=arg?[arg]:SLOTS.map(function(x){return x[0]});
 var slot=slots[Math.floor(Math.random()*slots.length)];
 var maxT=Math.min(7,2+Math.floor(((g.campaign?g.campaign.bestStage:0)||0)/40)+Math.floor(sm/2));
 var tier=1;if(Math.random()<.12+.04*sm)tier=2;if(tier===2&&maxT>=3&&Math.random()<.25+.03*sm)tier=3;if(tier===3&&maxT>=4&&Math.random()<.15+.02*sm)tier=4;if(tier>maxT)tier=maxT;
 s.inventory.push({slot:slot,tier:tier,stars:0,src:"تصنيع الحدادة"});
 s.counters.crafts++;save();
 toast("⚒️ صنعت "+pieceName({slot:slot,tier:tier,stars:0}));renderPanel();evalAch()
};
ACT["forge-piece"]=function(b,arg){
 var s=st(),i=+arg,p=s.inventory[i],g=G();if(!p)return;
 var sl=SLOTS.find(function(x){return x[0]===p.slot})||["","قطعة","⚙️"];
 var ma=s.flags.mergeA,mb=s.flags.mergeB;
 var h='<div style="text-align:center"><div style="font-size:40px">'+sl[2]+'</div><b style="font:900 15px Cairo;color:#fde68a">'+pieceName(p)+'</b><div style="font:10px Cairo;color:rgba(255,234,176,.55);margin:4px 0 10px">المصدر: '+esc(p.src||"مجهول")+' • الشطب: '+TNm(p.tier)+' '+"+".repeat(p.stars||0)+'</div>';
 h+='<div style="display:grid;gap:7px">';
 h+='<button class="sp-btn gold" style="padding:10px" data-sp="forge-equip" data-arg="'+i+'">🧑‍🚀 تجهيز على بطل</button>';
 var mc=0;s.inventory.forEach(function(q,k){if(k!==i&&q.slot===p.slot&&q.tier===p.tier)mc++});
 h+='<button class="sp-btn purple" style="padding:10px" '+(mc&&p.tier<7?"":"disabled")+' data-sp="forge-merge-list" data-arg="'+i+'">🔨 دمج'+(p.tier>=7?" — الشطب الأقصى":mc?" ("+mc+" قطعة مشابهة)":" — لا توجد قطعة مشابهة")+'</button>';
 var ec={mats:8+12*(p.stars||0),gold:800*((p.stars||0)+1)};
 if((p.stars||0)<5)h+='<button class="sp-btn" style="padding:10px" '+(g&&g.resources.mats>=ec.mats&&g.resources.gold>=ec.gold?"":"disabled")+' data-sp="forge-star" data-arg="'+i+'">⭐ شطب النجوم — ⚙️'+ec.mats+' + 🪙'+ec.gold+'</button>';
 h+='<button class="sp-btn red" style="padding:10px" data-sp="forge-sell" data-arg="'+i+'">💰 بيع القطعة — 🪙'+(200*p.tier)+'</button>';
 h+='<button class="sp-btn" style="padding:10px" data-sp="forge-close-piece">رجوع</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["forge-close-piece"]=function(){closeModal()};
ACT["forge-merge-list"]=function(b,arg){
 var s=st(),i=+arg,p=s.inventory[i];if(!p)return;
 var sl=SLOTS.find(function(x){return x[0]===p.slot})||["","قطعة","⚙️"];
 var h='<div style="text-align:center"><div style="font-size:34px">'+sl[2]+'</div><b style="font:900 15px Cairo;color:#fde68a">دمج '+pieceName(p)+'</b><div style="font:10px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">اختر القطعة المشابهة — الناتج: '+sl[1]+' '+TNm(p.tier+1)+'</div><div style="display:grid;gap:7px">';
 var n=0;
 s.inventory.forEach(function(q,k){
  if(k===i||q.slot!==p.slot||q.tier!==p.tier)return;n++;
  h+='<button class="sp-btn" style="padding:10px;display:flex;justify-content:space-between;align-items:center" data-sp="forge-merge-do" data-arg="'+i+','+k+'"><span>'+sl[2]+' '+pieceName(q)+'</span><span style="font-size:9px;opacity:.7">'+esc(q.src||"")+'</span></button>'
 });
 if(!n)h+='<div class="sp-sub">لا توجد قطعة مشابهة (نفس النوع ونفس الشطب)</div>';
 h+='<button class="sp-btn" style="padding:10px" data-sp="forge-piece" data-arg="'+i+'">رجوع</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["forge-merge-do"]=function(b,arg){
 var s=st(),ids=String(arg).split(","),a=+ids[0],c=+ids[1],p1=s.inventory[a],p2=s.inventory[c];
 if(!p1||!p2||a===c||p1.slot!==p2.slot||p1.tier!==p2.tier){toast("القطعتان يجب أن تكونا بنفس النوع والشطب");return}
 if(p1.tier>=7){toast("الشطب الأقصى 7");return}
 var merged={slot:p1.slot,tier:p1.tier+1,stars:Math.max(p1.stars||0,p2.stars||0),src:"دمج الحدادة"};
 s.inventory=s.inventory.filter(function(_,ix){return ix!==a&&ix!==c});
 s.inventory.push(merged);s.flags.mergeA=null;s.flags.mergeB=null;s.counters.merges++;save();
 toast("🔨 صارت القطعة "+pieceName(merged));closeModal();renderPanel();evalAch()
};
ACT["forge-merge-pick"]=function(b,arg){var s=st();s.flags.mergeA=+arg;s.flags.mergeB=null;save();closeModal();renderPanel();toast("① حددت قطعة للدمج — اختر الثانية بنفس النوع والشطب")};
ACT["forge-merge-now"]=function(b,arg){
 var s=st(),a=s.flags.mergeA,i=+arg;
 if(a==null||a===i){toast("حدد قطعتين مختلفتين بنفس النوع والشطب");return}
 var p1=s.inventory[a],p2=s.inventory[i];
 if(!p1||!p2||p1.slot!==p2.slot||p1.tier!==p2.tier){toast("القطعتان يجب أن تكونا بنفس النوع والشطب");return}
 if(p1.tier>=7){toast("الشطب الأقصى 7");return}
 var merged={slot:p1.slot,tier:p1.tier+1,stars:Math.max(p1.stars||0,p2.stars||0),src:"دمج الحدادة"};
 var keep=Math.max(a,i);s.inventory=s.inventory.filter(function(_,ix){return ix!==a&&ix!==i});
 s.inventory.push(merged);
 s.flags.mergeA=null;s.flags.mergeB=null;s.counters.merges++;save();
 toast("🔨 صارت القطعة "+pieceName(merged));closeModal();renderPanel();evalAch()
};
ACT["forge-star"]=function(b,arg){
 var s=st(),i=+arg,p=s.inventory[i],g=G();
 if(!p||!g)return;
 var ec={mats:8+12*(p.stars||0),gold:800*((p.stars||0)+1)};
 if((p.stars||0)>=5)return;
 if(g.resources.mats<ec.mats||g.resources.gold<ec.gold){toast("الموارد لا تكفي");return}
 addRes({mats:-ec.mats,gold:-ec.gold});
 p.stars=(p.stars||0)+1;save();toast("⭐ صارت "+pieceName(p));ACT["forge-piece"](b,String(i))
};
ACT["forge-sell"]=function(b,arg){
 var s=st(),i=+arg,p=s.inventory[i];
 if(!p)return;
 addRes({gold:200*p.tier});
 s.inventory.splice(i,1);s.flags.mergeA=null;s.flags.mergeB=null;save();
 toast("💰 بيعت القطعة");closeModal();renderPanel()
};
ACT["forge-equip"]=function(b,arg){
 var s=st(),i=+arg,p=s.inventory[i],g=G();
 if(!p||!g)return;
 var ids=Object.keys(g.heroes),h='<div style="text-align:center"><b style="font:900 15px Cairo;color:#fde68a">تجهيز '+pieceName(p)+'</b><div style="font:10px Cairo;color:rgba(255,234,176,.55);margin:4px 0 10px">اختر البطل — إن كانت الخانة مشغولة فستعود القطعة القديمة للمخزن</div><div style="display:grid;gap:6px">';
 ids.forEach(function(id){
  var def=(window.__solHeroes&&window.__solHeroes[id])||{name:id,faction:"abyss"},cur=g.heroes[id].gear&&g.heroes[id].gear[p.slot];
  h+='<button class="sp-btn" style="text-align:right;padding:9px" data-sp="forge-equip-hero" data-arg="'+i+":"+id+'">'+((FACTIONS[def.faction]||{}).icon||"🌊")+' '+esc(def.name)+(cur?' <span style="font:8.5px Cairo;color:#fca5a5">(الحالية: '+TNm(cur.tier)+')</span>':'')+'</button>'
 });
 h+='</div><div style="margin-top:8px"><button class="sp-btn" style="width:100%" data-sp="forge-close-piece">رجوع</button></div></div>';
 openModal(h,{dark:!0})
};
/* ---------- المعدات على مجسم الشخصية — الربط + تأثير التجهيز/الإزالة ---------- */
window.SOLTIERC=TIERC;
if(window.SOLFBX&&!window.SOLFBX.gearProvider){
 window.SOLFBX.gearProvider=function(name){
  try{
   var H=window.__solHeroes;if(!H||!name)return null;
   var id=null;
   for(var k in H){if(H[k]&&H[k].name===name){id=k;break}}
   if(id===null)return null;
   var g=window.__solGet&&window.__solGet();
   if(!g||!g.heroes||!g.heroes[id])return null;
   var p=window.__solPlusState?window.__solPlusState():null;
   var gr={gear:g.heroes[id].gear||{},wingLevel:(p&&p.wingLevel)||1,role:H[id].role||"dps",ranged:/^(صقر|هلال)/.test(H[id].name||"")};
   /* كل بطل يحصل على أجنحة افتراضية تتطور مع مستوى الأجنحة */
   return gr;
  }catch(e){return null}
 };
}
function solGearFx(name,kind){
 try{
  if(!name)return 0;
  var list=document.querySelectorAll("canvas[data-fbx],canvas[data-fbxav]"),n=0;
  for(var i=0;i<list.length;i++){
   var cv=list[i];
   if(!cv.isConnected||!cv.offsetParent)continue;
   if((cv.getAttribute("data-n")||"")!==name)continue;
   var w=cv.clientWidth;if(w<46)continue;
   var r=cv.getBoundingClientRect();
   cv.classList.remove("sol-gpop");void cv.offsetWidth;cv.classList.add("sol-gpop");
   var host=document.createElement("div");
   host.style.cssText="position:fixed;pointer-events:none;z-index:9999;left:"+r.left+"px;top:"+r.top+"px;width:"+r.width+"px;height:"+r.height+"px;overflow:visible";
   var cx=r.width/2,cy=r.height*(kind==="unequip"?0.55:0.42),NN=kind==="unequip"?9:13;
   for(var k=0;k<NN;k++){
    var sp=document.createElement("div");
    sp.className="sol-gspark";
    var ang=k/NN*Math.PI*2+Math.random()*.6,dd=(kind==="unequip"?20:28)+Math.random()*24;
    var sz=(kind==="unequip"?4:5)+Math.random()*3;
    var col=kind==="unequip"?(Math.random()<.5?"#c9b79a":"#8f8272"):(Math.random()<.5?"#ffd236":"#fff3c4");
    sp.style.cssText="left:"+(cx+Math.cos(ang)*9).toFixed(1)+"px;top:"+(cy+Math.sin(ang)*9).toFixed(1)+"px;width:"+sz.toFixed(1)+"px;height:"+sz.toFixed(1)+"px;background:"+col+";box-shadow:0 0 7px "+col+";--dx:"+(Math.cos(ang)*dd).toFixed(1)+"px;--dy:"+(Math.sin(ang)*dd-12).toFixed(1)+"px";
    host.appendChild(sp);
   }
   if(kind==="equip"){
    var ring=document.createElement("div");
    ring.className="sol-gring";
    var rw=r.width*.86;
    ring.style.cssText="left:"+(cx-rw/2)+"px;top:"+(cy-rw/2)+"px;width:"+rw+"px;height:"+rw+"px";
    host.appendChild(ring);
   }
   document.body.appendChild(host);
   setTimeout(function(h){return function(){if(h&&h.parentNode)h.parentNode.removeChild(h)}}(host),950);
   n++;
  }
  return n;
 }catch(e){return 0}
}
ACT["forge-equip-hero"]=function(b,arg){
 var parts=arg.split(":"),i=+parts[0],id=parts[1],s=st(),g=G(),p=s.inventory[i];
 if(!p||!g||!g.heroes[id]){toast("خطأ في التجهيز");return}
 var old=g.heroes[id].gear&&g.heroes[id].gear[p.slot];
 SET(function(st2){
  var hs=Object.assign({},st2.heroes),hh=Object.assign({},hs[id]),gg=Object.assign({},hh.gear||{});
  gg[p.slot]={tier:p.tier,stars:p.stars||0};hh.gear=gg;hs[id]=hh;
  return{heroes:hs}
 });
 s.inventory=s.inventory.filter(function(_,ix){return ix!==i});
 s.flags.mergeA=null;s.flags.mergeB=null;
 if(old)s.inventory.push({slot:p.slot,tier:old.tier,stars:old.stars||0,src:"مُخلوعة"});
 save();
 var _gn=(window.__solHeroes&&window.__solHeroes[id]||{}).name;
 setTimeout(function(){try{solGearFx(_gn,"equip")}catch(e){}},80);
 toast("✅ جهّزت "+pieceName(p));closeModal();renderPanel();evalAch()
};
ACT["wing-up"]=function(){
 var s=st(),g=G(),wc={mats:30+20*(s.wingLevel-1),gold:2500+1500*(s.wingLevel-1)};
 if(!g||g.resources.mats<wc.mats||g.resources.gold<wc.gold){toast("الموارد لا تكفي");return}
 addRes({mats:-wc.mats,gold:-wc.gold});
 s.wingLevel++;save();
 var ws=WING_STAGES.filter(function(w){return s.wingLevel>=w[0]}).pop();
 toast("🪽 تطور الأجنحة: "+ws[1]+" — مستوى "+s.wingLevel);renderPanel();evalAch()
};

/* ---------- التشكيلات ---------- */
ACT["open-formations"]=function(){
 var s=st(),g=G(),h='<div style="text-align:center"><b style="font:900 17px Cairo;color:#fde68a">📋 التشكيلات المحفوظة</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 10px">احفظ فريقك الحالي (أبطال + معدات + مهارات) واسترجعه بضغطة — تشكيلات مختلفة للحملة والبرج والزعماء</div>';
 [0,1,2].forEach(function(i){
  var p=s.presets[i];
  h+='<div class="sp-card"><div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:800 12.5px Cairo;color:#fde68a">التشكيلة '+(i+1)+'</b><div style="font:9.5px Cairo;color:rgba(255,234,176,.55)">'+(p?p.team.length+" أبطال • "+Object.keys(p.heroes||{}).length+" سجل معدات":"فارغة — احفظ الفريق الحالي فيها")+'</div></div><div style="display:flex;gap:4px"><button class="sp-btn" data-sp="preset-save" data-arg="'+i+'">💾 حفظ الحالي</button>'+(p?'<button class="sp-btn green" data-sp="preset-load" data-arg="'+i+'">↩ استرجاع</button>':"")+'</div></div></div>'
 });
 h+='<div style="margin-top:10px"><button class="sp-btn" style="width:100%" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["preset-save"]=function(b,arg){
 var g=G();if(!g)return;
 var s=st(),i=+arg;
 s.presets[i]={team:(g.team||[]).slice(),heroes:Object.keys(g.heroes||{}).reduce(function(a,id){a[id]={gear:Object.assign({},g.heroes[id].gear||{}),sk:g.heroes[id].sk||0,level:g.heroes[id].level,stars:g.heroes[id].stars};return a},{})};
 save();toast("💾 حُفظت التشكيلة "+(i+1));ACT["open-formations"]()
};
ACT["preset-load"]=function(b,arg){
 var g=G(),s=st(),i=+arg,p=s.presets[i];
 if(!p||!g)return;
 SET(function(st2){
  var hs=Object.assign({},st2.heroes);
  Object.keys(p.heroes||{}).forEach(function(id){
   if(hs[id]){var h0=Object.assign({},hs[id]);
    if(p.heroes[id].gear)h0.gear=Object.assign({},p.heroes[id].gear);
    if(p.heroes[id].sk!=null)h0.sk=p.heroes[id].sk;
    hs[id]=h0}
  });
  return{team:p.team.filter(function(id){return hs[id]}).slice(0,5),heroes:hs}
 });
 toast("↩ استُرجعت التشكيلة "+(i+1));closeModal()
};

/* ---------- عجلة الحظ ---------- */
var WHEEL=[{icon:"💎",label:"80 جوهرة",apply:function(){addRes({gems:80})}},{icon:"🪙",label:"4000 ذهب",apply:function(){addRes({gold:4000})}},{icon:"⚙️",label:"18 خامة",apply:function(){addRes({mats:18})}},{icon:"🎯",label:"3 توكنات",apply:function(){st().tokens+=3;save()}},{icon:"⚔️",label:"قطعة معدات",apply:function(){var slots=SLOTS.map(function(x){return x[0]}),sl=slots[Math.floor(Math.random()*8)],g=G();st().inventory.push({slot:sl,tier:Math.max(2,Math.min(7,2+Math.floor(((g&&g.campaign?g.campaign.bestStage:0)||0)/50))),stars:0,src:"عجلة الحظ"});save()}},{icon:"📜",label:"2500 خبرة",apply:function(){addRes({xp:2500})}},{icon:"🔷",label:"12 شظية",apply:function(){addRes({shards:12})}},{icon:"⚡",label:"40 طاقة",apply:function(){addRes({energy:40})}}];
ACT["open-gift"]=function(){
 var s=st(),can=s.wheel.date!==hh(),h='<div style="text-align:center"><div style="font-size:38px">🎁</div><b style="font:900 16px Cairo;color:#fde68a">عجلة حظ الصحراء</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 8px">دورة مجانية كل يوم — أو بدفع 2 توكن</div><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:10px" id="sp-wheel-grid">';
 WHEEL.forEach(function(w,i){h+='<div id="sp-w'+i+'" style="border:1px solid rgba(212,169,65,.3);border-radius:11px;padding:9px 3px;background:rgba(0,0,0,.3);transition:.15s"><div style="font-size:20px">'+w.icon+'</div><div style="font:700 8.5px Cairo;color:#ffe9a3">'+w.label+'</div></div>'});
 h+='</div><div style="margin-top:12px;display:grid;gap:7px">';
 h+='<button class="sp-btn gold" style="padding:11px" id="sp-spin-free" '+(can?"":"disabled")+' data-sp="wheel-spin" data-arg="free">'+(can?"🎁 انح العجلة مجانًا":"انحصت اليوم — عد غدًا")+'</button>';
 h+='<button class="sp-btn purple" style="padding:10px" '+(s.tokens>=2?"":"disabled")+' data-sp="wheel-spin" data-arg="pay">🎯 دورة إضافية — 2 توكن</button>';
 h+='<button class="sp-btn" style="padding:9px" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["wheel-spin"]=function(b,arg){
 var s=st();
 if(arg==="free"){if(s.wheel.date===hh())return;s.wheel.date=hh()}
 else{if(s.tokens<2)return;s.tokens-=2}
 var idx=Math.floor(Math.random()*8),grid=document.getElementById("sp-wheel-grid");
 if(!grid)return;
 var step=0,cur=0;
 var t=setInterval(function(){
  document.querySelectorAll("#sp-wheel-grid > div").forEach(function(d,i){d.style.borderColor="rgba(212,169,65,.3)";d.style.background="rgba(0,0,0,.3)"});
  var el=document.getElementById("sp-w"+(cur%8));if(el){el.style.borderColor="#ffd236";el.style.background="rgba(240,199,94,.15)"}
  cur++;step++;
  if(step>14&&cur%8===idx){
   clearInterval(t);
   var w=WHEEL[idx];w.apply();
   toast("🎁 العجلة أهدتك: "+w.label);evalAch();setTimeout(function(){if(modalOpen()&&document.getElementById("sp-spin-free"))ACT["open-gift"]()},900)
  }
 },110)
};

/* ---------- الحضور اليومي ---------- */
var LOGIN_TABLE=[{gems:30},{gold:2500},{mats:12},{tokens:2},{gems:60},{shards:15},{gems:120,tokens:4}];
ACT["open-login"]=function(){
 var s=st(),today=hh(),claimed=s.login.last===today;
 var day=((s.login.streak||0)%7)+1;
 var h='<div style="text-align:center"><div style="font-size:38px">📅</div><b style="font:900 16px Cairo;color:#fde68a">مكافأة الحضور اليومي</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.6);margin:4px 0 8px">سلسلتك: '+((s.login.streak||0))+' يوم متواصل</div><div class="sp-row" style="justify-content:center">';
 LOGIN_TABLE.forEach(function(r,i){
  var d=i+1,isToday=(i+1)===((s.login.streak||0)%7)+1&&!claimed;
  h+='<div style="border:1px solid '+(isToday?"#ffd236":"rgba(212,169,65,.25)")+';border-radius:10px;padding:7px 9px;background:'+(isToday?"rgba(240,199,94,.12)":"rgba(0,0,0,.3)")+'"><div style="font:800 9px Cairo;color:'+(isToday?"#fde68a":"rgba(255,234,176,.5)")+'">يوم '+(i+1)+'</div><div style="font:700 9px Cairo;color:#ffe9a3">'+(r.gems?"💎"+r.gems:"")+(r.gold?"🪙"+r.gold:"")+(r.mats?"⚙️"+r.mats:"")+(r.tokens?"🎯"+r.tokens:"")+(r.shards?"🔷"+r.shards:"")+'</div></div>'
 });
 h+='</div><div style="margin-top:12px">';
 h+=claimed?'<div style="font:700 11px Cairo;color:#86efac;margin-bottom:8px">✓ استلمت مكافأة اليوم — عد غدًا للاستمرار</div>':'<button class="sp-btn gold" style="width:100%;padding:11px" data-sp="login-claim">📅 ادّعي مكافأة اليوم '+(day)+'</button>';
 h+='<button class="sp-btn" style="width:100%;margin-top:7px" data-sp="sp-close">إغلاق</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["login-claim"]=function(){
 var s=st(),today=hh();
 if(s.login.last===today)return;
 var yest=new Date();yest.setDate(yest.getDate()-1);
 var ys=yest.getFullYear()+"-"+(yest.getMonth()+1)+"-"+yest.getDate();
 s.login.streak=s.login.last===ys?(s.login.streak||0)+1:1;
 s.login.last=today;
 var r=LOGIN_TABLE[(s.login.streak-1)%7];
 var d={};["gems","gold","mats","shards"].forEach(function(k){if(r[k])d[k]=r[k]});
 if(Object.keys(d).length)addRes(d);
 if(r.tokens){s.tokens+=r.tokens}
 save();toast("📅 مكافأة اليوم: "+(r.gems?"💎"+r.gems+" ":"")+(r.gold?"🪙"+r.gold+" ":"")+(r.mats?"⚙️"+r.mats+" ":"")+(r.tokens?"🎯"+r.tokens+" توكن ":"")+(r.shards?"🔷"+r.shards:""));evalAch();ACT["open-login"]()
};

/* ============================================================
   الجزء المتقدم — الهاوية • النقوش • المزاد • عهد الطوفان • الروابط • البطولة
   ============================================================ */
var RN={
 flame:{n:"لهب الفتيان",i:"🔥",atk:.05,d:"هجوم +5% لكل مستوى"},
 bulwark:{n:"صلابة السور",i:"🛡️",def:.06,d:"دفاع +6% لكل مستوى"},
 life:{n:"سرى الحياة",i:"❤️",hp:.05,d:"صحة +5% لكل مستوى"},
 wind:{n:"همسة الريح",i:"💨",spd:2,d:"سرعة +2 لكل مستوى"},
 venom:{n:"سم الأفاعي",i:"🐍",atk:.03,hp:.02,d:"هجوم +3% وصحة +2% لكل مستوى"},
 tideR:{n:"نبض الطوفان",i:"🌊",atk:.04,def:.04,d:"هجوم ودفاع +4% لكل مستوى"},
 greed:{n:"حظ الرمال",i:"🪙",d:"ذهب معارك الأنظمة +10% لكل مستوى"}
};
var RUNE_COST=[{gold:1200,mats:6},{gold:2600,mats:14},{gold:5200,mats:26}];
var HERO_NAMES={sadeem:["سدّيم الحصن","guardians","tank"],nibras:["نبراس المدن","guardians","dps"],daya:["داية الطين","guardians","support"],rukn:["رُكن الصرح","guardians","control"],saqr:["صقر السهول","plains","dps"],baraka:["بركة الريح","plains","tank"],ghassan:["غسّان الربى","plains","support"],aasif:["عاصف الخيل","plains","dps"],nada:["ندى الواحة","oasis","support"],suhhar:["سُحّار الجدول","oasis","control"],hilal:["هلال الليل","oasis","dps"],dhufr:["ظفر الليل","shadow","control"],hamma:["هامّة الظل","shadow","tank"],sarab:["سراب العتمة","shadow","support"],zahraa:["زهراء الفجر","light","support"],mared:["مارد الهاوية","abyss","dps"]};
function heroName(id){var w=window.__solHeroes;if(w&&w[id]&&w[id].name)return w[id].name;var d=HERO_NAMES[id];return d?d[0]:id}
var BONDS=[
 {a:"sadeem",b:"nibras",n:"حرّاس السور",hp:.05,def:.06,d:"صحة +5% ودفاع +6% لكلا البطلين"},
 {a:"saqr",b:"aasif",n:"خيّالة الربى",atk:.08,d:"هجوم +8% لكلا البطلين"},
 {a:"nada",b:"suhhar",n:"أسرار الغدير",hp:.08,d:"صحة +8% لكلا البطلين"},
 {a:"hamma",b:"dhufr",n:"عتمة التوأم",atk:.05,spd:2,d:"هجوم +5% وسرعة +2 لكلا البطلين"},
 {a:"zahraa",b:"mared",n:"الفجر ضد الهاوية",atk:.10,hp:.05,d:"هجوم +10% وصحة +5% لكلا البطلين"},
 {a:"baraka",b:"ghassan",n:"أهل الخير",hp:.06,def:.05,d:"صحة +6% ودفاع +5% لكلا البطلين"},
 {a:"hilal",b:"sarab",n:"أهل الليل الواحاتي",spd:3,d:"سرعة +3 لكلا البطلين"},
 {a:"daya",b:"sadeem",n:"طين الحصن",def:.08,d:"دفاع +8% لكلا البطلين"}];
var ABYSS_MOBS=["زهرة الهاوية","قادم من تحت","همس الأعماق","رمادي منسيّ","بقايا أسطورة","فم صغير"];
var ABYSS_CURSES=[
 {id:"dark",n:"زخم الظلام",d:"أعداء العمق أكثر صحة بـ 25%"},
 {id:"spite",n:"شماتة الهاوية",d:"أعداء العمق أشد هجومًا بـ 20%"},
 {id:"slow",n:"ثقل الرمال",d:"أبطالك أبطأ بـ 4 نقاط سرعة"},
 {id:"weaken",n:"وهن السلاح",d:"هجوم أبطالك -8%"},
 {id:"brittle",n:"صفائح متصدعة",d:"دفاع أبطالك -8%"}];
var TRIALS=[
 {id:"titan",n:"وحش الهاوية الأكبر",rule:"وحش واحد ضخم — صحة ×7 وهجوم ×1.3 — سقف الوقت 120 ثانية",
  build:function(L){return[mkEnemy("تيتان الطوفان الرمادي","abyss","tank",L+4,{isBoss:!0,hpM:7,atkM:1.3})]},tl:120},
 {id:"swarm",n:"أسراب الظلام",rule:"5 أعداء في نفس الوقت — أعداد كثيرة، ليست قوية فرديًا",
  build:function(L){var r=["dps","dps","control","support","dps"],out=[];for(var i=0;i<5;i++)out.push(mkEnemy("طائر ظلام "+(i+1),"abyss",r[i],L,{hpM:.8,atkM:.9}));return out}},
 {id:"iron",n:"الحرس الصلب",rule:"3 حرّاس — دفاع ×1.8 وصحة ×1.6 — المعركة طويلة وشاقة",
  build:function(L){return[mkEnemy("حرس الصفائح","abyss","tank",L,{hpM:1.6,defM:1.8}),mkEnemy("رمي الصلب","abyss","dps",L,{hpM:1.6,defM:1.8}),mkEnemy("كاهن الحديد","abyss","support",L,{hpM:1.6,defM:1.8})]}},
 {id:"clock",n:"ساعة الجحيم",rule:"3 أعداء أقوياء — لكن عندك 60 ثانية فقط!",
  build:function(L){return[mkEnemy("ساعي الجحيم","abyss","dps",L+2,{hpM:1.8,atkM:1.2}),mkEnemy("عقرب الرمال","abyss","control",L+2,{hpM:1.8,atkM:1.2}),mkEnemy("جرس الانهيار","abyss","tank",L+2,{hpM:2.0,atkM:1.1})]},tl:60},
 {id:"mirror",n:"المرآة الرمادية",rule:"صدى أبطالك — نسخ رمادية أقوى بـ 40% تقلّد تشكيلتك",
  build:function(L){var tm=(G()&&G().team)||[],out=[];for(var i=0;i<Math.max(2,Math.min(5,tm.length));i++){var id=tm[i];out.push(mkEnemy("صدى "+heroName(id),"abyss",HERO_NAMES[id]?HERO_NAMES[id][2]:"dps",L+2,{hpM:1.9,atkM:1.4,defM:1.2}))}return out}}];
var RIVALS=[{n:"شيخ المزاد",aggr:.82},{n:"التاجر الغمّاص",aggr:.68},{n:"لصّة الجيوب",aggr:.9},{n:"ابن الدفتر",aggr:.55}];
var AUC_LORE=["قطعة خرجت من قلب السراديب وما زالت تلمع","قال عنها شيخ مزاد قديم: «لا تقبل بالذهب وحده»","يُشاع أنها كانت لأسطورة نسيها الناس","نقوشها الحافية تنبض عند منتصف الليل","صاحبها الأول لم يُهزم قط — ثم اختفى","مصقولة بماء الواحة وخُتمت بخيط الفجر"];
function todayStr(){var d=new Date();return d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()}
var advPend=null;
/* ملخص النقوش المحفورة */
function runeScan(){
 var g=G(),out={count:0,gold:0};
 if(!g)return out;
 (g.team||[]).forEach(function(id){var hr=g.heroes[id];if(!hr)return;
  Object.keys(hr.gear||{}).forEach(function(k){var it=hr.gear[k];(it.runes||[]).forEach(function(rn){out.count++;if(rn.t==="greed")out.gold+=(rn.lvl||1)})})});
 return out
}
/* ===== واجهة البوكس المتقدم ===== */
function advStatTile(icon,val,lab){return '<div style="text-align:center;padding:8px 4px;border:1px solid rgba(212,169,65,.25);border-radius:12px;background:rgba(0,0,0,.28)"><div style="font-size:18px">'+icon+'</div><div style="font:900 13px Cairo;color:#fde68a">'+val+'</div><div style="font:9px Cairo;color:rgba(255,234,176,.55)">'+lab+'</div></div>'}
var ADV_TABS=[["abyss","🕳️ الهاوية"],["runes","⚡ النقوش"],["auc","🏛️ المزاد"],["tide","🌊 الطوفان"],["bonds","🤝 الروابط"],["trial","🏆 البطولة"]];
function renderAdvTab(){
 var s=st(),g=G();
 var rs=runeScan();
 var h='<div style="border:1px solid rgba(212,169,65,.35);border-radius:16px;padding:12px;background:linear-gradient(180deg,#171325,#120f18)">';
 h+='<div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:900 17px Cairo;color:#fde68a">🔥 الأنظمة المتقدمة</b><div style="font:10px Cairo;color:rgba(255,234,176,.55)">طبقة النخبة — الهاوية، النقوش، المزاد، الطوفان، الروابط، البطولة</div></div><span class="sp-chip" style="border-color:#8b5cf666;color:#d8b4fe">أوفلاين ✓</span></div>';
 h+='<div class="sp-grid3" style="margin-top:9px;grid-template-columns:repeat(6,1fr)">'
  +advStatTile("🕳️",s.abyss.best,"أبعد عمق")
  +advStatTile("⚡",rs.count,"نقش محفور")
  +advStatTile("🏛️",s.auction.wins||0,"مزادات مكسوبة")
  +advStatTile("🌊",s.tide.meter+"/60","عهد الطوفان")
  +advStatTile("🫧",s.tide.pearls||0,"لآلئ")
  +advStatTile("🏆",s.trial.won||0,"بطولات اليوم")
  +'</div>';
 h+='<div class="sp-tabs" style="margin:10px 0 0">'+ADV_TABS.map(function(t){return '<button class="sp-tab'+(s.advTab===t[0]?" on":"")+'" data-sp="adv-tab" data-arg="'+t[0]+'">'+t[1]+'</button>'}).join("")+'</div>';
 h+='<div style="margin-top:9px">';
 if(s.advTab==="abyss")h+=renderAdvAbyss();
 else if(s.advTab==="runes")h+=renderAdvRunes();
 else if(s.advTab==="auc")h+=renderAdvAuc();
 else if(s.advTab==="tide")h+=renderAdvTide();
 else if(s.advTab==="bonds")h+=renderAdvBonds();
 else h+=renderAdvTrial();
 h+='</div></div>';
 return h
}
function paintAdv(){var h=document.getElementById("sp-adv-host");if(h&&h.isConnected)h.innerHTML=renderAdvTab()}
window.SOADVTAB=renderAdvTab;
ACT["adv-tab"]=function(b,arg){st().advTab=arg;save();paintAdv()};
/* ===== 1) الهاوية اللانهائية ===== */
function abyssLevel(d){var bs=(G()&&G().campaign?G().campaign.bestStage:0)||0;return Math.max(2,Math.round(bs*.6)+Math.round(2.2*d))}
function abyssEnemies(d,curse){
 var L=abyssLevel(d),n=d<5?2:3,out=[];
 for(var i=0;i<n;i++){
  var role=["tank","dps","support","control"][Math.floor(Math.random()*4)];
  out.push(mkEnemy(ABYSS_MOBS[Math.floor(Math.random()*ABYSS_MOBS.length)],"abyss",role,L,{hpM:1+.10*d,atkM:1+.055*d,defM:1+.02*d}))
 }
 if(d%10===0)out[out.length-1]=mkEnemy("حاجز الهاوية — العمق "+d,"abyss","tank",L+2,{isBoss:!0,hpM:2.4+.10*d,atkM:1.18+.05*d});
 if(curse==="dark")out.forEach(function(e){e.hpM*=1.25});
 if(curse==="spite")out.forEach(function(e){e.atkM*=1.2});
 return out
}
function renderAdvAbyss(){
 var s=st(),g=G(),d=s.abyss.depth||0;
 var h='<div class="sp-card" style="border-color:#8b5cf655;background:rgba(139,92,246,.05)"><div style="display:flex;justify-content:space-between;align-items:center"><div><b class="sp-h" style="color:#d8b4fe">🕳️ الهاوية اللانهائية</b><div class="sp-sub">عمق لا نهائي — كل طابق أعمق وأشرس، وكل 5 طوابق لعنة جديدة تلاحقك حتى تنصر نفسها</div></div></div>';
 h+='<div class="sp-row"><span class="sp-chip">العمق القادم: '+(d+1)+'</span><span class="sp-chip">أبعد عمق: '+s.abyss.best+'</span><span class="sp-chip">محاولات: '+s.abyss.runs+'</span></div>';
 if((d+1)%5===0&&d>0){
  var c=ABYSS_CURSES[Math.floor(Math.random()*ABYSS_CURSES.length)];
  h+='<div style="margin-top:8px;border:1px dashed rgba(224,82,82,.45);border-radius:12px;padding:8px;background:rgba(224,82,82,.06)"><b style="font:800 11px Cairo;color:#fca5a5">☠ لعنة الطابق '+(d+1)+': '+c.n+'</b><div style="font:9.5px Cairo;color:rgba(252,165,165,.75);margin-top:3px">'+c.d+' — تُختم على المعركة القادمة فقط.</div></div>';
  s.abyss.pendCurse=c.id;
 } else s.abyss.pendCurse=null;
 h+=enemyRowHTML(abyssEnemies(d+1,s.abyss.pendCurse));
 var rw={gold:900+130*(d+1),xp:700+110*(d+1),mats:4+Math.min(20,d+1),gems:((d+1)%5===0?30:0),tokens:1};
 h+='<div class="sp-row" style="justify-content:center;margin-top:6px"><span class="sp-chip">🪙 '+rw.gold.toLocaleString("en-US")+'</span><span class="sp-chip">📜 '+rw.xp.toLocaleString("en-US")+'</span><span class="sp-chip">⚙️ '+rw.mats+'</span>'+(rw.gems?'<span class="sp-chip">💎 '+rw.gems+'</span>':"")+'<span class="sp-chip">🎯 توكن 1</span></div>';
 h+='<div style="margin-top:8px"><button class="sp-btn purple" style="width:100%;padding:11px" data-sp="adv-abyss-open">🕳️ اغمر أعمق — الطابق '+(d+1)+'</button></div>';
 h+='<div style="font:9px Cairo;color:rgba(255,234,176,.45);margin-top:6px">اللعنة تُفعّل عند فتح المعركة وتزول بمجرد انتهائها. كل فوز يرفع «عهد الطوفان» +2.</div></div>';
 return h
}
ACT["adv-abyss-open"]=function(){
 var s=st(),d=s.abyss.depth||0,curse=s.abyss.pendCurse||null;
 var ens=abyssEnemies(d+1,curse);
 advPend={kind:"abyss",enemies:ens,curse:curse,depth:d+1};
 var cDef=curse?ABYSS_CURSES.filter(function(x){return x.id===curse})[0]:null;
 var h='<div style="text-align:center"><div style="font-size:40px">🕳️</div><b style="font:900 16px Cairo;color:#d8b4fe">الهاوية — العمق '+(d+1)+'</b>'
  +'<div style="font:10.5px Cairo;color:rgba(255,234,176,.65);margin:5px 0">أفضل عمق: '+s.abyss.best+' • مستوى الأعداء: '+abyssLevel(d+1)+'</div>'
  +enemyRowHTML(ens)
  +(cDef?'<div style="margin-top:6px;border:1px dashed rgba(224,82,82,.45);border-radius:12px;padding:8px;background:rgba(224,82,82,.06)"><b style="font:800 11px Cairo;color:#fca5a5">☠ لعنة نشطة: '+cDef.n+'</b><div style="font:9.5px Cairo;color:rgba(252,165,165,.75)">'+cDef.d+'</div></div>':"")
  +'<div style="margin-top:10px"><button class="sp-btn purple" style="width:100%;padding:11px" data-sp="adv-abyss-go">⚔️ انزل إلى العمق '+(d+1)+'</button><button class="sp-btn" style="width:100%;margin-top:7px" data-sp="sp-close">تراجع</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["adv-abyss-go"]=function(){
 var p=advPend;if(!p){toast("حضّر المعركة أولًا");return}
 var s=st();
 s.abyss.curse=p.curse;s.curseFlag=(p.curse==="slow"||p.curse==="weaken"||p.curse==="brittle")?p.curse:null;save();
 var dep=p.depth;
 advLaunch({enemies:p.enemies,timeLimit:150,rewards:function(){var s2=st();var d2=s2.abyss.depth+1;return{gold:900+130*d2,xp:700+110*d2,mats:4+Math.min(20,d2),gems:((d2)%5===0?30:0),tokens:1}}},"الهاوية — العمق "+dep,function(vic){
  var s2=st();
  if(vic){s2.abyss.depth=dep;s2.abyss.best=Math.max(s2.abyss.best,dep);s2.abyss.runs++;save();toast("🕳️ عبورت العمق "+dep+"! العدّ لا يتوقف")}
  s2.abyss.curse=null;s2.curseFlag=null;s2.abyss.pendCurse=null;save();paintAdv()
 });
 closeModal()
};
/* ===== 2) نقوش الرمال ===== */
function gearRunesOf(heroId,slot){
 var g=G();if(!g)return[];
 var hr=g.heroes[heroId];if(!hr||!hr.gear||!hr.gear[slot])return[];
 return hr.gear[slot].runes||[]
}
function renderAdvRunes(){
 var g=G();
 var h='<div class="sp-card"><div class="sp-h">⚡ نقوش الرمال</div><div class="sp-sub">احفر نقوشًا على تجهيز أبطال فريقك — أثر حقيقي في كل معارك اللعبة (الحملة والأنظمة). كل قطعة تتسع لنقش أو اثنين حسب الشطب.</div>';
 var tm=(g&&g.team)||[];
 if(!tm.length)h+='<div class="sp-sub">فريقك فارغ — استحضر أبطالًا أولًا.</div>';
 h+='<div class="sp-grid">'+tm.map(function(id){return '<button class="sp-btn" style="text-align:right;padding:9px" data-sp="adv-rune-hero" data-arg="'+id+'"><b>'+heroName(id)+'</b><div style="font:9px Cairo;opacity:.65">فحص النقوش والنقش الجديد</div></button>'}).join("")+'</div>';
 h+='<div style="margin-top:8px;border-top:1px dashed rgba(212,169,65,.22);padding-top:7px"><div style="font:800 10.5px Cairo;color:#fde68a">فهرس النقوش</div><div style="display:grid;grid-template-columns:repeat(2,1fr);gap:5px;margin-top:5px">'
  +Object.keys(RN).map(function(k){var r=RN[k];return '<div style="border:1px solid rgba(212,169,65,.22);border-radius:9px;padding:6px;background:rgba(0,0,0,.25)"><b style="font:800 10px Cairo;color:#ffe9a3">'+r.i+' '+r.n+'</b><div style="font:9px Cairo;opacity:.6">'+r.d+'</div></div>'}).join("")
  +'</div></div></div>';
 return h
}
ACT["adv-rune-hero"]=function(b,arg){
 var id=arg,g=G(),hr=g&&g.heroes[id];
 if(!hr){toast("البطل غير موجود");return}
 var slots=Object.keys(hr.gear||{});
 if(!slots.length){openModal('<div style="text-align:center"><div style="font-size:38px">🪨</div><b style="font:900 14px Cairo;color:#fde68a">'+esc(heroName(id))+' بلا تجهيز</b><div style="font:11px Cairo;opacity:.7;margin:6px 0">جهّز له قطعًا من الحدادة أولًا — النقوش تُحفر على القطع المجهّزة فقط.</div><button class="sp-btn gold" style="width:100%;margin-top:8px;padding:10px" data-sp="sp-close">فهمت</button></div>',{dark:!0});return}
 var h='<div style="text-align:center"><b style="font:900 15px Cairo;color:#fde68a">⚡ نقوش '+esc(heroName(id))+'</b><div style="font:10px Cairo;opacity:.6;margin:3px 0 8px">اختر قطعة مجهّزة لفحص نقوشها</div><div style="display:grid;gap:7px">';
 slots.forEach(function(sl){
  var it=hr.gear[sl],rn=it.runes||[],cap=(it.tier>=6?2:1);
  var slD=SLOTS.filter(function(x){return x[0]===sl})[0]||["",sl,"⚙️"];
  var rnTxt=rn.length?rn.map(function(r){var d=RN[r.t];return (d?d.i+" "+d.n:"؟")+" م"+(r.lvl||1)}).join(" • "):"بلا نقش";
  h+='<button class="sp-btn" style="text-align:right;padding:9px" data-sp="adv-rune-slot" data-arg="'+id+","+sl+'"><div style="display:flex;justify-content:space-between;align-items:center"><b>'+slD[2]+' '+slD[1]+' '+TNm(it.tier)+'</b><span class="sp-chip" style="font-size:8.5px">'+rn.length+'/'+cap+' نقش</span></div><div style="font:9px Cairo;opacity:.65;margin-top:3px">'+rnTxt+'</div></button>'
 });
 h+='</div><button class="sp-btn" style="width:100%;margin-top:9px" data-sp="sp-close">رجوع</button></div>';
 openModal(h,{dark:!0})
};
ACT["adv-rune-slot"]=function(b,arg){
 var parts=String(arg).split(","),id=parts[0],sl=parts[1],g=G(),hr=g&&g.heroes[id];
 if(!hr||!hr.gear||!hr.gear[sl])return;
 var it=hr.gear[sl],rn=it.runes||[],cap=(it.tier>=6?2:1);
 var slD=SLOTS.filter(function(x){return x[0]===sl})[0]||["",sl,"⚙️"];
 var res=g.resources||{};
 var h='<div style="text-align:center"><div style="font-size:34px">'+slD[2]+'</div><b style="font:900 14px Cairo;color:#fde68a">'+slD[1]+' '+TNm(it.tier)+' — نقوشها</b>';
 if(rn.length)h+='<div style="font:10px Cairo;opacity:.7;margin:4px 0">'+rn.map(function(r){var d=RN[r.t];return (d?d.i+" "+d.n:"؟")+" م"+(r.lvl||1)}).join(" • ")+'</div>';
 else h+='<div style="font:10px Cairo;opacity:.6;margin:4px 0">لا نقوش — السعة '+cap+'</div>';
 h+='<div style="display:grid;gap:6px;margin-top:8px">';
 Object.keys(RN).forEach(function(k){
  var r=RN[k],ex=rn.filter(function(x){return x.t===k})[0];
  var cost=ex?RUNE_COST[Math.min(2,ex.lvl||1)]:RUNE_COST[0];
  var act=ex?("ترقية إلى م"+((ex.lvl||1)+1)):("نقش م1");
  var blocked=ex&&((ex.lvl||1)>=3);
  var blockedTier=(!ex)&&rn.length>=cap;
  var ok=!blocked&&!blockedTier&&res.gold>=cost.gold&&res.mats>=cost.mats;
  h+='<button class="sp-btn'+(ok?" gold":"")+'" style="text-align:right;padding:8px" '+(ok?"":"disabled")+' data-sp="adv-rune-do" data-arg="'+id+","+sl+","+k+'"><div style="display:flex;justify-content:space-between;align-items:center"><span><b>'+r.i+' '+r.n+'</b> <span style="font:9px Cairo;opacity:.6">'+r.d+'</span></span><span style="font:9px Cairo;white-space:nowrap">'+(blocked?"أقصى مستوى":blockedTier?"السعة ممتلئة":"🪙"+cost.gold+" + ⚙️"+cost.mats+" — "+act)+'</span></div></button>'
 });
 h+='</div><button class="sp-btn" style="width:100%;margin-top:9px" data-sp="adv-rune-hero" data-arg="'+id+'">رجوع للقطع</button></div>';
 openModal(h,{dark:!0})
};
ACT["adv-rune-do"]=function(b,arg){
 var parts=String(arg).split(","),id=parts[0],sl=parts[1],ty=parts[2],g=G(),r=RN[ty];
 if(!g||!r)return;
 var hr=g.heroes[id];if(!hr||!hr.gear||!hr.gear[sl])return;
 var it=hr.gear[sl],rn=it.runes||[],cap=(it.tier>=6?2:1);
 var ex=rn.filter(function(x){return x.t===ty})[0];
 if(ex&&(ex.lvl||1)>=3){toast("هذا النقش بلغ أقصى مستوى");return}
 if(!ex&&rn.length>=cap){toast("سعة القطعة ممتلئة — استبدل عبر نقش نوع جديد على قطعة أخرى");return}
 var cost=ex?RUNE_COST[Math.min(2,ex.lvl||1)]:RUNE_COST[0];
 if(g.resources.gold<cost.gold||g.resources.mats<cost.mats){toast("الموارد لا تكفي");return}
 addRes({gold:-cost.gold,mats:-cost.mats});
 SET(function(s){
  var it2=s.heroes[id].gear[sl];
  if(!it2.runes)it2.runes=[];
  var ex2=it2.runes.filter(function(x){return x.t===ty})[0];
  if(ex2)ex2.lvl=(ex2.lvl||1)+1;
  else it2.runes.push({t:ty,lvl:1});
  return{}
 });
 toast(r.i+" حُفر "+r.n+(ex?" — ترقّى إلى م"+((ex.lvl||1)+1):" م1")+" — أثره في كل المعارك");
 closeModal();setTimeout(function(){ACT["adv-rune-hero"](null,id)},80);paintAdv();evalAch()
};
/* ===== 3) مزاد الأساطير ===== */
function aucBase(item){return Math.round((1500*item.tier+900*(item.stars||0))*(1+.15*Math.min(10,st().auction.wins||0)))}
function aucNew(){
 var s=st();
 var slot=SLOTS[Math.floor(Math.random()*SLOTS.length)][0];
 var tier=5+Math.floor(Math.random()*3);
 var stars=Math.random()<.3?2:(Math.random()<.6?1:0);
 s.auction={item:{slot:slot,tier:tier,stars:stars,lore:AUC_LORE[Math.floor(Math.random()*AUC_LORE.length)]},price:0,heat:0,stage:"open",rival:Math.floor(Math.random()*RIVALS.length)};
 s.auction.price=aucBase(s.auction.item);
 save()
}
function renderAdvAuc(){
 var s=st(),a=s.auction,g=G();
 var h='<div class="sp-card" style="border-color:#f0c75e44"><div class="sp-h">🏛️ مزاد الأساطير</div><div class="sp-sub">قطع أسطورية تُطرح هنا — زايد ضد خصوم أذكياء: كل مزايدة ترفع الحرارة، وقد ينهار الخصم ويُسأم… أو يرتفع السعر عليك. تدفع فقط عند الفوز.</div>';
 if(!a||a.stage!=="open"||!a.item){
  if(a&&a.stage==="won"&&a.item)h+='<div style="text-align:center;padding:8px;border:1px dashed rgba(16,185,129,.4);border-radius:12px;background:rgba(16,185,129,.06)"><b style="color:#86efac;font:800 11.5px Cairo">🏆 كسبت '+esc(pieceName(a.item))+' بسعر 🪙'+a.price.toLocaleString("en-US")+' — القطعة في المخزن</b></div>';
  if(a&&a.stage==="closed")h+='<div style="text-align:center;padding:8px;border:1px dashed rgba(212,169,65,.3);border-radius:12px"><b style="font:800 11px Cairo;color:#fde68a">انسحبت — القطعة ذهبت لخصمك</b></div>';
  h+='<div style="margin-top:8px"><button class="sp-btn gold" style="width:100%;padding:11px" data-sp="adv-auc-open">🔐 افتح مزادًا جديدًا</button></div>';
  h+='<div class="sp-row" style="margin-top:6px"><span class="sp-chip">مزادات مكسوبة: '+(s.auction.wins||0)+'</span></div></div>';
  return h
 }
 var it=a.item,riv=RIVALS[a.rival],slD=SLOTS.filter(function(x){return x[0]===it.slot})[0]||["",it.slot,"⚙️"];
 var afford=g&&g.resources.gold>=a.price;
 var heatP=Math.min(100,a.heat*14);
 h+='<div style="border:1px solid rgba(240,199,94,.4);border-radius:13px;padding:10px;background:rgba(0,0,0,.3);margin-top:7px"><div style="display:flex;justify-content:space-between;align-items:center"><div><b style="font:900 13px Cairo;color:#ffedb0">'+slD[2]+' '+esc(pieceName(it))+'</b><div style="font:9px Cairo;color:rgba(255,234,176,.55);margin-top:2px">'+esc(it.lore)+'</div></div><span class="sp-chip">'+TNm(it.tier)+(it.stars?"+"+it.stars:"")+'</span></div>';
 h+='<div style="margin-top:7px"><div style="display:flex;justify-content:space-between;font:800 10px Cairo;color:#fde68a"><span>السعر الحالي: 🪙 '+a.price.toLocaleString("en-US")+'</span><span>الخصم: '+riv.n+'</span></div>';
 h+='<div class="sp-bar" style="margin-top:5px"><i style="width:'+heatP+'%;background:linear-gradient(90deg,#e05252,#f0c75e)"></i></div><div style="font:9px Cairo;opacity:.55;margin-top:3px">حرارة القاعة: '+Math.min(100,a.heat*14)+'% — كلما ارتفعت اقترب انهيار الخصم</div></div>';
 h+='<div class="sp-row" style="margin-top:8px"><button class="sp-btn gold" style="flex:1;padding:10px" '+(afford?"":"disabled")+' data-sp="adv-auc-bid">🔨 مزايدة 🪙 '+a.price.toLocaleString("en-US")+(afford?"":" — ذهبك لا يكفي")+'</button><button class="sp-btn red" style="padding:10px" data-sp="adv-auc-withdraw">انسحب</button></div>';
 h+='<div class="sp-row" style="margin-top:6px"><span class="sp-chip">ذهبك: 🪙 '+((g&&g.resources.gold)||0).toLocaleString("en-US")+'</span><span class="sp-chip">مزادات مكسوبة: '+(s.auction.wins||0)+'</span></div></div></div>';
 return h
}
ACT["adv-auc-open"]=function(){aucNew();toast("🔐 طُرحت قطعة جديدة في المزاد");paintAdv()};
ACT["adv-auc-bid"]=function(){
 var s=st(),a=s.auction,g=G();
 if(!a||a.stage!=="open")return;
 if(g.resources.gold<a.price){toast("ذهبك لا يكفي للدفع لو فزت الآن");return}
 a.heat++;
 var riv=RIVALS[a.rival];
 var counter=Math.random()<(riv.aggr*(1-.085*a.heat));
 if(counter){
  a.price=Math.ceil(a.price*(1.06+Math.random()*.07));
  save();toast("⚔️ "+riv.n+" رفع السعر! الآن 🪙"+a.price.toLocaleString("en-US"));paintAdv()
 } else {
  var it=a.item;
  SET(function(sx){sx.resources=Object.assign({},sx.resources,{gold:sx.resources.gold-a.price});return{}});
  st().inventory.push({slot:it.slot,tier:it.tier,stars:it.stars||0,src:"مزاد الأساطير"});
  s.auction.stage="won";s.auction.wins=(s.auction.wins||0)+1;save();
  toast("🏆 فزت بالمزاد! "+pieceName(it)+" — دفعت 🪙"+a.price.toLocaleString("en-US"));closeModal();paintAdv();renderPanel();evalAch()
 }
};
ACT["adv-auc-withdraw"]=function(){var s=st();if(!s.auction||s.auction.stage!=="open")return;s.auction.stage="closed";save();toast("🚶 انسحبت — لا تدفع شيئًا");paintAdv()};
/* ===== 4) عهد الطوفان ===== */
function renderAdvTide(){
 var s=st(),t=s.tide,g=G();
 var today=todayStr();
 if(s.tide.last!==today){s.tide.last=today;s.tide.meter=Math.min(60,(s.tide.meter||0)+3);save()}
 var forced=(t.meter||0)>=40,ready=(t.meter||0)>=20;
 var pct=Math.round((t.meter||0)/60*100);
 var h='<div class="sp-card" style="border-color:rgba(224,82,82,.4);background:rgba(224,82,82,.05)"><div class="sp-h" style="color:#fca5a5">🌊 عهد الطوفان</div><div class="sp-sub">كل فوز في الأنظمة المتقدمة يرفع المدّ +2، وكل يوم جديد +3. عند 20 يفتح «مدّ الطوفان» — اصدده لتحصد اللآلئ. إن بلغ 60 دون صدّ… يصير المدّ قسريًا وأشرس، ومكافأته أكبر.</div>';
 h+='<div class="sp-bar" style="height:12px"><i style="width:'+pct+'%;background:linear-gradient(90deg,#2fb8a6,#e05252)"></i></div>';
 h+='<div class="sp-row" style="margin-top:6px"><span class="sp-chip">المدّ: '+t.meter+'/60</span><span class="sp-chip">مدّات صُدّت: '+(t.surges||0)+'</span><span class="sp-chip">🫧 لآلئ: '+(t.pearls||0)+'</span></div>';
 h+='<div style="margin-top:8px"><button class="sp-btn red" style="width:100%;padding:11px" '+(ready?"":"disabled")+' data-sp="adv-surge-open">'+(forced?"☠️ مدّ قسري — الطوفان يزحف! (مكافأة مضاعفة)":ready?"🌊 صدّ مدّ الطوفان — استعدادية جاهزة":"المدّ لا يزال يتجمّع… واصل الفوز")+'</button></div>';
 h+='<div style="margin-top:9px;border-top:1px dashed rgba(212,169,65,.22);padding-top:7px"><div style="display:flex;justify-content:space-between;align-items:center"><b style="font:800 11px Cairo;color:#fde68a">🫧 سوق اللآلئ</b><span class="sp-chip">رصيدك: '+(t.pearls||0)+'</span></div>';
 h+='<div class="sp-grid" style="margin-top:6px">'
  +'<button class="sp-btn" style="text-align:right" data-sp="adv-pearl" data-arg="gear7"><b>⚔️ قطعة أسطوري أسطورية</b><div style="font:9px Cairo;opacity:.6">30 لؤلؤة — تُضاف للمخزن</div></button>'
  +'<button class="sp-btn" style="text-align:right" data-sp="adv-pearl" data-arg="shards"><b>🔷 300 شظية</b><div style="font:9px Cairo;opacity:.6">12 لؤلؤة</div></button>'
  +'<button class="sp-btn" style="text-align:right" data-sp="adv-pearl" data-arg="tickets"><b>🎫 5 تذاكر بطولة</b><div style="font:9px Cairo;opacity:.6">8 لآلئ</div></button>'
  +'<button class="sp-btn" style="text-align:right" data-sp="adv-pearl" data-arg="mats"><b>⚙️ 40 خامة</b><div style="font:9px Cairo;opacity:.6">5 لآلئ</div></button>'
  +'</div></div></div>';
 return h
}
ACT["adv-surge-open"]=function(){
 var s=st(),t=s.tide,g=G();if((t.meter||0)<20)return;
 var forced=(t.meter||0)>=40;
 var L=Math.max(4,Math.round(((g&&g.campaign?g.campaign.bestStage:0)||0)*.85)+6);
 var ens=[
  mkEnemy("طاغية المدّ الرمادي","abyss","tank",L,{isBoss:!0,hpM:forced?3.0:2.4,atkM:1.35}),
  mkEnemy("قادم من تحت","abyss","dps",L,{hpM:forced?2.2:1.9,atkM:1.3}),
  mkEnemy("همس رمادي","abyss","control",L,{hpM:forced?2.0:1.7,atkM:1.25})];
 advPend={kind:"surge",enemies:ens,forced:forced};
 var h='<div style="text-align:center"><div style="font-size:40px">'+(forced?"☠️":"🌊")+'</div><b style="font:900 16px Cairo;color:#fca5a5">'+(forced?"الطوفان يزحف — مدّ قسري":"صدّ مدّ الطوفان")+'</b>'
  +'<div style="font:10.5px Cairo;color:rgba(255,234,176,.65);margin:5px 0">'+(forced?"المدّ بلغ الذروة — لا مهرب. اهزم الموجة وسترتاح الرمال… وتضاعف اللآلئ.":"موجة غزيرية تقترب من السد. اهزمها لتجمع لآلئ الطوفان.")+'</div>'
  +enemyRowHTML(ens)
  +'<div class="sp-row" style="justify-content:center;margin-top:6px"><span class="sp-chip">🪙 6,000</span><span class="sp-chip">📜 5,200</span><span class="sp-chip">⚙️ 20</span><span class="sp-chip">💎 40</span><span class="sp-chip">🫧 '+(forced?5:3)+' لآلئ</span></div>'
  +'<div style="margin-top:10px"><button class="sp-btn red" style="width:100%;padding:11px" data-sp="adv-surge-go">⚔️ واجه الموجة</button><button class="sp-btn" style="width:100%;margin-top:7px" data-sp="sp-close">ليس الآن</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["adv-surge-go"]=function(){
 var p=advPend;if(!p||p.kind!=="surge")return;
 var s=st();
 advLaunch({enemies:p.enemies,timeLimit:180,rewards:function(){return{gold:6000,xp:5200,mats:20,gems:40,tokens:2}}},"عهد الطوفان — صدّ المدّ",function(vic){
  var s2=st();
  if(vic){
   var pearls=p.forced?5:3;
   s2.tide.pearls=(s2.tide.pearls||0)+pearls;s2.tide.meter=0;s2.tide.surges=(s2.tide.surges||0)+1;
   save();toast("🌊 صُدّ المدّ! 🫧 +"+pearls+" لآلئ الطوفان")
  } else {save();toast("المدّ ما زال يزحف — عد أقوى")}
  paintAdv()
 });
 closeModal()
};
ACT["adv-pearl"]=function(b,arg){
 var s=st(),t=s.tide;
 var cost={gear7:30,shards:12,tickets:8,mats:5}[arg];
 if(!cost)return;
 if((t.pearls||0)<cost){toast("لآلئك لا تكفي — صدّ مدًّا جديدًا");return}
 t.pearls-=cost;
 if(arg==="gear7"){var sl=SLOTS[Math.floor(Math.random()*SLOTS.length)][0];st().inventory.push({slot:sl,tier:7,stars:0,src:"لؤلؤ الطوفان"});toast("🫧 قطعة أسطوري أسطورية وصلت المخزن!")}
 else if(arg==="shards"){addRes({shards:300});toast("🔷 +300 شظية")}
 else if(arg==="tickets"){addRes({tickets:5});toast("🎫 +5 تذاكر بطولة")}
 else if(arg==="mats"){addRes({mats:40});toast("⚙️ +40 خامة")}
 save();paintAdv();renderPanel();evalAch()
};
/* ===== 5) روابط الأبطال ===== */
function renderAdvBonds(){
 var g=G(),h='<div class="sp-card"><div class="sp-h">🤝 روابط الأبطال</div><div class="sp-sub">أزيلات متوارثة من حكايات الرمال — إن اجتمعا في تشكيلتك الخماسية يعطيان بعضهما أثرًا حقيقيًا في كل المعارك، بدون أي تكلفة.</div>';
 if(!g){h+='</div>';return h}
 var tm=g.team||[],owned=Object.keys(g.heroes||{});
 BONDS.forEach(function(bd){
  var hasA=owned.indexOf(bd.a)>=0,hasB=owned.indexOf(bd.b)>=0;
  var active=tm.indexOf(bd.a)>=0&&tm.indexOf(bd.b)>=0;
  h+='<div style="display:flex;justify-content:space-between;align-items:center;border:1px solid '+(active?"rgba(16,185,129,.45)":"rgba(212,169,65,.22)")+';border-radius:12px;padding:8px;margin-top:6px;background:'+(active?"rgba(16,185,129,.06)":"rgba(0,0,0,.25)")+'"><div><b style="font:800 11px Cairo;color:#fde68a">'+heroName(bd.a)+' × '+heroName(bd.b)+'</b><div style="font:9px Cairo;opacity:.6;margin-top:2px">「'+bd.n+'」 '+bd.d+'</div></div>'
   +(active?'<span class="sp-chip" style="border-color:#05966966;color:#86efac">نشِط ✓</span>':(hasA&&hasB?'<span class="sp-chip" style="border-color:#f0c75e66">ضع الثاني في الفريق</span>':'<span class="sp-chip">مفقود بطل</span>'))+'</div>'
 });
 h+='</div>';
 return h
}
/* ===== 6) البطولة الكبرى ===== */
function trialOfToday(){
 var d=todayStr(),x=0;
 for(var i=0;i<d.length;i++)x=(x*31+d.charCodeAt(i))%9973;
 return TRIALS[x%TRIALS.length]
}
function renderAdvTrial(){
 var s=st(),g=G(),tr=s.trial,t=trialOfToday();
 if(tr.date!==todayStr()){tr.date=todayStr();tr.won=0;tr.tries=0;save()}
 var L=Math.max(4,Math.round(((g&&g.campaign?g.campaign.bestStage:0)||0)*.75)+5);
 var ens=t.build(L);
 var ticks=(g&&g.resources.tickets)||0;
 var h='<div class="sp-card" style="border-color:#f0c75e55;background:rgba(240,199,94,.05)"><div class="sp-h">🏆 البطولة الكبرى — '+t.n+'</div><div class="sp-sub">'+t.rule+'</div>';
 h+=enemyRowHTML(ens);
 var full=!(tr.won>0);
 h+='<div class="sp-row" style="justify-content:center;margin-top:6px"><span class="sp-chip">🎫 تذاكر: '+ticks+'</span><span class="sp-chip">محاولات اليوم: '+(tr.tries||0)+'</span><span class="sp-chip">'+(full?"المكافأة الكاملة":"مكافأة الإعادة 40%")+'</span></div>';
 h+='<div class="sp-row" style="justify-content:center;margin-top:5px"><span class="sp-chip">💎 '+(full?100:40)+'</span><span class="sp-chip">🔷 '+(full?30:12)+'</span><span class="sp-chip">🪙 '+(full?9000:3600).toLocaleString("en-US")+'</span><span class="sp-chip">📚 '+(full?3:1)+'</span><span class="sp-chip">🎯 توكن '+(full?2:1)+'</span></div>';
 h+='<div style="margin-top:8px"><button class="sp-btn gold" style="width:100%;padding:11px" '+(ticks>=1?"":"disabled")+' data-sp="adv-trial-open">🏆 خُض البطولة — تذكرة 1'+(ticks>=1?"":" — لا تذاكر (الزعيم والرحلات تمنحها)")+'</button></div>';
 h+='<div style="font:9px Cairo;color:rgba(255,234,176,.45);margin-top:6px">النظام يتبدل كل يوم — يعاد تحديه بعد منتصف الليل.</div></div>';
 return h
}
ACT["adv-trial-open"]=function(){
 var s=st(),t=trialOfToday(),g=G();
 if(((g&&g.resources.tickets)||0)<1){toast("تحتاج تذكرة واحدة — الزعيم الأسبوعي والرحلات تمنحها");return}
 var L=Math.max(4,Math.round(((g&&g.campaign?g.campaign.bestStage:0)||0)*.75)+5);
 var ens=t.build(L);
 advPend={kind:"trial",enemies:ens,tl:t.tl||150,trial:t};
 var h='<div style="text-align:center"><div style="font-size:40px">🏆</div><b style="font:900 16px Cairo;color:#fde68a">البطولة الكبرى — '+t.n+'</b><div style="font:10.5px Cairo;color:rgba(255,234,176,.65);margin:5px 0">'+t.rule+'</div>'
  +enemyRowHTML(ens)
  +'<div style="font:9.5px Cairo;color:rgba(255,234,176,.5);margin-top:5px">الدخول يستهلك تذكرة 🎫 — حتى لو خسرت.</div>'
  +'<div style="margin-top:10px"><button class="sp-btn gold" style="width:100%;padding:11px" data-sp="adv-trial-go">⚔️ ابدأ التحدي</button><button class="sp-btn" style="width:100%;margin-top:7px" data-sp="sp-close">تراجع</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["adv-trial-go"]=function(){
 var p=advPend;if(!p||p.kind!=="trial")return;
 var s=st(),g=G();
 if(((g&&g.resources.tickets)||0)<1){toast("لا تذاكر");return}
 addRes({tickets:-1});
 s.trial.tries=(s.trial.tries||0)+1;save();
 var full=!(s.trial.won>0);
 advLaunch({enemies:p.enemies,timeLimit:p.tl||150,rewards:function(){return{gems:full?100:40,shards:full?30:12,gold:full?9000:3600,xp:full?4000:1600,books:full?3:1,tokens:full?2:1}}},"البطولة الكبرى — "+p.trial.n,function(vic){
  var s2=st();
  if(vic){s2.trial.won=(s2.trial.won||0)+1;save();toast("🏆 كسرت تحدي اليوم"+(!full&&s2.trial.won>1?" — مكافأة الإعادة":"!"))}
  paintAdv()
 });
 closeModal()
};
/* ===== قاذف موحّد يربط الأنظمة بالطوفان وينظف اللعنات ===== */
function advLaunch(custom,title,onWin){
 var wrap=function(vic){try{if(vic){var s2=st();s2.tide.meter=Math.min(60,(s2.tide.meter||0)+2);save()}}catch(e){}if(onWin)onWin(vic)};
 custom.onWin=wrap;
 launch(custom,title,null,function(){try{var s3=st();s3.curseFlag=null;s3.abyss.curse=null;save()}catch(e){}paintAdv()})
}

/* ============================================================ التركيب على الشاشات ============================================================ */
var spTabs=null,spPanel=null;
var TABS=[["tower","🏰 برج الرمال","tower"],["story","📖 الحكايات",""],["atlas","🗺️ الأطلس",""],["hub","🌍 المركز",""]];
function createTabs(scroll){
 spTabs=document.createElement("div");
 spTabs.className="sp-tabs sp-ui";
 spTabs.innerHTML=TABS.map(function(t){return '<button class="sp-tab '+t[2]+'" data-sp="sp-tab" data-arg="'+t[0]+'">'+t[1]+'</button>'}).join("");
 /* الشريط يوضع في تخطيط الصفحة بين الهيدر والمحتوى ليظل ظاهرًا دائمًا في الحملة */
 spTabs.style.display="none";
 spTabs.addEventListener("click",function(e){
  var b=e.target.closest("button.sp-tab");if(!b)return;
  setActiveTab(b.getAttribute("data-arg"))
 })
}
function createPanel(scroll){
 spPanel=document.createElement("div");
 spPanel.className="sp-panel sp-ui";
 spPanel.style.margin="0 0 8px";
 if(spTabs&&spTabs.isConnected)spTabs.after(spPanel);else scroll.appendChild(spPanel)
}
var openBox=null,headA=null,headB=null;
function mkHead(k,html){var b=document.createElement("button");b.type="button";b.className="sp-boxhead sp-ui";b.innerHTML=html+'<span class="ch">▾</span>';b.addEventListener("click",function(){toggleBox(k)});return b}
function campRoot(){var sc=document.querySelector("main .flex-1.overflow-y-auto");return sc?sc.querySelector(":scope > div.space-y-3"):null}
function ensureLayout(scroll){
 if(!headA||!headA.isConnected){
  headA=mkHead("A",'<span>🏰 أجنحة عالم الرمال<small>برج الرمال • الحكايات • الأطلس • المركز</small></span>');
  scroll.insertBefore(headA,scroll.firstChild)
 }
 if(!spTabs||!spTabs.isConnected){createTabs(scroll);headA.after(spTabs)}
 if(!spPanel||!spPanel.isConnected){spPanel=null;createPanel(scroll)}
 if(!headB||!headB.isConnected){
  headB=mkHead("B",'<span>🗺️ مناطق الحملة<small>حصون الطين • السهول • الواحات • الظلال • الطوفان</small></span>');
  spPanel.after(headB)
 }
}
function applyBoxes(){
 var cr=campRoot();
 if(headA)headA.classList.toggle("open",openBox==="A");
 if(headB)headB.classList.toggle("open",openBox==="B");
 if(spTabs)spTabs.style.display=openBox==="A"?"flex":"none";
 if(spPanel)spPanel.style.display=(openBox==="A"&&activeTab)?"block":"none";
 if(cr)cr.style.display=openBox==="B"?"":"none"
}
function toggleBox(k){
 openBox=(openBox===k)?null:k;
 if(openBox==="A"&&!activeTab)activeTab="tower";
 if(openBox==="A"){if(spTabs)Array.prototype.forEach.call(spTabs.children,function(b,i){b.classList.toggle("on",TABS[i][0]===activeTab)});renderPanel()}
 applyBoxes()
}
function setActiveTab(tab){
 activeTab=tab;if(tab)openBox="A";
 if(spTabs)Array.prototype.forEach.call(spTabs.children,function(b,i){b.classList.toggle("on",TABS[i][0]===tab)});
 if(tab){
  if(!spPanel||!spPanel.isConnected){var sc=(spTabs&&spTabs.isConnected)?spTabs.parentElement:document.querySelector("main .flex-1.overflow-y-auto");if(sc)createPanel(sc)}
  renderPanel();applyBoxes();
  if(spPanel)setTimeout(function(){try{spPanel.scrollIntoView({behavior:"smooth",block:"start"})}catch(e){}},60)
 } else if(spPanel){spPanel.style.display="none"}
}
var forgeSig="";
function paintForge(force,host){var g=G();if(!g)return;var hs=host?[host]:Array.prototype.slice.call(document.querySelectorAll("#sp-forge-host,#sp-summon-forge-host"));var sg=JSON.stringify([st().inventory,st().buildings,st().wingLevel,st().style,st().flags,g.resources]);hs.forEach(function(h){if(!h||!h.isConnected)return;if(!force&&h.getAttribute("data-sg")===sg&&h.innerHTML)return;h.setAttribute("data-sg",sg);h.innerHTML=renderForgePanel()})}
window.__solPaintForge=paintForge;
/* ---------- إسطبل المطيات: تجهيز مطية لكل بطل ---------- */
function mountBonusChips(m){
 var c=[];
 if(m.atk)c.push("⚔️ +"+Math.round(m.atk*100)+"% هجوم");
 if(m.hp)c.push("❤️ +"+Math.round(m.hp*100)+"% صحة");
 if(m.def)c.push("🛡️ +"+Math.round(m.def*100)+"% دفاع");
 return c.map(function(x){return '<span class="sp-chip">'+x+'</span>'}).join(" ")
}
function renderMountsPanel(){
 if(!(window.SOLMNT&&window.SOLMNT.ok))return '<div class="sp-card"><div class="sp-sub">المطيات غير متاحة في هذا الجهاز</div></div>';
 var D=window.SOLMNT.defs;
 var h='<div class="sp-card"><div class="sp-h">🐎 إسطبل المطيات</div><div class="sp-sub">كل بطل يركب مطية ثلاثية الأبعاد تظهر في ساحة القتال وفي صورته. جهّز مطية لكل بطل لتُضاف خصائصها إلى قوته — والعدوّ أيضًا يمتطي مطاياه الظلامية!</div><div class="sp-sub" style="margin-top:7px;color:#e8c76a">محرك Glyph Valley المدمج: دورة حوافر بأربع نقاط تماس، مشي وعدو مضبوطَان، وحركة راكب متزامنة مع المطية.</div></div>';
 h+='<div class="sp-grid">';
 D.forEach(function(m){
  var n=window.SOLMNT.usersOf(m.id).length;
  h+='<button class="sp-btn" style="text-align:right;padding:9px" data-sp="mnt-view" data-arg="'+m.id+'">'
    +'<div style="display:flex;gap:9px;align-items:center"><span style="font-size:26px;filter:drop-shadow(0 2px 4px rgba(0,0,0,.5))">'+m.icon+'</span>'
    +'<div style="min-width:0"><b style="font:900 12px Cairo;color:#fde68a">'+esc(m.name)+'</b>'
    +'<div style="margin:2px 0 0">'+mountBonusChips(m)+'</div>'
    +'<div class="sp-sub" style="margin:3px 0 0">مُجهَّزة لـ '+n+' '+(n===1?"بطل":"أبطال")+'</div></div></div></button>'
 });
 h+='</div>';
 h+='<div class="sp-card"><div class="sp-h">🎲 مطية عشوائية للجميع</div><div class="sp-sub">وزّع مطيات جديدة عشوائيًا على كل الأبطال — لمسة حظ سريعة.</div>'
   +'<div style="margin-top:6px"><button class="sp-btn purple" style="width:100%;padding:9px" data-sp="mnt-random">🎲 لف النرد على كل الأبطال</button></div></div>';
 return h
}
window.__solPaintMounts=function(host){
 try{var h=host||document.getElementById("sp-summon-mounts-host");if(h&&h.isConnected)h.innerHTML=renderMountsPanel()}catch(e){}
};
ACT["mnt-view"]=function(b,arg){
 if(!(window.SOLMNT&&window.SOLMNT.ok))return;
 var m=window.SOLMNT.byId(arg);if(!m)return;
 var h='<div style="text-align:center"><div style="font-size:46px;filter:drop-shadow(0 3px 8px rgba(0,0,0,.6))">'+m.icon+'</div>'
   +'<b style="font:900 16px Cairo;color:#fde68a">'+esc(m.name)+'</b>'
   +'<div class="sp-sub" style="margin:4px auto 6px;max-width:330px">'+esc(m.desc)+'</div>'
   +'<div class="sp-row" style="justify-content:center">'+mountBonusChips(m)+'</div></div>';
 h+='<div class="sp-card" style="margin-top:10px"><div class="sp-h">جهّزها لأي بطل</div>';
 var H=window.__solHeroes||{},cnt=0;
 Object.keys(H).sort(function(a2,b2){
  var ha=(H[a2]&&H[a2].name)||"",hb=(H[b2]&&H[b2].name)||"";
  return ha.localeCompare(hb,"ar");
 }).forEach(function(id){
  if(String(id).indexOf("·")>=0)return;
  var hd=H[id];if(!hd)return;cnt++;
  var cur=window.SOLMNT.currentId(hd.name);
  var curM=window.SOLMNT.byId(cur);
  var isCur=cur===m.id;
  h+='<button class="sp-btn" style="width:100%;text-align:right;padding:8px;margin-top:5px;display:flex;justify-content:space-between;gap:8px;align-items:center" data-sp="mnt-set" data-arg="'+m.id+"|"+esc(hd.name)+'">'
    +'<span style="font:700 11.5px Cairo">'+esc(hd.name)+'</span>'
    +'<b style="font:700 10px Cairo;color:'+(isCur?"#4ade80":"rgba(255,234,176,.55)")+';white-space:nowrap">'+(isCur?"✓ مطيته الحالية":(curM?curM.icon+" "+esc(curM.name):"—"))+'</b></button>'
 });
 if(!cnt)h+='<div class="sp-sub">لا يوجد أبطال بعد</div>';
 h+='</div><button class="sp-btn" style="width:100%;margin-top:9px" data-sp="mnt-close">رجوع</button>';
 openModal(h,{dark:!0})
};
ACT["mnt-set"]=function(b,arg){
 var p=String(arg||"").split("|");if(p.length<2)return;
 if(window.SOLMNT.set(p.slice(1).join("|"),p[0])){
  toast("🐎 تم تجهيز المطية — ستظهر فورًا في المعركة القادمة");
  closeModal();
  if(window.__solPaintMounts)window.__solPaintMounts();
  renderPanel();
 }
};
ACT["mnt-close"]=function(){closeModal()};
ACT["mnt-random"]=function(){
 if(!(window.SOLMNT&&window.SOLMNT.ok))return;
 var H=window.__solHeroes||{},D=window.SOLMNT.defs,ch=0;
 Object.keys(H).forEach(function(id){
  if(String(id).indexOf("·")>=0)return;
  var hd=H[id];if(!hd)return;
  window.SOLMNT.set(hd.name,D[Math.floor(Math.random()*D.length)].id);ch++
 });
 toast("🎲 وُزّعت مطيات جديدة على "+ch+" بطلًا");
 if(window.__solPaintMounts)window.__solPaintMounts();
 renderPanel()
};
function renderPanel(){
 paintForge(true);
 if(!spPanel||!activeTab)return;
 var html="";
 if(activeTab==="tower")html=renderTowerPanel((G()&&G().modes?G().modes.tower:0)||0);
 else if(activeTab==="story")html=renderStoryTab();
 else if(activeTab==="atlas")html=renderAtlasPanel();
 else if(activeTab==="hub")html=renderHubPanel();
 spPanel.innerHTML=html;
 spPanel.style.display="block"
}
var modalName=null;
function openModalNamed(html,opts,name){modalName=name||null;openModal(html,opts)}
function refreshOpen(){
 if(modalOpen()&&modalName){
  if(modalName==="bestiary")renderBestiary();
  else if(modalName==="ach")ACT["open-ach"]();
  else if(modalName==="city")ACT["open-city"]();
  else if(modalName==="camp")ACT["open-camp"]();
 }
 renderPanel()
}
ACT["sp-tab"]=function(b,arg){setActiveTab(arg)};
ACT["noop"]=function(){};
var mountTick=0;
function mount(){
 var g=G();if(!g)return;
 try{ensureBodyNodes()}catch(e){}
 try{paintForge()}catch(e){}
 if((mountTick++%8)===0){try{evalAch()}catch(e){}}
 var scroll=document.querySelector("main .flex-1.overflow-y-auto");
 if(!scroll)return;
 if(g.screen==="campaign"){
  ensureLayout(scroll);
  if(activeTab)Array.prototype.forEach.call(spTabs.children,function(b,i){b.classList.toggle("on",TABS[i][0]===activeTab)});
  if(openBox==="A"&&activeTab)renderPanel();
  applyBoxes();
  if(headA)headA.style.display="";if(headB)headB.style.display="";
 } else {
  if(spTabs)spTabs.style.display="none";
  if(spPanel)spPanel.style.display="none";
  if(headA)headA.style.display="none";if(headB)headB.style.display="none";
 }
 if(g.screen==="bag"){
  if(!spBag||!spBag.isConnected){spBag=document.createElement("div");spBag.className="sp-ui";spBag.style.cssText="padding:8px 10px;height:100%;box-sizing:border-box;flex-direction:column;overflow:hidden";scroll.insertBefore(spBag,scroll.firstChild);bagSig=""}
  spBag.style.display="flex";try{var nv=document.querySelector('nav[aria-label]'),hh=window.innerHeight-scroll.getBoundingClientRect().top-(nv?nv.offsetHeight:56);if(hh>200)spBag.style.height=hh+"px"}catch(e){}
  var bsg=bagSignature();if(bsg!==bagSig){bagSig=bsg;spBag.innerHTML=renderBag()}
 } else if(spBag)spBag.style.display="none";
}
/* إخفاء اللوحة عند الرجوع لتبويب منطقة أصلي */
document.addEventListener("click",function(e){
 var scroll=document.querySelector("main .flex-1.overflow-y-auto");
 if(!scroll||!spPanel)return;
 var btn=e.target.closest("button");
 if(!btn)return;
 var cRoot=scroll.querySelector(":scope > div.space-y-3");
 if(!1&&cRoot&&cRoot.contains(btn)&&btn.parentElement===cRoot.firstElementChild){
  activeTab=null;
  if(spPanel)spPanel.style.display="none";
  if(spTabs)Array.prototype.forEach.call(spTabs.children,function(b){b.classList.remove("on")})
 }
},!0);

/* أزرار data-sol لقائمة «المزيد» في اللعبة الأصلية */
var solBtns=[];
function mkDataSol(k,label,fn){
 var b=document.createElement("button");
 b.type="button";b.setAttribute("data-sol",k);b.style.display="none";
 b.textContent=label;b.onclick=fn;
 document.body.appendChild(b);solBtns.push(b);return b
}
function ensureBodyNodes(){
 try{solBtns.forEach(function(b){if(b&&!b.isConnected)document.body.appendChild(b)})}catch(e){}
 try{ensureModal()}catch(e){}
}
mkDataSol("ach","إنجازاتك: 0 — ومكافآتها فورية",function(){ACT["open-ach"]()});
mkDataSol("gift","عجلة الحظ مجانية كل يوم",function(){ACT["open-gift"]()});
mkDataSol("login","سلسلة حضورك: 0 يوم — ادّعي مكافأة اليوم",function(){ACT["open-login"]()});
mkDataSol("loot","آخر ما ربحته من المعارك",function(){ACT["open-loot"]()});

/* ==================== الحقيبة ==================== */
window.__solPlusBag=true;
var spBag=null,bagCat="gear",bagSlot="all",bagSig="";
window.__solPlusLoot=function(t){
 try{
  if(!t)return;
  var s=st();if(!s.loot)s.loot=[];
  var e={ts:Date.now()},any=false;
  ["gems","gold","xp","shards","mats","tickets"].forEach(function(k){if(t[k]){e[k]=t[k];any=true}});
  if(t.gear&&t.gear.length){
   e.gear=t.gear.map(function(g){return{slot:g.slot,tier:g.tier}});
   t.gear.forEach(function(g){s.inventory.push({slot:g.slot,tier:g.tier,stars:0,src:"غنيمة الوحوش"})});
   any=true
  }
  if(any){s.loot.unshift(e);s.loot=s.loot.slice(0,40);save()}
 }catch(x){}
};
function bagTile(icon,name,val){return '<div style="text-align:center;padding:9px 4px;border:1px solid rgba(212,169,65,.25);border-radius:12px;background:rgba(0,0,0,.28)"><div style="font-size:20px">'+icon+'</div><div style="font:900 14px Cairo;color:#fde68a">'+val+'</div><div style="font:9px Cairo;color:rgba(255,234,176,.6)">'+name+'</div></div>'}
function bagHeroName(id){var d=window.__solHeroes&&window.__solHeroes[id];return d?d.name:id}
function bagTime(ts){try{return new Date(ts).toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"})}catch(e){return""}}
var bagHero=null,bagDis=!1,bagDD=!1;
var TIERC={1:"#9aa3ad",2:"#4ade80",3:"#38bdf8",4:"#a855f7",5:"#d946ef",6:"#f59e0b",7:"#ef4444"};
var BAG_L=["helmet","necklace","shoulder","cloak","armor","belt","gloves","bracer"],BAG_R=["talisman","trinket","relic","legs","boots","ring","ring2","wing"],BAG_B=["weapon","weapon2"];
var PSTAT={weapon:{atk:.07},armor:{def:.09,hp:.05},talisman:{hp:.04,spd:3},helmet:{hp:.06,def:.04},gloves:{atk:.04,spd:1.5},boots:{spd:3.5,hp:.03},ring:{atk:.05,hp:.02},wing:{atk:.03,def:.03,spd:2.5},shoulder:{def:.05,hp:.03},belt:{hp:.05,def:.02},legs:{def:.05,hp:.03},necklace:{atk:.03,hp:.03},ring2:{atk:.04,spd:1},bracer:{def:.03,spd:1.5},cloak:{hp:.03,spd:2},trinket:{atk:.03,spd:2},relic:{hp:.04,atk:.02},weapon2:{atk:.05}};
function weaponFor(hid,slot){
 var H=window.__solHeroes&&window.__solHeroes[hid];if(!H)return null;
 var r=H.role,rg=/^(صقر|هلال)/.test(H.name||"");
 var T={tank:{weapon:["السيف","🗡️"],weapon2:["القوس","🏹"]},
  support:{weapon:["صولجان الشفاء","⚕️"],weapon2:["كتاب الأدعية","📖"]},
  control:{weapon:["عصا السحر","🪄"],weapon2:["كتاب التعاويذ","📖"]},
  dps:{weapon:["الخنجر","🗡️"],weapon2:["الخنجر الثاني","🔪"]}};
 if(rg)T.dps={weapon:["القوس","🏹"],weapon2:["سهام الجعبة","🎯"]};
 return (T[r]||T.dps)[slot]||null}
function bagRole(){var d=bagDef(bagHid());return{r:d.role||"dps",g:/^(صقر|هلال)/.test(d.name||"")}}
function bagSl(id){var b=SLOTS.filter(function(x){return x[0]===id})[0]||[id,id,"⚙️"];
 if(id==="weapon"||id==="weapon2"){var w=weaponFor(bagHid(),id);if(w)return [id,w[0],w[1]]}
 return b}
function bagHid(){var g=G();if(!g)return null;var tm=(g.team||[]).filter(function(id){return g.heroes[id]});if(bagHero&&tm.indexOf(bagHero)>=0)return bagHero;return tm[0]||null}
function bagDef(id){return(window.__solHeroes&&window.__solHeroes[id])||{name:id,faction:"abyss",role:"dps"}}
function bagSprite(id,w){var d=bagDef(id);if(window.SOLFBX&&window.SOLFBX.ok&&window.SOLFBX.avHTML)return window.SOLFBX.avHTML(d.name,d.faction,d.role||"dps",w);var svg=window.__solSpriteSVG?window.__solSpriteSVG({name:d.name,faction:d.faction,role:d.role||"dps",side:0}):"";return svg?'<div style="width:'+w+'px;flex:none">'+svg+'</div>':'<div style="font-size:'+Math.round(w*.5)+'px">'+((FACTIONS[d.faction]||{}).icon||"🌊")+'</div>'}
function bagBetter(sid,cur,inv){return inv.some(function(p){return p.slot===sid&&(!cur||p.tier>cur.tier||(p.tier===cur.tier&&(p.stars||0)>(cur.stars||0)))})}
function bagSlotBtn(sid,hr,inv){
 var it=(hr.gear||{})[sid],sl=bagSl(sid),c=it?TIERC[it.tier]||TIERC[1]:"#4b3f2a",up=bagBetter(sid,it,inv),on=bagSlot===sid;
 return '<button data-sp="bag-slot-tap" data-arg="'+sid+'" aria-label="'+sl[1]+'" style="position:relative;width:34px;height:34px;padding:0;border-radius:7px;border:2px '+(it?"solid":"dashed")+' '+c+';background:'+(it?"linear-gradient(160deg,"+c+"40,#120c06)":"rgba(0,0,0,.45)")+';box-shadow:'+(on?"0 0 0 2px #fff9,0 0 10px "+c:it?"0 0 7px "+c+"66":"none")+';cursor:pointer;display:flex;align-items:center;justify-content:center">'+(it?gearThumbHTML(sid,25,it.tier,bagRole().r,bagRole().g):'<span style="font-size:17px;opacity:.3">'+sl[2]+'</span>')+
  (it?'<span style="position:absolute;bottom:-1px;inset-inline-end:2px;font:900 8px Cairo;color:'+c+';text-shadow:0 0 3px #000,0 0 3px #000">'+TNm(it.tier)+'</span>':'')
  +(it&&it.stars>0?'<span style="position:absolute;top:-1px;inset-inline-start:2px;font:900 8px Cairo;color:#fde047;text-shadow:0 0 3px #000">★'+it.stars+'</span>':'')
  +(up?'<span style="position:absolute;top:-5px;inset-inline-end:-4px;background:#16a34a;color:#fff;border-radius:50%;width:14px;height:14px;font:900 9px/14px Cairo;text-align:center;box-shadow:0 0 5px #000">▲</span>':'')+'</button>'
}
function bagStage(id){
 var g=G(),hr=g.heroes[id],d=bagDef(id),inv=st().inventory,fc=(FACTIONS[d.faction]||{}).color||"#d4a941",pw=0;
 var mountDef=(window.SOLMNT&&window.SOLMNT.ok)?window.SOLMNT.byId(window.SOLMNT.currentId(d.name)):null;
 try{pw=window.__solPower(d,hr).power}catch(e){}
 var col=function(a){return '<div style="display:flex;flex-direction:column;gap:3px">'+a.map(function(s){return bagSlotBtn(s,hr,inv)}).join("")+'</div>'};
 return '<div style="border:2px solid #8a6d2e;border-radius:12px;background:linear-gradient(180deg,#2a1e10,#150e07);padding:6px">'
  +'<div style="display:grid;grid-template-columns:34px 1fr 34px;gap:6px;direction:ltr">'+col(BAG_L)
  +'<div style="position:relative;border-radius:8px;border:2px solid #8a6d2e66;overflow:hidden;min-height:290px;background:radial-gradient(circle at 50% 72%,'+fc+'66 0%,'+fc+'22 42%,#0d0a06 82%);direction:rtl">'
  +'<div style="text-align:center;padding-top:6px;font:900 13px Cairo;color:#ffedb0;text-shadow:0 1px 3px #000">'+esc(d.name)+'</div>'
  +'<div style="text-align:center;font:800 10.5px Cairo;color:#facc15">المستوى '+hr.level+' <span style="color:#fde047">'+"★".repeat(hr.stars||1)+'</span></div>'
  +(pw?'<div style="text-align:center;font:700 10px Cairo;color:#86efac">⚡ قوة '+pw.toLocaleString("en-US")+'</div>':'')
  +'<div style="position:absolute;left:50%;bottom:46px;transform:translateX(-50%);width:130px;display:flex;justify-content:center">'+bagSprite(id,110)+'</div><div style="position:absolute;bottom:5px;left:0;right:0;display:flex;justify-content:center;gap:8px">'+BAG_B.map(function(s){return bagSlotBtn(s,hr,inv)}).join("")+'<button data-sp="bag-mount-wheel" data-arg="'+id+'" aria-label="المطية" title="'+(mountDef?esc(mountDef.name):"المطية")+'" style="position:relative;width:34px;height:34px;padding:0;border-radius:7px;border:2px solid '+(mountDef?"#c49a4a":"#4b3f2a")+';background:'+(mountDef?"linear-gradient(160deg,#c49a4a40,#120c06)":"rgba(0,0,0,.45)")+';cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:19px;line-height:1">'+(mountDef?mountDef.icon:'<span style="opacity:.3">🐎</span>')+'</button></div></div>'
  +col(BAG_R)+'</div>'

  +'</div>'
}
function bagStrip(sel){
 var g=G(),tm=(g.team||[]).filter(function(id){return g.heroes[id]}),h='<div style="flex:none;display:flex;gap:5px;padding:6px 4px;margin:8px -2px 0;background:linear-gradient(180deg,rgba(21,14,7,.85),#150e07);border-top:2px solid #8a6d2e">';
 for(var k=0;k<5;k++){var id=tm[k];
  if(!id){h+='<div style="flex:1;border:1px dashed rgba(212,169,65,.25);border-radius:9px;height:56px;display:flex;align-items:center;justify-content:center;color:rgba(255,234,176,.3);font:10px Cairo">فارغ</div>';continue}
  var d=bagDef(id),on=id===sel;
  h+='<button data-sp="bag-hero" data-arg="'+id+'" style="flex:1;min-width:0;border:2px solid '+(on?"#ffd236":"rgba(212,169,65,.3)")+';border-radius:9px;background:'+(on?"rgba(240,199,94,.14)":"rgba(0,0,0,.35)")+';padding:3px 1px;cursor:pointer;display:flex;flex-direction:column;align-items:center;height:56px;overflow:hidden;box-shadow:'+(on?"0 0 10px #f0c75e88":"none")+'">'+bagSprite(id,22)+'<div style="flex:none;font:800 8.5px/11px Cairo;color:#ffe9a3;width:100%;text-align:center;overflow:hidden;white-space:nowrap">'+esc(d.name)+'</div><span style="flex:none;font:700 8px/10px Cairo;color:#fde047">م'+g.heroes[id].level+'</span></button>'
 }
 return h+'</div>'
}
function bagSignature(){
 var s=st(),g=G();if(!g)return"";
 var eq=Object.keys(g.heroes||{}).map(function(id){return id+":"+JSON.stringify(g.heroes[id].gear||{})});
 return JSON.stringify([bagCat,bagSlot,bagHero,bagDis,bagDD,g.team,s.inventory,g.resources,s.tokens,g.books,s.relics,s.skills,s.buff,s.wingLevel,eq,window.SOLMNT&&window.SOLMNT.map?window.SOLMNT.map():{}])
}
function renderBag(){
 var s=st(),g=G();if(!g)return"";
 var hid=bagHid();
 var cats=[["gear","⚔️ المعدات"],["res","💎 الموارد"],["skills","📚 المهارات"],["relics","🏺 الآثار"]];
 var h='';
 if(hid)h+=bagStage(hid);
 var SC='<div style="flex:1;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:2px 0">';
 h+='<div style="margin-top:8px;flex:1;min-height:0;display:flex;flex-direction:column;border:2px solid #8a6d2e;border-radius:12px;background:rgba(0,0,0,.28);padding:8px"><div class="sp-tabs" style="margin:0 0 8px;flex:none">'+cats.map(function(c){return '<button class="sp-tab'+(bagCat===c[0]?" on":"")+'" data-sp="bag-cat" data-arg="'+c[0]+'">'+c[1]+'</button>'}).join("")+'</div>';
 if(bagCat==="res"){h+=SC;
  var r=g.resources||{};
  h+='<div class="sp-grid3">'
   +bagTile("🪙","الذهب",(r.gold||0).toLocaleString("en-US"))+bagTile("💎","الجواهر",(r.gems||0).toLocaleString("en-US"))+bagTile("📜","الخبرة",(r.xp||0).toLocaleString("en-US"))
   +bagTile("⚙️","الخامات",(r.mats||0).toLocaleString("en-US"))+bagTile("🔷","الشظايا",(r.shards||0).toLocaleString("en-US"))+bagTile("🎫","التذاكر",(r.tickets||0).toLocaleString("en-US"))
   +bagTile("🎯","التوكن",(s.tokens||0).toLocaleString("en-US"))+bagTile("📘","كتب المهارات",(g.books||0).toLocaleString("en-US"))+bagTile("⚡","الطاقة",(g.energy?g.energy.value:0))
   +'</div>'
 }
 if(bagCat==="gear"){
  var curS=bagSlot==="all"?["all","الكل","🎒"]:bagSl(bagSlot);
  h+='<div style="display:flex;align-items:center;gap:5px;margin-bottom:8px;flex:none"><div style="position:relative;flex:none"><button data-sp="bag-dd" class="sp-btn gold" style="padding:5px 9px;display:flex;gap:6px;justify-content:space-between;align-items:center;font:800 11px Cairo;white-space:nowrap"><span>'+curS[2]+' '+curS[1]+'</span><span>'+(bagDD?"▲":"▼")+'</span></button>';
  if(bagDD){h+='<div style="position:absolute;top:100%;inset-inline-start:0;min-width:170px;z-index:30;margin-top:3px;max-height:114px;overflow-y:auto;border:2px solid #8a6d2e;border-radius:10px;background:#1a120a;box-shadow:0 6px 18px #000a">'
   +[["all","الكل","🎒"]].concat(SLOTS).map(function(sl){return '<button data-sp="bag-slot" data-arg="'+sl[0]+'" style="display:flex;align-items:center;gap:8px;width:100%;height:38px;padding:0 12px;border:0;border-bottom:1px solid rgba(212,169,65,.15);background:'+(bagSlot===sl[0]?"rgba(240,199,94,.18)":"transparent")+';color:#ffe9a3;font:700 12px Cairo;cursor:pointer;text-align:right"><span style="font-size:16px">'+sl[2]+'</span><span>'+sl[1]+'</span></button>'}).join("")+'</div>'}
  h+='</div><span class="sp-chip" style="font-size:10.5px;padding:4px 8px;white-space:nowrap">الإجمالي: '+s.inventory.length+'</span><button class="sp-btn gold" style="padding:5px 9px;font:800 11px Cairo;white-space:nowrap" data-sp="open-forge">🔨 صناعة</button><button class="sp-btn'+(bagDis?" gold":" red")+'" style="padding:5px 9px;font:800 11px Cairo;white-space:nowrap" data-sp="bag-dis">'+(bagDis?"✓ إنهاء":"♻️ تفكيك")+'</button></div>';
  var hr=hid?g.heroes[hid]:null,items=[];
  s.inventory.forEach(function(p,i){if(bagSlot==="all"||p.slot===bagSlot)items.push([p,i])});
  items.sort(function(a,b){return b[0].tier-a[0].tier||(b[0].stars||0)-(a[0].stars||0)});
  h+=SC;
  if(bagDis)h+='<div style="text-align:center;font:800 10.5px Cairo;color:#fca5a5;margin-bottom:6px">وضع التفكيك: اضغط على أي قطعة لبيعها</div>';
  if(!items.length)h+='<div class="sp-sub" style="text-align:center;padding:30px 0">لا توجد قطع'+(bagSlot==="all"?" — اهزم الوحوش في الحملة لتحصل على معدات":" من هذا النوع")+'</div>';
  else{
   h+='<div style="display:flex;flex-wrap:wrap;gap:6px">';
   items.forEach(function(x){var p=x[0],i=x[1],sl=bagSl(p.slot),c=TIERC[p.tier]||TIERC[1],cur=hr&&hr.gear&&hr.gear[p.slot],up=hr&&(!cur||p.tier>cur.tier||(p.tier===cur.tier&&(p.stars||0)>(cur.stars||0)));
    h+='<button data-sp="bag-item" data-arg="'+i+'" title="'+sl[1]+' '+TNm(p.tier)+'" style="position:relative;width:52px;height:52px;padding:0;border-radius:8px;border:2px solid '+c+';background:linear-gradient(160deg,'+c+'40,#120c06);box-shadow:0 0 6px '+c+'55;cursor:pointer;display:flex;align-items:center;justify-content:center">'+gearThumbHTML(p.slot,38,p.tier,bagRole().r,bagRole().g)+'<span style="position:absolute;bottom:0;inset-inline-end:3px;font:900 9px Cairo;color:'+c+';text-shadow:0 0 3px #000,0 0 3px #000">'+TNm(p.tier)+'</span>'
     +(p.stars?'<span style="position:absolute;top:0;inset-inline-start:3px;font:900 8.5px Cairo;color:#fde047;text-shadow:0 0 3px #000">★'+p.stars+'</span>':'')
     +(up&&!bagDis?'<span style="position:absolute;top:1px;inset-inline-end:2px;color:#4ade80;font:900 12px Cairo;text-shadow:0 0 3px #000">▲</span>':'')+'</button>'
   });
   h+='</div>'
  }
  h+='</div>'
 }
 if(bagCat==="skills"){h+=SC;
  var P=[["attack","⚔️","الهجوم","+2% ضرر"],["defense","🛡️","الدفاع","+2% دفاع"],["support","💚","الدعم","+2% صحة"],["speed","💨","السرعة","+1.5 سرعة"]];
  h+='<div class="sp-sub" style="margin-bottom:6px">كتب المهارات: '+(g.books||0)+' — جناح مستوى '+(s.wingLevel||1)+(s.buff?" • تعزيز: "+esc(s.buff.label||""):"")+'</div><div class="sp-grid">'
   +P.map(function(p){return '<div style="padding:9px;border:1px solid rgba(212,169,65,.25);border-radius:12px;background:rgba(0,0,0,.28);text-align:center"><div style="font-size:20px">'+p[1]+'</div><b style="font:800 12px Cairo">'+p[2]+'</b><div style="font:900 15px Cairo;color:#fde68a">مستوى '+(s.skills[p[0]]||0)+'</div><div style="font:9px Cairo;color:rgba(255,234,176,.55)">'+p[3]+' لكل مستوى</div></div>'}).join("")
   +'</div><div style="margin-top:8px"><button class="sp-btn gold" style="width:100%;padding:9px" data-sp="open-skills">🌿 شجرة المهارات</button></div>'
 }
 if(bagCat==="relics"){h+=SC;
  var own=s.relics||[];
  h+='<div class="sp-sub">الآثار ('+own.length+'/'+RELICS.length+')</div><div style="margin-top:6px">'
   +RELICS.map(function(x){var has=own.indexOf(x.id)>=0;return '<div style="display:flex;justify-content:space-between;gap:8px;border-top:1px solid rgba(212,169,65,.15);padding:6px 0;'+(has?"":"opacity:.5")+'"><div><b style="font:800 11px Cairo;color:'+(has?"#fde68a":"#c9b78a")+'">'+(has?"🏺 "+esc(x.name):"🔒 ؟؟؟")+'</b><div style="font:9px Cairo;color:rgba(255,234,176,.55)">'+esc(x.src)+'</div></div></div>'}).join("")+'</div>'
 }
 if(bagCat!=="gear")h+='</div>';
 h+='</div>';
 if(hid)h+=bagStrip(hid);
 return h
}
ACT["bag-hero"]=function(b,arg){bagHero=arg;bagSlot="all";bagRefresh()};
ACT["bag-dis"]=function(){bagDis=!bagDis;bagRefresh()};
ACT["bag-item"]=function(b,arg){
 var s=st(),i=+arg,p=s.inventory[i],id=bagHid();if(!p||!id)return;
 if(bagDis){ACT["forge-sell"](null,String(i));bagRefresh();return}
 ACT["forge-equip-hero"](null,i+":"+id);bagRefresh()
};
ACT["bag-slot-tap"]=function(b,arg){
 var g=G(),id=bagHid();if(!g||!id)return;
 var it=(g.heroes[id].gear||{})[arg],sl=bagSl(arg);
 if(!it){bagSlot=arg;bagCat="gear";toast("اختر قطعة لخانة "+sl[1]);bagRefresh();return}
 var c=TIERC[it.tier]||TIERC[1],cf=((arg==="weapon"||arg==="weapon2")&&window.__solWPS&&window.__solHeroes[g.heroes[id].defId||id]?window.__solWPS(window.__solHeroes[g.heroes[id].defId||id],arg):PSTAT[arg])||{}||{},m=it.tier*(1+.04*it.stars),ln=[];
 if(cf.atk)ln.push("هجوم ‎+"+(cf.atk*m*100).toFixed(1)+"%‎");if(cf.def)ln.push("دفاع ‎+"+(cf.def*m*100).toFixed(1)+"%‎");if(cf.hp)ln.push("صحة ‎+"+(cf.hp*m*100).toFixed(1)+"%‎");if(cf.spd)ln.push("سرعة ‎+"+(cf.spd*it.tier+it.stars).toFixed(1)+"‎");
 var ec={mats:8+12*it.stars,gold:800*(it.stars+1)};
 var h='<div style="text-align:center"><div style="display:flex;justify-content:center;min-height:110px;font-size:40px">'+gearThumbHTML(arg,110,it.tier,bagRole().r,bagRole().g,1)+'</div><b style="font:900 15px Cairo;color:'+c+'">'+sl[1]+' '+TNm(it.tier)+(it.stars?" ★"+it.stars:"")+'</b><div style="font:10px Cairo;color:rgba(255,234,176,.6);margin:3px 0 8px">مجهّزة على '+esc(bagDef(id).name)+'</div>'
  +'<div style="font:700 11px Cairo;color:#86efac;line-height:1.7;margin-bottom:10px">'+ln.join(" • ")+'</div><div style="display:grid;gap:7px">'
  +(it.stars<5?'<button class="sp-btn purple" style="padding:10px" data-sp="bag-enh" data-arg="'+arg+'">★ ارتقاء — ⚙️'+ec.mats+' + 🪙'+ec.gold.toLocaleString("en-US")+'</button>':'<div style="color:#fde047;font:700 11px Cairo">★★★★★ مكتملة</div>')
  +'<button class="sp-btn red" style="padding:10px" data-sp="bag-unequip" data-arg="'+arg+'">⬇️ إزالة إلى الحقيبة</button><button class="sp-btn" style="padding:10px" data-sp="forge-close-piece">رجوع</button></div></div>';
 openModal(h,{dark:!0})
};
ACT["bag-enh"]=function(b,arg){
 var g=G(),id=bagHid();if(!g||!id)return;
 var r=g.enhanceGear?g.enhanceGear(id,arg):{ok:!1,error:"غير متاح"};
 if(r&&r.ok){toast("★ تمت الترقية");closeModal();ACT["bag-slot-tap"](null,arg)}else toast("⚠️ "+((r&&r.error)||"تعذّر"));
 bagRefresh()
};
ACT["bag-unequip"]=function(b,arg){
 var g=G(),s=st(),id=bagHid();if(!g||!id)return;
 var it=(g.heroes[id].gear||{})[arg];if(!it)return;
 SET(function(st2){var hs=Object.assign({},st2.heroes),hh=Object.assign({},hs[id]),gg=Object.assign({},hh.gear||{});delete gg[arg];hh.gear=gg;hs[id]=hh;return{heroes:hs}});
 s.inventory.push({slot:arg,tier:it.tier,stars:it.stars||0,src:"مُخلوعة"});save();
 toast("⬇️ أُزيلت القطعة إلى الحقيبة");closeModal();bagRefresh();
 try{var _gu=(window.__solHeroes&&window.__solHeroes[id]||{}).name;setTimeout(function(){try{solGearFx(_gu,"unequip")}catch(e){}},80)}catch(e){}
};
function bagRefresh(){bagSig="";if(spBag){bagSig=bagSignature();spBag.innerHTML=renderBag()}}
ACT["open-loot"]=function(){
 var L=st().loot||[],h='<div style="text-align:center"><b style="font:900 16px Cairo;color:#fde68a">📜 سجل الغنائم</b></div><div style="margin-top:8px;max-height:60vh;overflow-y:auto">';
 if(!L.length)h+='<div class="sp-sub" style="text-align:center;padding:14px 0">لا غنائم بعد — اربح معركة في الحملة</div>';
 L.slice(0,25).forEach(function(e){
  var ch=[];
  [["gold","🪙"],["gems","💎"],["xp","📜"],["mats","⚙️"],["shards","🔷"],["tickets","🎫"]].forEach(function(k){if(e[k[0]])ch.push('<span class="sp-chip" style="padding:2px 7px">'+k[1]+' '+e[k[0]].toLocaleString("en-US")+'</span>')});
  (e.gear||[]).forEach(function(x){var sl=bagSl(x.slot);ch.push('<span class="sp-chip" style="padding:2px 7px">'+sl[2]+' '+sl[1]+' '+TNm(x.tier)+'</span>')});
  h+='<div style="border-top:1px solid rgba(212,169,65,.15);padding:6px 0"><div style="font:9px Cairo;color:rgba(255,234,176,.45);margin-bottom:3px">'+bagTime(e.ts)+'</div><div class="sp-row">'+ch.join("")+'</div></div>'
 });
 h+='</div><div style="margin-top:8px"><button class="sp-btn" style="width:100%" data-sp="forge-close-piece">إغلاق</button></div>';
 openModal(h,{dark:!0})
};
ACT["bag-mount-wheel"]=function(b,arg){
 var id=String(arg||bagHid()),def=bagDef(id),mnt=window.SOLMNT,defs=mnt&&mnt.defs||[];
 if(!mnt||!mnt.ok||!defs.length){toast("المطيات غير جاهزة");return}
 var current=mnt.currentId(def.name),h='<div style="text-align:center;direction:rtl"><b style="font:900 16px Cairo;color:#ffe5a3">🐎 دائرة المطايا — '+esc(def.name)+'</b><div style="font:10px Cairo;color:#cbb78f;margin:4px 0 10px">اختر مطية لتجهيزها في خانة البطل</div><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:7px">';
 defs.forEach(function(m){h+='<button data-sp="bag-mount-set" data-arg="'+id+','+m.id+'" style="min-height:76px;border:2px solid '+(m.id===current?'#ffe08a':'#8a6d2e')+';border-radius:12px;background:'+(m.id===current?'linear-gradient(145deg,#795525,#251607)':'rgba(0,0,0,.35)')+';color:#ffe9b0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px"><span style="font-size:27px">'+m.icon+'</span><b style="font:800 9px Cairo">'+esc(m.name)+'</b>'+(m.id===current?'<small style="color:#86efac;font:800 8px Cairo">مركّبة ✓</small>':'')+'</button>'});
 h+='</div>'+(current?'<button class="sp-btn red" style="width:100%;margin-top:9px" data-sp="bag-mount-set" data-arg="'+id+',none">⬇️ إزالة المطية</button>':'')+'<button class="sp-btn" style="width:100%;margin-top:7px" data-sp="sp-close">إغلاق</button></div>';openModal(h,{dark:!0});
};
ACT["bag-mount-set"]=function(b,arg){
 var q=String(arg||"").split(","),id=q[0],mountId=q[1],def=bagDef(id);
 if(!window.SOLMNT||!window.SOLMNT.set(def.name,mountId)){toast("تعذر تجهيز المطية");return}
 closeModal();bagSig="";if(spBag){bagSig=bagSignature();spBag.innerHTML=renderBag()}toast(mountId==="none"?"⬇️ أُزيلت المطية عن "+def.name:"🐎 تم تجهيز المطية على "+def.name);
};
ACT["bag-cat"]=function(b,arg){bagCat=arg;bagDD=!1;bagSig="";if(spBag){bagSig=bagSignature();spBag.innerHTML=renderBag()}};
ACT["bag-dd"]=function(){bagDD=!bagDD;bagRefresh()};
ACT["bag-slot"]=function(b,arg){bagSlot=arg;bagDD=!1;bagSig="";if(spBag){bagSig=bagSignature();spBag.innerHTML=renderBag()}};

/* ==================== الإقلاع ==================== */
var booted=0;
function boot(){
 if(booted)return;booted=1;
 evalAch();updateDataSol();
 setInterval(mount,700);
 setTimeout(mount,700);
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);
else setTimeout(boot,300);
setTimeout(function(){if(!booted)boot()},2500);
})();


