
/* ============================================================
   SOLMNT — المطيات ثلاثية الأبعاد لأساطير الرمال
   كل بطل بشري يركب مطية حقيقية متحركة في ساحة القتال،
   وتظهر المطية أيضًا تحت البطل في صوره المصغّرة (الأفاتار).
   10 مطيات: نمر الأرواح • حصان الحرب • ذئب الظلال • غزال البلور
   أسد الرمال • دريك الصغرى • كبش الجبال • فهد الليل
   جارحة السهول • وحيد القرن الحجري
   لكل مطية خصائص (+هجوم/+صحة/+دفاع) وتُدار من تبويب «المطيات».
   ============================================================ */
(function () {
  "use strict";
  if (window.SOLMNT) return;
  var S = { ok: true };
  window.SOLMNT = S;

  /* ==================== ألوان وهندسة (ظل مخبوز مثل SOL3D) ==================== */
  var BRIGHT = { top: 1.16, bottom: 0.5, front: 0.98, back: 0.62, right: 0.8, left: 0.84 };
  function hex2rgb(h) {
    h = String(h || "#fff").replace("#", "");
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }
  function GB() { this.v = []; this.i = []; this.n = 0; }
  GB.prototype.quad = function (a, b, c, d, col) {
    var V = this.v, I = this.i, n0 = this.n;
    V.push(a[0], a[1], a[2], col[0], col[1], col[2]);
    V.push(b[0], b[1], b[2], col[0], col[1], col[2]);
    V.push(c[0], c[1], c[2], col[0], col[1], col[2]);
    V.push(d[0], d[1], d[2], col[0], col[1], col[2]);
    I.push(n0, n0 + 1, n0 + 2, n0, n0 + 2, n0 + 3);
    this.n += 4;
  };
  /* صندوق مُظلل — ry دوران حول Y اختياري */
  GB.prototype.box = function (cx, cy, cz, w, h, d, hex, opt) {
    var col = typeof hex === "string" ? hex2rgb(hex) : hex;
    var ry = opt && opt.ry || 0, cs = Math.cos(ry), sn = Math.sin(ry);
    var x0 = -w / 2, x1 = w / 2, y0 = -h / 2, y1 = h / 2, z0 = -d / 2, z1 = d / 2;
    var self = this;
    function rot(p) { return [cx + p[0] * cs - p[2] * sn, cy + p[1], cz + p[0] * sn + p[2] * cs]; }
    function shade(k) { return [col[0] * k, col[1] * k, col[2] * k]; }
    var A, B, C, D;
    A = [x0, y1, z1]; B = [x1, y1, z1]; C = [x1, y1, z0]; D = [x0, y1, z0];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.top));
    A = [x0, y0, z0]; B = [x1, y0, z0]; C = [x1, y0, z1]; D = [x0, y0, z1];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.bottom));
    A = [x0, y0, z1]; B = [x1, y0, z1]; C = [x1, y1, z1]; D = [x0, y1, z1];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.front));
    A = [x1, y0, z0]; B = [x0, y0, z0]; C = [x0, y1, z0]; D = [x1, y1, z0];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.back));
    A = [x1, y0, z1]; B = [x1, y0, z0]; C = [x1, y1, z0]; D = [x1, y1, z1];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.right));
    A = [x0, y0, z0]; B = [x0, y0, z1]; C = [x0, y1, z1]; D = [x0, y1, z0];
    self.quad(rot(A), rot(B), rot(C), rot(D), shade(BRIGHT.left));
  };
  function uploadG(gl, gb) {
    var vb = gl.createBuffer(), ib = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(gb.v), gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(gb.i), gl.STATIC_DRAW);
    return { vb: vb, ib: ib, n: gb.i.length };
  }

  /* ==================== قائمة المطيات ==================== */
  S.defs = [
    { id: "tiger",   icon: "🐅", name: "نمر الأرواح المقدّس", atk: .02, hp: .02, def: .01,
      desc: "نمر أبيض بدرع ذهبي وخطوط بنفسجية متوهجة — مطية النخبة كما في أساطير الحرب.", style: "cat", armor: 1, stripes: 1,
      C: { body: "#ece6f5", belly: "#f9f5ff", dark: "#c9bfe0", accent: "#8b5cf6", armor: "#d4af37", eye: "#ffd35a", hoof: "#3a3148", mane: "#8b5cf6" } },
    { id: "horse",   icon: "🐎", name: "حصان الحرب الذهبي", atk: .015, hp: .03, def: .015,
      desc: "فرس حرب بعُرف أسود وسرج مزخرف — صديق الفرسان في كل الحملات.", style: "horse", armor: 1, maneHair: 1,
      C: { body: "#b98a4e", belly: "#e8d0a8", dark: "#8a6434", accent: "#d4a941", armor: "#e8c76a", eye: "#2a1a0a", hoof: "#2c2014", mane: "#3a2814" } },
    { id: "wolf",    icon: "🐺", name: "ذئب الظلال", atk: .03, hp: .01, def: .01,
      desc: "ذئب ضخم بعيون وردية و أشواك ظلالية — يهمس قبل أن ينقضّ.", style: "cat", spikes: 1,
      C: { body: "#46405a", belly: "#6a6284", dark: "#2e2a40", accent: "#b34a68", armor: "#4a4260", eye: "#ff6a9e", hoof: "#1a1626", mane: "#2e2a40" } },
    { id: "stag",    icon: "🦌", name: "غزال البلور", atk: .01, hp: .02, def: .03,
      desc: "غزال بقرون بلورية زرقاء تُضيء الساحة — بركة الواحات على ظهره.", style: "horse", antlers: 1,
      C: { body: "#d8e8f2", belly: "#f4fbff", dark: "#a8c4d4", accent: "#7fd8ff", armor: "#bfe4f7", eye: "#2a6a9e", hoof: "#3a4a56", mane: "#cfe4f0" } },
    { id: "lion",    icon: "🦁", name: "أسد الرمال", atk: .025, hp: .015, def: .01,
      desc: "أسد بُنّي بعُرفة نارية ودرع صدر ذهبي — ملك الكثبان.", style: "cat", maneBig: 1, armor: 1,
      C: { body: "#cf9a4e", belly: "#e8c88a", dark: "#a8763a", accent: "#d4a941", armor: "#e8c76a", eye: "#3a1a08", hoof: "#5a3a1e", mane: "#8a4b1e" } },
    { id: "drake",   icon: "🐉", name: "دُريك الصغرى", atk: .035, hp: .005, def: .005,
      desc: "تنّين صغير بأجنحة بنفسجية ترفرف — ينفث شرارة تزيد ضربات صاحبه.", style: "cat", wings: 1, horns: 1,
      C: { body: "#7a4ae0", belly: "#a88af0", dark: "#5a34b0", accent: "#ffd35a", armor: "#8b5cf6", eye: "#ffd35a", hoof: "#3a2470", mane: "#5a34b0" } },
    { id: "ram",     icon: "🐏", name: "كبش الجبال الحديد", atk: .01, hp: .015, def: .04,
      desc: "كبش بقرنون حديديان ودرع جبهة — حائط يندفع به الحصار.", style: "ram", ramHorns: 1, armor: 1,
      C: { body: "#9aa3ad", belly: "#c4ccd4", dark: "#6e7680", accent: "#d4a941", armor: "#aeb8c2", eye: "#1a1410", hoof: "#2c241a", mane: "#e4e9ee" } },
    { id: "panther", icon: "🐈‍⬛", name: "فهد الليل", atk: .03, hp: .012, def: .008,
      desc: "فهد أسود بعيون وردية وأشواك بنفسجية — لا يُرى حتى يهجم.", style: "cat", spikes: 1,
      C: { body: "#221c30", belly: "#38304a", dark: "#161220", accent: "#4a3a6a", armor: "#38304a", eye: "#ff4a9e", hoof: "#0e0a16", mane: "#161220" } },
    { id: "hawk",    icon: "🦅", name: "جارحة السهول", atk: .02, hp: .01, def: .01,
      desc: "طائر جارح ضخم بريش ذهبي — يركض أسرع من الريح على أرض الساحة.", style: "bird",
      C: { body: "#d9b06a", belly: "#f4e4c0", dark: "#a8843e", accent: "#e0a040", armor: "#c49a4a", eye: "#1a1008", hoof: "#c9a04a", mane: "#a8843e" } },
    { id: "rhino",   icon: "🦏", name: "وحيد القرن الحجري", atk: .015, hp: .025, def: .025,
      desc: "وحيد قرن بجلد حجري وقرن ذهبي — مطية المحطّمين للأسوار.", style: "rhino", noseHorn: 1, armor: 1,
      C: { body: "#6a7280", belly: "#8a94a0", dark: "#4a5260", accent: "#d4a941", armor: "#5a626e", eye: "#18140e", hoof: "#2e3440", mane: "#4a5260" } }
  ];
  S.byId = function (id) { for (var i = 0; i < S.defs.length; i++) if (S.defs[i].id === id) return S.defs[i]; return null; };

  /* ==================== اختيار/حفظ المطية لكل بطل ==================== */
  var LSK = "solmnt_v1";
  function loadMap() { try { return JSON.parse(localStorage.getItem(LSK) || "{}") || {}; } catch (e) { return {}; } }
  function saveMap(m) { try { localStorage.setItem(LSK, JSON.stringify(m)); } catch (e) { } }
  function hash(s) { var h = 7; s = String(s || "x"); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; }
  S.baseName = function (name) {
    var n = String(name || "");
    /* أشكال البطل المتنوعة تحمل لاحقة ·N — انزعها لتوريث مطية البطل الأصلي */
    var i = n.indexOf("·");
    if (i > 0) n = n.slice(0, i).trim();
    return n;
  };
  S.pickId = function (name, enemy) {
    var m = loadMap(), bn = S.baseName(name);
    var id = m[bn] || m[name];
    if (id === "none" && !enemy) return null;   /* بطل بلا مطية */
    if (id && S.byId(id)) return id;
    return S.defs[hash(bn || name || "x") % S.defs.length].id;
  };
  S.currentId = function (name) { return S.pickId(name, false); };
  S.set = function (name, id) { if (id !== "none" && !S.byId(id)) return false; var m = loadMap(); m[S.baseName(name)] = id; saveMap(m); S.mapSig = (S.mapSig || 0) + 1; return true; };
  S.reset = function (name) { var m = loadMap(); delete m[S.baseName(name)]; saveMap(m); S.mapSig = (S.mapSig || 0) + 1; };
  S.map = loadMap;
  S.defOf = function (name) { var i2 = S.pickId(name, false); return i2 === null ? null : (S.byId(i2) || S.defs[0]); };
  S.usersOf = function (id) {
    var out = [], H = window.__solHeroes || {};
    for (var k in H) { if (String(k).indexOf("·") >= 0) continue; if (H[k] && S.currentId(H[k].name) === id) out.push(H[k].name); }
    return out;
  };

  /* ==================== بناء أجزاء المطية (نسبة إلى محور كل جزء) ==================== */
  function darkC(C) {
    var D = {};
    for (var k in C) D[k] = C[k];
    D.body = shadeHex(C.body, 0.42); D.belly = shadeHex(C.belly, 0.5); D.dark = shadeHex(C.dark, 0.6);
    D.accent = "#8a2233"; D.eye = "#ff4a3a"; D.armor = shadeHex(C.armor, 0.5);
    return D;
  }
  function shadeHex(h, k) {
    var c = hex2rgb(h);
    function to(x) { x = Math.round(Math.min(1, x * k) * 255).toString(16); return x.length < 2 ? "0" + x : x; }
    return "#" + to(c[0]) + to(c[1]) + to(c[2]);
  }

  function buildParts(def, enemy) {
    var C = enemy ? darkC(def.C) : def.C, st2 = def.style, parts = [];
    function part(name, fn, piv) { var g = new GB(); fn(g); parts.push({ name: name, gb: g, piv: piv }); }

    /* --- الجسم: إرداف + صدر مرتفع + بطن + سرج مُذهّب + دروع كتف --- */
    part("mbody", function (g) {
      g.box(0, 0, -9, 26, 18, 27, C.body);                    /* الإرداف */
      g.box(0, 1.2, 9, 27, 20.5, 23, C.body);                 /* الصدر أعلى وأضخم */
      g.box(0, 2, 9, 28.4, 5, 8, C.dark);                     /* عضلات الكتف */
      g.box(0, -8.2, -2, 21, 3.6, 44, C.belly);               /* البطن */
      g.box(0, 10.6, -4, 28, 3.8, 35, C.accent);              /* بطانية السرج */
      g.box(0, 12.9, -4, 24, 2.4, 29, C.armor);               /* إطار السرج المُذهّب */
      g.box(0, 14.4, 9, 7, 4.4, 6, C.armor);                  /* مقدمة السرج */
      g.box(0, 14.4, -14, 7, 4.4, 6, C.armor);                /* مؤخرة السرج */
      if (def.armor) {
        g.box(-14.2, 4, 6, 4.6, 13, 22, C.armor, { ry: 0.06 });  /* درع كتف يسار */
        g.box(14.2, 4, 6, 4.6, 13, 22, C.armor, { ry: -0.06 });  /* درع كتف يمين */
        g.box(-14.6, -2, -10, 4, 10, 16, shadeHex(C.armor, 0.8), { ry: 0.1 });
        g.box(14.6, -2, -10, 4, 10, 16, shadeHex(C.armor, 0.8), { ry: -0.1 });
        g.box(0, -3, 22, 22, 6, 3.4, C.armor);                /* صدرية أمامية */
      }
      if (def.stripes) {
        for (var i = 0; i < 4; i++) { g.box(-13.6, 2, 10 - i * 9, 1.8, 14, 3.6, C.accent); g.box(13.6, 2, 10 - i * 9, 1.8, 14, 3.6, C.accent); }
        g.box(0, 10, 2, 3.4, 1.8, 28, C.accent);
        g.box(-9, 11.2, -20, 3, 3, 3, C.accent); g.box(9, 11.2, -20, 3, 3, 3, C.accent);
      }
      if (def.spikes) {
        for (var s2 = 0; s2 < 4; s2++) { g.box(0, 12.6 + s2 * 0.3, -4 + s2 * 6.4, 3.2, 5.4, 3.2, C.accent); }
        g.box(-9.5, 10.6, -14, 2.8, 4.4, 2.8, C.accent); g.box(9.5, 10.6, -14, 2.8, 4.4, 2.8, C.accent);
      }
    }, [0, 27, 0]);

    /* --- الرقبة المرفوعة (تتمايل) --- */
    part("mneck", function (g) {
      if (st2 === "bird") { g.box(0, 8, 0, 9, 18, 9, C.body); g.box(0, 17, 1, 8, 7, 8, C.belly); }
      else {
        g.box(0, 7, 2, 13, 18, 14, C.body);
        g.box(0, 15, 3, 11, 6, 11, C.body);
        g.box(0, 3, 6, 10.4, 6, 11, C.belly);
      }
      if (def.maneHair) { g.box(0, 12, -5.4, 5, 16, 4.4, C.mane); g.box(0, 17, -2.6, 4, 9, 3.4, C.mane, { ry: 0.2 }); }
      if (def.maneBig) { g.box(0, 4, -6.4, 17, 15, 6, C.mane); }
    }, [0, 33, 20]);

    /* --- الرأس العالي (آذان/قرون/عيون متوهجة/كمامة/فك) --- */
    part("mhead", function (g) {
      if (st2 === "bird") {
        g.box(0, 0, 5, 11, 10, 14, C.body);
        g.box(0, 1.6, 16, 5, 3.6, 9, C.accent);               /* منقار */
        g.box(0, -2.6, 15.4, 4, 2.6, 6, shadeHex(C.accent, 0.75));
        g.box(-3, 4.6, 2, 2.6, 3.4, 1.6, C.eye); g.box(3, 4.6, 2, 2.6, 3.4, 1.6, C.eye);
        g.box(-3, 4.6, 2.8, 1.4, 1.6, 1, "#ffffff"); g.box(3, 4.6, 2.8, 1.4, 1.6, 1, "#ffffff");
        g.box(0, 6.2, -7, 3.4, 9, 5.4, C.mane, { ry: 0.5 });  /* عُرفة خلفية */
      } else {
        g.box(0, 0, 4, 14, 13, 18, C.body);
        g.box(0, -2.8, 15.5, 9.6, 7.6, 10, C.dark);           /* كمامة */
        g.box(0, -6.4, 13.5, 7.4, 3.6, 8, shadeHex(C.dark, 0.7)); /* الفك السفلي */
        g.box(0, -4.6, 20.8, 7.4, 2.6, 2, shadeHex(C.dark, 0.55)); /* أنف */
        g.box(-3.9, 1.8, 14.2, 2.5, 2.5, 1.6, C.eye); g.box(3.9, 1.8, 14.2, 2.5, 2.5, 1.6, C.eye);
        g.box(-3.9, 1.8, 15.1, 1.4, 1.5, 1, "#ffffff"); g.box(3.9, 1.8, 15.1, 1.4, 1.5, 1, "#ffffff");
        if (st2 === "ram") {
          g.box(-7.8, 6.8, -2, 4.4, 4.4, 13, C.mane, { ry: 0.5 });
          g.box(-9.4, 2.8, 3, 4.4, 4.4, 6, C.mane, { ry: -0.4 });
          g.box(7.8, 6.8, -2, 4.4, 4.4, 13, C.mane, { ry: -0.5 });
          g.box(9.4, 2.8, 3, 4.4, 4.4, 6, C.mane, { ry: 0.4 });
        } else if (def.antlers) {
          g.box(-3.6, 8.8, 0, 2.2, 10, 2.2, C.accent, { ry: 0.22 });
          g.box(-6.6, 12.4, 0, 5.4, 2, 2, C.accent, { ry: 0.5 });
          g.box(-7.2, 10.2, 2, 1.8, 5.4, 1.8, C.accent, { ry: 0.3 });
          g.box(3.6, 8.8, 0, 2.2, 10, 2.2, C.accent, { ry: -0.22 });
          g.box(6.6, 12.4, 0, 5.4, 2, 2, C.accent, { ry: -0.5 });
          g.box(7.2, 10.2, 2, 1.8, 5.4, 1.8, C.accent, { ry: -0.3 });
        } else if (def.ramHorns || def.noseHorn) {
          g.box(-4.8, 7.4, -1, 3.4, 6.6, 3.4, C.mane, { ry: 0.35 });
          g.box(4.8, 7.4, -1, 3.4, 6.6, 3.4, C.mane, { ry: -0.35 });
        } else {
          g.box(-5, 8, -3.4, 3.4, 6.8, 2.6, C.body, { ry: 0.15 });
          g.box(5, 8, -3.4, 3.4, 6.8, 2.6, C.body, { ry: -0.15 });
          g.box(-5, 10.4, -3.4, 2.2, 3.2, 1.8, shadeHex(C.dark, 0.8), { ry: 0.15 });
          g.box(5, 10.4, -3.4, 2.2, 3.2, 1.8, shadeHex(C.dark, 0.8), { ry: -0.15 });
        }
        if (def.horns) { g.box(-2.8, 9, -4.4, 2.4, 6.4, 2.4, C.accent, { ry: 0.3 }); g.box(2.8, 9, -4.4, 2.4, 6.4, 2.4, C.accent, { ry: -0.3 }); }
        if (def.noseHorn) { g.box(0, 4, 19, 2.8, 7.6, 2.8, C.accent); g.box(0, 7, 16.6, 2.2, 4.6, 2.2, shadeHex(C.accent, 0.85)); }
        if (def.armor) {
          g.box(0, 2.6, 10.8, 13, 9.4, 2.4, C.armor);          /* قناع وجه */
          g.box(0, 8, 6.4, 11.6, 2.6, 8.4, shadeHex(C.armor, 0.85));
        }
        if (def.maneBig) {
          g.box(0, 1.4, -5.8, 17, 16, 5.8, C.mane);
          g.box(-8.8, 3.4, -2.6, 4.8, 13, 5.4, C.mane, { ry: 0.5 });
          g.box(8.8, 3.4, -2.6, 4.8, 13, 5.4, C.mane, { ry: -0.5 });
        }
        if (def.spikes) { g.box(0, 9.4, -6.4, 2.8, 5, 2.8, C.accent); }
      }
    }, [0, 49, 28]);

    /* --- الأرجل الأربع (محور الورك) — ركبة وحافر واضحان --- */
    var legH = st2 === "bird" ? 27 : 23.5, legW = st2 === "bird" ? 7 : 9;
    if (st2 === "bird") {
      part("legFL", function (g) { g.box(0, -legH / 2 + 2, 0, legW, legH, legW, C.body); g.box(0, -legH + 3.6, 2.4, legW + 3.4, 3.6, 10, C.hoof); }, [7.5, 21, 2]);
      part("legFR", function (g) { g.box(0, -legH / 2 + 2, 0, legW, legH, legW, C.body); g.box(0, -legH + 3.6, 2.4, legW + 3.4, 3.6, 10, C.hoof); }, [-7.5, 21, 2]);
    } else {
      part("legFL", function (g) { g.box(0, -legH / 2, 0, legW, legH, legW + 1, C.dark); g.box(0, -legH + 5, 1.6, legW + 0.6, 6.4, legW + 1.4, shadeHex(C.body, 0.85)); g.box(0, -legH + 2.4, 0, legW + 1.8, 5, legW + 2.8, C.hoof); }, [11.5, 23, 16]);
      part("legFR", function (g) { g.box(0, -legH / 2, 0, legW, legH, legW + 1, C.dark); g.box(0, -legH + 5, 1.6, legW + 0.6, 6.4, legW + 1.4, shadeHex(C.body, 0.85)); g.box(0, -legH + 2.4, 0, legW + 1.8, 5, legW + 2.8, C.hoof); }, [-11.5, 23, 16]);
      part("legBL", function (g) { g.box(0, -legH / 2, 0, legW + 1.4, legH, legW + 2, C.dark); g.box(0, -legH + 5, -1.4, legW + 2, 6.4, legW + 2.6, shadeHex(C.body, 0.85)); g.box(0, -legH + 2.4, 0, legW + 2.8, 5, legW + 3.6, C.hoof); }, [11.5, 23, -17]);
      part("legBR", function (g) { g.box(0, -legH / 2, 0, legW + 1.4, legH, legW + 2, C.dark); g.box(0, -legH + 5, -1.4, legW + 2, 6.4, legW + 2.6, shadeHex(C.body, 0.85)); g.box(0, -legH + 2.4, 0, legW + 2.8, 5, legW + 3.6, C.hoof); }, [-11.5, 23, -17]);
    }

    /* --- الذيل المتقوّس (3 فقرات) --- */
    part("mtail", function (g) {
      if (st2 === "bird") {
        g.box(0, -1.6, -7, 15, 2.6, 15, C.mane);
        g.box(0, -0.6, -16, 11, 2.2, 8, shadeHex(C.mane, 0.85), { ry: 0.1 });
        g.box(0, 0.6, -23, 7, 1.8, 5, shadeHex(C.mane, 0.7), { ry: 0.14 });
      } else {
        g.box(0, -2.4, -6, 6.4, 6.4, 13, C.dark, { ry: 0.1 });
        g.box(0, -4.6, -14, 4.8, 4.8, 11, C.dark, { ry: 0.14 });
        g.box(0, -6.2, -21, 3.6, 3.6, 10, st2 === "cat" || st2 === "horse" ? C.mane : C.dark, { ry: 0.16 });
        if (st2 === "horse" || st2 === "stag") g.box(0, -8.4, -26, 3.4, 10, 6.4, C.mane, { ry: 0.2 });
      }
    }, [0, 33, -26]);

    /* --- عُرفة الأسد / أجنحة الدُريك --- */
    if (def.maneBig) {
      part("mmane", function (g) {
        g.box(0, 0, 0, 21, 19, 6.4, C.mane);
        g.box(-11, 2.4, 2.4, 5.8, 15, 5.4, shadeHex(C.mane, 0.85), { ry: 0.4 });
        g.box(11, 2.4, 2.4, 5.8, 15, 5.4, shadeHex(C.mane, 0.85), { ry: -0.4 });
        g.box(-9.4, 9, -4, 4.8, 6, 4.8, shadeHex(C.mane, 0.8), { ry: 0.7 });
        g.box(9.4, 9, -4, 4.8, 6, 4.8, shadeHex(C.mane, 0.8), { ry: -0.7 });
      }, [0, 42, 14]);
    }
    if (def.wings) {
      part("mwingL", function (g) {
        g.box(8, 2, -2, 18, 2.6, 13, C.accent, { ry: -0.28 });
        g.box(17, 5, -3.4, 13, 2.2, 10, shadeHex(C.accent, 0.85), { ry: -0.5 });
      }, [11, 36, 4]);
      part("mwingR", function (g) {
        g.box(-8, 2, -2, 18, 2.6, 13, C.accent, { ry: 0.28 });
        g.box(-17, 5, -3.4, 13, 2.2, 10, shadeHex(C.accent, 0.85), { ry: 0.5 });
      }, [-11, 36, 4]);
    }
    return parts;
  }

  /* أبعاد الرفع: ارتفاع سرج المطية (بأبعاد مجسم البطل 66 وحدة) */
  var STYLE_H = { cat: 41, horse: 41, ram: 40, rhino: 40, bird: 38 };

  S.build = function (gl, name, enemy) {
    try {
      var id = S.pickId(name, enemy), def = id ? S.byId(id) : null;
      if (!def) return null;
      var parts = buildParts(def, enemy), out = [];
      for (var i = 0; i < parts.length; i++) out.push({ name: parts[i].name, mesh: uploadG(gl, parts[i].gb), piv: parts[i].piv });
      return { id: id, def: def, parts: out, lift: STYLE_H[def.style] || 36, h: (STYLE_H[def.style] || 36) + 24 };
    } catch (e) { return null; }
  };

  /* ==================== mesh ثابت للأفاتار (مطية واقفة) ==================== */
  var AVC = {};
  S.avInfo = function (name) {
    var id = S.pickId(name, false), def = id ? S.byId(id) : null;
    if (!def) return null;
    var lift = STYLE_H[def.style] || 36;
    return { id: id, lift: lift, k: 66 / (66 + lift + 6) };
  };
  S.avMesh = function (gl, id) {
    var key = String(id);
    if (AVC[key]) return AVC[key];
    try {
      var def = S.byId(key); if (!def) return null;
      var parts = buildParts(def, false), g = new GB(), tmp;
      /* ادمج الأجزاء في mesh واحد بإزاحة محور كل جزء — أرجل واقفة */
      for (var i = 0; i < parts.length; i++) {
        tmp = parts[i];
        var V = tmp.gb.v, I = tmp.gb.i;
        var base = g.n;
        for (var vv = 0; vv < tmp.gb.n; vv++) {
          g.v.push(V[vv * 6] + tmp.piv[0], V[vv * 6 + 1] + tmp.piv[1], V[vv * 6 + 2] + tmp.piv[2],
            V[vv * 6 + 3], V[vv * 6 + 4], V[vv * 6 + 5]);
        }
        for (var ii = 0; ii < I.length; ii++) g.i.push(base + I[ii]);
        g.n += tmp.gb.n;
      }
      var m = uploadG(gl, g);
      m.arr = new Float32Array(g.v);
      AVC[key] = m;
      return m;
    } catch (e) { return null; }
  };

  /* ============================================================
     ASCII Engine locomotion integration
     Adapted from src/horse-animation.ts, src/horse-walk.ts and
     src/rider-motion.ts in NYLLON-SOFTWARE/ascii-engine.
     Uses the engine's 1.40× walk / 1.65× gallop rates and its
     staggered four-hoof contacts (.63/.64 stance duty factors).
     The active battle renderer keeps its own mesh format; this profile
     drives those native meshes and synchronizes the rider to their clock.
     ============================================================ */
  S.engineProfile = {
    source: "NYLLON-SOFTWARE/ascii-engine",
    walkRate: 1.4, gallopRate: 1.65,
    walkDuration: 2.6666667461, gallopDuration: 0.8333333135,
    contacts: { legBL: 0, legFL: 0.25, legBR: 0.5, legFR: 0.75 },
    stance: { legBL: 0.63, legFL: 0.64, legBR: 0.63, legFR: 0.64 }
  };
  function gaitWrap(v) { return ((v % 1) + 1) % 1; }
  function gaitEase(v) { v = Math.max(0, Math.min(1, v)); return v * v * (3 - 2 * v); }
  function gaitFoot(phase, contact, stance, amplitude, lift) {
    var p = gaitWrap(phase - contact), k, angle, up = 0;
    if (p <= stance) {
      k = p / stance;
      angle = -amplitude + 2 * amplitude * k;
    } else {
      k = (p - stance) / (1 - stance);
      angle = amplitude - 2 * amplitude * gaitEase(k);
      up = Math.sin(Math.PI * k) * lift;
    }
    return { angle: angle, lift: Math.max(0, up) };
  }
  S.sampleStride = function(clock, offset, runBlend) {
    var P = S.engineProfile, mix = Math.max(0, Math.min(1, Number(runBlend) || 0));
    var seed = gaitWrap((Number(offset) || 0) / (Math.PI * 2));
    var walkPhase = gaitWrap((Number(clock) || 0) * P.walkRate / P.walkDuration + seed);
    var runPhase = gaitWrap((Number(clock) || 0) * P.gallopRate / P.gallopDuration + seed);
    var legs = {};
    Object.keys(P.contacts).forEach(function(name) {
      var c = P.contacts[name], d = P.stance[name];
      var w = gaitFoot(walkPhase, c, d, 0.22, 0.10);
      var r = gaitFoot(runPhase, c, d, 0.48, 0.24);
      legs[name] = { angle: w.angle * (1 - mix) + r.angle * mix, lift: w.lift * (1 - mix) + r.lift * mix };
    });
    var bounce = (1 - mix) * (0.2 + 0.35 * Math.abs(Math.sin(walkPhase * Math.PI * 4)))
      + mix * (0.35 + 2.25 * Math.abs(Math.sin(runPhase * Math.PI * 2)));
    return {
      walkPhase: walkPhase, runPhase: runPhase,
      phase: mix > 0.5 ? runPhase : walkPhase,
      runBlend: mix, legs: legs, bounce: bounce,
      bodyPitch: -0.04 * (1 - mix) + 0.08 * mix * Math.sin(runPhase * Math.PI * 2 - 0.45)
    };
  };
  S.sampleRiderMotion = function(state) {
    var tau = Math.PI * 2;
    function phase(v) { return Number.isFinite(v) ? ((v % 1) + 1) % 1 : 0; }
    function weight(v) { return Number.isFinite(v) ? Math.max(0, Math.min(1, v)) : 0; }
    var w = phase(state.walkPhase) * tau, r = phase(state.runPhase) * tau;
    var ww = weight(state.walkWeight), rw = weight(state.runWeight), total = Math.max(1, ww + rw);
    ww /= total; rw /= total;
    var walk = {
      seatLift: 0.006 + 0.006 * Math.cos(w * 2), seatForward: 0.007 * Math.sin(w * 2 - 0.25),
      pelvisPitch: 0.018 * Math.sin(w * 2 - 0.3), pelvisRoll: 0.015 * Math.sin(w),
      lean: 0.045 + 0.008 * Math.sin(w * 2 - 0.6), torsoRoll: -0.006 * Math.sin(w - 0.22),
      headPitch: -0.018 - 0.006 * Math.sin(w * 2 - 0.6), clothSway: 0.012 * Math.sin(w - 0.45)
    };
    var gallopRock = Math.sin(r - tau * 0.10), gallopLean = 0.055 * Math.sin(r - tau * 0.12);
    var run = {
      seatLift: 0.05 + 0.025 * Math.cos(r - tau * 0.40), seatForward: 0.018 + 0.016 * Math.sin(r - tau * 0.16),
      pelvisPitch: 0.045 * gallopRock, pelvisRoll: 0.012 * Math.sin(r + 0.35),
      lean: 0.32 + gallopLean, torsoRoll: -0.007 * Math.sin(r + 0.1),
      headPitch: -0.12 - 0.65 * gallopLean, clothSway: 0.025 * Math.sin(r - 0.65)
    };
    var out = {};
    Object.keys(walk).forEach(function(key) { out[key] = walk[key] * ww + run[key] * rw; });
    var bank = Number.isFinite(state.bank) ? state.bank : 0;
    out.headRoll = -0.45 * out.torsoRoll - 0.5 * bank;
    out.torsoRoll += 0.12 * bank;
    return out;
  };
})();

