
/* SOLMOB-BUILD-VER 2 */

/* ============================================================
   SOLMOB — مجسمات الوحوش ثلاثية الأبعاد (كائنات حقيقية بالمعركة)
   وحوش البركة والزعماء يظهرون كمخلوقات 3D متحركة حسب نوعهم:
   وحش رباع • طائر • أفعى • عنكبوت/عقرب • وحل • شبح/روح • نبات
   تمثال/معدن • غول • عين طائفة • فم الهاوية.
   الأبطال يبقون على مجسماتهم FBX — والبشر من الوحوش أيضًا.
   ============================================================ */
(function () {
  "use strict";
  if (window.SOLMOB) return;

  /* ==================== بناء الهندسة ==================== */
  function GB() { this.v = []; this.i = []; this.n = 0; }
  GB.prototype.quad = function (a, b, c, d, col) {
    var V = this.v, I = this.i, n0 = this.n;
    V.push(a[0], a[1], a[2], col[0], col[1], col[2],
      b[0], b[1], b[2], col[0], col[1], col[2],
      c[0], c[1], c[2], col[0], col[1], col[2],
      d[0], d[1], d[2], col[0], col[1], col[2]);
    I.push(n0, n0 + 1, n0 + 2, n0, n0 + 2, n0 + 3);
    this.n += 4;
  };
  GB.prototype.box = function (cx, cy, cz, w, h, d, rgb, ry, rx, rz) {
    ry = ry || 0; rx = rx || 0; rz = rz || 0;
    var A = Math.cos(ry), B = Math.sin(ry), C = Math.cos(rx), D = Math.sin(rx), E = Math.cos(rz), F = Math.sin(rz);
    var x0 = -w / 2, x1 = w / 2, y0 = -h / 2, y1 = h / 2, z0 = -d / 2, z1 = d / 2, self = this;
    function rot(p) {
      var x = p[0], y = p[1], z = p[2];
      var y1 = y * C - z * D, z1 = y * D + z * C;
      var x2 = x * A + z1 * B, z2 = -x * B + z1 * A;
      var x3 = x2 * E - y1 * F, y3 = x2 * F + y1 * E;
      return [cx + x3, cy + y3, cz + z2];
    }
    function sh(k) { return [Math.min(1.3, rgb[0] * k), Math.min(1.3, rgb[1] * k), Math.min(1.3, rgb[2] * k)]; }
    var a, b, c, d2;
    a = [x0, y1, z1]; b = [x1, y1, z1]; c = [x1, y1, z0]; d2 = [x0, y1, z0]; self.quad(rot(a), rot(b), rot(c), rot(d2), sh(1.18));
    a = [x0, y0, z0]; b = [x1, y0, z0]; c = [x1, y0, z1]; d2 = [x0, y0, z1]; self.quad(rot(a), rot(b), rot(c), rot(d2), sh(0.45));
    a = [x0, y0, z1]; b = [x1, y0, z1]; c = [x1, y1, z1]; d2 = [x0, y1, z1]; self.quad(rot(a), rot(b), rot(c), rot(d2), sh(1.0));
    a = [x1, y0, z0]; b = [x0, y0, z0]; c = [x0, y1, z0]; d2 = [x1, y1, z0]; self.quad(rot(a), rot(b), rot(c), rot(d2), sh(0.62));
    a = [x1, y0, z1]; b = [x1, y0, z0]; c = [x1, y1, z0]; d2 = [x1, y1, z1]; self.quad(rot(a), rot(b), rot(c), rot(d2), sh(0.82));
    a = [x0, y0, z0]; b = [x0, y0, z1]; c = [x0, y1, z1]; d2 = [x0, y1, z0]; self.quad(rot(a), rot(b), rot(c), rot(d2), sh(0.82));
  };

  function hx(h) {
    h = String(h || "#888").replace("#", "");
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var v = parseInt(h, 16);
    return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
  }
  function mixc(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }

  /* ==================== حركة مساعدة ==================== */
  function easeO(q) { q = Math.max(0, Math.min(1, q)); return 1 - (1 - q) * (1 - q); }
  function clamp01(q) { return Math.max(0, Math.min(1, q)); }
  function env(t, a, b) { return clamp01((t - a) / (b - a)); }
  function bell(t, a, b) { return Math.sin(Math.PI * clamp01((t - a) / (b - a))); }
  /* موت عام: سقوط على الجنب ثم ثبات */
  function dieFall(side) {
    return function (t) {
      var e = easeO(t / 0.55);
      return { g: [0, 9, 0], rz: (1.32 * (side || 1)) * e, oy: -5 * e, rx: 0.12 * e };
    };
  }
  /* ارتداد عند الإصابة */
  function hitRecoil() {
    return function (t) { return { oz: -7 * bell(t, 0, 0.5), rx: -0.22 * bell(t, 0, 0.5) }; };
  }

  /* ==================== تعريف جزء ==================== */
  function Part(piv, anims) { this.piv = piv; this.a = anims || {}; this.gb = new GB(); this.nv = 0; this.v = null; this.c = null; }
  Part.prototype.fin = function () {
    this.nv = this.gb.n;
    this.v = new Float32Array(this.gb.v.length / 2); /* xyz فقط */
    this.c = new Float32Array(this.gb.v.length / 2); /* rgb فقط */
    for (var i = 0, j = 0; j < this.gb.v.length; i += 3, j += 6) {
      this.v[i] = this.gb.v[j]; this.v[i + 1] = this.gb.v[j + 1]; this.v[i + 2] = this.gb.v[j + 2];
      this.c[i] = this.gb.v[j + 3]; this.c[i + 1] = this.gb.v[j + 4]; this.c[i + 2] = this.gb.v[j + 5];
    }
    this.idx = this.gb.i; this.gb = null; return this;
  };
  function pt(piv, anims) { return new Part(piv, anims); }

  /* ==================== لوحات الألوان ==================== */
  var PAL = {
    beast: { fur: "#7d6146", fur2: "#5c4632", belly: "#b39873", dark: "#3a2b1c", tooth: "#efe6d2", claw: "#d8cfa8", mouth: "#8a2b2b" },
    bird: { body: "#4a5568", wing: "#39424f", belly: "#8a94a2", beak: "#e0a040", dark: "#23282f", eye: "#ffd35a" },
    serpent: { skin: "#4a7a3a", skin2: "#385e2c", belly: "#c9bd8a", dark: "#243d1c", fang: "#efe6d2", mouth: "#7a2424", hood: "#8a6a2a" },
    spider: { body: "#4a3a52", body2: "#382c40", leg: "#2e2436", eye: "#ff5a5a", mark: "#c9a0e0", dark: "#241c2c" },
    scorp: { body: "#8a5a2a", body2: "#6a4420", claw: "#a06a30", sting: "#e0a040", dark: "#3d2a14", eye: "#ffd35a" },
    slime: { body: "#7a5a3a", body2: "#6a4c30", hi: "#a88a5a", core: "#e0b060", dark: "#3d2c1c", eye: "#241a10" },
    wraith: { robe: "#3a3550", robe2: "#2c2840", hood: "#46406a", dark: "#1a1826", eye: "#7fe0ff", claw: "#b060ff" },
    plant: { stalk: "#4a7a3a", stalk2: "#3a5e2c", leaf: "#5e9a44", petal: "#c94a6a", petal2: "#e0c75e", core: "#ffd35a", dark: "#243d1c" },
    golem: { rock: "#8a8a92", rock2: "#6e6e76", dark: "#4a4a52", crack: "#ffb84a", moss: "#5a8a3a", eye: "#ffb84a" },
    ogre: { skin: "#7a9a5a", skin2: "#5e7a44", belly: "#9ab074", dark: "#3d4a2a", tusk: "#efe6d2", club: "#6a4a2a", club2: "#54391c", eye: "#ff5a3a", armor: "#8a6a2a" },
    eye: { ball: "#e8e4d8", ball2: "#c9c4b4", iris: "#c94a3a", pupil: "#181818", vein: "#c94a5a", tend: "#a89888", tend2: "#8a7a6a" },
    maw: { skin: "#8a3a4a", skin2: "#6a2a38", tooth: "#efe6d2", tongue: "#c94a5a", dark: "#3d1a22", eye: "#ffd35a", spike: "#d8cfa8" }
  };
  /* تعديلات لقب الوحش: تنويع لوني داخل النوع نفسه */
  var EPI = [
    [/الغاضب/, function (c) { return [Math.min(1.25, c[0] * 1.24), c[1] * 0.84, c[2] * 0.84]; }],
    [/القديم|العجوز/, function (c) { var g = (c[0] + c[1] + c[2]) / 3; return mixc(c, [g, g, g], 0.45); }],
    [/المنسي/, function (c) { return [c[0] * 0.68, c[1] * 0.68, c[2] * 0.72]; }],
    [/المتوحش/, function (c) { return [Math.min(1.2, c[0] * 1.12), c[1] * 1.04, c[2] * 0.78]; }],
    [/السريع/, function (c) { return [Math.min(1.25, c[0] * 1.14), Math.min(1.25, c[1] * 1.14), Math.min(1.25, c[2] * 1.14)]; }],
    [/الجائع/, function (c) { return [Math.min(1.2, c[0] * 1.16), c[1] * 0.9, c[2] * 0.9]; }],
    [/المسحور/, function (c) { return mixc(c, [0.24, 0.72, 0.66], 0.3); }],
    [/الغائب/, function (c) { return mixc(c, [0.9, 0.94, 1.0], 0.35); }],
    [/الصامت/, function (c) { return [c[0] * 0.78, c[1] * 0.78, c[2] * 0.82]; }],
    [/القاسي/, function (c) { return [Math.min(1.25, c[0] * 1.18), c[1] * 0.92, c[2] * 0.92]; }],
    [/البارد/, function (c) { return [c[0] * 0.82, c[1] * 0.92, Math.min(1.25, c[2] * 1.24)]; }],
    [/الأعمى/, function (c) { var g = (c[0] + c[1] + c[2]) / 3; return mixc(c, [g, g, g], 0.3); }],
    [/الأبدي/, function (c) { return mixc(c, [0.9, 0.78, 0.38], 0.25); }]
  ];

  function hsh(str) { var h = 7; str = String(str || "x"); for (var i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0; return h; }

  /* لوحة النوع بعد التعديلات (hash + لقب) */
  function palette(kind, name) {
    var base = PAL[kind] || PAL.beast, out = {}, h = hsh(name);
    var hue = (h % 5); /* تنويع بسيط لكل اسم */
    var k, c, j;
    for (k in base) {
      c = hx(base[k]); /* تحويل hex إلى [r,g,b] */
      if (hue === 1) c = [c[0] * 1.08, c[1] * 0.96, c[2] * 0.92];
      else if (hue === 2) c = [c[0] * 0.92, c[1] * 1.06, c[2] * 0.98];
      else if (hue === 3) c = [c[0] * 0.94, c[1] * 0.98, c[2] * 1.08];
      else if (hue === 4) c = mixc(c, [0.15, 0.13, 0.12], 0.12);
      for (j = 0; j < EPI.length; j++) { if (EPI[j][0].test(name)) { c = EPI[j][1](c); break; } }
      out[k] = [Math.min(1.25, c[0]), Math.min(1.25, c[1]), Math.min(1.25, c[2])];
    }
    return out;
  }

  /* ==================== تصنيف الوحش ==================== */
  var HUM = /راعٍ|فرسان|صيّاد|عقّار|حرّاس|قنّاص|رامي|سارق|عرّاب|ساحر|قابل|حكواتي|بائع|حامل|حاكّ|خرّاز|نجّار|كاهن|خاطف|خيّاط|ربّاب|جنديّ|جاسوس|قاتل|حطّاب|عامل|طبيب|قائد|والي|سيدة|شيخ|فارس الكثبان|أمّ|ملكة|سيد الأقنعة|عرّافة|غسّان|داية|زهراء|سدّيم|بركة|هامّة|نبراس|صقر|عاصف|هلال|مارد|رُكن|سُحّار|ظفر|غريق|نديم|سفير|حاملة|منسل|ابن السديم|همّال|متأمل|راهب|منادي|مذبح|قنّاع|قناع|بائعة|رامي الحجارة|حارس الرايات|حارس الغدير|حارس الأسرار|حارس البوابة|حارس سجين|عريف|رمّاح|حرس|حكيم|هائم|راقص|حارس/;
  /* قواعد قاطعة — كائنات لا تلبس بشرًا أبدًا */
  var RULES = [
    [/حارس الحجر|حرس الحجر|حارس الحديد|حرس الحديد|حارس الرماد/, "golem", {}],
    [/أفعى|ثعبان|حية/, "serpent", {}],
    [/تمساح/, "beast", { low: 1, snout: 2 }],
    [/ضفدع/, "beast", { squat: 1 }],
    [/سلحفاة/, "beast", { shell: 1, low: 1 }],
    [/عنكب/, "spider", {}],
    [/عقرب/, "scorp", {}],
    [/غزّال|ظبي/, "beast", { gazelle: 1 }],
    [/ثور/, "beast", { bull: 1 }],
    [/خيل|حصان/, "beast", { horse: 1 }],
    [/أسد|نمر|جاغوار|ذيب|ذئب|كلب|جربو|فأر|جرذ|ثعلب/, "beast", {}],
    [/حرباء|سحلية/, "beast", { lizard: 1 }],
    [/وحش|قنطور/, "beast", { bulk: 1 }],
    [/نسر|طائر|غراب|عصفور|ببغاء|طاووس|عنقاء|نسور|طوط/, "bird", {}],
    [/زهرة|نخلة|كرمة|شجرة|ورد|لوتس/, "plant", {}],
    [/عين/, "eye", {}],
    [/فم/, "maw", {}],
    [/مطرقة/, "golem", {}],
    [/عملاق الطوب|عملاق الغبار|تمثال|جرس|ساعة|ساعاتي|قلب/, "golem", {}],
    [/وحل|سلايم|طفح|موج|نبض|حمأ|طيني/, "slime", {}],
    [/غول|عملاق|طاغية|همّاج|إفريت|عفريت/, "ogre", {}]
  ];
  /* قواعد مرنة — تُطبق على غير البشر (أرواح وأشباح) */
  var RULES_SOFT = [
    [/روح|شبح|طيف|سديم|همس|صدى|أسطورة|قادم|رمادي|هيّة|ظل|قمر الواحة|دوّامة|الشفق|زوبعة/, "wraith", {}]
  ];
  function classify(name) {
    var n = String(name || "");
    var i;
    if (/عرّاب الخيل|حامل المطرقة/.test(n)) return null; /* بشر مميزون */
    for (i = 0; i < RULES.length; i++) {
      if (RULES[i][0].test(n)) return { a: RULES[i][1], v: RULES[i][2] };
    }
    if (HUM.test(n)) return null; /* بشر — يرسمهم SOLFBX */
    for (i = 0; i < RULES_SOFT.length; i++) {
      if (RULES_SOFT[i][0].test(n)) return { a: RULES_SOFT[i][1], v: RULES_SOFT[i][2] };
    }
    return { a: "beast", v: {} }; /* الافتراضي: وحش رباع */
  }

  /* ==================== مكتبة حركات مشتركة ==================== */
  var CLIPS = ["idle", "atk", "cast", "hit", "die"];
  var DUR = { idle: 2.6, atk: 0.9, cast: 1.0, hit: 0.5, die: 1.15 };

  /* ==================== بناة الأنواع ==================== */
  /* كل باني يعيد { parts:[...], h: الارتفاع } — الواجهة: الأمام نحو +Z، القدم عند y=0 */
  var BUILDERS = {};

  /* ---------- وحش رباعي: ذئب/ثور/حصان/تمساح/غزّال ---------- */
  BUILDERS.beast = function (C, rnd, boss, V) {
    var bull = V.bull, horse = V.horse, gaz = V.gazelle, low = V.low, squat = V.squat, shell = V.shell, lizard = V.lizard, bulk = V.bulk;
    var legH = squat ? 13 : (low ? 15 : (gaz || horse ? 26 : 21));
    var by = legH + (bulk ? 11 : 10);          /* مركز الجسم */
    var bw = bulk ? 28 : (gaz || horse ? 19 : 23);
    var bh = bulk ? 24 : (gaz || horse ? 18 : 20);
    var bl = bulk ? 46 : (low ? 58 : 42);      /* طول الجسم */
    var parts = [], p;
    var dieA = dieFall(1);
    var A_LEGS = [[8, bl * 0.3], [-8, bl * 0.3], [8, -bl * 0.28], [-8, -bl * 0.28]];
    var li, sx2;
    /* الجسم */
    var body = pt([0, by, 0], {
      idle: function (t) { return { oy: Math.sin(t * 2.1) * 1.3, rx: Math.sin(t * 2.1 + 1) * 0.02 }; },
      atk: function (t) { return { oy: -3 * bell(t, 0, 0.3) + 9 * bell(t, 0.3, 0.72), oz: 9 * env(t, 0.3, 0.7) - 9 * env(t, 0.7, 0.9), rx: -0.22 * bell(t, 0.3, 0.72) }; },
      cast: function (t) { return { oy: 7 * bell(t, 0, 1.0), rx: -0.3 * bell(t, 0.1, 0.9) }; },
      hit: hitRecoil(),
      die: dieA
    });
    body.gb.box(0, by, 0, bw, bh, bl, C.fur);
    body.gb.box(0, by - bh * 0.3, 1, bw * 0.78, bh * 0.42, bl * 0.8, C.belly);
    if (bulk) body.gb.box(0, by + 4, bl * 0.16, bw * 1.04, bh * 0.9, bl * 0.34, C.fur2);
    if (shell) {
      body.gb.box(0, by + bh * 0.55, 0, bw * 1.05, bh * 0.62, bl * 0.82, C.fur2, 0, 0, 0);
      body.gb.box(0, by + bh * 0.55, bl * 0.2, bw * 0.9, bh * 0.3, 6, C.dark);
    }
    if (lizard || low) {
      body.gb.box(0, by + 2, bl * 0.3, bw * 0.9, bh * 0.62, bl * 0.3, C.fur2);
    }
    parts.push(body.fin());
    /* الرأس + الفك */
    var headY = by + bh * 0.55 + (bull || bulk ? 4 : 2), headZ = bl * 0.5 - 2;
    var hy = squat ? by + 10 : headY;
    var jaw = pt([0, hy - 4, headZ - 4], {
      idle: function (t) { return { rx: Math.max(0, Math.sin(t * 1.3)) * 0.06 }; },
      atk: function (t) { return { rx: 0.85 * bell(t, 0.28, 0.78) }; },
      cast: function (t) { return { rx: 0.4 * bell(t, 0.2, 0.9) }; },
      die: dieA
    });
    jaw.gb.box(0, hy - 8, headZ + 6, bw * 0.36, 5, 14, C.dark);
    jaw.gb.box(0, hy - 6, headZ + 11, bw * 0.2, 4, 4, C.tooth);
    parts.push(jaw.fin());
    var head = pt([0, hy, headZ - 4], {
      idle: function (t) { return { oy: Math.sin(t * 2.1 + 0.6) * 1.6, ry: Math.sin(t * 0.9) * 0.12 }; },
      atk: function (t) { return { rx: -0.5 * bell(t, 0.3, 0.75), oy: 2 * bell(t, 0.3, 0.75) }; },
      cast: function (t) { return { rx: -0.42 * bell(t, 0.15, 0.9), oy: 3 * bell(t, 0.1, 0.9) }; },
      hit: function (t) { return { rx: 0.3 * bell(t, 0, 0.5), oz: -4 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    var hs = (bull || bulk) ? 19 : 16;
    head.gb.box(0, hy + 3, headZ + 6, hs, hs * 0.82, 17, C.fur);
    head.gb.box(0, hy + (low ? -1 : 0), headZ + 13, (V.snout === 2 ? bw * 0.3 : 9), hs * 0.42, (V.snout === 2 ? 16 : 11), C.fur2);
    head.gb.box(-hs * 0.28, hy + 7.5, headZ + 11, 2.6, 2.6, 2.2, boss ? [1, 0.2, 0.2] : C.dark);
    head.gb.box(hs * 0.28, hy + 7.5, headZ + 11, 2.6, 2.6, 2.2, boss ? [1, 0.2, 0.2] : C.dark);
    if (!low) {
      head.gb.box(-hs * 0.3, hy + hs * 0.62 + 3, headZ + 3, 4.5, 8, 3.5, C.fur2, 0, 0, 0.25);
      head.gb.box(hs * 0.3, hy + hs * 0.62 + 3, headZ + 3, 4.5, 8, 3.5, C.fur2, 0, 0, -0.25);
    }
    if (bull) {
      head.gb.box(-hs * 0.5, hy + hs * 0.6 + 6, headZ + 2, 3.5, 12, 3.5, C.claw, 0, 0, 0.65);
      head.gb.box(hs * 0.5, hy + hs * 0.6 + 6, headZ + 2, 3.5, 12, 3.5, C.claw, 0, 0, -0.65);
    }
    if (boss) {
      head.gb.box(0, hy + hs * 0.75 + 6, headZ + 4, 15, 3.5, 13, [0.85, 0.68, 0.25]);
      head.gb.box(-6, hy + hs * 0.75 + 10, headZ + 4, 3, 7, 3, [0.85, 0.68, 0.25]);
      head.gb.box(6, hy + hs * 0.75 + 10, headZ + 4, 3, 7, 3, [0.85, 0.68, 0.25]);
    }
    parts.push(head.fin());
    /* الأرجل الأربع */
    for (li = 0; li < 4; li++) {
      (function (i2) {
        var lx = A_LEGS[i2][0] * (bw / 23), lz = A_LEGS[i2][1];
        var ph = i2 * 1.7;
        var leg = pt([lx, legH + 2, lz], {
          idle: function (t) { return { rx: Math.sin(t * 2.1 + ph) * 0.05 }; },
          atk: function (t) { return { rx: (i2 < 2 ? -0.5 : 0.45) * bell(t, 0.3, 0.75) }; },
          hit: function (t) { return { rx: -0.2 * bell(t, 0, 0.5) }; },
          die: dieA
        });
        leg.gb.box(lx, legH / 2 + 1, lz, bw * 0.3, legH, bw * 0.28, C.fur2);
        leg.gb.box(lx, 2, lz + 1.5, bw * 0.32, 4, bw * 0.34, C.dark);
        if (bull || bulk) leg.gb.box(lx, legH * 0.55, lz, bw * 0.36, legH * 0.5, bw * 0.34, C.fur2);
        parts.push(leg.fin());
      })(li);
    }
    /* الذيل */
    var tail = pt([0, by + 4, -bl * 0.5], {
      idle: function (t) { return { ry: Math.sin(t * 2.6) * 0.4, rx: 0.15 + Math.sin(t * 1.7) * 0.1 }; },
      atk: function (t) { return { ry: Math.sin(t * 9) * 0.5, rx: -0.35 * bell(t, 0.3, 0.8) }; },
      die: dieA
    });
    var tl = gaz ? 26 : 20;
    tail.gb.box(0, -4, -tl * 0.45, 6, 6, tl, C.fur2, 0, gaz ? 0.5 : 0.3);
    if (low) tail.gb.box(0, -2, -tl * 0.9, 4, 4, tl * 0.5, C.dark, 0, 0.4);
    parts.push(tail.fin());
    return { parts: parts, h: hy + hs * 1.2 + 8 };
  };

  /* ---------- طائر: نسر/غراب/عصفور ---------- */
  BUILDERS.bird = function (C, rnd, boss) {
    var parts = [];
    var dieA = dieFall(1);
    var big = boss ? 1.35 : 1;
    var by = 30 * big;
    var body = pt([0, by, 0], {
      idle: function (t) { return { oy: Math.sin(t * 2.3) * 2.2, rx: Math.sin(t * 2.3 + 1.2) * 0.05 }; },
      atk: function (t) { return { rx: -0.5 * bell(t, 0.05, 0.4) + 0.4 * bell(t, 0.45, 0.85), oy: 10 * bell(t, 0.1, 0.5) - 6 * bell(t, 0.5, 0.9), oz: 10 * env(t, 0.35, 0.8) - 10 * env(t, 0.8, 0.95) }; },
      cast: function (t) { return { rx: -0.45 * bell(t, 0.1, 0.9), oy: 8 * bell(t, 0.05, 1.0) }; },
      hit: hitRecoil(),
      die: dieA
    });
    body.gb.box(0, by, 0, 17, 17, 25 * big, C.body);
    body.gb.box(0, by - 4, 3, 12, 10, 18 * big, C.belly);
    body.gb.box(0, by + 5, -14 * big, 9, 4, 15 * big, C.wing, 0, -0.4);
    body.gb.box(0, by + 7, -20 * big, 5, 3, 9 * big, C.wing, 0, -0.8);
    parts.push(body.fin());
    var head = pt([0, by + 9, 7], {
      idle: function (t) { return { ry: Math.sin(t * 1.4) * 0.3, oy: Math.sin(t * 2.3) * 2.2 }; },
      atk: function (t) { return { rx: -0.4 * bell(t, 0.05, 0.45) + 0.5 * bell(t, 0.45, 0.9), oy: 10 * bell(t, 0.1, 0.5) - 6 * bell(t, 0.5, 0.9) }; },
      cast: function (t) { return { rx: -0.3 * bell(t, 0.1, 0.9), oy: 8 * bell(t, 0.05, 1.0) }; },
      hit: function (t) { return { rx: 0.35 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    head.gb.box(0, by + 14, 9, 12, 11, 12, C.body);
    head.gb.box(0, by + 12, 16, 5.5, 4.5, 10, C.beak, 0, 0.08);
    head.gb.box(-3.6, by + 16, 14.5, 2.4, 2.4, 2, C.dark);
    head.gb.box(3.6, by + 16, 14.5, 2.4, 2.4, 2, C.dark);
    head.gb.box(-4, by + 19, 7, 3, 5, 4, C.wing, 0, 0, 0.3);
    head.gb.box(4, by + 19, 7, 3, 5, 4, C.wing, 0, 0, -0.3);
    if (boss) {
      head.gb.box(0, by + 22, 8, 14, 3.5, 12, [0.85, 0.68, 0.25]);
      head.gb.box(-5, by + 26, 8, 3, 7, 3, [0.85, 0.68, 0.25]);
      head.gb.box(5, by + 26, 8, 3, 7, 3, [0.85, 0.68, 0.25]);
    }
    parts.push(head.fin());
    /* جناحان */
    var W = [[-8.5, 1], [8.5, -1]];
    for (var wi = 0; wi < 2; wi++) {
      (function (i2) {
        var sd = W[i2][1], px = W[i2][0];
        var wing = pt([px, by + 6, 2], {
          idle: function (t) { return { rz: sd * Math.sin(t * 3.0) * 0.3 }; },
          atk: function (t) { return { rz: sd * (0.85 * bell(t, 0.05, 0.45) - 0.9 * bell(t, 0.45, 0.9)), rx: -0.3 * bell(t, 0.4, 0.8) }; },
          cast: function (t) { return { rz: sd * 0.55 * bell(t, 0.1, 1.0) }; },
          hit: function (t) { return { rz: sd * 0.35 * bell(t, 0, 0.5) }; },
          die: function (t) { var e = easeO(t / 0.5); return { g: [0, 9, 0], rz: 1.32 * e, oy: -5 * e, rz2: 0 }; }
        });
        wing.gb.box(px + sd * 9, by + 7, 0, 20, 3.2, 15 * big, C.wing, 0, 0, -sd * 0.18);
        wing.gb.box(px + sd * 19, by + 8.5, -2, 14, 2.6, 11 * big, C.wing, 0, 0, -sd * 0.4);
        wing.gb.box(px + sd * 6, by + 9, -10 * big, 12, 2.4, 10 * big, C.wing, 0, -0.5, -sd * 0.1);
        parts.push(wing.fin());
      })(wi);
    }
    /* قدمان */
    for (var fi = 0; fi < 2; fi++) {
      (function (i2) {
        var lx = (i2 === 0 ? -5 : 5);
        var leg = pt([lx, 14 * big, 0], {
          idle: function (t) { return {}; },
          atk: function (t) { return { rx: -0.7 * bell(t, 0.3, 0.8) }; },
          die: dieA
        });
        leg.gb.box(lx, 8 * big, 0, 3.4, 16 * big, 3.4, C.beak);
        leg.gb.box(lx, 2.2, 3, 4.6, 3, 9, C.beak);
        parts.push(leg.fin());
      })(fi);
    }
    return { parts: parts, h: by + 30 };
  };

  /* ---------- أفعى ---------- */
  BUILDERS.serpent = function (C, rnd, boss) {
    var parts = [];
    var dieA = dieFall(1);
    var S = boss ? 1.3 : 1;
    var base = pt([0, 5, -2], {
      idle: function (t) { return { ry: Math.sin(t * 1.8) * 0.08 }; },
      atk: function (t) { return { rx: 0.1 * bell(t, 0.3, 0.7) }; },
      die: dieA
    });
    base.gb.box(0, 5, -6 * S, 24 * S, 10, 20 * S, C.skin2, 0.5);
    base.gb.box(0, 5, 4 * S, 20 * S, 10, 16 * S, C.skin2, -0.6);
    base.gb.box(0, 7, -14 * S, 16 * S, 8, 12 * S, C.dark, 0.9);
    parts.push(base.fin());
    /* فقرات الجسم المتلوية */
    var segs = [
      { y: 12, z: 8, w: 14, h: 13, ph: 0 },
      { y: 18, z: 2, w: 13, h: 12, ph: 1.1 },
      { y: 22, z: -6, w: 12, h: 11, ph: 2.2 },
      { y: 24, z: -14, w: 9, h: 8, ph: 3.3 }
    ];
    for (var si = 0; si < segs.length; si++) {
      (function (i2) {
        var g = segs[i2];
        var seg = pt([0, g.y * S, (g.z + 6) * S], {
          idle: function (t) { return { ry: Math.sin(t * 2.2 - i2 * 0.9) * 0.2, oy: Math.sin(t * 2.2 - i2 * 0.9) * 1.2 }; },
          atk: function (t) { return { ry: Math.sin(t * 2.2 - i2 * 0.9) * 0.2, rx: -0.18 * bell(t, 0.25, 0.75), oy: 3 * bell(t, 0.25, 0.75) }; },
          hit: hitRecoil(),
          die: dieA
        });
        seg.gb.box(0, g.y * S + 4, g.z * S, g.w * S, g.h * S, 17 * S, C.skin, 0, 0, 0);
        seg.gb.box(0, (g.y - g.h * 0.35) * S + 4, g.z * S, g.w * 0.72 * S, g.h * 0.4 * S, 15 * S, C.belly);
        parts.push(seg.fin());
      })(si);
    }
    /* الرأس + النابان */
    var head = pt([0, 26 * S, 12 * S], {
      idle: function (t) { return { ry: Math.sin(t * 2.2 - 3.6) * 0.3, oy: Math.sin(t * 2.2 + 0.5) * 1.6, rx: Math.sin(t * 1.6) * 0.08 }; },
      atk: function (t) { return { rx: 0.55 * bell(t, 0, 0.3) - 1.0 * bell(t, 0.3, 0.62), oz: 16 * bell(t, 0.3, 0.7), oy: 5 * bell(t, 0, 0.3) - 4 * bell(t, 0.3, 0.7) }; },
      cast: function (t) { return { rx: -0.5 * bell(t, 0.1, 0.95), oy: 7 * bell(t, 0.05, 1.0) }; },
      hit: function (t) { return { rx: 0.4 * bell(t, 0, 0.5), oz: -6 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    head.gb.box(0, 30 * S, 6 * S, 14 * S, 12 * S, 15 * S, C.skin);
    head.gb.box(0, 27 * S, 13 * S, 10 * S, 6 * S, 10 * S, C.skin2);
    head.gb.box(-4.5 * S, 33 * S, 12 * S, 3, 3, 2.5, boss ? [1, 0.15, 0.15] : [1, 0.85, 0.2]);
    head.gb.box(4.5 * S, 33 * S, 12 * S, 3, 3, 2.5, boss ? [1, 0.15, 0.15] : [1, 0.85, 0.2]);
    head.gb.box(-3 * S, 26.5 * S, 15 * S, 2, 5, 2.5, C.fang);
    head.gb.box(3 * S, 26.5 * S, 15 * S, 2, 5, 2.5, C.fang);
    head.gb.box(0, 29.5 * S, 20 * S, 2.2, 1.6, 7, C.mouth);
    if (boss) {
      head.gb.box(-8 * S, 36 * S, 4 * S, 3.5, 11, 3.5, [0.85, 0.68, 0.25], 0, 0, 0.5);
      head.gb.box(8 * S, 36 * S, 4 * S, 3.5, 11, 3.5, [0.85, 0.68, 0.25], 0, 0, -0.5);
      head.gb.box(0, 37 * S, 6 * S, 13, 3, 12, [0.85, 0.68, 0.25]);
    }
    parts.push(head.fin());
    /* قلنسوة كوبرا */
    var hood = pt([0, 26 * S, 12 * S], {
      idle: function (t) { return { ry: Math.sin(t * 2.2 - 3.6) * 0.3, oy: Math.sin(t * 2.2 + 0.5) * 1.6 }; },
      atk: function (t) { return { rx: 0.55 * bell(t, 0, 0.3) - 1.0 * bell(t, 0.3, 0.62), oz: 16 * bell(t, 0.3, 0.7), oy: 5 * bell(t, 0, 0.3) - 4 * bell(t, 0.3, 0.7) }; },
      cast: function (t) { return { rx: -0.5 * bell(t, 0.1, 0.95), oy: 7 * bell(t, 0.05, 1.0) }; },
      die: dieA
    });
    hood.gb.box(0, 31 * S, 2 * S, 21 * S, 15 * S, 3.5, C.hood, 0, -0.15);
    hood.gb.box(0, 31 * S, 2 * S, 15 * S, 10 * S, 4, C.skin2, 0, -0.15);
    parts.push(hood.fin());
    return { parts: parts, h: 46 * S };
  };

  /* ---------- عنكبوت / عقرب ---------- */
  BUILDERS.spider = function (C, rnd, boss) {
    var parts = [];
    var dieA = dieFall(1);
    var S = boss ? 1.25 : 1;
    var abd = pt([0, 20 * S, -9 * S], {
      idle: function (t) { return { oy: Math.sin(t * 2.4) * 1.5, rx: Math.sin(t * 2.4 + 0.8) * 0.03 }; },
      atk: function (t) { return { rx: -0.25 * bell(t, 0.25, 0.8), oy: 3 * bell(t, 0.25, 0.8) }; },
      hit: hitRecoil(),
      die: dieA
    });
    abd.gb.box(0, 23 * S, -10 * S, 25 * S, 21 * S, 24 * S, C.body);
    abd.gb.box(0, 28 * S, -10 * S, 13 * S, 7 * S, 14 * S, C.mark, Math.PI / 4);
    abd.gb.box(0, 20 * S, -22 * S, 8 * S, 7 * S, 6 * S, C.body2);
    parts.push(abd.fin());
    var head = pt([0, 20 * S, 8 * S], {
      idle: function (t) { return { oy: Math.sin(t * 2.4 + 0.4) * 1.2, ry: Math.sin(t * 1.1) * 0.15 }; },
      atk: function (t) { return { rx: -0.4 * bell(t, 0.3, 0.75), oz: 7 * bell(t, 0.3, 0.75), oy: 2 * bell(t, 0.3, 0.75) }; },
      cast: function (t) { return { rx: -0.35 * bell(t, 0.1, 0.95) }; },
      hit: function (t) { return { oz: -5 * bell(t, 0, 0.5), rx: 0.25 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    head.gb.box(0, 20 * S, 8 * S, 18 * S, 15 * S, 17 * S, C.body2);
    head.gb.box(0, 21 * S, 17 * S, 12 * S, 10 * S, 8 * S, C.body);
    head.gb.box(-3.4 * S, 23 * S, 21 * S, 2.6, 2.6, 2, C.eye);
    head.gb.box(3.4 * S, 23 * S, 21 * S, 2.6, 2.6, 2, C.eye);
    head.gb.box(-1.6 * S, 19 * S, 21 * S, 2, 2, 2, C.eye);
    head.gb.box(1.6 * S, 19 * S, 21 * S, 2, 2, 2, C.eye);
    head.gb.box(-2.6 * S, 15.5 * S, 21 * S, 2.6, 5, 2.6, C.dark);
    head.gb.box(2.6 * S, 15.5 * S, 21 * S, 2.6, 5, 2.6, C.dark);
    if (boss) {
      head.gb.box(0, 28 * S, 14 * S, 12, 3, 11, [0.85, 0.68, 0.25]);
    }
    parts.push(head.fin());
    /* 8 أرجل */
    var LZ = [9 * S, 3 * S, -4 * S, -10 * S];
    for (var li = 0; li < 8; li++) {
      (function (i2) {
        var sd = i2 < 4 ? -1 : 1, k = i2 % 4;
        var lx = sd * 9 * S, lz = LZ[k];
        var ph = (k * 1.6) + (sd > 0 ? Math.PI : 0);
        var leg = pt([lx, 22 * S, lz], {
          idle: function (t) { return { rz: sd * (0.18 + Math.sin(t * 2.8 + ph) * 0.1), rx: Math.sin(t * 2.8 + ph) * 0.05 }; },
          atk: function (t) { return { rz: sd * (k === 0 ? 0.85 * bell(t, 0.25, 0.8) : 0.3 * bell(t, 0.3, 0.75)), rx: (k === 0 ? -0.5 * bell(t, 0.25, 0.8) : 0) }; },
          die: dieA
        });
        leg.gb.box(lx + sd * 10 * S, 27 * S, lz, 20 * S, 3.6, 3.6, C.leg, 0, 0, sd * 0.55);
        leg.gb.box(lx + sd * 18 * S, 14 * S, lz + (sd * 2), 3.4, 20 * S, 3.4, C.leg, 0, 0, -sd * 0.12);
        leg.gb.box(lx + sd * 19 * S, 2 * S, lz + sd * 4, 3, 5, 5, C.leg);
        parts.push(leg.fin());
      })(li);
    }
    return { parts: parts, h: 40 * S };
  };

  BUILDERS.scorp = function (C, rnd, boss) {
    var parts = [];
    var dieA = dieFall(1);
    var S = boss ? 1.25 : 1;
    var body = pt([0, 14 * S, 0], {
      idle: function (t) { return { oy: Math.sin(t * 2.2) * 1.2 }; },
      atk: function (t) { return { oz: 7 * bell(t, 0.35, 0.8), rx: -0.15 * bell(t, 0.35, 0.8) }; },
      hit: hitRecoil(),
      die: dieA
    });
    body.gb.box(0, 15 * S, 0, 20 * S, 13 * S, 26 * S, C.body);
    body.gb.box(0, 15 * S, -14 * S, 16 * S, 11 * S, 10 * S, C.body2);
    body.gb.box(0, 10 * S, 2 * S, 15 * S, 5 * S, 20 * S, C.dark);
    parts.push(body.fin());
    var head = pt([0, 15 * S, 15 * S], {
      idle: function (t) { return { oy: Math.sin(t * 2.2 + 0.5) * 1.4 }; },
      atk: function (t) { return { oz: 8 * bell(t, 0.35, 0.8) }; },
      hit: hitRecoil(),
      die: dieA
    });
    head.gb.box(0, 15 * S, 16 * S, 14 * S, 11 * S, 12 * S, C.body2);
    head.gb.box(-3 * S, 18 * S, 21 * S, 2.6, 2.6, 2, C.eye);
    head.gb.box(3 * S, 18 * S, 21 * S, 2.6, 2.6, 2, C.eye);
    parts.push(head.fin());
    /* ذيل اللاسع — سلسلة مقوّسة */
    var tail = pt([0, 18 * S, -14 * S], {
      idle: function (t) { return { ry: Math.sin(t * 1.9) * 0.25, rx: Math.sin(t * 2.2 + 1) * 0.08 }; },
      atk: function (t) { return { rx: -1.25 * bell(t, 0.3, 0.65), oy: 2 * bell(t, 0.3, 0.65), ry: 0 }; },
      cast: function (t) { return { rx: -0.7 * bell(t, 0.1, 0.95) }; },
      hit: hitRecoil(),
      die: dieA
    });
    tail.gb.box(0, 24 * S, -17 * S, 7.5 * S, 7.5 * S, 11 * S, C.body2, 0, 0.55);
    tail.gb.box(0, 31 * S, -20 * S, 7 * S, 7 * S, 10 * S, C.body2, 0, 1.0);
    tail.gb.box(0, 37 * S, -18 * S, 6.5 * S, 6.5 * S, 9 * S, C.body, 0, 1.5);
    tail.gb.box(0, 41 * S, -14 * S, 5.5 * S, 5.5 * S, 8 * S, C.body, 0, 2.1);
    tail.gb.box(0, 43 * S, -10 * S, 3.5 * S, 5 * S, 4.5 * S, C.sting, 0, 2.6);
    parts.push(tail.fin());
    /* كلبان */
    for (var ci = 0; ci < 2; ci++) {
      (function (i2) {
        var sd = i2 === 0 ? -1 : 1;
        var claw = pt([sd * 10 * S, 14 * S, 12 * S], {
          idle: function (t) { return { rx: Math.sin(t * 2.2 + sd) * 0.1 }; },
          atk: function (t) { return { rx: -0.9 * bell(t, 0.25, 0.5) + 0.7 * bell(t, 0.5, 0.8), oz: 9 * bell(t, 0.3, 0.75) }; },
          die: dieA
        });
        claw.gb.box(sd * 13 * S, 14 * S, 16 * S, 6 * S, 6 * S, 12 * S, C.claw, 0, -0.15);
        claw.gb.box(sd * 15 * S, 15 * S, 25 * S, 9 * S, 9 * S, 8 * S, C.claw);
        claw.gb.box(sd * 15 * S, 18 * S, 29 * S, 3 * S, 3.5 * S, 6 * S, C.dark, 0, 0.2);
        claw.gb.box(sd * 15 * S, 12 * S, 29 * S, 3 * S, 3.5 * S, 6 * S, C.dark, 0, -0.2);
        parts.push(claw.fin());
      })(ci);
    }
    /* 6 أرجل صغيرة */
    var LZ2 = [8 * S, 0, -8 * S];
    for (var li = 0; li < 6; li++) {
      (function (i2) {
        var sd = i2 < 3 ? -1 : 1, k = i2 % 3;
        var lx = sd * 9 * S, lz = LZ2[k], ph = k * 1.8 + (sd > 0 ? Math.PI : 0);
        var leg = pt([lx, 13 * S, lz], {
          idle: function (t) { return { rz: sd * (0.3 + Math.sin(t * 2.6 + ph) * 0.08) }; },
          die: dieA
        });
        leg.gb.box(lx + sd * 8 * S, 17 * S, lz, 16 * S, 3.2, 3.2, C.dark, 0, 0, sd * 0.5);
        leg.gb.box(lx + sd * 14 * S, 7 * S, lz, 3, 14 * S, 3, C.dark, 0, 0, -sd * 0.15);
        parts.push(leg.fin());
      })(li);
    }
    return { parts: parts, h: 50 * S };
  };

  /* ---------- وحل / سلايم ---------- */
  BUILDERS.slime = function (C, rnd, boss) {
    var parts = [];
    var S = boss ? 1.45 : 1;
    var dieA = function (t) { var e = easeO(t / 0.5); return { g: [0, 4, 0], sy: 1 - 0.82 * e, sx: 1 + 0.35 * e, sz: 1 + 0.35 * e }; };
    var blob = pt([0, 0, 0], {
      idle: function (t) { var w = Math.sin(t * 2.6); return { sx: 1 + 0.07 * w, sy: 1 - 0.07 * w, sz: 1 + 0.07 * w }; },
      atk: function (t) { return { sy: 1 - 0.32 * bell(t, 0, 0.25) + 0.25 * bell(t, 0.28, 0.62), sx: 1 + 0.2 * bell(t, 0, 0.25) - 0.16 * bell(t, 0.28, 0.62), sz: 1 + 0.2 * bell(t, 0, 0.25) - 0.16 * bell(t, 0.28, 0.62), oy: 26 * bell(t, 0.3, 0.68), oz: 8 * bell(t, 0.3, 0.75) }; },
      cast: function (t) { return { sy: 1 + 0.22 * bell(t, 0.1, 0.95), sx: 1 - 0.12 * bell(t, 0.1, 0.95), sz: 1 - 0.12 * bell(t, 0.1, 0.95) }; },
      hit: function (t) { return { sx: 1 + 0.16 * bell(t, 0, 0.5), sy: 1 - 0.16 * bell(t, 0, 0.5), sz: 1 + 0.16 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    blob.gb.box(0, 8 * S, 0, 32 * S, 16 * S, 32 * S, C.body);
    blob.gb.box(0, 19 * S, 0, 26 * S, 13 * S, 26 * S, C.body2, Math.PI / 4);
    blob.gb.box(0, 27 * S, 0, 17 * S, 11 * S, 17 * S, C.hi, 0);
    blob.gb.box(0, 32 * S, 0, 9 * S, 7 * S, 9 * S, C.hi, Math.PI / 4);
    parts.push(blob.fin());
    var core = pt([0, 0, 0], {
      idle: function (t) { return { oy: Math.sin(t * 2.2 + 1) * 2.5 * S }; },
      atk: function (t) { return { oy: 26 * bell(t, 0.3, 0.68) + 4, oz: 8 * bell(t, 0.3, 0.75) }; },
      cast: function (t) { return { oy: 10 * bell(t, 0.1, 0.95) * S }; },
      die: dieA
    });
    core.gb.box(0, 15 * S, 3 * S, 12 * S, 12 * S, 12 * S, C.core, Math.PI / 4);
    core.gb.box(0, 15 * S, 3 * S, 7 * S, 7 * S, 7 * S, [1, 0.95, 0.7], 0);
    parts.push(core.fin());
    var face = pt([0, 0, 0], {
      idle: function (t) { return { oy: Math.sin(t * 2.6) * 1 * S }; },
      atk: function (t) { return { oy: 26 * bell(t, 0.3, 0.68), oz: 8 * bell(t, 0.3, 0.75) }; },
      hit: function (t) { return { sy: 1 - 0.16 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    face.gb.box(-6.5 * S, 21 * S, 15 * S, 4.5 * S, 5.5 * S, 3, C.eye);
    face.gb.box(6.5 * S, 21 * S, 15 * S, 4.5 * S, 5.5 * S, 3, C.eye);
    face.gb.box(0, 13 * S, 15.5 * S, 9 * S, 3.2 * S, 2.5, C.eye);
    parts.push(face.fin());
    var drips = pt([0, 0, 0], {
      idle: function (t) { return {}; },
      die: dieA
    });
    drips.gb.box(-15 * S, 3 * S, -8 * S, 6 * S, 6 * S, 6 * S, C.body2);
    drips.gb.box(14 * S, 2.5 * S, 9 * S, 5 * S, 5 * S, 5 * S, C.body2, Math.PI / 4);
    drips.gb.box(-4 * S, 2.5 * S, -17 * S, 5 * S, 5 * S, 5 * S, C.body);
    parts.push(drips.fin());
    return { parts: parts, h: 38 * S };
  };

  /* ---------- شبح / روح طائفة ---------- */
  BUILDERS.wraith = function (C, rnd, boss) {
    var parts = [];
    var S = boss ? 1.3 : 1;
    function floatOy(t) { return Math.sin(t * 1.75) * 4 * S; }
    var dieA = function (t) { var e = easeO(t / 0.7); return { g: [0, 6, 0], ry: 1.6 * e, oy: -26 * e, sy: 1 - 0.45 * e, sx: 1 + 0.2 * e, sz: 1 + 0.2 * e }; };
    var head = pt([0, 0, 0], {
      idle: function (t) { return { oy: floatOy(t), ry: Math.sin(t * 1.1) * 0.18, rx: Math.sin(t * 1.3) * 0.06 }; },
      atk: function (t) { return { oy: floatOy(t) + 4 * bell(t, 0.25, 0.8), rx: 0.25 * bell(t, 0.3, 0.8), oz: 9 * bell(t, 0.3, 0.8) }; },
      cast: function (t) { return { oy: floatOy(t) + 9 * bell(t, 0.05, 1.0), rx: -0.3 * bell(t, 0.1, 0.9) }; },
      hit: hitRecoil(),
      die: dieA
    });
    head.gb.box(0, 66 * S, 0, 20 * S, 20 * S, 19 * S, C.hood);
    head.gb.box(0, 68 * S, 4 * S, 22 * S, 14 * S, 14 * S, C.hood, 0, 0.1);
    head.gb.box(0, 62 * S, 7 * S, 14 * S, 14 * S, 8 * S, C.dark);
    head.gb.box(-4 * S, 64 * S, 10 * S, 3.2, 4.5, 2.5, C.eye);
    head.gb.box(4 * S, 64 * S, 10 * S, 3.2, 4.5, 2.5, C.eye);
    if (boss) {
      head.gb.box(0, 78 * S, 0, 17 * S, 3.5, 15 * S, [0.85, 0.68, 0.25]);
      head.gb.box(-6 * S, 83 * S, 0, 3.5, 8, 3.5, [0.85, 0.68, 0.25]);
      head.gb.box(6 * S, 83 * S, 0, 3.5, 8, 3.5, [0.85, 0.68, 0.25]);
      head.gb.box(0, 84 * S, 0, 4, 6, 4, [0.85, 0.68, 0.25]);
    }
    parts.push(head.fin());
    var robe = pt([0, 0, 0], {
      idle: function (t) { return { oy: floatOy(t), rx: Math.sin(t * 1.75 + 0.5) * 0.04 }; },
      atk: function (t) { return { oy: floatOy(t) + 4 * bell(t, 0.25, 0.8), oz: 9 * bell(t, 0.3, 0.8) }; },
      cast: function (t) { return { oy: floatOy(t) + 9 * bell(t, 0.05, 1.0) }; },
      hit: hitRecoil(),
      die: dieA
    });
    robe.gb.box(0, 50 * S, 0, 24 * S, 20 * S, 16 * S, C.robe);
    robe.gb.box(0, 36 * S, 0, 28 * S, 16 * S, 18 * S, C.robe2);
    robe.gb.box(0, 44 * S, 8 * S, 10 * S, 14 * S, 3, C.robe2);
    parts.push(robe.fin());
    var tatters = pt([0, 0, 0], {
      idle: function (t) { return { oy: floatOy(t) - 2, rx: Math.sin(t * 2.2) * 0.08, ry: Math.sin(t * 1.5) * 0.1 }; },
      atk: function (t) { return { oy: floatOy(t) - 2 + 4 * bell(t, 0.25, 0.8) }; },
      die: dieA
    });
    tatters.gb.box(-9 * S, 20 * S, 2, 6 * S, 16 * S, 6 * S, C.robe2, 0, 0.06, 0.1);
    tatters.gb.box(0, 19 * S, 4, 6 * S, 14 * S, 6 * S, C.robe, 0, 0.1, -0.08);
    tatters.gb.box(9 * S, 20 * S, 0, 6 * S, 16 * S, 6 * S, C.robe2, 0, 0.05, -0.12);
    tatters.gb.box(-5 * S, 18 * S, -6 * S, 5 * S, 12 * S, 5 * S, C.dark, 0, 0.12, 0);
    tatters.gb.box(5 * S, 18 * S, -6 * S, 5 * S, 12 * S, 5 * S, C.dark, 0, 0.12, 0);
    parts.push(tatters.fin());
    /* ذراعان بمخالب */
    var ARMS = [[-15 * S, -1], [15 * S, 1]];
    for (var ai = 0; ai < 2; ai++) {
      (function (i2) {
        var px = ARMS[i2][0], sd = ARMS[i2][1];
        var arm = pt([px, 50 * S, 0], {
          idle: function (t) { return { oy: floatOy(t), rx: Math.sin(t * 1.9 + sd) * 0.08 - 0.15 }; },
          atk: function (t) { return { oy: floatOy(t), rx: -1.9 * bell(t, 0, 0.3) + 2.6 * bell(t, 0.3, 0.6), oz: 6 * bell(t, 0.3, 0.6) }; },
          cast: function (t) { return { oy: floatOy(t), rx: -2.1 * bell(t, 0.1, 1.0) }; },
          hit: function (t) { return { oy: floatOy(t) }; },
          die: dieA
        });
        arm.gb.box(px + sd * 2, 42 * S, 2, 8 * S, 20 * S, 9 * S, C.robe2, 0, 0.15);
        arm.gb.box(px + sd * 3, 30 * S, 5, 6.5 * S, 9 * S, 7 * S, C.dark);
        arm.gb.box(px + sd * 3, 24 * S, 7, 2.2, 7, 2.2, C.claw, 0, 0.3);
        arm.gb.box(px + sd * 3 - 3, 25 * S, 7, 2, 5.5, 2, C.claw, 0, 0.45);
        arm.gb.box(px + sd * 3 + 3, 25 * S, 7, 2, 5.5, 2, C.claw, 0, 0.45);
        parts.push(arm.fin());
      })(ai);
    }
    return { parts: parts, h: 84 * S };
  };

  /* ---------- نبات مفترس ---------- */
  BUILDERS.plant = function (C, rnd, boss) {
    var parts = [];
    var S = boss ? 1.3 : 1;
    var dieA = function (t) { var e = easeO(t / 0.6); return { g: [0, 8, 0], rx: 1.0 * e, oy: -6 * e, sy: 1 - 0.15 * e }; };
    var roots = pt([0, 0, 0], {
      idle: function (t) { return {}; },
      atk: function (t) { return { rx: 0.05 * bell(t, 0.25, 0.6) }; },
      die: dieA
    });
    roots.gb.box(0, 4 * S, 0, 26 * S, 8 * S, 26 * S, C.stalk2);
    roots.gb.box(-11 * S, 3 * S, 9 * S, 7 * S, 6 * S, 10 * S, C.dark, 0.5);
    roots.gb.box(11 * S, 3 * S, 9 * S, 7 * S, 6 * S, 10 * S, C.dark, -0.5);
    roots.gb.box(0, 3 * S, -12 * S, 8 * S, 6 * S, 9 * S, C.dark);
    parts.push(roots.fin());
    var stalk = pt([0, 8 * S, 0], {
      idle: function (t) { return { rx: Math.sin(t * 1.6) * 0.04, ry: Math.sin(t * 1.2) * 0.05 }; },
      atk: function (t) { return { rx: -0.3 * bell(t, 0.25, 0.65) }; },
      cast: function (t) { return { rx: -0.15 * bell(t, 0.1, 0.9), oy: 2 * bell(t, 0.1, 0.9) }; },
      hit: hitRecoil(),
      die: dieA
    });
    stalk.gb.box(0, 10 * S, 0, 10 * S, 22 * S, 10 * S, C.stalk);
    stalk.gb.box(0, 20 * S, 0, 8 * S, 10 * S, 8 * S, C.stalk2);
    parts.push(stalk.fin());
    var head = pt([0, 30 * S, 0], {
      idle: function (t) { return { ry: Math.sin(t * 1.9) * 0.14, oy: Math.sin(t * 1.6 + 0.4) * 1.5 }; },
      atk: function (t) { return { ry: 0.45 * bell(t, 0, 0.25) - 0.2 * bell(t, 0.25, 0.65), rx: -0.95 * bell(t, 0.25, 0.6) + 0.7 * bell(t, 0.6, 0.9), oz: 6 * bell(t, 0.25, 0.6) }; },
      cast: function (t) { return { oy: 5 * bell(t, 0.1, 0.95), rz: Math.sin(t * 7) * 0.15 * bell(t, 0.1, 0.95) }; },
      hit: function (t) { return { rx: 0.3 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    head.gb.box(0, 36 * S, 0, 13 * S, 13 * S, 13 * S, C.core, Math.PI / 4);
    head.gb.box(0, 36 * S, 0, 9 * S, 9 * S, 9 * S, [1, 0.9, 0.5], 0);
    var PA = [0, Math.PI / 3, 2 * Math.PI / 3, Math.PI, 4 * Math.PI / 3, 5 * Math.PI / 3];
    for (var pi = 0; pi < PA.length; pi++) {
      var a = PA[pi];
      head.gb.box(Math.sin(a) * 12 * S, 36 * S, Math.cos(a) * 12 * S, 11 * S, 4.5 * S, 9 * S, pi % 2 ? C.petal2 : C.petal, a);
    }
    if (boss) {
      head.gb.box(0, 46 * S, 0, 4, 7, 4, [0.85, 0.68, 0.25]);
      head.gb.box(-8 * S, 44 * S, 0, 3, 5, 3, [0.85, 0.68, 0.25]);
      head.gb.box(8 * S, 44 * S, 0, 3, 5, 3, [0.85, 0.68, 0.25]);
    }
    parts.push(head.fin());
    var leaves = pt([0, 16 * S, 0], {
      idle: function (t) { return { rz: Math.sin(t * 2.1) * 0.12, oy: Math.sin(t * 1.6 + 0.4) * 1.5 }; },
      atk: function (t) { return { rx: -0.4 * bell(t, 0.25, 0.6) }; },
      die: dieA
    });
    leaves.gb.box(-11 * S, 22 * S, 0, 17 * S, 3.5 * S, 8 * S, C.leaf, 0, 0, 0.35);
    leaves.gb.box(11 * S, 22 * S, 0, 17 * S, 3.5 * S, 8 * S, C.leaf, 0, 0, -0.35);
    leaves.gb.box(0, 24 * S, -10 * S, 8 * S, 3.5 * S, 14 * S, C.leaf2 || C.leaf, 0, -0.3);
    parts.push(leaves.fin());
    return { parts: parts, h: 50 * S };
  };

  /* ---------- تمثال / معدني ضخم ---------- */
  BUILDERS.golem = function (C, rnd, boss) {
    var parts = [];
    var S = boss ? 1.3 : 1;
    var dieA = function (t) { var e = easeO(t / 0.6); return { g: [0, 10, 0], rx: 1.15 * e, oy: -7 * e }; };
    var hips = pt([0, 0, 0], {
      idle: function (t) { return { rz: Math.sin(t * 1.3) * 0.02 }; },
      atk: function (t) { return { oz: 4 * bell(t, 0.35, 0.8) }; },
      hit: hitRecoil(),
      die: dieA
    });
    hips.gb.box(0, 27 * S, 0, 27 * S, 15 * S, 21 * S, C.rock2);
    hips.gb.box(0, 20 * S, 0, 22 * S, 6 * S, 18 * S, C.dark);
    parts.push(hips.fin());
    var torso = pt([0, 34 * S, 0], {
      idle: function (t) { return { oy: Math.sin(t * 1.3) * 0.9, rz: Math.sin(t * 1.1) * 0.025 }; },
      atk: function (t) { return { rx: 0.28 * bell(t, 0.3, 0.55) - 0.15 * bell(t, 0.55, 0.9), oy: -2 * bell(t, 0.5, 0.75) }; },
      cast: function (t) { return { oy: 3 * bell(t, 0.1, 0.9), rx: -0.12 * bell(t, 0.1, 0.9) }; },
      hit: hitRecoil(),
      die: dieA
    });
    torso.gb.box(0, 50 * S, 0, 33 * S, 30 * S, 25 * S, C.rock);
    torso.gb.box(-18 * S, 62 * S, 0, 11 * S, 11 * S, 13 * S, C.rock2);
    torso.gb.box(18 * S, 62 * S, 0, 11 * S, 11 * S, 13 * S, C.rock2);
    torso.gb.box(0, 44 * S, 12.6 * S, 2.5, 12 * S, 1.2, C.crack);
    torso.gb.box(4 * S, 52 * S, 12.6 * S, 2, 7 * S, 1.2, C.crack);
    torso.gb.box(0, 36 * S, 0, 26 * S, 5 * S, 20 * S, C.rock2);
    parts.push(torso.fin());
    var head = pt([0, 66 * S, 0], {
      idle: function (t) { return { oy: Math.sin(t * 1.3 + 0.3) * 0.9, ry: Math.sin(t * 0.7) * 0.15 }; },
      atk: function (t) { return { rx: 0.25 * bell(t, 0.35, 0.7) }; },
      cast: function (t) { return { rx: -0.3 * bell(t, 0.1, 0.9) }; },
      hit: function (t) { return { rx: 0.25 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    head.gb.box(0, 69 * S, 0, 15 * S, 13 * S, 15 * S, C.rock2);
    head.gb.box(-3.8 * S, 70 * S, 7.6 * S, 3, 3.5, 2.5, C.eye);
    head.gb.box(3.8 * S, 70 * S, 7.6 * S, 3, 3.5, 2.5, C.eye);
    head.gb.box(0, 76.5 * S, 0, 11 * S, 4 * S, 11 * S, C.rock);
    if (boss) {
      head.gb.box(0, 82 * S, 0, 16 * S, 3.5, 14 * S, [0.85, 0.68, 0.25]);
      head.gb.box(-6 * S, 86 * S, 0, 3.5, 8, 3.5, [0.85, 0.68, 0.25]);
      head.gb.box(6 * S, 86 * S, 0, 3.5, 8, 3.5, [0.85, 0.68, 0.25]);
    }
    parts.push(head.fin());
    var ARMS = [[-20 * S, -1], [20 * S, 1]];
    for (var ai = 0; ai < 2; ai++) {
      (function (i2) {
        var px = ARMS[i2][0];
        var arm = pt([px, 60 * S, 0], {
          idle: function (t) { return { rx: Math.sin(t * 1.3 + i2 * 2.4) * 0.05 - 0.04 }; },
          atk: function (t) { return i2 === 1 ? { rx: 0.8 * bell(t, 0, 0.35) - 2.5 * bell(t, 0.35, 0.65) } : { rx: -0.3 * bell(t, 0.3, 0.7) }; },
          cast: function (t) { return { rx: -1.7 * bell(t, 0.1, 0.95) }; },
          hit: function (t) { return { rx: -0.2 * bell(t, 0, 0.5) }; },
          die: dieA
        });
        arm.gb.box(px, 46 * S, 0, 11 * S, 30 * S, 12 * S, C.rock2);
        arm.gb.box(px, 27 * S, 1, 13 * S, 14 * S, 14 * S, C.rock);
        parts.push(arm.fin());
      })(ai);
    }
    var LEGS = [[-9 * S], [9 * S]];
    for (var li = 0; li < 2; li++) {
      (function (i2) {
        var lx = LEGS[i2][0];
        var leg = pt([lx, 26 * S, 0], {
          idle: function (t) { return {}; },
          atk: function (t) { return i2 === 0 ? { rx: -0.2 * bell(t, 0.3, 0.7) } : { rx: 0.2 * bell(t, 0.3, 0.7) }; },
          die: dieA
        });
        leg.gb.box(lx, 14 * S, 0, 12 * S, 26 * S, 13 * S, C.rock2);
        leg.gb.box(lx, 2.5 * S, 2 * S, 13 * S, 5 * S, 16 * S, C.dark);
        parts.push(leg.fin());
      })(li);
    }
    return { parts: parts, h: 88 * S };
  };

  /* ---------- غول ضخم ---------- */
  BUILDERS.ogre = function (C, rnd, boss) {
    var parts = [];
    var S = boss ? 1.3 : 1;
    var dieA = function (t) { var e = easeO(t / 0.55); return { g: [0, 10, 0], rx: -1.3 * e, oy: -5 * e }; };
    var LEGS = [[-10 * S], [10 * S]];
    for (var li = 0; li < 2; li++) {
      (function (i2) {
        var lx = LEGS[i2][0];
        var leg = pt([lx, 32 * S, 0], {
          idle: function (t) { return {}; },
          atk: function (t) { return { rx: (i2 === 0 ? -0.3 : 0.25) * bell(t, 0.35, 0.75) }; },
          die: dieA
        });
        leg.gb.box(lx, 16 * S, 0, 13 * S, 30 * S, 13 * S, C.skin2);
        leg.gb.box(lx, 3 * S, 3 * S, 14 * S, 6 * S, 17 * S, C.dark);
        parts.push(leg.fin());
      })(li);
    }
    var torso = pt([0, 32 * S, 0], {
      idle: function (t) { return { rz: Math.sin(t * 1.5) * 0.035, oy: Math.sin(t * 1.5 + 0.4) * 1.4, sx: 1 + 0.02 * Math.sin(t * 2.2) }; },
      atk: function (t) { return { rx: 0.3 * bell(t, 0.35, 0.6) - 0.12 * bell(t, 0.6, 0.9), oz: 5 * bell(t, 0.4, 0.8), oy: Math.sin(t * 1.5 + 0.4) * 1.4 }; },
      cast: function (t) { return { oy: 4 * bell(t, 0.1, 0.95) + Math.sin(t * 1.5 + 0.4) * 1.4, rx: -0.15 * bell(t, 0.1, 0.9) }; },
      hit: hitRecoil(),
      die: dieA
    });
    torso.gb.box(0, 38 * S, 0, 35 * S, 24 * S, 25 * S, C.skin);
    torso.gb.box(0, 32 * S, 1, 31 * S, 14 * S, 24 * S, C.belly);
    torso.gb.box(0, 51 * S, 0, 30 * S, 12 * S, 22 * S, C.skin2);
    torso.gb.box(0, 29 * S, 0, 31 * S, 5 * S, 23 * S, C.dark);
    torso.gb.box(-19 * S, 54 * S, 0, 13 * S, 11 * S, 15 * S, C.armor);
    parts.push(torso.fin());
    var head = pt([0, 58 * S, 0], {
      idle: function (t) { return { oy: Math.sin(t * 1.5 + 0.7) * 1.6, ry: Math.sin(t * 0.8) * 0.14, rx: Math.sin(t * 1.9) * 0.03 }; },
      atk: function (t) { return { rx: 0.2 * bell(t, 0.35, 0.65), oy: Math.sin(t * 1.5 + 0.7) * 1.6 }; },
      cast: function (t) { return { rx: -0.45 * bell(t, 0.1, 0.9), oy: 4 * bell(t, 0.1, 0.95) }; },
      hit: function (t) { return { rx: 0.3 * bell(t, 0, 0.5), oz: -4 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    head.gb.box(0, 66 * S, 0, 19 * S, 17 * S, 19 * S, C.skin);
    head.gb.box(0, 59 * S, 3 * S, 15 * S, 9 * S, 17 * S, C.belly);
    head.gb.box(-5 * S, 58.5 * S, 11 * S, 3.5, 7, 3.5, C.tusk, 0, -0.15);
    head.gb.box(5 * S, 58.5 * S, 11 * S, 3.5, 7, 3.5, C.tusk, 0, -0.15);
    head.gb.box(-4.5 * S, 68 * S, 9.6 * S, 3.2, 3.2, 2.5, C.eye);
    head.gb.box(4.5 * S, 68 * S, 9.6 * S, 3.2, 3.2, 2.5, C.eye);
    head.gb.box(-11 * S, 70 * S, 0, 4 * S, 7 * S, 3.5 * S, C.skin2, 0, 0, 0.2);
    head.gb.box(11 * S, 70 * S, 0, 4 * S, 7 * S, 3.5 * S, C.skin2, 0, 0, -0.2);
    if (boss) {
      head.gb.box(0, 76 * S, 0, 18 * S, 3.5, 16 * S, [0.85, 0.68, 0.25]);
      head.gb.box(-7 * S, 80 * S, 0, 4, 9, 4, [0.85, 0.68, 0.25]);
      head.gb.box(7 * S, 80 * S, 0, 4, 9, 4, [0.85, 0.68, 0.25]);
    }
    parts.push(head.fin());
    var ARMS = [[-19 * S, -1], [19 * S, 1]];
    for (var ai = 0; ai < 2; ai++) {
      (function (i2) {
        var px = ARMS[i2][0];
        var arm = pt([px, 52 * S, 0], {
          idle: function (t) { return { rx: Math.sin(t * 1.5 + i2 * 2.6) * 0.07 - 0.06, oy: Math.sin(t * 1.5 + 0.4) * 1.4 }; },
          atk: function (t) { return i2 === 1 ? { rx: 2.3 * bell(t, 0, 0.35) - 3.7 * bell(t, 0.35, 0.62), oy: Math.sin(t * 1.5 + 0.4) * 1.4 } : { rx: -0.35 * bell(t, 0.3, 0.7), oy: Math.sin(t * 1.5 + 0.4) * 1.4 }; },
          cast: function (t) { return { rx: i2 === 1 ? -2.6 * bell(t, 0.1, 0.95) : -0.4 * bell(t, 0.1, 0.95) }; },
          hit: function (t) { return { rx: -0.25 * bell(t, 0, 0.5) }; },
          die: dieA
        });
        arm.gb.box(px, 38 * S, 0, 12 * S, 28 * S, 13 * S, C.skin2);
        arm.gb.box(px, 22 * S, 1.5, 11 * S, 15 * S, 12 * S, C.skin);
        arm.gb.box(px, 12 * S, 2, 13 * S, 12 * S, 13 * S, C.skin2);
        if (i2 === 1) {
          arm.gb.box(px, 1 * S, 4 * S, 5.5 * S, 20 * S, 5.5 * S, C.club);
          arm.gb.box(px, -10 * S, 4 * S, 15 * S, 13 * S, 15 * S, C.club2);
          arm.gb.box(px, -10 * S, 4 * S, 17 * S, 5 * S, 6 * S, C.dark);
          arm.gb.box(px, -17 * S, 4 * S, 5 * S, 5 * S, 5 * S, C.dark);
        }
        parts.push(arm.fin());
      })(ai);
    }
    return { parts: parts, h: 86 * S };
  };

  /* ---------- عين طائفة ---------- */
  BUILDERS.eye = function (C, rnd, boss) {
    var parts = [];
    var S = boss ? 1.4 : 1;
    var dieA = function (t) { var e = easeO(t / 0.6); return { g: [0, 20, 0], rx: -0.9 * e, oy: -14 * e, sy: 1 - 0.4 * e }; };
    var ball = pt([0, 0, 0], {
      idle: function (t) { return { oy: Math.sin(t * 1.6) * 3.5 * S }; },
      atk: function (t) { return { oy: Math.sin(t * 1.6) * 3.5 * S + 4 * bell(t, 0.2, 0.7), ox: Math.sin(t * 30) * 0.8 * bell(t, 0.25, 0.6) }; },
      cast: function (t) { return { oy: Math.sin(t * 1.6) * 3.5 * S + 9 * bell(t, 0.05, 1.0) }; },
      hit: hitRecoil(),
      die: dieA
    });
    ball.gb.box(0, 46 * S, 0, 30 * S, 30 * S, 30 * S, C.ball);
    ball.gb.box(0, 46 * S, 0, 33 * S, 21 * S, 21 * S, C.ball2, Math.PI / 4);
    ball.gb.box(0, 46 * S, 0, 21 * S, 33 * S, 21 * S, C.ball2, 0, Math.PI / 4);
    ball.gb.box(-13 * S, 52 * S, 8 * S, 2, 8, 2, C.vein, 0, 0, 0.3);
    ball.gb.box(12 * S, 40 * S, 8 * S, 2, 7, 2, C.vein, 0, 0, -0.3);
    parts.push(ball.fin());
    var iris = pt([0, 0, 0], {
      idle: function (t) { return { oy: Math.sin(t * 1.6) * 3.5 * S, ox: Math.sin(t * 0.8) * 3 * S, oy2: 0 }; },
      atk: function (t) { return { oy: Math.sin(t * 1.6) * 3.5 * S + 4 * bell(t, 0.2, 0.7), oz: 7 * bell(t, 0.2, 0.65), ox: 0 }; },
      cast: function (t) { return { oy: Math.sin(t * 1.6) * 3.5 * S + 9 * bell(t, 0.05, 1.0), oz: 4 * bell(t, 0.1, 0.9) }; },
      die: dieA
    });
    iris.gb.box(0, 46 * S, 13 * S, 19 * S, 19 * S, 12 * S, C.iris);
    iris.gb.box(0, 46 * S, 17 * S, 10 * S, 10 * S, 6 * S, C.pupil);
    iris.gb.box(-3 * S, 49 * S, 20 * S, 3, 3, 2, [1, 1, 1]);
    parts.push(iris.fin());
    var lids = pt([0, 0, 0], {
      idle: function (t) { return { oy: Math.sin(t * 1.6) * 3.5 * S }; },
      atk: function (t) { return { oy: Math.sin(t * 1.6) * 3.5 * S + 4 * bell(t, 0.2, 0.7), ry: Math.sin(t * 26) * 0.1 * bell(t, 0.3, 0.6) }; },
      die: dieA
    });
    lids.gb.box(0, 60 * S, 0, 31 * S, 9 * S, 31 * S, C.ball2);
    lids.gb.box(0, 32 * S, 0, 31 * S, 9 * S, 31 * S, C.ball2);
    parts.push(lids.fin());
    var tendrils = pt([0, 0, 0], {
      idle: function (t) { return { rx: Math.sin(t * 2.0) * 0.12, ry: Math.sin(t * 1.3) * 0.15 }; },
      atk: function (t) { return { rz: Math.sin(t * 22) * 0.2 * bell(t, 0.2, 0.7), oy: Math.sin(t * 1.6) * 3.5 * S + 4 * bell(t, 0.2, 0.7) }; },
      die: dieA
    });
    var TD = [-11 * S, -4 * S, 3 * S, 10 * S];
    for (var ti = 0; ti < TD.length; ti++) {
      tendrils.gb.box(TD[ti], 24 * S - Math.abs(TD[ti]) * 0.3, 0, 3.2, 17 * S, 3.2, ti % 2 ? C.tend : C.tend2, 0, Math.sin(ti * 2.1) * 0.25, Math.cos(ti * 1.7) * 0.2);
    }
    parts.push(tendrils.fin());
    return { parts: parts, h: 64 * S };
  };

  /* ---------- فم الهاوية ---------- */
  BUILDERS.maw = function (C, rnd, boss) {
    var parts = [];
    var S = boss ? 1.35 : 1;
    var dieA = function (t) { var e = easeO(t / 0.55); return { g: [0, 10, 0], rx: 1.1 * e, oy: -6 * e }; };
    var body = pt([0, 26 * S, -14 * S], {
      idle: function (t) { return { oy: Math.sin(t * 2.0) * 1.5, sx: 1 + 0.025 * Math.sin(t * 2.6) }; },
      atk: function (t) { return { oz: 11 * bell(t, 0.3, 0.7), oy: Math.sin(t * 2.0) * 1.5 }; },
      cast: function (t) { return { oy: 4 * bell(t, 0.1, 0.95) }; },
      hit: hitRecoil(),
      die: dieA
    });
    body.gb.box(0, 26 * S, -14 * S, 30 * S, 30 * S, 22 * S, C.skin2);
    body.gb.box(0, 40 * S, -14 * S, 20 * S, 8 * S, 14 * S, C.dark, 0, -0.3);
    for (var sp = -1; sp <= 1; sp++) body.gb.box(sp * 8 * S, 44 * S, -16 * S, 5 * S, 7 * S, 5 * S, C.spike);
    body.gb.box(-14 * S, 10 * S, -4 * S, 8 * S, 18 * S, 10 * S, C.dark);
    body.gb.box(14 * S, 10 * S, -4 * S, 8 * S, 18 * S, 10 * S, C.dark);
    body.gb.box(-13 * S, 4 * S, 6 * S, 9 * S, 8 * S, 12 * S, C.skin2);
    body.gb.box(13 * S, 4 * S, 6 * S, 9 * S, 8 * S, 12 * S, C.skin2);
    parts.push(body.fin());
    var lower = pt([0, 0, 0], {
      idle: function (t) { return { oy: Math.sin(t * 2.0) * 1.2 }; },
      atk: function (t) { return { oy: Math.sin(t * 2.0) * 1.2, oz: 11 * bell(t, 0.3, 0.7) }; },
      cast: function (t) { return { oy: 4 * bell(t, 0.1, 0.95) }; },
      hit: hitRecoil(),
      die: function (t) { var e = easeO(t / 0.55); return { g: [0, 10, 0], rx: 1.1 * e, oy: -6 * e, rx2: 0 }; }
    });
    lower.gb.box(0, 15 * S, 2 * S, 32 * S, 13 * S, 36 * S, C.skin);
    lower.gb.box(0, 19 * S, 6 * S, 26 * S, 6 * S, 30 * S, C.tongue);
    for (var ti = -2; ti <= 2; ti++) lower.gb.box(ti * 6.4 * S, 22.5 * S, 16 * S, 3.4 * S, 6 * S, 3.4 * S, C.tooth);
    parts.push(lower.fin());
    var upper = pt([0, 30 * S, -12 * S], {
      idle: function (t) { return { rx: Math.sin(t * 2.0 + 0.3) * 0.05, oy: Math.sin(t * 2.0) * 1.2 }; },
      atk: function (t) { return { rx: -0.95 * bell(t, 0.05, 0.3) + 1.15 * bell(t, 0.3, 0.55), oz: 11 * bell(t, 0.3, 0.7), oy: Math.sin(t * 2.0) * 1.2 }; },
      cast: function (t) { return { rx: -0.8 * bell(t, 0.1, 0.95) + Math.sin(t * 24) * 0.05 * bell(t, 0.3, 0.9), oy: 4 * bell(t, 0.1, 0.95) }; },
      hit: function (t) { return { rx: 0.3 * bell(t, 0, 0.5) }; },
      die: dieA
    });
    upper.gb.box(0, 34 * S, 2 * S, 34 * S, 15 * S, 38 * S, C.skin2);
    upper.gb.box(0, 42 * S, 0, 22 * S, 7 * S, 20 * S, C.dark);
    upper.gb.box(-9 * S, 44 * S, 4 * S, 4.5, 4.5, 4.5, C.eye);
    upper.gb.box(9 * S, 44 * S, 4 * S, 4.5, 4.5, 4.5, C.eye);
    for (var ti2 = -2; ti2 <= 2; ti2++) {
      upper.gb.box(ti2 * 7 * S, 26.5 * S, 14 * S, 3.6 * S, 6.5 * S, 3.6 * S, C.tooth);
      upper.gb.box(ti2 * 7 * S + 3.5 * S, 25 * S, 20 * S, 2.8 * S, 5 * S, 2.8 * S, C.tooth);
    }
    if (boss) {
      upper.gb.box(-10 * S, 48 * S, 0, 5, 12, 5, [0.85, 0.68, 0.25], 0, 0, 0.4);
      upper.gb.box(10 * S, 48 * S, 0, 5, 12, 5, [0.85, 0.68, 0.25], 0, 0, -0.4);
      upper.gb.box(0, 49 * S, -2 * S, 14, 4, 12, [0.85, 0.68, 0.25]);
    }
    parts.push(upper.fin());
    return { parts: parts, h: 52 * S };
  };

  /* ==================== مصنع الوحوش (U.fx) ==================== */
  var SCALE_BY_KIND = { golem: 1.0, ogre: 1.0, beast: 0.92, bird: 0.88, serpent: 0.95, spider: 0.9, scorp: 0.9, slime: 1.0, wraith: 0.95, plant: 0.9, eye: 0.85, maw: 1.0 };

  /* ذاكرة بناء الكائنات — الأجزاء للقراءة فقط بعد البناء */
  var CR_CACHE = {};
  function buildCreature(name, boss) {
    var key = name + "|" + (boss ? 1 : 0);
    if (CR_CACHE[key]) return CR_CACHE[key];
    var cls = classify(name);
    var kind = cls.a, V = cls.v || {};
    var C = palette(kind, name);
    var b = BUILDERS[kind] || BUILDERS.beast;
    var built = b(C, hsh(name), boss, V);
    /* حسم الحجم داخل الإحداثيات (المحرك يضرب في U.scale لاحقًا) */
    var bake = (SCALE_BY_KIND[kind] || 1) * (boss ? 0.86 : (0.92 + (hsh(name) % 9) / 70));
    for (var pi = 0; pi < built.parts.length; pi++) {
      var pp = built.parts[pi], k;
      pp.piv = [pp.piv[0] * bake, pp.piv[1] * bake, pp.piv[2] * bake];
      for (k = 0; k < pp.v.length; k++) pp.v[k] *= bake;
    }
    built.h *= bake;
    CR_CACHE[key] = { kind: kind, built: built, V: V };
    return CR_CACHE[key];
  }

  function make(gl, u, boss) {
    try {
      var name = (u && u.name) || "";
      var cls = classify(name);
      if (!cls) return null; /* بشر → SOLFBX يتكفل */
      var cr = buildCreature(name, boss);
      var parts = cr.built.parts;
      /* إجمالي الرؤوس والفهارس */
      var V = 0, I = 0, i;
      for (i = 0; i < parts.length; i++) { V += parts[i].nv; I += parts[i].idx.length; }
      if (V > 65000) return null;
      var out = new Float32Array(V * 6);
      var idx = new Uint16Array(I);
      var base = 0, o = 0;
      for (i = 0; i < parts.length; i++) {
        var p = parts[i], j;
        p.base = base;
        for (j = 0; j < p.idx.length; j++) idx[o + j] = p.idx[j] + base;
        o += p.idx.length;
        base += p.nv;
      }
      var vb = gl.createBuffer(), ib = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, vb);
      gl.bufferData(gl.ARRAY_BUFFER, out.byteLength, gl.DYNAMIC_DRAW);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
      var mesh = { vb: vb, ib: ib, n: I };
      return {
        cls: cr.kind,
        mesh: mesh,
        out: out,
        parts: parts,
        h: cr.built.h,
        update: function (clip, t) {
          var ps = this.parts, oo = 0, k;
          var cl = (clip === "cast" || clip === "atk" || clip === "hit" || clip === "die") ? clip : "idle";
          var oneT = t;
          if (cl === "die" && oneT > DUR.die) oneT = DUR.die;
          for (var q = 0; q < ps.length; q++) {
            var pp = ps[q], f = pp.a[cl];
            var tr = f ? f(oneT, pp) : null;
            var v = pp.v, c = pp.c, nv = pp.nv;
            if (!tr) {
              for (k = 0; k < nv; k++) {
                var b6 = oo + k * 6, b3 = k * 3;
                this.out[b6] = v[b3]; this.out[b6 + 1] = v[b3 + 1]; this.out[b6 + 2] = v[b3 + 2];
                this.out[b6 + 3] = c[b3]; this.out[b6 + 4] = c[b3 + 1]; this.out[b6 + 5] = c[b3 + 2];
              }
              oo += nv * 6;
              continue;
            }
            var rx = tr.rx || 0, ry = tr.ry || 0, rz = tr.rz || 0;
            var ox = tr.ox || 0, oy = tr.oy || 0, oz = tr.oz || 0;
            var sx = tr.sx || 1, sy = tr.sy || 1, sz = tr.sz || 1;
            var piv = tr.g || pp.piv;
            var ident = !rx && !ry && !rz && sx === 1 && sy === 1 && sz === 1;
            var cA = Math.cos(rx), sA = Math.sin(rx), cB = Math.cos(ry), sB = Math.sin(ry), cC = Math.cos(rz), sC = Math.sin(rz);
            for (k = 0; k < nv; k++) {
              var b62 = oo + k * 6, b32 = k * 3;
              var X = (v[b32] - piv[0]) * sx, Y = (v[b32 + 1] - piv[1]) * sy, Z = (v[b32 + 2] - piv[2]) * sz;
              var y1 = Y * cA - Z * sA, z1 = Y * sA + Z * cA;
              var x2 = X * cB + z1 * sB, z2 = -X * sB + z1 * cB;
              var x3 = x2 * cC - y1 * sC, y3 = x2 * sC + y1 * cC;
              this.out[b62] = piv[0] + x3 + ox;
              this.out[b62 + 1] = piv[1] + y3 + oy;
              this.out[b62 + 2] = piv[2] + z2 + oz;
              this.out[b62 + 3] = c[b32]; this.out[b62 + 4] = c[b32 + 1]; this.out[b62 + 5] = c[b32 + 2];
            }
            oo += nv * 6;
          }
          gl.bindBuffer(gl.ARRAY_BUFFER, vb);
          gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.out);
          return mesh;
        },
        dur: function (clip) { return DUR[clip] || 2.4; },
        boneP: function () { return null; },
        gear: null
      };
    } catch (e) {
      try { window.SOLMOB_LASTERR = String((e && (e.stack || e.message)) || e).slice(0, 500); } catch (e2) {}
      return null;
    }
  }

  /* ==================== صور الوحوش ثلاثية الأبعاد (أفاتار) ==================== */
  var AR2 = null, AR2fail = false;
  var VS2 = "attribute vec3 aP;attribute vec3 aC;uniform mat4 uM;varying vec3 vC;void main(){gl_Position=uM*vec4(aP,1.0);vC=aC;}";
  var FS2 = "precision mediump float;varying vec3 vC;void main(){gl_FragColor=vec4(vC,1.0);}";
  function avInit2() {
    if (AR2 || AR2fail) return AR2;
    try {
      var cv = document.createElement("canvas"); cv.width = 140; cv.height = 170;
      var gl = cv.getContext("webgl", { alpha: true, premultipliedAlpha: true, antialias: true, preserveDrawingBuffer: false }) || cv.getContext("experimental-webgl");
      if (!gl) throw 0;
      function sh(t, s) { var o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw 1; return o; }
      var p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, VS2)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FS2)); gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw 2;
      gl.useProgram(p);
      gl.enable(gl.DEPTH_TEST);
      AR2 = { gl: gl, cv: cv, aP: gl.getAttribLocation(p, "aP"), aC: gl.getAttribLocation(p, "aC"), uM: gl.getUniformLocation(p, "uM"), vb: gl.createBuffer(), ib: gl.createBuffer(), cur: null };
      gl.viewport(0, 0, 140, 170);
    } catch (e) { AR2fail = true; AR2 = null; }
    return AR2;
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&"<>]/g, function (c) { return { "&": "&amp;", '"': "&quot;", "<": "&lt;", ">": "&gt;" }[c]; }); }

  var AV_CACHE = {};
  var LIVE2 = [], raf2 = 0, last2 = 0;
  function mobDraw(it, t) {
    var A = avInit2(); if (!A) return;
    var cr = buildCreature(it.name, it.boss);
    var parts = cr.built.parts;
    var V = 0, I = 0, i, j;
    for (i = 0; i < parts.length; i++) { V += parts[i].nv; I += parts[i].idx.length; }
    var out = new Float32Array(V * 6), idx = new Uint16Array(I), base = 0, o = 0;
    for (i = 0; i < parts.length; i++) {
      var p = parts[i];
      for (j = 0; j < p.idx.length; j++) idx[o + j] = p.idx[j] + base;
      o += p.idx.length; base += p.nv;
    }
    /* تحريك الأجزاء (وقفة idle) يدويًا */
    var oo = 0;
    for (i = 0; i < parts.length; i++) {
      var pp = parts[i], f = pp.a.idle, tr = f ? f(t, pp) : null;
      var v = pp.v, c = pp.c, nv = pp.nv, k;
      if (!tr) {
        for (k = 0; k < nv; k++) { var b6 = oo + k * 6, b3 = k * 3; out[b6] = v[b3]; out[b6 + 1] = v[b3 + 1]; out[b6 + 2] = v[b3 + 2]; out[b6 + 3] = c[b3]; out[b6 + 4] = c[b3 + 1]; out[b6 + 5] = c[b3 + 2]; }
        oo += nv * 6; continue;
      }
      var rx = tr.rx || 0, ry = tr.ry || 0, rz = tr.rz || 0, ox = tr.ox || 0, oy = tr.oy || 0, oz = tr.oz || 0;
      var sx = tr.sx || 1, sy = tr.sy || 1, sz = tr.sz || 1;
      var piv = tr.g || pp.piv;
      var cA = Math.cos(rx), sA = Math.sin(rx), cB = Math.cos(ry), sB = Math.sin(ry), cC = Math.cos(rz), sC = Math.sin(rz);
      for (k = 0; k < nv; k++) {
        var b62 = oo + k * 6, b32 = k * 3;
        var X = (v[b32] - piv[0]) * sx, Y = (v[b32 + 1] - piv[1]) * sy, Z = (v[b32 + 2] - piv[2]) * sz;
        var y1 = Y * cA - Z * sA, z1 = Y * sA + Z * cA;
        var x2 = X * cB + z1 * sB, z2 = -X * sB + z1 * cB;
        var x3 = x2 * cC - y1 * sC, y3 = x2 * sC + y1 * cC;
        out[b62] = piv[0] + x3 + ox; out[b62 + 1] = piv[1] + y3 + oy; out[b62 + 2] = piv[2] + z2 + oz;
        out[b62 + 3] = c[b32]; out[b62 + 4] = c[b32 + 1]; out[b62 + 5] = c[b32 + 2];
      }
      oo += nv * 6;
    }
    var gl = A.gl;
    /* مصفوفة العرض: دوران خفيف + ملاءمة الارتفاع إلى فضاء القص [-1,1] */
    var hh = Math.max(30, cr.built.h);
    var yaw = 0.55, cy = Math.cos(yaw), sy = Math.sin(yaw);
    var sc = 1.9 / hh;
    var m = new Float32Array([
      cy * sc, 0, -sy * sc, 0,
      0.10 * sc, 1.0 * sc, 0.16 * sc, 0,
      sy * sc, 0, cy * sc, 0,
      0, -(hh * 0.52) * sc, 0, 1
    ]);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniformMatrix4fv(A.uM, false, m);
    gl.bindBuffer(gl.ARRAY_BUFFER, A.vb); gl.bufferData(gl.ARRAY_BUFFER, out, gl.DYNAMIC_DRAW);
    gl.vertexAttribPointer(A.aP, 3, gl.FLOAT, false, 24, 0);
    gl.vertexAttribPointer(A.aC, 3, gl.FLOAT, false, 24, 12);
    gl.enableVertexAttribArray(A.aP); gl.enableVertexAttribArray(A.aC);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, A.ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
    gl.drawElements(gl.TRIANGLES, I, gl.UNSIGNED_SHORT, 0);
    var c2 = it.ctx;
    c2.clearRect(0, 0, it.cv.width, it.cv.height);
    c2.drawImage(A.cv, 0, 0, it.cv.width, it.cv.height);
  }
  function loop2(ts) {
    raf2 = 0;
    var any = false, i;
    if (ts - last2 >= 60) {
      last2 = ts;
      for (i = LIVE2.length - 1; i >= 0; i--) {
        var it = LIVE2[i];
        if (!it.cv.isConnected) { LIVE2.splice(i, 1); continue; }
        var w = it.cv.clientWidth;
        if (w === 0) continue;
        if (!it.drawn || w >= 70) { mobDraw(it, ts / 1000 + it.ph); it.drawn = true; }
        if (w >= 70) any = true;
      }
    } else any = true;
    if (LIVE2.length && (any || LIVE2.some(function (z) { return !z.drawn; }))) raf2 = requestAnimationFrame(loop2);
  }
  function kick2() { if (!raf2) raf2 = requestAnimationFrame(loop2); }
  function reg2(cv, name, boss) {
    cv.__sm = { cv: cv, ctx: cv.getContext("2d"), name: name, boss: boss, ph: (hsh(name) % 70) / 10, drawn: false };
    LIVE2.push(cv.__sm); kick2();
  }
  function scan2() {
    var l = document.querySelectorAll("canvas[data-slmobav]:not([data-slmok])");
    for (var i = 0; i < l.length; i++) {
      l[i].setAttribute("data-slmok", "1");
      reg2(l[i], l[i].getAttribute("data-n") || "", l[i].getAttribute("data-b") === "1");
    }
  }
  try {
    if (window.MutationObserver) {
      var mo2 = new MutationObserver(function () { setTimeout(scan2, 60); });
      if (document.body) mo2.observe(document.body, { childList: true, subtree: true });
      else setTimeout(function () { if (document.body) mo2.observe(document.body, { childList: true, subtree: true }); }, 500);
    }
  } catch (e) {}
  setInterval(scan2, 1100);
  setTimeout(scan2, 300);

  /* ==================== الواجهة العامة ==================== */
  window.SOLMOB = {
    ok: true,
    classify: classify,
    make: make,
    avHTML: function (name, w, boss) {
      var cls = classify(name);
      if (!cls) return "";
      return '<div style="width:' + (w || 64) + 'px;flex:none"><canvas data-slmobav="1" data-n="' + esc(name) + '" data-b="' + (boss ? 1 : 0) +
        '" width="140" height="170" style="width:100%;aspect-ratio:14/17;display:block;pointer-events:none;filter:drop-shadow(0 3px 4px rgba(0,0,0,.45))"></canvas></div>';
    },
    kindOf: function (name) { var c = classify(name); return c ? c.a : "humanoid"; },
    _dbg: function () { return { kinds: Object.keys(BUILDERS), live: LIVE2.length }; }
  };
})();

