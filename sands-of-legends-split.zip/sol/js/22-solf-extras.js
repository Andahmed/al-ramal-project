
/* ============================================================
   SOLF — الحزمة الإضافية العشر لأساطير الرمال
   1) تلويح هجمات الأعداء والزعماء (في محرك القتال 3D)
   2) سجل المعارك + إعادة المشاهدة
   3) ساحة تدريب مجانية بلا تكلفة
   4) بورصة الموارد اليومية (تبادل مضبوط)
   5) مقارنة المعدات قبل التبديل (معاينة قوة حقيقية)
   6) نسخة احتياطية واستعادة الحفظ
   7) مؤشر فجوة القوة في استعداد المعركة
   8) تحديات الرمال اليومية بمكافآت حقيقية
   9) تقرير المعركة الموسّع
   10) مدير الفريق السريع (إضافة/إزالة/أفضل فريق)
   يعمل عبر الخطافات الرسمية: __solGet/__solSet/__solPower/__solHeroes/
   __solFightMode/__solBattle/__solPlusState — دون تعديل منطق اللعبة.
   ============================================================ */
(function () {
  "use strict";
  if (window.SOLF) return;
  window.SOLF = 1;

  /* ================= الحالة ================= */
  var KEY = "sol-fx-v1";
  function today() { var d = new Date(); return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); }
  function load() {
    try { return JSON.parse(localStorage.getItem(KEY) || "{}") || {}; } catch (e) { return {}; }
  }
  function save(d) { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) {} }
  function FX() {
    var d = load();
    if (!d.history) d.history = [];
    if (!d.daily || d.daily.date !== today()) d.daily = { date: today(), prog: { win: 0, skills: 0, boss: 0 }, claimed: {} };
    if (!d.exchange || d.exchange.date !== today()) d.exchange = { date: today(), mats: 0, xp: 0 };
    if (!d.training) d.training = { runs: 0, bestTime: 0 };
    return d;
  }
  function persist(d) { save(d); }
  function G() { return window.__solGet ? window.__solGet() : null; }
  function SET(fn) { if (window.__solSet) window.__solSet(fn); }
  function fmt(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + "م";
    if (n >= 1e4) return (n / 1e3).toFixed(n >= 1e5 ? 0 : 1) + "ألف";
    return Math.max(0, Math.round(n || 0)).toLocaleString("en-US");
  }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

  /* ================= توست خاص ================= */
  var toastEl = null, toastT = 0;
  function toast(msg) {
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.className = "fx-toast fx-ui";
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.classList.add("on");
    clearTimeout(toastT);
    toastT = setTimeout(function () { toastEl.classList.remove("on"); }, 2600);
  }

  /* ================= نافذة منبثقة عامة ================= */
  var modalEl = null;
  function openModal(html) {
    closeModal();
    modalEl = document.createElement("div");
    modalEl.className = "fx-modal fx-ui";
    modalEl.innerHTML = '<div class="fx-backdrop"></div><div class="fx-dialog">' + html +
      '<button class="fx-close" data-fx="fx-close">✕</button></div>';
    document.body.appendChild(modalEl);
    modalEl.querySelector(".fx-backdrop").addEventListener("click", closeModal);
    return modalEl;
  }
  function closeModal() { if (modalEl && modalEl.parentNode) modalEl.parentNode.removeChild(modalEl); modalEl = null; }

  /* ================= القوة ================= */
  function heroPower(id, gearOverride) {
    if (!window.__solPower || !window.__solHeroes) return 0;
    var g = G(); if (!g || !g.heroes[id]) return 0;
    var base = window.__solHeroes[id];
    var st2 = Object.assign({}, g.heroes[id]);
    if (gearOverride) st2 = Object.assign({}, st2, { gear: gearOverride });
    var r = window.__solPower(base, st2);
    return r && r.power ? r.power : 0;
  }
  function teamPower() {
    var g = G(); if (!g) return 0;
    var t = 0;
    (g.team || []).forEach(function (id) { t += heroPower(id); });
    return t;
  }
  /* قوة أي وحدة من نتيجة معركة — نفس معادلة اللعبة */
  function unitPower(u) {
    return Math.round(.06 * u.maxHp + 2.4 * (u.atk || 0) + 2.2 * (u.def || 0) + 3 * (u.spd || 0));
  }
  function sidePower(units, side) {
    var t = 0;
    (units || []).forEach(function (u) { if (u.side === side) t += unitPower(u); });
    return t;
  }

  /* ================= اعتراض فتح المعارك (سجل + مؤشر) ================= */
  var realBattle = null;
  var lastBattle = null;
  function record(o, title, bg) {
    try {
      if (!o || !o.result || !o.result.units) return;
      if (String(title || "").indexOf("إعادة") >= 0) return; /* لا تسجّل إعادة المشاهدة */
      var d = FX();
      var entry = {
        id: Date.now(), ts: Date.now(), title: String(title || "معركة"), bg: String(bg || ""),
        victory: null, done: false,
        result: {
          units: o.result.units, events: o.result.events || [], duration: o.result.duration || 0,
          timeLimit: o.result.timeLimit || 0, playerDamage: o.result.playerDamage || 0
        }
      };
      var size = 0;
      try { size = JSON.stringify(entry).length; } catch (e) {}
      entry.heavy = size > 260000;
      if (entry.heavy) { delete entry.result.events; }
      d.history.unshift(entry);
      d.history = d.history.slice(0, 6);
      persist(d);
      lastBattle = entry;
      try {
        if (o && o.result && o.result.units) {
          var _kd = {}, _evs = o.result.events || [];
          _evs.forEach(function (ev) { if (ev.kind === "death" && ev.targets) ev.targets.forEach(function (t) { _kd[t] = 1; }); });
          var _kn = [];
          o.result.units.forEach(function (u) { if (u.side === 1 && u.name && _kd[u.uid] && _kn.indexOf(u.name) < 0) _kn.push(u.name); });
          if (_kn.length && window.SOLBOX_REC) window.SOLBOX_REC(_kn);
        }
      } catch (e) {}
      injectGaugeSoon(entry);
      watchResult(entry);
    } catch (e) {}
  }
  function watchResult(entry) {
    var n = 0, seen = false;
    var iv = setInterval(function () {
      n++;
      var txt = "";
      try { txt = document.body.innerText || ""; } catch (e) {}
      if (!seen) {
        if (txt.indexOf("نصرٌ حاسم") >= 0) { entry.victory = true; seen = true; }
        else if (txt.indexOf("هزيمة") >= 0 || txt.indexOf("انتهى الوقت") >= 0) { entry.victory = false; seen = true; }
        if (seen) {
          entry.done = true;
          var d = FX();
          for (var i = 0; i < d.history.length; i++) if (d.history[i].id === entry.id) d.history[i] = entry;
          persist(d);
          countDaily(entry);
        }
      }
      var stillOpen = txt.indexOf(entry.title.split(" — ")[0]) >= 0 && (txt.indexOf("نصرٌ حاسم") >= 0 || txt.indexOf("هزيمة") >= 0 || txt.indexOf("استعداد المعركة") >= 0 || true);
      if ((seen && txt.indexOf(entry.title.split(" — ")[0]) < 0) || n > 1600) { clearInterval(iv); }
    }, 300);
  }
  function countDaily(entry) {
    var d = FX();
    var p = d.daily.prog;
    if (entry.victory) p.win++;
    if (entry.victory && entry.result.units && entry.result.units.some(function (u) { return u.side === 1 && u.isBoss; })) p.boss++;
    var sk = 0;
    (entry.result.events || []).forEach(function (e) {
      if ((e.kind === "skill" || e.kind === "ultimate") && e.source !== undefined) {
        var su = (entry.result.units || []).find(function (u) { return u.uid === e.source; });
        if (su && su.side === 0) sk++;
      }
    });
    p.skills += sk;
    persist(d);
  }

  /* تركيب المعترض على window.__solBattle (اللعبة تعيّنه عند فتح شاشة الحملة) */
  Object.defineProperty(window, "__solBattle", {
    configurable: true,
    get: function () {
      return function (o, title, bg, rep, next) {
        try { window.__solLastBattleArgs = [o, title, bg, rep, next]; } catch (e) {}
        record(o, title, bg);
        if (realBattle) return realBattle(o, title, bg, rep, next);
      };
    },
    set: function (v) { realBattle = v; }
  });

  /* ================= إعادة خوض المعركة بترتيب صفوف جديد ================= */
  window.__solBattleOpenRefight = function (o, title, bg, rep, next) {
    if (!realBattle) return;
    window.__solRefighting = true;
    try { return realBattle(o, title, bg, rep, next); } finally { setTimeout(function () { window.__solRefighting = false; }, 150); }
  };
  window.__solRecordBattle = function (o, title, bg) { record(o, title, bg); };
  window.__solGaugeFor = function (o) { try { injectGaugeSoon({ result: o && o.result, title: "refight" }); } catch (e) {} };
  (function () {
    function wrapFights() {
      var stt = window.__solGet ? window.__solGet() : null;
      if (!stt || window.__solFightsWrappedFlag) return false;
      var names = ["fightCampaign", "fightArena", "fightBoss"], patched = {};
      for (var i = 0; i < names.length; i++) {
        var nm = names[i];
        if (typeof stt[nm] !== "function") return false;
        patched[nm] = (function (orig, nmx) {
          return function () {
            try {
              if (window.__solGet) { window.__solBattleSnapshot = window.__solGet(); window.__solSnapAt = Date.now(); }
              window.__solLastFight = { action: nmx, args: Array.prototype.slice.call(arguments), at: Date.now() };
            } catch (e) {}
            return orig.apply(this, arguments);
          };
        })(stt[nm], nm);
      }
      window.__solSet(patched);
      window.__solFightsWrappedFlag = true;
      try { window.__solSet({ __solFightsWrapped: undefined }); } catch (e) {}
      return true;
    }
    var iv = setInterval(function () { if (wrapFights()) clearInterval(iv); }, 700);
    setTimeout(function () { clearInterval(iv); wrapFights(); }, 20000);
  })();
  (function () {
    function wrapFM() {
      if (window.__solFMWrappedFlag) return true;
      if (typeof window.__solFightMode !== "function") return false;
      var origFM = window.__solFightMode;
      window.__solFightMode = function (m, lv, custom) {
        try { window.__solLastFM = { m: m, lv: lv, custom: custom, at: Date.now() }; } catch (e) {}
        return origFM(m, lv, custom);
      };
      window.__solFMWrappedFlag = true;
      return true;
    }
    var iv2 = setInterval(function () { if (wrapFM()) clearInterval(iv2); }, 700);
    setTimeout(function () { clearInterval(iv2); wrapFM(); }, 20000);
  })();

  /* ================= مؤشر فجوة القوة في استعداد المعركة ================= */
  var gaugeDoneTs = 0;
  function injectGaugeSoon(entry) {
    var tries = 0;
    var iv = setInterval(function () {
      tries++;
      if (tries > 60) { clearInterval(iv); return; }
      var prep = null;
      var divs = document.querySelectorAll("div");
      for (var i = 0; i < divs.length; i++) {
        if ((divs[i].innerText || "").indexOf("استعداد المعركة") >= 0 && divs[i].children.length && divs[i].querySelector("button")) { prep = divs[i]; break; }
      }
      if (!prep || prep.querySelector(".fx-gauge")) { if (prep) clearInterval(iv); return; }
      clearInterval(iv);
      try {
        var units = entry.result.units || [];
        var mine = sidePower(units, 0), foe = sidePower(units, 1);
        var diff = mine - foe;
        var pct = Math.round(clampPct(mine / Math.max(1, foe) * 100));
        var tone = diff >= 0 ? "#34d399" : "#ff6b5e";
        var advice = diff >= foe * .3 ? "تفوق واضح — انطلق بثقة"
          : diff >= 0 ? "أنت الأقوى بقليل — التشكيلة مناسبة"
          : diff >= -foe * .3 ? "فجوة بسيطة — جرّب ترتيب الفصائل أو التجهيز"
          : "فجوة كبيرة — طوّر الأبطال أو المعدات أولًا";
        var bar = document.createElement("div");
        bar.className = "fx-gauge fx-ui";
        bar.innerHTML =
          '<div style="display:flex;justify-content:space-between;font:800 10.5px Cairo">' +
          '<span style="color:#7ee08a">فريقك ' + fmt(mine) + '</span>' +
          '<span style="color:#ffb3a0">العدو ' + fmt(foe) + '</span></div>' +
          '<div class="fx-gauge-track"><i style="width:' + pct + '%;background:' + tone + '"></i></div>' +
          '<div style="margin-top:4px;font:700 9.5px Cairo;color:' + tone + '">' + advice + ' — نسبة القوة ' + pct + '%</div>';
        prep.insertBefore(bar, prep.querySelector("div") || prep.firstChild);
      } catch (e) {}
    }, 120);
  }
  function clampPct(v) { return Math.max(4, Math.min(196, v || 100)); }

  /* ================= 2) سجل المعارك ================= */
  function historyModal() {
    var d = FX();
    var h = '<div class="fx-mtitle">📜 سجل المعارك — إعادة المشاهدة</div>';
    if (!d.history.length) {
      h += '<div class="fx-empty">لا معارك مسجّلة بعد — اخض أي معركة وستظهر هنا تلقائيًا</div>';
    } else {
      h += '<div class="fx-list">';
      d.history.forEach(function (e) {
        var v = e.victory === true ? '<span class="fx-badge win">🏆 نصر</span>'
          : e.victory === false ? '<span class="fx-badge lose">💀 خسارة</span>'
          : '<span class="fx-badge">… جارية</span>';
        var can = e.victory !== null && !e.heavy;
        h += '<div class="fx-row"><div><b>' + esc(e.title) + '</b>' +
          '<small>' + new Date(e.ts).toLocaleTimeString("ar") + ' • ' + fmt((e.result.duration || 0)) + ' ث' + (e.heavy ? ' • كبيرة الحجم' : '') + '</small></div>' +
          '<div style="display:flex;gap:5px;align-items:center">' + v +
          (can ? '<button class="fx-btn" data-fx="fx-replay" data-arg="' + e.id + '">▶ إعادة</button>' : '') +
          '</div></div>';
      });
      h += '</div><div class="fx-note">الإعادة تعرض المعركة نفسها نتائجها نفسها — دون احتساب غنائم جديدة</div>';
    }
    openModal(h);
  }
  function replay(id) {
    var d = FX();
    var e = d.history.find(function (x) { return x.id === +id; });
    if (!e || !e.result) { toast("التسجيل غير متوفر"); return; }
    var o = { result: e.result, victory: e.victory, rewards: {}, firstClear: false };
    closeModal();
    if (realBattle) realBattle(o, e.title + " — إعادة مشاهدة", e.bg || "linear-gradient(180deg,#3a2317 0%,#241610 100%)", null);
  }

  /* ================= 3) ساحة التدريب ================= */
  function trainingModal() {
    var g = G(); if (!g) return;
    var lv = 1, n = 0;
    Object.keys(g.heroes).forEach(function (id) { lv += g.heroes[id].level; n++; });
    lv = Math.max(1, Math.round(lv / Math.max(1, n)));
    var opts = [["mob", "⚔️ دمية مهاجمة", "dps"], ["tank", "🛡️ دمية صامدة", "tank"], ["heal", "✨ دمية داعمة", "support"], ["boss", "☠️ زعيم تدريب", "boss"]];
    var h = '<div class="fx-mtitle">🎯 ساحة التدريب المجانية</div>' +
      '<div class="fx-note">لا طاقة، لا خسارة، لا غنائم — فقط تجربة تشكيلاتك وقياس زمن الإنهاء. مستوى الدمى: ' + lv + '</div><div class="fx-grid2">';
    opts.forEach(function (o, i) {
      h += '<button class="fx-cardbtn" data-fx="fx-train-go" data-arg="' + o[2] + ':' + (lv + i) + '">' + o[1] + '<small>مستوى ' + (lv + i) + '</small></button>';
    });
    h += '</div><div class="fx-note">جلسات التدريب: ' + FX().training.runs + '</div>';
    openModal(h);
  }
  function startTraining(arg) {
    var parts = arg.split(":"), role = parts[0], lv = +parts[1];
    var name = role === "boss" ? "زعيم التدريب" : "دمية " + (role === "tank" ? "صامدة" : role === "support" ? "داعمة" : "مهاجمة");
    /* أدوار اللعبة الصحيحة فقط — الزعيم دور عادي + علم isBoss */
    var gameRole = role === "boss" ? "dps" : role;
    var custom = {
      mode: "training",
      enemies: [{ name: name, role: gameRole, faction: "abyss", level: lv, isBoss: role === "boss" }],
      timeLimit: 120
    };
    closeModal();
    if (!window.__solFightMode || !realBattle) { toast("محرك القتال لم يجهز بعد"); return; }
    var o = window.__solFightMode("custom", 1, custom);
    if (o.error) { toast(o.error); return; }
    var d = FX(); d.training.runs++; persist(d);
    window.__solBattleSnapshot = window.__solGet ? window.__solGet() : null;
    window.__solSnapAt = Date.now();
    /* عبر المعترض الرسمي — تُسجّل في سجل المعارك ويظهر مؤشر القوة */
    window.__solBattle(o, "ساحة التدريب — " + name, "linear-gradient(180deg,#241d38,#171026)", null);
  }

  /* ================= 4) بورصة الموارد ================= */
  var EX_RATES = [
    { id: "mats", label: "⛏️ خامات التطوير", give: 6000, get: 40, unit: "خامة", limit: 3, cur: "mats" },
    { id: "xp", label: "📗 خبرة الأبطال", give: 4000, get: 2500, unit: "خبرة", limit: 3, cur: "xp" }
  ];
  function exchangeModal() {
    var d = FX(), g = G(); if (!g) return;
    var h = '<div class="fx-mtitle">💱 بورصة الرمال اليومية</div>' +
      '<div class="fx-note">حوّل فائض الذهب إلى موارد تحتاجها — بحدود يومية عادلة تحفظ التوازن. ذهبك: ' + fmt(g.resources.gold) + '</div>';
    EX_RATES.forEach(function (r) {
      var used = d.exchange[r.id] || 0, left = Math.max(0, r.limit - used);
      h += '<div class="fx-row"><div><b>' + r.label + '</b><small>' + fmt(r.give) + ' ذهب ← ' + fmt(r.get) + ' ' + r.unit + ' • المتبقي اليوم: ' + left + '/' + r.limit + '</small></div>' +
        '<button class="fx-btn' + (left && g.resources.gold >= r.give ? "" : " dim") + '" data-fx="fx-exchange-do" data-arg="' + r.id + '">تبديل</button></div>';
    });
    openModal(h);
  }
  function exchangeDo(id) {
    var r = EX_RATES.find(function (x) { return x.id === id; });
    var g = G(), d = FX();
    if (!r || !g) return;
    var used = d.exchange[id] || 0;
    if (used >= r.limit) { toast("انتهى حد اليوم لهذا التبديل"); return; }
    if (g.resources.gold < r.give) { toast("الذهب غير كافٍ (" + fmt(r.give) + " مطلوب)"); return; }
    SET(function (s) {
      var res = Object.assign({}, s.resources);
      res.gold -= r.give;
      if (id === "mats") res.mats = (res.mats || 0) + r.get;
      else res.xp = (res.xp || 0) + r.get;
      return { resources: res };
    });
    d.exchange[id] = used + 1;
    persist(d);
    toast("✅ استلمت " + fmt(r.get) + " " + r.unit);
    exchangeModal();
    refreshFxPanel();
  }

  /* ================= 5) مقارنة المعدات قبل التبديل ================= */
  var compareCtx = null;
  function compareModal() {
    var s = (window.__solPlusState && window.__solPlusState()) || null;
    var g = G();
    if (!s || !g) { toast("لم تجهز بعد"); return; }
    if (!s.inventory.length) { toast("المخزن فارغ — اصنع قطعة من الحدادة أولًا"); return; }
    compareCtx = { invIndex: 0 };
    renderCompare();
  }
  function renderCompare() {
    var s = window.__solPlusState(), g = G();
    var i = compareCtx.invIndex;
    var p = s.inventory[i];
    if (!p) { closeModal(); return; }
    var ids = Object.keys(g.heroes);
    var SLOT_AR = { weapon: "السلاح", armor: "الدرع", talisman: "التعويذة", wing: "الجناح", weapon2: "السلاح الثانوي", shoulder: "الكتفية", belt: "الحزام", legs: "السروال", necklace: "القلادة", ring2: "الخاتم الثاني", bracer: "السوار", cloak: "العباءة", trinket: "الحلية", relic: "الأثر" };
    var h = '<div class="fx-mtitle">⚖️ معاينة قبل التجهيز — ' + esc(p.slot && SLOT_AR[p.slot] ? SLOT_AR[p.slot] : p.slot) + ' درجة ' + p.tier + (p.stars ? " • " + p.stars + "★" : "") + '</div>';
    h += '<div class="fx-note">القوة محسوبة بمعادلة اللعبة نفسها — قارن ثم جهّز، والقطعة القديمة تعود للمخزن</div>';
    h += '<div style="display:flex;gap:5px;overflow-x:auto;padding-bottom:4px" class="fx-chips">';
    s.inventory.forEach(function (q, ix) {
      h += '<button class="fx-chip' + (ix === i ? " on" : "") + '" data-fx="fx-cmp-sel" data-arg="' + ix + '">' + (q.slot && SLOT_AR[q.slot] ? SLOT_AR[q.slot][0] : "?") + q.tier + (q.stars ? "+" + q.stars : "") + '</button>';
    });
    h += '</div><div class="fx-list">';
    ids.forEach(function (id) {
      var def = (window.__solHeroes && window.__solHeroes[id]) || { name: id, faction: "abyss" };
      var cur = g.heroes[id].gear && g.heroes[id].gear[p.slot];
      var oldGear = Object.assign({}, g.heroes[id].gear || {});
      var newGear = Object.assign({}, g.heroes[id].gear || {});
      newGear[p.slot] = { tier: p.tier, stars: p.stars || 0 };
      var pNow = heroPower(id), pNew = heroPower(id, newGear);
      var delta = pNew - pNow;
      var cls = delta > 0 ? "up" : delta < 0 ? "dn" : "";
      var curTxt = cur ? ("المُجهّز: درجة " + cur.tier + (cur.stars ? " " + cur.stars + "★" : "")) : "الخانة فارغة";
      h += '<div class="fx-row"><div><b>' + esc(def.name || id) + '</b><small>' + curTxt + ' • قوة ' + fmt(pNow) + '</small></div>' +
        '<div style="display:flex;gap:6px;align-items:center"><span class="fx-delta ' + cls + '">' + (delta > 0 ? "+" : "") + fmt(delta) + '</span>' +
        '<span style="font:800 10px Cairo;color:#ffe9b0">→ ' + fmt(pNew) + '</span>' +
        '<button class="fx-btn' + (delta >= 0 ? "" : " dim") + '" data-sp="forge-equip-hero" data-arg="' + i + ':' + id + '">جهّز</button></div></div>';
    });
    h += '</div><div class="fx-note">زر «جهّز» يستخدم نظام اللعبة الرسمي — بعد التجهيز ستغلق النافذة تلقائيًا</div>';
    openModal(h);
  }

  /* ================= 6) نسخة احتياطية ================= */
  function backupModal() {
    var h = '<div class="fx-mtitle">💾 نسخة احتياطية واستعادة</div>' +
      '<div class="fx-note">صدر كل تقدمك (اللعبة + الأنظمة الإضافية) كملف أو رمز، واستعده على أي جهاز</div>' +
      '<div style="display:flex;gap:6px;margin:8px 0">' +
      '<button class="fx-btn" data-fx="fx-bk-dl">⬇️ تنزيل ملف النسخة</button>' +
      '<button class="fx-btn" data-fx="fx-bk-code">📋 توليد رمز النسخة</button></div>' +
      '<textarea id="fx-bk-area" class="fx-area" placeholder="الصق رمز النسخة هنا ثم اضغط استعادة…" dir="ltr"></textarea>' +
      '<button class="fx-btn gold" style="margin-top:6px" data-fx="fx-bk-restore">♻️ استعادة من الرمز أعلاه</button>' +
      '<div class="fx-note">تحذير: الاستعادة تستبدل الحفظ الحالي بالكامل</div>';
    openModal(h);
  }
  function backupPayload() {
    return JSON.stringify({
      app: "sands-of-legends", v: 2, at: new Date().toISOString(),
      game: localStorage.getItem("sands-of-legends-save") || "",
      plus: localStorage.getItem("sol-plus-v1") || "",
      fx: localStorage.getItem(KEY) || ""
    });
  }
  function backupDownload() {
    try {
      var blob = new Blob([backupPayload()], { type: "application/json" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "sands-of-legends-backup-" + today() + ".json";
      document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800);
      toast("تم تنزيل ملف النسخة");
    } catch (e) { toast("فشل التنزيل — استخدم الرمز"); }
  }
  function backupCode() {
    var ta = document.getElementById("fx-bk-area");
    if (ta) {
      ta.value = btoa(unescape(encodeURIComponent(backupPayload())));
      ta.select();
      try { document.execCommand("copy"); toast("تم النسخ إلى الحافظة"); } catch (e) { toast("حدد الرمز وانسخه يدويًا"); }
    }
  }
  function backupRestore() {
    var ta = document.getElementById("fx-bk-area");
    if (!ta || !ta.value.trim()) { toast("الصق الرمز أولًا"); return; }
    try {
      var json = decodeURIComponent(escape(atob(ta.value.trim())));
      var data = JSON.parse(json);
      if (data.app !== "sands-of-legends") throw new Error("bad");
      if (!confirm("سيتم استبدال حفظك الحالي بالكامل. متابعة؟")) return;
      if (data.game) localStorage.setItem("sands-of-legends-save", data.game);
      if (data.plus) localStorage.setItem("sol-plus-v1", data.plus);
      if (data.fx) localStorage.setItem(KEY, data.fx);
      toast("تمت الاستعادة — تُعاد تحميل اللعبة");
      setTimeout(function () { location.reload(); }, 900);
    } catch (e) { toast("رمز غير صالح"); }
  }

  /* ================= 8) تحديات الرمال اليومية ================= */
  var DAILY = [
    { id: "win", name: "⚔️ اكسب 3 معارك", target: 3, rw: { gems: 20 } },
    { id: "skills", name: "✦ استخدم 12 مهارة بأبطالك", target: 12, rw: { gold: 1500 } },
    { id: "boss", name: "☠️ اهزم زعيمًا", target: 1, rw: { tokens: 1 } }
  ];
  function dailyClaim(id) {
    var d = FX(), t = DAILY.find(function (x) { return x.id === id; });
    if (!t) return;
    if (d.daily.claimed[id]) { toast("استلمتها بالفعل"); return; }
    if ((d.daily.prog[id] || 0) < t.target) { toast("لم تكمل التحدي بعد"); return; }
    var rw = t.rw;
    SET(function (s) {
      var res = Object.assign({}, s.resources);
      if (rw.gems) res.gems = (res.gems || 0) + rw.gems;
      if (rw.gold) res.gold = (res.gold || 0) + rw.gold;
      return { resources: res };
    });
    if (rw.tokens && window.__solPlusTokens) window.__solPlusTokens(rw.tokens);
    d.daily.claimed[id] = 1;
    persist(d);
    toast("🎁 مكافأة التحدي استُلمت");
    refreshFxPanel();
  }

  /* ================= 9) تقرير المعركة الموسّع ================= */
  function reportModal() {
    var e = lastBattle || (FX().history[0] || null);
    if (!e || !e.result) { toast("لا توجد معركة حديثة — اخض معركة أولًا"); return; }
    var units = e.result.units || [], evs = e.result.events || [];
    var agg = {};
    units.forEach(function (u) { if (u.side === 0) agg[u.uid] = { name: u.name, dmg: 0, heal: 0, shield: 0, cc: 0, ults: 0, alive: null }; });
    evs.forEach(function (ev) {
      if (ev.source === undefined) return;
      var su = units.find(function (u) { return u.uid === ev.source; });
      if (!su || su.side !== 0) return;
      var a = agg[su.uid]; if (!a) return;
      if ((ev.kind === "basic" || ev.kind === "skill" || ev.kind === "ultimate") && ev.effect !== "heal" && ev.value !== undefined) a.dmg += ev.value;
      if (ev.effect === "heal" && ev.value !== undefined) a.heal += ev.value;
      if (ev.effect === "stun" || ev.effect === "freeze" || (ev.fxl && ev.fxl.some(function (q) { return q[0] === "stun"; }))) a.cc++;
      if (ev.kind === "ultimate") a.ults++;
    });
    var rows = Object.values(agg).sort(function (a, b) { return b.dmg - a.dmg; });
    var maxD = Math.max.apply(null, rows.map(function (r) { return r.dmg; }).concat([1]));
    var survivors = units.filter(function (u) { return u.side === 0; }).length;
    var h = '<div class="fx-mtitle">📊 تقرير المعركة — ' + esc(e.title) + '</div>';
    h += '<div class="fx-note">' + (e.victory === true ? "🏆 نصر حاسم" : e.victory === false ? "💀 هزيمة" : "… لم تُحسم") +
      ' • المدة: ' + (e.result.duration || 0).toFixed(1) + ' ث • البقاء: ' + survivors + '/' + units.filter(function (u) { return u.side === 0; }).length + '</div>';
    if (!evs.length) {
      h += '<div class="fx-empty">التسجيل كبير الحجم — بدون تفاصيل الأحداث (الأرقام الكاملة تظهر في المعارك القادمة)</div>';
      openModal(h);
      return;
    }
    h += '<div class="fx-list">';
    rows.forEach(function (r) {
      h += '<div class="fx-row"><div><b>' + esc(r.name) + '</b>' +
        '<div class="fx-mini-bar"><i style="width:' + Math.round(r.dmg / maxD * 100) + '%"></i></div></div>' +
        '<small style="text-align:end;line-height:1.5">ضرر <b class="fx-c-red">' + fmt(r.dmg) + '</b>' +
        (r.heal ? ' • شفاء <b class="fx-c-grn">' + fmt(r.heal) + '</b>' : '') +
        (r.cc ? ' • تجشئة <b class="fx-c-blu">' + r.cc + '</b>' : '') +
        (r.ults ? ' • نهائيات <b class="fx-c-gold">' + r.ults + '</b>' : '') + '</small></div>';
    });
    h += '</div>';
    var ultList = evs.filter(function (ev) { return ev.kind === "ultimate" && ev.skillName; }).slice(0, 8);
    if (ultList.length) {
      h += '<div class="fx-sub">لحظات نهائية بارزة</div><div class="fx-list">';
      ultList.forEach(function (ev) {
        var su = units.find(function (u) { return u.uid === ev.source; });
        h += '<div class="fx-row"><small>' + esc(su ? su.name : "؟") + ' ✦ ' + esc(ev.skillName) + ' — عند ' + (ev.t || 0).toFixed(1) + ' ث</small></div>';
      });
      h += '</div>';
    }
    openModal(h);
  }

  /* ================= 10) مدير الفريق ================= */
  function teamModal() {
    var g = G(); if (!g) return;
    var ids = Object.keys(g.heroes);
    function row(id) {
      var def = (window.__solHeroes && window.__solHeroes[id]) || { name: id, faction: "abyss", role: "dps" };
      var inTeam = g.team.indexOf(id) >= 0;
      return '<div class="fx-row' + (inTeam ? " sel" : "") + '"><div><b>' + esc(def.name || id) + '</b>' +
        '<small>مستوى ' + g.heroes[id].level + ' • ' + (g.heroes[id].stars || 1) + '★ • قوة ' + fmt(heroPower(id)) + '</small></div>' +
        '<button class="fx-btn' + (inTeam ? " red" : "") + '" data-fx="fx-team-toggle" data-arg="' + id + '">' + (inTeam ? "إخراج" : "إضافة") + '</button></div>';
    }
    var inRows = "", outRows = "";
    ids.forEach(function (id) {
      if (g.team.indexOf(id) >= 0) inRows += row(id); else outRows += row(id);
    });
    var h = '<div class="fx-mtitle">👥 مدير الفريق السريع</div>' +
      '<div class="fx-note">فريقك (' + g.team.length + '/5) — بضغطة واحدة إضافة أو إخراج، أو اترك اللعبة تبني أقوى فريق</div>' +
      '<div class="fx-sub">في الفريق</div><div class="fx-list">' + (inRows || '<div class="fx-empty">فارغ</div>') + '</div>' +
      '<div class="fx-sub">على الدكة</div><div class="fx-list" style="max-height:240px">' + (outRows || '<div class="fx-empty">كل أبطالك في الفريق</div>') + '</div>' +
      '<button class="fx-btn gold" style="margin-top:8px" data-fx="fx-team-auto">⚡ بناء أقوى فريق تلقائيًا</button>';
    openModal(h);
  }
  function teamToggle(id) {
    var g = G();
    if (!g || !g.heroes[id]) return;
    var team = (g.team || []).slice();
    var ix = team.indexOf(id);
    if (ix >= 0) {
      if (team.length <= 1) { toast("الفريق لا يبقى فارغًا"); return; }
      team.splice(ix, 1);
      toast("أُخرج من الفريق");
    } else {
      if (team.length >= 5) { toast("الفريق خماسي — أخرج بطلًا أولًا"); return; }
      team.push(id);
      toast("أُضيف إلى الفريق");
    }
    SET(function (s) { return { team: team }; });
    teamModal();
  }
  function teamAuto() {
    var g = G(); if (!g) return;
    var ids = Object.keys(g.heroes).map(function (id) { return { id: id, p: heroPower(id) }; });
    ids.sort(function (a, b) { return b.p - a.p; });
    var team = ids.slice(0, 5).map(function (x) { return x.id; });
    SET(function (s) { return { team: team }; });
    toast("تم بناء أقوى فريق (" + fmt(team.reduce(function (t, id) { return t + heroPower(id); }, 0)) + " قوة)");
    teamModal();
  }

  /* ================= التبويب ================= */
  window.SOLFXTAB = function () {
    var d = FX(), g = G();
    var tp = teamPower();
    var doneCount = DAILY.filter(function (t) { return d.daily.claimed[t.id]; }).length;
    var html = '<div style="display:flex;justify-content:space-between;align-items:center"><b style="font:900 15px Cairo;color:#fde68a">🧩 الإضافات — عشر ميزات جديدة</b>' +
      '<span style="font:700 9.5px Cairo;color:rgba(255,234,176,.55)">قوة فريقك: ' + fmt(tp) + '</span></div>';
    html += '<div style="margin-top:8px;display:grid;grid-template-columns:1fr 1fr;gap:6px">';
    var CARDS = [
      ["fx-team", "👥", "مدير الفريق", "إضافة/إخراج بضغطة + أقوى فريق تلقائيًا"],
      ["fx-history", "📜", "سجل المعارك", "أعد مشاهدة آخر " + d.history.length + " معارك"],
      ["fx-train", "🎯", "ساحة التدريب", "تجربة مجانية بلا طاقة ولا خسارة"],
      ["fx-cmp", "⚖️", "مقارنة المعدات", "معاينة قوة كل قطعة قبل تجهيزها"],
      ["fx-report", "📊", "تقرير المعركة", "ضرر وشفاء وتجشئة ونهائيات"],
      ["fx-exchange", "💱", "بورصة الرمال", "حوّل الذهب الفائض — حد يومي"],
      ["fx-backup", "💾", "نسخة احتياطية", "صدّر واستورد تقدمك بملف أو رمز"],
      ["fx-gauge-hint", "📈", "مؤشر القوة", "يظهر تلقائيًا قبل كل معركة"]
    ];
    CARDS.forEach(function (c) {
      html += '<button class="fx-cardbtn" data-fx="' + c[0] + '"><span class="ic">' + c[1] + '</span><b>' + c[2] + '</b><small>' + c[3] + '</small></button>';
    });
    html += '</div>';
    html += '<div class="fx-daily"><div class="fx-daily-h">🗓️ تحديات الرمال — اليوم <span>' + doneCount + '/' + DAILY.length + ' مستلمة</span></div>';
    DAILY.forEach(function (t) {
      var p = Math.min(t.target, d.daily.prog[t.id] || 0);
      var claimed = d.daily.claimed[t.id];
      html += '<div class="fx-daily-row"><span>' + t.name + '</span>' +
        '<div class="fx-mini-bar"><i style="width:' + Math.round(p / t.target * 100) + '%"></i></div>' +
        (claimed ? '<b class="ok">✔ استلمت</b>' : '<button class="fx-btn tiny' + (p >= t.target ? " gold" : " dim") + '" data-fx="fx-daily" data-arg="' + t.id + '">' + p + '/' + t.target + ' 🎁</button>') +
        '</div>';
    });
    html += '</div>';
    return html;
  };
  function refreshFxPanel() {
    var ps = document.querySelectorAll(".sp-panel.sp-ui:not(#sp-forge-host),#sp-summon-fx-host");
    Array.prototype.forEach.call(ps, function (p) {
      if (!p) return;
      if (p.id === "sp-summon-fx-host" || (p.innerHTML && p.innerHTML.indexOf("الإضافات") >= 0)) p.innerHTML = window.SOLFXTAB();
    });
  }

  /* ================= التوجيه ================= */
  var ACT_FX = {
    "fx-close": closeModal,
    "fx-history": historyModal,
    "fx-replay": function (b, arg) { replay(arg); },
    "fx-train": function () { trainingModal(); },
    "fx-train-go": function (b, arg) { startTraining(arg); },
    "fx-exchange": function () { exchangeModal(); },
    "fx-exchange-do": function (b, arg) { exchangeDo(arg); },
    "fx-cmp": function () { compareModal(); },
    "fx-cmp-sel": function (b, arg) { compareCtx.invIndex = +arg; renderCompare(); },
    "fx-backup": function () { backupModal(); },
    "fx-bk-dl": backupDownload,
    "fx-bk-code": backupCode,
    "fx-bk-restore": backupRestore,
    "fx-report": reportModal,
    "fx-team": function () { teamModal(); },
    "fx-team-toggle": function (b, arg) { teamToggle(arg); },
    "fx-team-auto": teamAuto,
    "fx-daily": function (b, arg) { dailyClaim(arg); },
    "fx-gauge-hint": function () {
      openModal('<div class="fx-mtitle">📈 مؤشر فجوة القوة</div>' +
        '<div class="fx-note">قبل كل معركة تظهر لوحة تقارن قوة فريقك بقوة الأعداء بمعادلة اللعبة نفسها، وتعطيك نصيحة مختصرة إن كانت الفجوة كبيرة.</div>');
    }
  };
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-fx]");
    if (b) {
      var fn = ACT_FX[b.getAttribute("data-fx")];
      if (fn) { e.preventDefault(); fn(b, b.getAttribute("data-arg")); }
      return;
    }
    /* إغلاق نافذة المقارنة بعد تجهيز رسمي */
    if (modalEl && e.target.closest('[data-sp="forge-equip-hero"]')) {
      setTimeout(closeModal, 350);
    }
    if (modalEl && b && b.getAttribute && String(b.getAttribute("data-fx") || "").indexOf("fx-exchange-do") === 0) {
      /* handled above */
    }
  }, true);

  /* تهيئة DOM بعد الجاهزية */
  function init() {
    /* تفعيل خطافات القوة مبكرًا (اللعبة تُعرّفها عند أول قتال) */
    try {
      if (window.__solFightMode && !window.__solPower) {
        window.__solFightMode("_fx-boot", 1, { enemies: [] });
      }
    } catch (e) {}
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();

