
(function(){
  'use strict';
  if (window.__SOL_MOUNT_WHEEL__) return;
  window.__SOL_MOUNT_WHEEL__ = true;
  var style = document.createElement('style');
  style.textContent = `
  .sol-mount-wheel-panel{direction:rtl;margin:10px;padding:12px;border:1px solid #b88c3b88;border-radius:16px;background:linear-gradient(160deg,#2b1d10,#120d08);color:#f8e6b4;box-shadow:0 8px 24px #0008}
  .sol-mount-wheel-head{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
  .sol-mount-wheel-title{font:900 14px Cairo, sans-serif;color:#ffe19a}
  .sol-mount-wheel-select{max-width:100%;background:#170f08;color:#ffe9b0;border:1px solid #b88c3b88;border-radius:9px;padding:7px;font:700 11px Cairo}
  .sol-mount-wheel-wrap{position:relative;width:min(100%,310px);aspect-ratio:1;margin:12px auto 6px;border-radius:50%;background:radial-gradient(circle,#51371955 0 24%,#2b1b0b88 25% 54%,#b88c3b22 55% 57%,transparent 58%);border:2px solid #b88c3b66;box-shadow:inset 0 0 28px #0009,0 0 20px #b88c3b22}
  .sol-mount-wheel-center{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:88px;height:88px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;background:radial-gradient(circle at 35% 25%,#795525,#251607 72%);border:2px solid #d8ad55;box-shadow:0 0 16px #d8ad5544;font:800 10px Cairo;pointer-events:none}
  .sol-mount-wheel-center b{font-size:25px;line-height:1.1}
  .sol-mount-wheel-item{position:absolute;left:50%;top:50%;width:64px;height:64px;margin:-32px 0 0 -32px;border-radius:50%;border:1px solid #a77c38;background:linear-gradient(145deg,#4b3218,#1b1209);color:#f8e6b4;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;box-shadow:0 3px 10px #0009;cursor:pointer;padding:3px;transform:translate(var(--x),var(--y));font-family:Cairo;touch-action:manipulation}
  .sol-mount-wheel-item span:first-child{font-size:22px;line-height:1.1}.sol-mount-wheel-item small{font-size:8px;line-height:1.1;max-width:58px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .sol-mount-wheel-item.active{border:2px solid #ffe08a;background:linear-gradient(145deg,#876025,#39230d);box-shadow:0 0 0 3px #f7d16b33,0 0 18px #e8b74b66}
  .sol-mount-slot{display:flex;align-items:center;gap:10px;padding:9px 11px;border:1px solid #c49a4a77;border-radius:12px;background:#120c07aa;margin-top:8px}
  .sol-mount-slot-icon{width:48px;height:48px;border-radius:10px;display:grid;place-items:center;font-size:27px;background:linear-gradient(145deg,#503617,#1c1209);border:1px solid #c49a4a}
  .sol-mount-slot-info{flex:1;min-width:0}.sol-mount-slot-info b{display:block;color:#ffe5a3;font:900 12px Cairo}.sol-mount-slot-info small{display:block;color:#cbb78f;font:10px Cairo}
  .sol-mount-wheel-hint{text-align:center;color:#bca77e;font:10px Cairo;margin-top:6px}
  @media(max-width:380px){.sol-mount-wheel-wrap{width:280px}.sol-mount-wheel-item{width:58px;height:58px;margin:-29px 0 0 -29px}.sol-mount-wheel-item span:first-child{font-size:20px}}
  `;
  document.head.appendChild(style);
  function heroList(){
    var H=window.__solHeroes||{}, out=[];
    Object.keys(H).forEach(function(k){var h=H[k];if(!h||!h.name||String(h.name).indexOf('·')>=0)return;if(!out.some(function(x){return x.name===h.name}))out.push({id:k,name:h.name,faction:h.faction});});
    return out;
  }
  function makePanel(host){
    if(!host||host.querySelector('.sol-mount-wheel-panel')||!window.SOLMNT||!window.SOLMNT.ok)return;
    var heroes=heroList(), defs=window.SOLMNT.defs||[];
    if(!heroes.length||!defs.length)return;
    var panel=document.createElement('section');panel.className='sol-mount-wheel-panel';
    panel.innerHTML='<div class="sol-mount-wheel-head"><div class="sol-mount-wheel-title">🐎 دائرة المطايا الكاملة</div><select class="sol-mount-wheel-select" aria-label="اختر البطل"></select></div><div class="sol-mount-slot"><div class="sol-mount-slot-icon">🐎</div><div class="sol-mount-slot-info"><b>خانة المطية الإضافية</b><small>اختر مطية من الدائرة لتركيبها على البطل المحدد</small></div></div><div class="sol-mount-wheel-wrap"><div class="sol-mount-wheel-center"><b>🐎</b><span>مطية البطل</span></div></div><div class="sol-mount-wheel-hint">اضغط على أي مطية حول الدائرة لتجهيزها فورًا</div>';
    var sel=panel.querySelector('select'), wheel=panel.querySelector('.sol-mount-wheel-wrap'), slotIcon=panel.querySelector('.sol-mount-slot-icon'), slotInfo=panel.querySelector('.sol-mount-slot-info');
    heroes.forEach(function(h){var o=document.createElement('option');o.value=h.name;o.textContent=h.name;sel.appendChild(o);});
    var game=window.__solGet&&window.__solGet(), team=game&&game.team||[];
    if(team.length){var first=heroes.find(function(h){return h.id===team[0]});if(first)sel.value=first.name;}
    function refresh(){
      var hero=sel.value, current=window.SOLMNT.currentId(hero), def=window.SOLMNT.byId(current)||{icon:'—',name:'بدون مطية'};
      wheel.querySelectorAll('.sol-mount-wheel-item').forEach(function(b){b.classList.toggle('active',b.getAttribute('data-id')===current);});
      slotIcon.textContent=def.icon||'🐎';
      slotInfo.innerHTML='<b>المطية المركّبة: '+def.name+'</b><small>مخصصة للبطل: '+hero+' • تُحفظ تلقائيًا</small>';
    }
    defs.forEach(function(d,i){
      var angle=(-Math.PI/2)+(i/defs.length)*Math.PI*2, radius=104;
      var b=document.createElement('button');b.type='button';b.className='sol-mount-wheel-item';b.style.setProperty('--x',(Math.cos(angle)*radius)+'px');b.style.setProperty('--y',(Math.sin(angle)*radius)+'px');b.setAttribute('data-id',d.id);b.title=d.name;
      b.innerHTML='<span>'+String(d.icon||'🐎')+'</span><small>'+String(d.name||'مطية')+'</small>';
      b.addEventListener('click',function(){var hero=sel.value;if(!hero)return;if(window.SOLMNT.set(hero,d.id)){refresh();try{window.dispatchEvent(new CustomEvent('sol:mount-equipped',{detail:{hero:hero,mount:d.id}}));}catch(e){}}});
      wheel.appendChild(b);
    });
    sel.addEventListener('change',refresh);host.insertBefore(panel,host.firstChild);refresh();
  }
  function scan(){var host=document.getElementById('sp-summon-mounts-host');if(host&&host.offsetParent!==null)makePanel(host);}
  var obs=new MutationObserver(scan);obs.observe(document.documentElement,{childList:true,subtree:true});
  document.addEventListener('click',function(e){var t=e.target;if(t&&t.closest&&t.closest('[data-sp]'))setTimeout(scan,120);});
  scan();setTimeout(scan,500);setTimeout(scan,1600);setTimeout(scan,3500);
})();

