# Sands of Legends - split build

index.html loads css/ and js/ files in the same order as the original single file
(the numeric prefix = original order, do not reorder).

Key files:
- js/20-sol3d-battle-engine.js : 3D battle engine
- js/21-solbtx-battle-style.js : battle style layer
- js/28-sol-plus-systems.js    : game systems
- js/17-solfbx-models.js       : embedded character models (large)
- js/13-kgear-data.js          : embedded gear meshes (large)
- css/11-battle3d.css, css/12-features.css : battle + features styles

Note: index.html references ./assets/kaykit-runtime.js (same as the original);
that file was not in the upload, so add it under assets/ if the game needs it.
